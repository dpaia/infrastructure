"""Factory functions for creating SWE-Bench evaluator configurations.

This module provides factory functions for creating evaluators with
dependency injection. All dependencies must be provided via constructor.

Use DI containers (like JvmSweContainer) to create evaluators automatically.
"""

from typing import List

from ee_bench_core.adapters.eval import TestRunnerEvaluator, PatchApplierEvaluator
from ee_bench_core.core import EvaluatorDependency, DependencyPosition
from .eval import (
    PredictionEvaluator
)


# ============================================================================
# Pipeline Factories (with dependency injection)
# ============================================================================

def create_standard_swe_pipeline(
    test_runner,
    patch_adapter,
    predictions_provider
) -> List:
    """Create standard SWE-Bench evaluation pipeline with dependency injection.

    This factory creates evaluators with pre-configured dependencies injected
    via constructor. All dependencies are REQUIRED.

    Pipeline stages:
    1. Baseline evaluation (all tests should pass)
    2. Test patch application (apply test patch)
    3. Fail-to-pass validation (fail_to_pass tests should fail)
    4. Prediction application (apply AI/agent patch)
    5. Fail-to-pass checking (fail_to_pass should now pass)
    6. Pass-to-pass checking (pass_to_pass should still pass)

    Args:
        test_runner: Pre-configured TestRunner (MavenTestRunner/GradleTestRunner
            with correct ProcessManager injected)
        patch_adapter: Pre-configured PatchAdapter (with correct ProcessManager injected)
        predictions_provider: PredictionsProvider (GoldPredictionsProvider
            or JsonPredictionsProvider)

    Returns:
        List of evaluators with injected dependencies

    Example:
        >>> # From DI container
        >>> container = JvmSweContainer.create_for_evaluation(...)
        >>> test_runner = container.test_runner()
        >>> patch_adapter = container.patch_adapter()
        >>> predictions_provider = container.predictions_provider()
        >>>
        >>> # Create pipeline with injected dependencies
        >>> evaluators = create_standard_swe_pipeline(
        ...     test_runner=test_runner,
        ...     patch_adapter=patch_adapter,
        ...     predictions_provider=predictions_provider
        ... )

    Note:
        Prefer using container.evaluators() directly instead of calling
        this factory manually. The container handles all dependency injection
        automatically.
    """
    # Create evaluators with injected dependencies
    evaluators = [
        TestRunnerEvaluator(
            name="baseline_evaluation",
            test_getter=lambda config, context: config.pass_to_pass,
            expect_pass=True,
            dependencies=EvaluatorDependency(position=DependencyPosition.FIRST),
            is_terminal=True,
            description="Run baseline tests to verify initial state",
            test_runner=test_runner
        ),
        PatchApplierEvaluator(
            name="test_patch_application",
            patch_getter=lambda config, context: config.test_patch,
            dependencies=EvaluatorDependency(after=["baseline_evaluation"]),
            is_terminal=True,
            description="Apply test patch from dataset",
            patch_adapter=patch_adapter  # Pass through injected dependency
        ),
        TestRunnerEvaluator(
            name="fail_to_pass_validation",
            test_getter=lambda config, context: config.fail_to_pass,
            expect_pass=False,  # Tests should fail
            dependencies=EvaluatorDependency(after=["test_patch_application"]),
            is_terminal=True,
            description="Validate fail_to_pass tests fail with test patch",
            test_runner=test_runner  # Pass through injected dependency
        ),
        PredictionEvaluator(
            name="prediction_application",
            patch_adapter=patch_adapter,
            predictions_provider=predictions_provider,
            dependencies=EvaluatorDependency(after=["fail_to_pass_validation"]),
            is_terminal=True,
            description="Apply prediction patch from AI/agent",
        ),
        TestRunnerEvaluator(
            name="all_tests_validation",
            test_getter=lambda config, context: config.fail_to_pass + config.pass_to_pass,
            expect_pass=True,  # Tests should pass
            dependencies=EvaluatorDependency(after=["prediction_application"]),
            is_terminal=True,
            description="Verify all tests now pass after prediction",
            test_runner=test_runner  # Pass through injected dependency
        )
    ]

    return evaluators


def create_minimal_swe_pipeline(
    test_runner,
    patch_adapter,
    predictions_provider
) -> List:
    """Create minimal SWE-Bench evaluation pipeline with dependency injection.

    This factory creates evaluators with pre-configured dependencies injected
    via constructor. All dependencies are REQUIRED.

    Pipeline stages:
    1. Prediction application (apply AI/agent patch)
    2. Fail-to-pass checking (fail_to_pass should pass)
    3. Pass-to-pass checking (pass_to_pass should pass)

    Args:
        test_runner: Pre-configured TestRunner
        patch_adapter: Pre-configured PatchAdapter
        predictions_provider: PredictionsProvider

    Returns:
        List of evaluators with injected dependencies
    """
    return [
        PredictionEvaluator(
            name="prediction_application",
            patch_adapter=patch_adapter,
            predictions_provider=predictions_provider,
            dependencies=EvaluatorDependency(position=DependencyPosition.FIRST),
            is_terminal=True,
            description="Apply prediction patch from AI/agent",
        ),
        TestRunnerEvaluator(
            name="all_tests_validation",
            test_getter=lambda config, context: config.fail_to_pass + config.pass_to_pass,
            expect_pass=True,  # Tests should pass
            dependencies=EvaluatorDependency(after=["prediction_application"]),
            is_terminal=True,
            description="Verify all tests now pass after prediction",
            test_runner=test_runner  # Pass through injected dependency
        )
    ]