"""Show command — display provider plugin names."""

from __future__ import annotations

import click

from ee_bench.generator import load_provider
from ee_bench.generator.errors import PluginNotFoundError

from ee_bench.cli.cli import pass_context


@click.command()
@click.argument("name")
@pass_context
def show(ctx, name: str) -> None:
    """Show that a provider plugin exists and can be loaded.

    Examples:

        ee-dataset show huggingface_dataset
    """
    try:
        load_provider(name)
        click.echo(f"Provider '{name}' is installed and loadable.")
    except PluginNotFoundError:
        raise click.ClickException(
            f"Provider '{name}' not found. "
            f"Use 'ee-dataset list' to see available providers."
        )
