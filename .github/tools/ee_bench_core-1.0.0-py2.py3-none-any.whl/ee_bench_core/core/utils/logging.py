"""Logging utilities with environment-aware formatting."""

import logging
import os
import re
from pathlib import Path
from typing import Optional

# Global variable to store current command context
_current_command: Optional[str] = None


def set_command_context(command_name: str) -> None:
    """Set the current command context for logging.

    Args:
        command_name: Name of the command being executed
    """
    global _current_command
    _current_command = command_name


def get_command_context() -> str:
    """Get the current command context, with fallback.

    Returns:
        Command context string (e.g., "ee-bench prepare-environment")
    """
    global _current_command
    if _current_command:
        return f"ee-bench {_current_command}"
    return "ee-bench"


class ColorAwareFormatter(logging.Formatter):
    """Custom formatter that handles colors properly and separates system parts from messages."""

    # ANSI color codes
    GRAY = "\033[90m"
    RESET = "\033[0m"
    BLUE = "\033[34m"  # For Docker build prefix
    LEVEL_COLORS = {
        "DEBUG": "\033[90m",  # Dark Gray (muted)
        "INFO": "\033[92m",  # Light Green (less bright than 32)
        "WARNING": "\033[93m",  # Light Yellow (less bright than 33)
        "ERROR": "\033[91m",  # Light Red (less bright than 31)
        "CRITICAL": "\033[31m",  # Red
    }

    # Pattern to detect ANSI escape sequences
    ANSI_ESCAPE = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")

    def __init__(self, log_context: str = "host"):
        """Initialize color-aware formatter.

        Args:
            log_context: Context where logging occurs (host or container)
        """
        self.log_context = log_context
        if log_context == "container":
            super().__init__("[COMMAND] - %(message)s")
        else:
            super().__init__("[%(asctime)s] - %(message)s")

    def format(self, record: logging.LogRecord) -> str:
        """Format log record with color and context awareness.

        Args:
            record: Log record to format

        Returns:
            Formatted log message string
        """
        # Get the basic formatted message
        formatted = super().format(record)

        if self.log_context == "container":
            return self._format_container(formatted, record)
        else:
            return self._format_host(formatted, record)

    def _colorize_docker_prefix(self, message: str) -> str:
        """Add color to Docker build prefixes in messages.

        Args:
            message: Log message

        Returns:
            Message with colored Docker prefix
        """
        # Pattern to match "Docker build:" or "Docker build error:" at start of message
        if message.startswith("Docker build"):
            if message.startswith("Docker build error:"):
                # Keep error prefix red, but colorize "Docker build" part
                return f"{self.BLUE}Docker build{self.RESET} error:{message[19:]}"
            elif message.startswith("Docker build:"):
                # Colorize the "Docker build:" prefix
                return f"{self.BLUE}Docker build:{self.RESET}{message[13:]}"
        return message

    def _format_container(self, formatted: str, record: logging.LogRecord) -> str:
        """Format for container environment.

        Args:
            formatted: Pre-formatted message
            record: Log record

        Returns:
            Formatted message for container
        """
        level_color = self.LEVEL_COLORS.get(record.levelname, "")

        # Split into system and message parts
        parts = formatted.split(" - ", 1)
        if len(parts) >= 2:
            command_context = get_command_context()
            # Color only the brackets, not the command name
            command_part = (
                f"{level_color}[{self.RESET}{command_context}{level_color}]{self.RESET}"
            )
            message_part = parts[1]  # actual message

            # Colorize Docker prefixes
            message_part = self._colorize_docker_prefix(message_part)

            return f"{command_part} - {message_part}"

        return formatted

    def _format_host(self, formatted: str, record: logging.LogRecord) -> str:
        """Format for host environment with colored timestamp brackets.

        Args:
            formatted: Pre-formatted message
            record: Log record

        Returns:
            Formatted message for host
        """
        level_color = self.LEVEL_COLORS.get(record.levelname, "")

        # Split into system and message parts
        parts = formatted.split(" - ", 1)
        if len(parts) >= 2:
            timestamp_brackets = parts[0]  # [timestamp]
            message_part = parts[1]  # actual message

            # Extract timestamp from brackets [timestamp]
            if timestamp_brackets.startswith("[") and timestamp_brackets.endswith("]"):
                timestamp_content = timestamp_brackets[1:-1]  # Remove brackets
                # Color brackets with level color, timestamp content with gray
                colored_timestamp = f"{level_color}[{self.RESET}{self.GRAY}{timestamp_content}{self.RESET}{level_color}]{self.RESET}"
            else:
                # Fallback if format is unexpected
                colored_timestamp = f"{level_color}{timestamp_brackets}{self.RESET}"

            # Colorize Docker prefixes
            message_part = self._colorize_docker_prefix(message_part)

            return f"{colored_timestamp} - {message_part}"

        return formatted


def setup_logging(level: str = "INFO", log_file: Optional[Path] = None) -> None:
    """Set up logging configuration with environment-aware formatting.

    Args:
        level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: Optional path to log file
    """
    # Check if we're running inside a container
    log_context = os.getenv("EE_BENCH_LOG_CONTEXT", "host")

    # Clear any existing handlers
    root_logger = logging.getLogger()
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)

    # Create console handler with custom formatter
    handler = logging.StreamHandler()
    formatter = ColorAwareFormatter(log_context)
    handler.setFormatter(formatter)

    handlers = [handler]

    # Add file handler if log_file specified
    if log_file:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(logging.Formatter("[%(asctime)s] - %(message)s"))
        handlers.append(file_handler)

    # Configure root logger
    root_logger.handlers = []
    for h in handlers:
        root_logger.addHandler(h)
    root_logger.setLevel(getattr(logging, level.upper()))

    # Ensure all loggers use our handler
    logging.basicConfig(
        level=getattr(logging, level.upper()),
        handlers=handlers,
        force=True,  # Override any existing logging configuration
    )
