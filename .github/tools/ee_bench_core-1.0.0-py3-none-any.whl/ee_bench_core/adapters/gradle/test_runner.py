"""Gradle test runner adapter.

This module provides a test runner for Gradle-based Java projects.
"""

import logging
import shlex
from pathlib import Path
from typing import Optional

from ee_bench_core.core.models import ResultStatus, EnvironmentConfig
from ee_bench_core.core.utils import set_command_context

from ..junit_parser import parse_junit_report
from ..process_manager import LocalProcessManager
from ..process_manager_base import ProcessManager
from ..testrunner_base import TestResult, TestRunner
from .module_detector import GradleModuleDetector
from .output_parser import GradleOutputParser

logger = logging.getLogger(__name__)


class GradleTestRunner(TestRunner):
    """Test runner implementation for Gradle-based projects."""

    def __init__(self, process_manager: Optional[ProcessManager] = None):
        """Initialize Gradle test runner.

        Args:
            process_manager: ProcessManager instance (LocalProcessManager if None)
        """
        self.module_detector = GradleModuleDetector()
        self.output_parser = GradleOutputParser()
        self.process_manager = process_manager or LocalProcessManager(debug_output=True)

    def _run_test(
        self,
        test_name: str,
        working_dir: Path,
        timeout: int,
        test_args: Optional[str] = None,
        env_config: Optional[EnvironmentConfig] = None,
    ) -> TestResult:
        """Run Gradle test for a specific class and return parsed TestResult.

        Args:
            test_name: Test name to execute
            working_dir: Working directory where tests should run
            timeout: Timeout in seconds for test execution
            test_args: Optional additional arguments to pass to Gradle

        Returns:
            TestResult for the test execution
        """
        set_command_context(f"run_test:gradle:{test_name}")

        gradlew_path = working_dir / "gradlew"
        if gradlew_path.exists() and gradlew_path.is_file():
            gradle_cmd = ["./gradlew"]
        else:
            gradle_cmd = ["gradle"]

        module_hint, clean_name, class_for_search = self._normalize_test_name(test_name)
        module = module_hint or self.module_detector.detect_module(
            class_for_search, working_dir
        )

        if module:
            logger.debug(f"Detected module for {test_name}: {module}")
        else:
            logger.debug(f"No module detected for {test_name}, running from repo root")

        # Derive task name for module if provided
        task = "test"
        if module and module != ".":
            module_task = self._task_with_module(module, "test")
            task = module_task

        cmd = list(gradle_cmd)
        cmd.append(task)
        cmd.append("--no-daemon")
        cmd.append("--info")
        cmd.append("--build-cache")
        cmd.append("-Dtest.report.junitXml.required=true")

        if test_args:
            cmd.extend(shlex.split(test_args))

        cmd.extend(["--tests", clean_name])

        logger.info(f"Running Gradle command: {' '.join(cmd)}")

        # Execute command using ProcessManager
        result = self.process_manager.run_command(
            cmd=cmd,
            cwd=working_dir,
            timeout=timeout,
            log_prefix="     ",
            env_config=env_config,
        )

        # Handle timeout
        if result.timed_out:
            logger.error(f"Gradle test timed out after {timeout} seconds")
            timeout_result = TestResult(
                execution_time=result.duration, raw_output=result.stdout + result.stderr
            )
            timeout_result.add_test(
                test_name=test_name,
                status=ResultStatus.FAILED,
                reason=f"Gradle test timed out after {timeout} seconds",
                details=[f"Gradle test timed out after {timeout} seconds"],
            )
            return timeout_result

        combined = result.stdout + result.stderr
        duration = result.duration
        ret = result.returncode

        # Parse Gradle output (prefer JUnit XML, fall back to stdout)
        parsed = self._parse_output(
            working_dir, combined, duration, module, class_for_search
        )

        success = ret == 0

        # Update parsed result's success based on return code
        parsed.success = success
        parsed.execution_time = duration
        parsed.raw_output = combined

        return parsed

    @staticmethod
    def _task_with_module(module: Optional[str], task: str) -> str:
        """Construct a Gradle task path for a module, e.g., :app:sub:test.

        Args:
            module: Module path using '/' separators or '.' for root
            task: Task name, such as 'test'

        Returns:
            A Gradle-qualified task string
        """
        return ":" + ":".join(module.split("/")) + ":" + task

    def _parse_output(
        self,
        working_dir: Path,
        stdout: str,
        execution_time: float,
        module: Optional[str],
        class_fqn: str,
    ) -> TestResult:
        """Parse Gradle output, preferring JUnit XML.

        Args:
            working_dir: Project root directory
            stdout: Gradle stdout output
            execution_time: Execution time in seconds
            module: Module path or None
            class_fqn: Fully qualified class name

        Returns:
            TestResult from parsing
        """
        base = working_dir
        if module and module != ".":
            base = base / module

        for reports_dir in [base / "build" / "test-results" / "test"]:
            try:
                xml_result = parse_junit_report(reports_dir, class_fqn)
            except Exception as e:
                from core.utils import trace_error

                logger.debug(trace_error(e))
                xml_result = None

            if xml_result is not None:
                if not xml_result.execution_time:
                    xml_result.execution_time = execution_time
                return xml_result
            else:
                return self.output_parser.parse(stdout, class_fqn, execution_time)

        fallback_result = TestResult(execution_time=execution_time, raw_output=stdout)
        fallback_result.add_test(
            test_name=class_fqn,
            status=ResultStatus.FAILED,
            reason="No test results found",
            details=[],
        )
        return fallback_result
