"""Specification registry for managing evaluation specs.

This module provides the registry system for discovering, registering,
and retrieving evaluation specifications with plugin support.
"""

import importlib
import logging
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Type

from .abc_types import EvalSpec
from .config import get_config
from .errors import SpecNotFoundError

logger = logging.getLogger(__name__)


@dataclass
class SpecMetadata:
    """Metadata about a registered specification.

    Attributes:
        name: Canonical name of the spec
        spec_instance: The instantiated spec object
        source: Source of registration ("builtin", "entry_point", "config", "api")
        version: Spec version string (from spec.version property)
        author: Spec author (from spec.author property)
        homepage: Spec homepage URL (from spec.homepage property)
        enabled: Whether the spec is enabled
        package_name: Package name (for entry point specs)
        entry_point_name: Entry point name (for entry point specs)
        aliases: List of aliases for this spec
    """

    name: str
    spec_instance: EvalSpec
    source: str
    version: Optional[str] = None
    author: Optional[str] = None
    homepage: Optional[str] = None
    enabled: bool = True
    package_name: Optional[str] = None
    entry_point_name: Optional[str] = None
    aliases: List[str] = field(default_factory=list)


class EvalSpecRegistry:
    """Registry for managing evaluation specifications with plugin support.

    This class maintains a registry of all available evaluation specifications
    and provides methods for registration, retrieval, and discovery from multiple sources.
    """

    def __init__(self):
        """Initialize an empty registry."""
        self._specs: Dict[str, SpecMetadata] = {}  # name -> SpecMetadata
        self._aliases: Dict[str, str] = {}  # alias -> canonical name
        self._lazy_specs: Dict[str, str] = {}  # name -> "module:class" for lazy loading

    def register(
        self, spec_class: Type[EvalSpec], source: str = "api"
    ) -> Type[EvalSpec]:
        """Register a specification class.

        This method can be used as a decorator:

            @registry.register
            class MySpec(EvalSpec):
                ...

        Args:
            spec_class: The spec class to register (must inherit from EvalSpec)
            source: Source of registration ("builtin", "entry_point", "config", "api")

        Returns:
            The spec class unchanged (for decorator usage)

        Raises:
            TypeError: If spec_class doesn't implement EvalSpec protocol
        """
        # Check if it implements the EvalSpec protocol
        # We can't always use issubclass due to potential module path issues with dynamic imports
        if not (
            hasattr(spec_class, "name")
            and hasattr(spec_class, "description")
            and hasattr(spec_class, "run_evaluation")
        ):
            raise TypeError(
                f"{spec_class.__name__} must implement the EvalSpec protocol"
            )

        # Instantiate the spec to get its name
        try:
            spec_instance = spec_class()
        except Exception as e:
            logger.error(f"Failed to instantiate spec {spec_class.__name__}: {e}")
            raise

        spec_name = spec_instance.name

        # Check if spec is disabled in configuration
        config = get_config()
        is_enabled = config.is_spec_enabled(spec_name)

        if not is_enabled:
            logger.info(f"Spec '{spec_name}' is disabled in configuration, skipping registration")
            return spec_class

        # Check for duplicate registration
        if spec_name in self._specs:
            existing_metadata = self._specs[spec_name]
            # Skip re-registration if it's the same class
            if existing_metadata.spec_instance.__class__ == spec_class:
                logger.debug(
                    f"Spec '{spec_name}' is already registered from {existing_metadata.source}. "
                    f"Skipping duplicate registration from {source}."
                )
                return spec_class
            # Different class - warn and overwrite
            logger.warning(
                f"Spec '{spec_name}' is already registered "
                f"({existing_metadata.spec_instance.__class__.__name__}). "
                f"Overwriting with {spec_class.__name__}."
            )

        # Create metadata
        metadata = SpecMetadata(
            name=spec_name,
            spec_instance=spec_instance,
            source=source,
            version=getattr(spec_instance, "version", None),
            author=getattr(spec_instance, "author", None),
            homepage=getattr(spec_instance, "homepage", None),
            enabled=is_enabled,
        )

        # Register the metadata
        self._specs[spec_name] = metadata
        logger.debug(
            f"Registered spec: {spec_name} ({spec_class.__name__}) from {source}"
        )

        return spec_class

    def register_lazy(
        self,
        spec_path: str,
        name: Optional[str] = None,
        source: str = "config",
        **metadata_kwargs,
    ) -> None:
        """Register a spec for lazy loading without loading it immediately.

        The spec will be loaded on first access via get().

        Args:
            spec_path: Spec path in format "module.path:ClassName"
            name: Optional custom name (if None, will use spec's name property on load)
            source: Source of registration
            **metadata_kwargs: Additional metadata fields (enabled, author, etc.)

        Example:
            registry.register_lazy("my_package.spec:MySpec", source="config")
            spec = registry.get("my-spec")  # Auto-loads here
        """
        # Store for lazy loading
        lazy_name = name or spec_path.split(":")[-1].lower()
        self._lazy_specs[lazy_name] = spec_path
        logger.debug(f"Lazy registered spec: {lazy_name} from {spec_path}")

    def _load_spec_from_path(self, spec_path: str) -> Type[EvalSpec]:
        """Load a spec class from module:class path.

        Args:
            spec_path: String in format "module.path:ClassName"

        Returns:
            Loaded spec class

        Raises:
            ImportError: If module cannot be imported
            AttributeError: If class not found in module
            TypeError: If loaded class is not an EvalSpec
        """
        try:
            module_path, class_name = spec_path.rsplit(":", 1)
            module = importlib.import_module(module_path)
            spec_class = getattr(module, class_name)

            # Verify it's an EvalSpec by checking for required attributes/methods
            # We can't use issubclass due to potential module path issues with dynamic imports
            if not (
                hasattr(spec_class, "name")
                and hasattr(spec_class, "description")
                and hasattr(spec_class, "run_evaluation")
            ):
                raise TypeError(f"{spec_path} does not implement the EvalSpec protocol")

            return spec_class

        except ValueError as e:
            raise ValueError(
                f"Invalid spec_path format: {spec_path}. "
                f"Expected 'module.path:ClassName'"
            ) from e
        except Exception as e:
            logger.error(f"Failed to load spec from {spec_path}: {e}")
            raise

    def get(self, spec_name: str) -> EvalSpec:
        """Retrieve a registered specification by name.

        Supports lazy loading: if spec wasn't loaded yet, loads it now.

        Args:
            spec_name: Name or alias of the specification

        Returns:
            EvalSpec instance for the requested specification

        Raises:
            SpecNotFoundError: If the specification is not registered or disabled
        """
        # Check if it's an alias first
        canonical_name = self._aliases.get(spec_name, spec_name)

        # Try loaded specs first
        if canonical_name in self._specs:
            metadata = self._specs[canonical_name]

            # Check if disabled
            if not metadata.enabled:
                raise SpecNotFoundError(
                    f"Specification '{spec_name}' is disabled. "
                    f"Enable it with registry.enable('{canonical_name}')"
                )

            return metadata.spec_instance

        # Try lazy-loaded specs
        if canonical_name in self._lazy_specs:
            logger.info(f"Lazy-loading spec: {canonical_name}")
            spec_path = self._lazy_specs[canonical_name]

            try:
                # Load the spec class
                spec_class = self._load_spec_from_path(spec_path)

                # Register it normally
                self.register(spec_class, source="lazy")

                # Get the actual spec name after registration
                spec_instance = spec_class()
                actual_spec_name = spec_instance.name

                # Remove from lazy registry
                del self._lazy_specs[canonical_name]

                # If the lazy name is different from actual name, add an alias
                if canonical_name != actual_spec_name:
                    self._aliases[canonical_name] = actual_spec_name
                    logger.debug(
                        f"Created alias: {canonical_name} -> {actual_spec_name}"
                    )

                # Return the loaded spec
                if actual_spec_name in self._specs:
                    metadata = self._specs[actual_spec_name]
                    if not metadata.enabled:
                        raise SpecNotFoundError(
                            f"Specification '{spec_name}' is disabled. "
                            f"Enable it with registry.enable('{actual_spec_name}')"
                        )
                    return metadata.spec_instance

                # Fallback: try getting by canonical name
                return self.get(canonical_name)

            except Exception as e:
                logger.error(f"Failed to lazy-load spec '{canonical_name}': {e}")
                raise SpecNotFoundError(
                    f"Failed to load spec '{spec_name}' from {spec_path}: {e}"
                ) from e

        # Not found in either registry
        available = self.list_specs()
        raise SpecNotFoundError(
            f"Specification '{spec_name}' not found. "
            f"Available specs: {', '.join(available) if available else 'none'}"
        )

    def list_specs(self, include_lazy: bool = True) -> List[str]:
        """List all registered specification names.

        Args:
            include_lazy: Whether to include lazy-loaded specs (not yet loaded)

        Returns:
            Sorted list of registered spec names
        """
        specs = set(self._specs.keys())

        if include_lazy:
            specs.update(self._lazy_specs.keys())

        return sorted(specs)

    def get_info(self, spec_name: str) -> Dict[str, str]:
        """Get information about a registered specification.

        Args:
            spec_name: Name or alias of the specification

        Returns:
            Dictionary with spec information

        Raises:
            SpecNotFoundError: If the specification is not registered
        """
        canonical_name = self._aliases.get(spec_name, spec_name)

        if canonical_name not in self._specs:
            raise SpecNotFoundError(f"Specification '{spec_name}' not found")

        metadata = self._specs[canonical_name]
        spec = metadata.spec_instance

        info = {
            "name": metadata.name,
            "description": spec.description,
            "version": metadata.version or "unknown",
            "author": metadata.author or "unknown",
            "homepage": metadata.homepage or "N/A",
            "source": metadata.source,
            "enabled": metadata.enabled,
            "class_name": spec.__class__.__name__,
            "framework_version_min": spec.framework_version_min or "any",
        }

        # Add entry point metadata if available
        if metadata.package_name:
            info["package_name"] = metadata.package_name
        if metadata.entry_point_name:
            info["entry_point_name"] = metadata.entry_point_name

        return info

    def has_spec(self, spec_name: str) -> bool:
        """Check if a specification is registered.

        Args:
            spec_name: Name or alias of the specification

        Returns:
            True if the spec is registered, False otherwise
        """
        canonical_name = self._aliases.get(spec_name, spec_name)
        return canonical_name in self._specs

    def clear(self) -> None:
        """Clear all registered specifications.

        This is primarily for testing purposes.
        """
        self._specs.clear()
        self._lazy_specs.clear()
        self._aliases.clear()
        logger.debug("Spec registry cleared")

    def count(self) -> int:
        """Get the number of registered specifications.

        Returns:
            Number of registered specs
        """
        return len(self._specs)

    def disable(self, spec_name: str) -> None:
        """Disable a specification.

        Disabled specs cannot be retrieved via get() but remain registered.

        Args:
            spec_name: Name or alias of the specification to disable

        Raises:
            SpecNotFoundError: If the specification is not registered
        """
        canonical_name = self._aliases.get(spec_name, spec_name)

        if canonical_name not in self._specs:
            raise SpecNotFoundError(f"Specification '{spec_name}' not found")

        self._specs[canonical_name].enabled = False
        logger.info(f"Disabled spec: {canonical_name}")

    def enable(self, spec_name: str) -> None:
        """Enable a specification.

        Re-enables a previously disabled spec.

        Args:
            spec_name: Name or alias of the specification to enable

        Raises:
            SpecNotFoundError: If the specification is not registered
        """
        canonical_name = self._aliases.get(spec_name, spec_name)

        if canonical_name not in self._specs:
            raise SpecNotFoundError(f"Specification '{spec_name}' not found")

        self._specs[canonical_name].enabled = True
        logger.info(f"Enabled spec: {canonical_name}")

    def is_enabled(self, spec_name: str) -> bool:
        """Check if a specification is enabled.

        Args:
            spec_name: Name or alias of the specification

        Returns:
            True if the spec is registered and enabled, False otherwise
        """
        canonical_name = self._aliases.get(spec_name, spec_name)

        if canonical_name not in self._specs:
            return False

        return self._specs[canonical_name].enabled


# Global registry instance
_global_registry = EvalSpecRegistry()


def register_spec(spec_class: Type[EvalSpec]) -> Type[EvalSpec]:
    """Register a specification class with the global registry.

    This is a convenience function that delegates to the global registry.

    Args:
        spec_class: The spec class to register

    Returns:
        The spec class unchanged (for decorator usage)
    """
    return _global_registry.register(spec_class)


def get_eval_spec(spec_name: str) -> EvalSpec:
    """Retrieve a registered specification from the global registry.

    Args:
        spec_name: Name or alias of the specification

    Returns:
        EvalSpec instance

    Raises:
        SpecNotFoundError: If the specification is not registered
    """
    return _global_registry.get(spec_name)


def list_available_specs() -> List[str]:
    """List all registered specifications in the global registry.

    Returns:
        Sorted list of registered spec names
    """
    return _global_registry.list_specs()


def get_spec_info(spec_name: str) -> Dict[str, str]:
    """Get information about a registered specification from the global registry.

    Args:
        spec_name: Name or alias of the specification

    Returns:
        Dictionary with spec information
    """
    return _global_registry.get_info(spec_name)


def discover_builtin_specs() -> List[Type[EvalSpec]]:
    """Discover all builtin specification classes in src/specs/.

    Scans the specs directory for modules containing spec classes.
    Looks for classes that:
    - End with 'Spec' or 'EvalSpec'
    - Inherit from BaseEvalSpec (not abstract)
    - Are not abstract classes

    Returns:
        List of discovered spec classes
    """
    discovered_specs: List[Type[EvalSpec]] = []
    specs_dir = Path(__file__).parent.parent / "specs"

    if not specs_dir.exists():
        logger.warning(f"Specs directory not found: {specs_dir}")
        return discovered_specs

    # Find all Python files in specs directory
    for py_file in specs_dir.rglob("*.py"):
        if py_file.name.startswith("_"):
            continue

        # Convert path to module name
        try:
            rel_path = py_file.relative_to(specs_dir.parent)
            module_name = str(rel_path.with_suffix("")).replace("/", ".")

            # Import the module
            module = importlib.import_module(module_name)

            # Look for spec classes
            for name in dir(module):
                if name.startswith("_"):
                    continue

                obj = getattr(module, name)

                # Check if it's a class
                if not isinstance(obj, type):
                    continue

                # Check if it looks like a spec class
                if not (name.endswith("Spec") or name.endswith("EvalSpec")):
                    continue

                # Check if it has spec protocol
                if not (
                    hasattr(obj, "name")
                    and hasattr(obj, "description")
                    and hasattr(obj, "run_evaluation")
                ):
                    continue

                # Skip abstract classes
                if hasattr(obj, "__abstractmethods__") and obj.__abstractmethods__:
                    continue

                # Try to instantiate to verify it's concrete
                try:
                    test_instance = obj()
                    # Check it has a valid name
                    if test_instance.name:
                        discovered_specs.append(obj)
                        logger.debug(
                            f"Discovered builtin spec: {test_instance.name} ({name})"
                        )
                except Exception as e:
                    logger.debug(f"Skipping {name}: {e}")
                    continue

        except Exception as e:
            logger.debug(f"Failed to import {py_file}: {e}")
            continue

    return discovered_specs


def discover_entry_point_specs() -> List[Type[EvalSpec]]:
    """Discover specification classes from installed package entry points.

    Scans for entry points in the 'ee_bench.specs' group.
    External packages can register specs via pyproject.toml:

        [project.entry-points."ee_bench.specs"]
        my-spec = "my_package.specs:MySpec"

    Returns:
        List of discovered spec classes with metadata
    """
    discovered_specs: List[Type[EvalSpec]] = []

    try:
        # Python 3.10+ uses importlib.metadata
        if sys.version_info >= (3, 10):
            from importlib.metadata import entry_points
        else:
            # Fallback for Python 3.9
            from importlib_metadata import entry_points

        # Get all entry points in the 'ee_bench.specs' group
        eps = entry_points()

        # Handle both dict (3.10+) and EntryPoints (3.9) return types
        if hasattr(eps, "select"):
            # Python 3.10+
            spec_entries = eps.select(group="ee_bench.specs")
        elif isinstance(eps, dict):
            # Python 3.10+ alternative format
            spec_entries = eps.get("ee_bench.specs", [])
        else:
            # Python 3.9 fallback
            spec_entries = eps.get("ee_bench.specs", [])

        for entry_point in spec_entries:
            try:
                # Load the entry point
                spec_class = entry_point.load()

                # Verify it implements the spec protocol
                if not (
                    hasattr(spec_class, "name")
                    and hasattr(spec_class, "description")
                    and hasattr(spec_class, "run_evaluation")
                ):
                    logger.warning(
                        f"Entry point '{entry_point.name}' does not implement EvalSpec protocol"
                    )
                    continue

                # Store metadata about the entry point
                # We'll attach it to the class for later use in register()
                spec_class._entry_point_name = entry_point.name
                spec_class._package_name = (
                    entry_point.dist.name if hasattr(entry_point, "dist") else None
                )

                discovered_specs.append(spec_class)
                logger.debug(
                    f"Discovered entry point spec: {entry_point.name} "
                    f"from package {spec_class._package_name}"
                )

            except Exception as e:
                logger.warning(f"Failed to load entry point '{entry_point.name}': {e}")
                continue

    except ImportError:
        logger.debug("importlib.metadata not available, skipping entry point discovery")
    except Exception as e:
        logger.warning(f"Error during entry point discovery: {e}")

    return discovered_specs


def discover_config_file_specs(config_path: Optional[Path] = None) -> List[str]:
    """Discover specification classes from YAML configuration file.

    Reads specs from ~/.ee-bench/specs.yml (or custom path).
    Config file format:

        specs:
          - my_package.specs:MySpec
          - another_package:AnotherSpec
          - path.to:ThirdSpec

    Args:
        config_path: Optional custom config file path. If None, uses ~/.ee-bench/specs.yml

    Returns:
        List of spec paths in "module:class" format for lazy loading
    """
    spec_paths: List[str] = []

    # Determine config file path
    if config_path is None:
        config_path = Path.home() / ".ee-bench" / "specs.yml"

    if not config_path.exists():
        logger.debug(f"Config file not found: {config_path}")
        return spec_paths

    try:
        import yaml

        with open(config_path, "r") as f:
            config = yaml.safe_load(f)

        if not config or "specs" not in config:
            logger.debug(f"No specs found in config file: {config_path}")
            return spec_paths

        specs_list = config["specs"]
        if not isinstance(specs_list, list):
            logger.warning(f"Config 'specs' must be a list, got {type(specs_list)}")
            return spec_paths

        for spec_path in specs_list:
            if not isinstance(spec_path, str):
                logger.warning(
                    f"Spec path must be a string, got {type(spec_path)}: {spec_path}"
                )
                continue

            if ":" not in spec_path:
                logger.warning(
                    f"Invalid spec path format (expected 'module:class'): {spec_path}"
                )
                continue

            spec_paths.append(spec_path)
            logger.debug(f"Found config spec: {spec_path}")

    except ImportError:
        logger.warning("PyYAML not installed, skipping config file discovery")
    except Exception as e:
        logger.warning(f"Error reading config file {config_path}: {e}")

    return spec_paths


def auto_discover_specs() -> None:
    """Auto-discover and register all available specifications.

    This function is called at CLI startup to ensure all specs are loaded.

    Discovery sources (in order):
    1. Builtin specs in src/specs/ directory
    2. Entry point specs from installed packages
    3. Config file specs from ~/.ee-bench/specs.yml
    """
    # Discover builtin specs
    builtin_specs = discover_builtin_specs()
    for spec_class in builtin_specs:
        try:
            _global_registry.register(spec_class, source="builtin")
        except Exception as e:
            logger.warning(
                f"Failed to register builtin spec {spec_class.__name__}: {e}"
            )

    # Discover entry point specs
    entry_point_specs = discover_entry_point_specs()
    for spec_class in entry_point_specs:
        try:
            # Get entry point metadata if available
            package_name = getattr(spec_class, "_package_name", None)
            entry_point_name = getattr(spec_class, "_entry_point_name", None)

            # Register with entry_point source
            _global_registry.register(spec_class, source="entry_point")

            # Update metadata with package info
            spec_instance = spec_class()
            if spec_instance.name in _global_registry._specs:
                metadata = _global_registry._specs[spec_instance.name]
                metadata.package_name = package_name
                metadata.entry_point_name = entry_point_name

        except Exception as e:
            logger.warning(
                f"Failed to register entry point spec {spec_class.__name__}: {e}"
            )

    # Discover config file specs (lazy loading)
    config_spec_paths = discover_config_file_specs()
    for spec_path in config_spec_paths:
        try:
            # Register lazily with config source
            # Don't specify name - let it use the class name, and the spec's actual name
            # will be used when it's loaded
            _global_registry.register_lazy(spec_path, source="config")

        except Exception as e:
            logger.warning(f"Failed to register config spec {spec_path}: {e}")

    count = _global_registry.count()
    lazy_count = len(_global_registry._lazy_specs)
    logger.info(
        f"Auto-discovery complete. Registered {count} specs ({lazy_count} lazy-loaded)."
    )


def get_registry() -> EvalSpecRegistry:
    """Get the global registry instance.

    Returns:
        The global EvalSpecRegistry instance
    """
    return _global_registry
