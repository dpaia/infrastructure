"""GitHubAttachmentGenerator — attaches files to existing PR branches."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from ee_bench.generator import AttachmentFile, Provider
from ee_bench.generator.scripting import is_dry_run

logger = logging.getLogger(__name__)


@dataclass
class _FileEntry:
    """A resolved file ready to be committed."""

    path: str  # path relative to attachment_dir
    content: str
    mode: str  # git tree mode: "100644" or "100755"


class GitHubAttachmentGenerator(Provider):
    """Provider that attaches files to existing PR branches.

    For each item:
    1. Resolves a configurable list of files from data fields
    2. Supports wildcard expansion (dict fields)
    3. Commits files under a configurable directory (default ``.ee-bench/``)
    """

    def provide(
        self,
        item=None,
        *,
        instance_id="",
        upstream_repo="",
        data=None,
        target_org="",
        github_token="",
        dataset_label="",
        attachment_dir="",
        branch="",
        dry_run=None,
        files=None,
        target_repo=None,
        base_branch=None,
        **kwargs,
    ) -> list[dict[str, Any]]:
        """Attach files to an existing PR branch for a single item.

        Args:
            item: Item dict (unused after explicit-param migration).
            instance_id: Instance identifier.
            upstream_repo: Upstream GitHub repo (e.g. "owner/repo").
            data: Dict of field values for file content lookups.
            target_org: GitHub org.
            github_token: GitHub PAT.
            dataset_label: Label for the dataset.
            attachment_dir: Directory for attachments (default ".ee-bench").
            branch: Branch name.
            dry_run: Override dry run mode.
            files: List of AttachmentFile objects or dicts with path/field/mode keys.
            target_repo: Target repo override.
            base_branch: Base branch for creating new branches.
            **kwargs: Ignored.

        Returns:
            List containing single result dict.
        """
        data = data or {}
        if dry_run is None:
            dry_run = is_dry_run()
        attachment_dir = attachment_dir or ".ee-bench"
        dataset_label = dataset_label or "swe-bench-pro"

        if not branch:
            branch = f"{dataset_label}/{instance_id}/after"

        # Normalize files config
        files_config: list[dict[str, Any]] = []
        if files:
            for f in files:
                if isinstance(f, AttachmentFile):
                    files_config.append({
                        "path": f.path,
                        "field": f.field,
                        "mode": f.mode,
                    })
                else:
                    files_config.append(f)

        # Resolve files
        file_entries = self._resolve_files(files_config, data)

        if not file_entries:
            return [{
                "instance_id": instance_id,
                "status": "skipped",
                "files": [],
                "pr_url": "",
                "reason": "no_files",
                "error": "",
            }]

        # Prepend attachment_dir to each file path
        for entry in file_entries:
            entry.path = f"{attachment_dir}/{entry.path}"

        if dry_run:
            file_paths = [e.path for e in file_entries]
            logger.info("[DRY RUN] Would attach %s to %s", file_paths, instance_id)
            return [{
                "instance_id": instance_id,
                "status": "dry_run_attached",
                "files": file_paths,
                "pr_url": "",
                "reason": "",
                "error": "",
            }]

        if not github_token:
            raise ValueError("github_token is required for non-dry-run attachment uploads")

        from github import Github
        gh = Github(github_token)

        try:
            result = self._attach_files(
                gh=gh,
                instance_id=instance_id,
                upstream_repo=upstream_repo,
                target_org=target_org,
                target_repo_option=target_repo,
                dataset_label=dataset_label,
                branch_name=branch,
                base_branch=base_branch,
                file_entries=file_entries,
                repo_cache={},
            )
            return [result]
        except Exception as e:
            logger.error("Failed to attach files for %s: %s", instance_id, e)
            return [{
                "instance_id": instance_id,
                "status": "error",
                "files": [],
                "pr_url": "",
                "reason": "",
                "error": str(e),
            }]

    @staticmethod
    def _resolve_files(
        files_config: list[dict[str, Any]],
        data: dict[str, Any],
    ) -> list[_FileEntry]:
        """Resolve file config into a list of _FileEntry."""
        entries: dict[str, _FileEntry] = {}
        overrides: list[dict[str, Any]] = []

        for spec in files_config:
            path: str = spec["path"]
            field_name: str | None = spec.get("field")
            mode: str = spec.get("mode", "100644")

            if field_name is None:
                overrides.append(spec)
                continue

            content = data.get(field_name)
            if content is None:
                continue

            if path.endswith("/*"):
                if not isinstance(content, dict):
                    logger.warning(
                        "Field '%s' for wildcard path '%s' is not a dict — skipping",
                        field_name, path,
                    )
                    continue
                prefix = path[:-2]
                for key, value in content.items():
                    resolved_path = f"{prefix}/{key}"
                    entries[resolved_path] = _FileEntry(resolved_path, value, mode)
            else:
                if not isinstance(content, str):
                    content = str(content)
                entries[path] = _FileEntry(path, content, mode)

        for spec in overrides:
            path = spec["path"]
            if path in entries:
                entries[path].mode = spec.get("mode", entries[path].mode)

        return list(entries.values())

    @staticmethod
    def _attach_files(
        gh: Any,
        instance_id: str,
        upstream_repo: str,
        target_org: str,
        target_repo_option: str | None,
        dataset_label: str,
        branch_name: str,
        base_branch: str | None,
        file_entries: list[_FileEntry],
        repo_cache: dict[str, Any],
    ) -> dict[str, Any]:
        """Commit file entries to branch_name, creating it if needed."""
        from github import InputGitTreeElement

        if target_repo_option:
            fork_full_name = target_repo_option
        else:
            repo_name = upstream_repo.split("/")[-1]
            fork_full_name = f"{target_org}/{repo_name}"

        if fork_full_name not in repo_cache:
            repo_cache[fork_full_name] = gh.get_repo(fork_full_name)
        fork_repo = repo_cache[fork_full_name]

        ref = _get_or_create_branch(fork_repo, branch_name, base_branch)
        current_sha = ref.object.sha
        current_commit = fork_repo.get_git_commit(current_sha)

        tree_elements = []
        attached_files: list[str] = []
        for entry in file_entries:
            blob = fork_repo.create_git_blob(entry.content, "utf-8")
            tree_elements.append(
                InputGitTreeElement(
                    path=entry.path,
                    mode=entry.mode,
                    type="blob",
                    sha=blob.sha,
                )
            )
            attached_files.append(entry.path)

        new_tree = fork_repo.create_git_tree(tree_elements, current_commit.tree)
        new_commit = fork_repo.create_git_commit(
            message=f"Add files for {instance_id}",
            tree=new_tree,
            parents=[current_commit],
        )
        ref.edit(sha=new_commit.sha, force=True)

        pr_url = ""
        try:
            head_ref = f"{fork_repo.owner.login}:{branch_name}"
            pulls = fork_repo.get_pulls(state="all", head=head_ref)
            for pr in pulls:
                pr_url = pr.html_url
                break
        except Exception as e:
            logger.warning("Failed to look up PR for %s: %s", instance_id, e)

        return {
            "instance_id": instance_id,
            "status": "attached",
            "files": attached_files,
            "pr_url": pr_url,
            "reason": "",
            "error": "",
        }


def _get_or_create_branch(repo, branch_name, base_branch):
    """Return the git ref for branch_name, creating it from base_branch if needed."""
    try:
        return repo.get_git_ref(f"heads/{branch_name}")
    except Exception:
        if base_branch is None:
            raise ValueError(
                f"Branch '{branch_name}' not found in {repo.full_name} "
                "and no base_branch configured to create it"
            )
        try:
            base_ref = repo.get_git_ref(f"heads/{base_branch}")
            base_sha = base_ref.object.sha
        except Exception:
            base_sha = repo.get_branch(repo.default_branch).commit.sha
        return repo.create_git_ref(f"refs/heads/{branch_name}", base_sha)
