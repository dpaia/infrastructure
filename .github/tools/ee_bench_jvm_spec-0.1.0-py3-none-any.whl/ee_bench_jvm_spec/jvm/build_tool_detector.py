"""Build tool wrapper detection utilities.

This module provides utilities for detecting Maven and Gradle wrappers
in project directories using sandbox for environment-agnostic checks.
"""

import logging
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .sandbox_base import Sandbox

logger = logging.getLogger(__name__)


def detect_maven_command(
    sandbox: "Sandbox",
    working_dir: Path,
    timeout: int = 5,
) -> list[str]:
    """Detect Maven wrapper (mvnw) or use system Maven.

    Uses sandbox to check for wrapper file existence, ensuring
    compatibility with both Docker and local environments.

    Args:
        sandbox: Sandbox instance for command execution
        working_dir: Project directory to check
        timeout: Timeout for wrapper detection command (default: 5 seconds)

    Returns:
        List containing Maven command (either ['./mvnw'] or ['mvn'])
    """
    try:
        # Check if mvnw exists using sandbox
        result = sandbox.run_command(
            cmd=["test", "-f", "mvnw"],
            cwd=working_dir,
            timeout=timeout,
        )

        if result.returncode == 0:
            # Also check if maven-wrapper.jar exists
            jar_result = sandbox.run_command(
                cmd=["test", "-f", ".mvn/wrapper/maven-wrapper.jar"],
                cwd=working_dir,
                timeout=timeout,
            )

            if jar_result.returncode == 0:
                logger.debug(f"Found Maven wrapper at {working_dir / 'mvnw'}")
                return ["./mvnw"]
            logger.debug(
                "Maven wrapper script found but maven-wrapper.jar missing, "
                "using system Maven"
            )
            return ["mvn"]
        logger.debug("Maven wrapper not found, using system Maven")
        return ["mvn"]
    except Exception as e:
        logger.debug(f"Error checking for Maven wrapper: {e}, using system Maven")
        return ["mvn"]


def detect_gradle_command(
    sandbox: "Sandbox",
    working_dir: Path,
    timeout: int = 5,
) -> list[str]:
    """Detect Gradle wrapper (gradlew) or use system Gradle.

    Uses sandbox to check for wrapper file existence, ensuring
    compatibility with both Docker and local environments.

    Args:
        sandbox: Sandbox instance for command execution
        working_dir: Project directory to check
        timeout: Timeout for wrapper detection command (default: 5 seconds)

    Returns:
        List containing Gradle command (either ['./gradlew'] or ['gradle'])
    """
    try:
        # Check if gradlew exists using sandbox
        result = sandbox.run_command(
            cmd=["test", "-f", "gradlew"],
            cwd=working_dir,
            timeout=timeout,
        )

        if result.returncode == 0:
            # Also check if gradle-wrapper.jar exists
            jar_result = sandbox.run_command(
                cmd=["test", "-f", "gradle/wrapper/gradle-wrapper.jar"],
                cwd=working_dir,
                timeout=timeout,
            )

            if jar_result.returncode == 0:
                logger.debug(f"Found Gradle wrapper at {working_dir / 'gradlew'}")
                return ["./gradlew"]
            logger.debug(
                "Gradle wrapper script found but gradle-wrapper.jar missing, "
                "using system Gradle"
            )
            return ["gradle"]
        logger.debug("Gradle wrapper not found, using system Gradle")
        return ["gradle"]
    except Exception as e:
        logger.debug(f"Error checking for Gradle wrapper: {e}, using system Gradle")
        return ["gradle"]
