"""ModuleTestProvider — enriches test name lists with module prefixes."""

from __future__ import annotations

from typing import Any

from ee_bench.generator.build_utils import prefix_test_names
from ee_bench.generator.interfaces import Provider


class ModuleTestProvider(Provider):
    """Enrichment provider for test name module prefix enrichment."""

    def __init__(self, **kwargs: Any) -> None:
        self._test_group_names: list[str] = ["FAIL_TO_PASS", "PASS_TO_PASS"]
        if kwargs:
            self.prepare(**kwargs)

    def prepare(self, **options: Any) -> None:
        groups = options.get("test_groups")
        if groups:
            self._test_group_names = list(groups)

    def provide(self, item=None, *, module_map=None, FAIL_TO_PASS=None, PASS_TO_PASS=None, **kwargs) -> dict[str, Any]:
        """Enrich test names with module prefixes.

        Args:
            item: Item dict with test group fields and module_map.
            module_map: Dict mapping class FQNs to module notation prefixes.
            FAIL_TO_PASS: Override for FAIL_TO_PASS from item.
            PASS_TO_PASS: Override for PASS_TO_PASS from item.
            **kwargs: Ignored.

        Returns:
            Dict with enriched test group fields.
        """
        item = item or {}
        if module_map is None:
            module_map = item.get("module_map", {})

        result: dict[str, Any] = {}
        overrides = {"FAIL_TO_PASS": FAIL_TO_PASS, "PASS_TO_PASS": PASS_TO_PASS}

        for name in self._test_group_names:
            test_names = overrides.get(name) if overrides.get(name) is not None else item.get(name, "[]")
            if module_map:
                result[name] = prefix_test_names(str(test_names), module_map)
            else:
                result[name] = test_names

        return result
