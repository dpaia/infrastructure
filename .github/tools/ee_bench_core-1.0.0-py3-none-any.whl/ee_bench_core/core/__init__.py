"""Core framework for multi-specification benchmark evaluation."""

from ee_bench_core.adapters.eval import PatchApplierEvaluator, TestRunnerEvaluator
from .errors import (
    EEBenchError,
    SpecNotFoundError,
    DatasetError,
    EnvironmentError,
    EvaluationError,
    ConfigurationError,
    TimeoutError,
    PatchApplicationError,
    TestExecutionError,
    PluginError,
    PluginLoadError,
    SpecVersionError,
)
from .models import (
    DatasetConfig,
    EnvironmentConfig,
    EvaluationResult,
    EvaluationContext,
    ResultStatus,
)
from .abc_types import (
    DatasetManager,
    EnvironmentManager,
    ReportManager,
    EvaluationRunner,
    EnvironmentTools,
    EvalSpec,
)
from .spec_registry import (
    EvalSpecRegistry,
    register_spec,
    get_eval_spec,
    list_available_specs,
    get_spec_info,
    auto_discover_specs,
    get_registry,
)
from .report_manager import (
    SummaryReport,
    ReportManager as ConcreteReportManager,
)
from .eval import (
    Evaluator,
    EvaluationContext as EvaluatorContext,
    EvaluatorResult,
    EvaluatorStatus,
    EvaluatorDependency,
    DependencyPosition,
    EvaluatorValidator,
    PipelineRunner,
    PipelineEvaluationResult,
    BaseEvaluationRunner,
)

__version__ = "1.0.0"

__all__ = [
    "__version__",
    # Models
    "DatasetConfig",
    "EnvironmentConfig",
    "EvaluationResult",
    "EvaluationContext",
    "ResultStatus",
    # Abstract Types
    "DatasetManager",
    "EnvironmentManager",
    "ReportManager",
    "EvaluationRunner",
    "EnvironmentTools",
    "EvalSpec",
    # Registry
    "EvalSpecRegistry",
    "register_spec",
    "get_eval_spec",
    "list_available_specs",
    "get_spec_info",
    "auto_discover_specs",
    "get_registry",
    # Report Management
    "SummaryReport",
    "ConcreteReportManager",
    # Evaluator Framework
    "Evaluator",
    "EvaluatorContext",
    "EvaluatorResult",
    "EvaluatorStatus",
    "EvaluatorDependency",
    "DependencyPosition",
    "EvaluatorValidator",
    "PipelineRunner",
    "PipelineEvaluationResult",
    # Parametrized Evaluators
    "PatchApplierEvaluator",
    "TestRunnerEvaluator",
    # Base Evaluation Runner
    "BaseEvaluationRunner",
    # Errors
    "EEBenchError",
    "SpecNotFoundError",
    "DatasetError",
    "EnvironmentError",
    "EvaluationError",
    "ConfigurationError",
    "TimeoutError",
    "PatchApplicationError",
    "TestExecutionError",
    "PluginError",
    "PluginLoadError",
    "SpecVersionError",
]
