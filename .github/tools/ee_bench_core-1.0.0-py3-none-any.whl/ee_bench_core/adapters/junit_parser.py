"""JUnit XML report parser adapter.

This module provides functionality to parse JUnit XML test reports
and convert them into TestResult objects.
"""

import logging
from pathlib import Path
from typing import Optional

from junitparser import JUnitXml

from ee_bench_core.core.models import ResultStatus
from .testrunner_base import TestResult

logger = logging.getLogger(__name__)


def parse_junit_report(
    reports_dir: Path, class_fqn: Optional[str] = None
) -> Optional[TestResult]:
    """Parse JUnit XML reports in test-results directories.

    Args:
        reports_dir: Directory containing JUnit XML reports
        class_fqn: Optional fully qualified class name to filter results

    Returns:
        TestResult with aggregated results from all XML files, or None if no valid results found
    """
    logger.debug(f"Reports dir: {reports_dir}")

    if not reports_dir.exists():
        logger.warning(f"Reports directory does not exist: {reports_dir}")
        return None

    # Find all XML files in the reports directory
    xml_files = list(reports_dir.glob("**/*.xml"))
    if not xml_files:
        logger.warning(f"No XML files found in reports directory: {reports_dir}")
        return None

    result = TestResult(execution_time=0.0, raw_output="")

    for xml_file in xml_files:
        try:
            logger.debug(f"Parsing XML file: {xml_file}")
            xml = JUnitXml.fromfile(str(xml_file))

            for suite in xml:
                for case in suite:
                    # Filter by class if specified
                    if class_fqn and case.classname != class_fqn:
                        continue

                    test_name = f"{case.classname}#{case.name}"
                    logger.info(f"Test: {test_name}")

                    # Add case execution time
                    test_time = float(case.time) if case.time else 0.0
                    result.execution_time += test_time
                    logger.debug(f"Test execution time: {test_time} seconds")

                    # Collect result details
                    details = []
                    for res in case.result:
                        if res.message:
                            details.append(res.message)
                            logger.debug(f"Test result: {res.message}")

                    if case.is_passed:
                        # No result means passed
                        result.add_test(
                            test_name=test_name,
                            status=ResultStatus.SUCCESS,
                            reason="Test passed",
                            execution_time=test_time,
                            details=details,
                        )
                        logger.debug(f"Test passed: {test_name}")
                    elif case.is_skipped:
                        result.add_test(
                            test_name=test_name,
                            status=ResultStatus.SKIPPED,
                            reason="Test skipped",
                            execution_time=test_time,
                            details=details,
                        )
                        logger.debug(f"Test skipped: {test_name}")
                    else:
                        # Error, Failure, or other result types count as failures
                        reason = "Test failed"
                        if details:
                            reason = details[0] if details[0] else reason
                        result.add_test(
                            test_name=test_name,
                            status=ResultStatus.FAILED,
                            reason=reason,
                            execution_time=test_time,
                            details=details,
                        )
                        logger.debug(f"Test failed: {test_name}")

        except Exception as e:
            logger.error(f"Error parsing XML file {xml_file}: {e}")
            from ee_bench_core.core.utils import trace_error

            logger.debug(trace_error(e))
            continue

    if result.total_tests == 0:
        logger.warning("No test cases found in any XML files")
        return None

    return result
