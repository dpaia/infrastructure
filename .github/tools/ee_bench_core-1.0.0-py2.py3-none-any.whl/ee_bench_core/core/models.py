"""Base models and data structures for the evaluation framework."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, Optional, Set, Protocol

if TYPE_CHECKING:
    from ee_bench_core.core.eval import FinalScore


class ResultStatus(Enum):
    """Enumeration of possible evaluation result statuses."""

    SUCCESS = "success"
    """Evaluation passed successfully"""

    FAILED = "failed"
    """Evaluation failed"""

    TIMEOUT = "timeout"
    """Evaluation failed by timeout"""

    SKIPPED = "skipped"
    """Evaluation was skipped"""


class Reportable(Protocol):
    """Protocol for objects that can be reported.

    Any object that implements this protocol can be reported via ReportManager.
    This enables flexible reporting of evaluation results, environment configs,
    and custom result types.
    """

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage.

        Returns:
            Dictionary representation of the reportable object
        """
        ...

    @property
    @abstractmethod
    def result(self) -> "ResultStatus":
        """Get the execution status for counting.

        Returns:
            ResultStatus enum (SUCCESS, FAILED, SKIPPED, etc.)
        """
        ...


class DatasetConfig(ABC):
    """Abstract base class for dataset configuration.

    Each specification should implement this interface to provide
    task-specific configuration data.
    """

    @property
    @abstractmethod
    def instance_id(self) -> str:
        """Get the unique identifier for this task instance.

        Returns:
            Unique instance identifier
        """
        pass

    @abstractmethod
    def present(self) -> str:
        """Generate a human-readable presentation of this configuration.

        Returns:
            Formatted string representation for display
        """
        pass

    @abstractmethod
    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary format.

        Returns:
            Dictionary representation of the configuration
        """
        pass


class EnvironmentConfig(ABC):
    """Abstract base class for environment configuration.

    Represents the configured evaluation environment (e.g., Docker image,
    workspace paths, etc.).
    """

    @abstractmethod
    def to_dict(self) -> Dict[str, Any]:
        """Convert environment config to dictionary format.

        Returns:
            Dictionary representation of the environment configuration
        """
        pass


class EnvironmentConfigReportable(Reportable):
    """EnvironmentConfig implementation that implements Reportable protocol."""

    def __init__(
        self,
        env_config: Optional[EnvironmentConfig] = None,
        error: Optional[str] = None,
        status: ResultStatus = ResultStatus.SUCCESS,
    ):
        self.env_config = env_config
        self.status = status
        self.error = error

    @property
    def result(self) -> "ResultStatus":
        return self.status

    def to_dict(self) -> Dict[str, Any]:
        if self.env_config is None:
            # If no env_config (error case), return minimal dict
            return {
                "status": self.status.value,
                "error": self.error,
            }
        env_dict = self.env_config.to_dict()
        env_dict["status"] = self.status.value
        if self.error:
            env_dict["error"] = self.error
        return env_dict


class EvaluationResult(Reportable):
    """Abstract base class for evaluation results.

    Each specification should implement this interface to provide
    evaluation outcomes in their preferred format.
    """

    @property
    @abstractmethod
    def instance_id(self) -> str:
        """Get the unique identifier for the evaluated task.

        Returns:
            Task instance identifier
        """
        pass

    @property
    def successful(self) -> bool:
        """Check if the evaluation was successful.

        Returns:
            True if evaluation passed, False otherwise

        Note:
            This property is provided for backward compatibility.
            Prefer using the result property which returns ResultStatus enum.
        """
        return self.result == ResultStatus.SUCCESS

    @property
    @abstractmethod
    def reason(self) -> str:
        """Get the reason for success or failure.

        Returns:
            Human-readable explanation of the result
        """
        pass

    @abstractmethod
    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary format.

        Returns:
            Dictionary representation of the evaluation result
        """
        pass

    @property
    def execution_time(self) -> float:
        """Get the execution time in seconds.

        Returns:
            Execution time (default: 0.0)
        """
        return 0.0

    @property
    def score(self) -> "FinalScore":
        """Get the final score for the evaluation."""


@dataclass
class EvaluationContext:
    """Context object containing all information needed for evaluation.

    This is passed between components during the evaluation process.
    Spec-specific parameters (like prediction patches) should be passed
    via extra_params.
    """

    instance_id: str
    """Unique identifier for the task instance"""

    dataset_config: DatasetConfig
    """Configuration loaded from the dataset"""

    env_config: EnvironmentConfig
    """Environment configuration (Docker image, paths, etc.)"""

    timeout: int = 1800
    """Maximum execution time in seconds (default: 30 minutes)"""

    force_rebuild: bool = False
    """Whether to force rebuilding the environment"""

    work_dir: Optional[Path] = None
    """Working directory for evaluation"""

    extra_params: Dict[str, Any] = field(default_factory=dict)
    """Additional spec-specific parameters (e.g., prediction_patch)"""

    def to_dict(self) -> Dict[str, Any]:
        """Convert context to dictionary format.

        Returns:
            Dictionary representation of the evaluation context
        """
        return {
            "instance_id": self.instance_id,
            "dataset_config": self.dataset_config.to_dict(),
            "env_config": self.env_config.to_dict(),
            "timeout": self.timeout,
            "force_rebuild": self.force_rebuild,
            "work_dir": str(self.work_dir) if self.work_dir else None,
            "extra_params": self.extra_params,
        }


@dataclass
class EnvironmentPreparationResult:
    """Result of preparing evaluation environments for multiple instances.

    Provides structured information about which environments were successfully
    prepared and which failed, along with detailed error information.
    """

    successful_ids: Set[str] = field(default_factory=set)
    """Set of instance IDs that were successfully prepared"""

    failed_ids: Set[str] = field(default_factory=set)
    """Set of instance IDs that failed to prepare"""

    environments: Dict[str, EnvironmentConfig] = field(default_factory=dict)
    """Mapping of instance_id to EnvironmentConfig for successful preparations"""

    errors: Dict[str, str] = field(default_factory=dict)
    """Mapping of instance_id to error message for failed preparations"""

    total_count: int = 0
    """Total number of instances requested"""

    environment_config_file: str = "environment_config.json"
    """Filename for environment configuration file"""

    @property
    def success_count(self) -> int:
        """Number of successfully prepared environments."""
        return len(self.successful_ids)

    @property
    def failure_count(self) -> int:
        """Number of failed environment preparations."""
        return len(self.failed_ids)

    @property
    def success_rate(self) -> float:
        """Success rate as a percentage (0-100)."""
        if self.total_count == 0:
            return 0.0
        return (self.success_count / self.total_count) * 100

    @property
    def all_successful(self) -> bool:
        """Whether all environment preparations succeeded."""
        return self.failure_count == 0 and self.success_count == self.total_count

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation.

        Returns:
            Dictionary with all result information
        """
        return {
            "successful_ids": list(self.successful_ids),
            "failed_ids": list(self.failed_ids),
            "environments": {
                instance_id: env.to_dict()
                for instance_id, env in self.environments.items()
            },
            "errors": self.errors,
            "total_count": self.total_count,
            "success_count": self.success_count,
            "failure_count": self.failure_count,
            "success_rate": self.success_rate,
            "all_successful": self.all_successful,
            "environment_config_file": self.environment_config_file,
        }


@dataclass
class CommandExecutionResult(Reportable):
    """Result of executing a command in an environment.

    Implements the Reportable protocol for integration with ReportManager.
    """

    instance_id: str
    """Unique identifier for the task instance"""

    command: str
    """Shell command that was executed"""

    exit_code: int
    """Exit code from command execution"""

    stdout: str
    """Standard output from command"""

    stderr: str
    """Standard error from command"""

    duration: float
    """Execution duration in seconds"""

    timed_out: bool = False
    """Whether the command exceeded timeout"""

    error: Optional[str] = None
    """Error message if execution failed"""

    environment: Optional[EnvironmentConfig] = None
    """Environment configuration used for execution"""

    stdin_input: Optional[str] = None
    """Input sent to command via stdin"""

    interactive: bool = False
    """Whether command was run in interactive mode"""

    @property
    def successful(self) -> bool:
        """Check if command execution was successful.

        Returns:
            True if exit code is 0 and no errors, False otherwise
        """
        return self.exit_code == 0 and not self.error and not self.timed_out

    @property
    def result(self) -> ResultStatus:
        """Get result status for Reportable protocol.

        Returns:
            ResultStatus based on execution outcome
        """
        if self.error:
            return ResultStatus.FAILED
        elif self.timed_out:
            return ResultStatus.FAILED
        elif self.exit_code == 0:
            return ResultStatus.SUCCESS
        else:
            return ResultStatus.FAILED

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation.

        Returns:
            Dictionary with all execution result information
        """
        return {
            "instance_id": self.instance_id,
            "command": self.command,
            "exit_code": self.exit_code,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "duration": self.duration,
            "timed_out": self.timed_out,
            "successful": self.successful,
            "status": self.result.value,
            "error": self.error,
            "environment": self.environment.to_dict() if self.environment else None,
            "stdin_input": self.stdin_input,
            "interactive": self.interactive,
        }


@dataclass
class MultiCommandExecutionResult(Reportable):
    """Result of executing multiple commands in sequence.

    Implements the Reportable protocol for integration with ReportManager.
    Each command execution is tracked separately with its own CommandExecutionResult.
    """

    instance_id: str
    """Unique identifier for the task instance"""

    commands: list[str]
    """List of commands that were executed"""

    results: list[CommandExecutionResult]
    """Results for each command in sequence"""

    stop_on_error: bool = True
    """Whether execution stopped on first error"""

    environment: Optional[EnvironmentConfig] = None
    """Environment configuration used for execution"""

    @property
    def successful(self) -> bool:
        """Check if all command executions were successful.

        Returns:
            True if all commands succeeded, False otherwise
        """
        return all(r.successful for r in self.results)

    @property
    def total_duration(self) -> float:
        """Total duration of all command executions.

        Returns:
            Sum of all command durations in seconds
        """
        return sum(r.duration for r in self.results)

    @property
    def result(self) -> ResultStatus:
        """Get overall result status for Reportable protocol.

        Returns:
            ResultStatus based on all command outcomes
        """
        if any(r.result == ResultStatus.FAILED for r in self.results):
            return ResultStatus.FAILED
        elif all(r.result == ResultStatus.SUCCESS for r in self.results):
            return ResultStatus.SUCCESS
        else:
            return ResultStatus.FAILED

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation.

        Returns:
            Dictionary with all execution result information
        """
        return {
            "instance_id": self.instance_id,
            "commands": self.commands,
            "results": [r.to_dict() for r in self.results],
            "total_duration": self.total_duration,
            "successful": self.successful,
            "status": self.result.value,
            "stop_on_error": self.stop_on_error,
            "commands_executed": len(self.results),
            "commands_successful": sum(1 for r in self.results if r.successful),
            "commands_failed": sum(1 for r in self.results if not r.successful),
            "environment": self.environment.to_dict() if self.environment else None,
        }


@dataclass
class PredictionResult(Reportable):
    """Reportable prediction result carrying prediction content.

    This class combines the functionality of the old PredictionsEntry and PredictionResult,
    providing a unified structure for prediction data with source tracking.

    Fields:
      - instance_id: unique id of the dataset instance
      - content: the prediction payload (e.g., unified diff patch)
      - source: source of the prediction in format "type:detail", e.g.:
          * "gold" - from dataset gold patch
          * "json:/path/to/file.json" - from JSON predictions file
          * "agent:claude_code" - from agent execution
          * "git_diff" - from git diff
      - status: ResultStatus (auto-set to SKIPPED if content is empty)
      - error: optional error message
      - agent: agent name if source starts with "agent:" (DEPRECATED - use source field)
      - details: optional extra metadata
    """

    instance_id: str
    content: str
    source: str
    status: Optional[ResultStatus] = None
    error: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """Auto-set status to SKIPPED if content is empty and status is None."""
        if self.status is None:
            self.status = ResultStatus.SKIPPED if self.is_empty() else ResultStatus.SUCCESS

    def is_empty(self) -> bool:
        """Check if prediction content is empty."""
        return self.content == ""

    @property
    def result(self) -> ResultStatus:
        """Get result status for Reportable protocol.

        Returns:
            ResultStatus based on status field or SUCCESS if status is None
        """
        if self.status is not None:
            return self.status
        # If status is None and content is not empty, consider it SUCCESS
        return ResultStatus.SUCCESS if not self.is_empty() else ResultStatus.SKIPPED

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation for Reportable protocol.

        Returns:
            Dictionary with all fields including status
        """
        result = {
            "instance_id": self.instance_id,
            "content": self.content,
            "source": self.source,
            "status": self.result.value,
        }
        if self.error is not None:
            result["error"] = self.error

        from ee_bench_core.core.utils import filter_kwargs
        details = filter_kwargs(self.details, exclude=["instance_id", "content", "source", "status", "error"])
        if details:
            for key, value in details.items():
                result[key] = value
        return result

    def to_list_item(self) -> Dict[str, Any]:
        """Convert to list item format for predictions JSON output.

        This is the legacy format for predictions files (backwards compatible with PredictionsEntry).
        Only includes optional fields when they are not None.

        Returns:
            Dictionary with required fields and present optional fields
        """
        item: Dict[str, Any] = {
            "instance_id": self.instance_id,
            "content": self.content,
        }
        # Append optional fields when present
        if self.status is not None:
            item["status"] = self.status.value  # Serialize enum as string
        if self.error is not None:
            item["error"] = self.error
        if self.source:
            item["source"] = self.source
        return item


@dataclass
class PredictionsEntry(Reportable):
    """DEPRECATED: Use PredictionResult instead.

    This class is kept for backwards compatibility only.
    It wraps PredictionResult with the old 'prediction' field name.

    Required fields:
      - instance_id: unique id of the dataset instance
      - prediction: prediction string (e.g., patch text)

    Optional metadata fields are included only when not None in the serialized
    list item to keep output lean and backwards-friendly.

    The status field automatically defaults to ResultStatus.SKIPPED when the
    prediction is empty and no explicit status is provided.
    """

    instance_id: str
    prediction: str

    # Optional metadata
    status: Optional[ResultStatus] = None
    error: Optional[str] = None

    def __post_init__(self):
        """Auto-set status to SKIPPED if prediction is empty and status is None."""
        if self.status is None and self.prediction == "":
            self.status = ResultStatus.SKIPPED

    def is_empty(self) -> bool:
        return self.prediction == ""

    @property
    def result(self) -> ResultStatus:
        """Get result status for Reportable protocol.

        Returns:
            ResultStatus based on status field or SUCCESS if status is None
        """
        if self.status is not None:
            return self.status
        # If status is None and prediction is not empty, consider it SUCCESS
        return ResultStatus.SUCCESS if not self.is_empty() else ResultStatus.SKIPPED

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation for Reportable protocol.

        Returns:
            Dictionary with all fields including status
        """
        return {
            "instance_id": self.instance_id,
            "prediction": self.prediction,
            "status": self.result.value,
            "error": self.error,
        }

    def to_list_item(self) -> Dict[str, Any]:
        """Convert to list item format for predictions JSON output.

        This is the legacy format for predictions files.
        Only includes optional fields when they are not None.

        Returns:
            Dictionary with required fields and present optional fields
        """
        item: Dict[str, Any] = {
            "instance_id": self.instance_id,
            "prediction": self.prediction,
        }
        # Append optional fields when present
        if self.status is not None:
            item["status"] = self.status.value  # Serialize enum as string
        if self.error is not None:
            item["error"] = self.error
        return item

    def to_prediction_result(self, source: str = "unknown") -> "PredictionResult":
        """Convert to PredictionResult for migration purposes.

        Args:
            source: Source of the prediction (default: "unknown")

        Returns:
            PredictionResult instance
        """
        return PredictionResult(
            instance_id=self.instance_id,
            content=self.prediction,
            source=source,
            status=self.status,
            error=self.error,
        )
