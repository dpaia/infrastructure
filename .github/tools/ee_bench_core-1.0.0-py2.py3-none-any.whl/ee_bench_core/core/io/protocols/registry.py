"""Registry for file protocol providers.

This module provides a plugin registry for discovering and managing
protocol providers that handle different URI schemes.
"""

import logging
from typing import Dict, List, Optional

from ee_bench_core.core.eval.base_plugin_registry import (
    BasePluginRegistry,
    PluginMetadata,
)
from .base import FileProtocolProvider

logger = logging.getLogger(__name__)


class ProtocolProviderRegistry(BasePluginRegistry[FileProtocolProvider]):
    """Registry for protocol provider plugins.

    Manages protocol providers and maps URI schemes to appropriate handlers.
    Uses entry point group: ee_bench.file_protocols
    """

    # Entry point group name
    ENTRY_POINT_GROUP = "ee_bench.file_protocols"

    def __init__(self, auto_discover: bool = True):
        """Initialize protocol provider registry.

        Args:
            auto_discover: If True, auto-discover providers from entry points
        """
        self._scheme_map: Dict[str, str] = {}  # scheme -> provider_name
        super().__init__(auto_discover=auto_discover)
        self._rebuild_scheme_map()

    def _get_plugin_type_name(self) -> str:
        """Get plugin type name for logging."""
        return "file protocol provider"

    def _is_plugin_enabled(self, name: str) -> bool:
        """Check if protocol provider should be enabled.

        Args:
            name: Provider name

        Returns:
            Always True (no disable mechanism for protocol providers)
        """
        return True

    def _get_metadata_attributes(self) -> Dict[str, str]:
        """Get attribute names for extracting metadata from provider classes.

        Returns:
            Mapping of metadata fields to attribute names
        """
        return {
            "name": "__provider_name__",
            "description": "__provider_description__",
            "version": "__provider_version__",
            "author": "__provider_author__",
            "schemes": "__provider_schemes__",
        }

    def _create_metadata(
        self,
        name: str,
        factory,
        description: str,
        version: str,
        author: str,
        tags: List[str],
        specs: List[str],
        entry_point: Optional[str] = None,
        **kwargs,
    ) -> PluginMetadata[FileProtocolProvider]:
        """Create metadata for protocol provider.

        Args:
            name: Provider name
            factory: Provider class or factory
            description: Description
            version: Version string
            author: Author name
            tags: Tags (unused for providers)
            specs: Specs (unused for providers)
            entry_point: Entry point name
            **kwargs: Additional metadata (schemes)

        Returns:
            PluginMetadata instance
        """
        metadata = PluginMetadata(
            name=name,
            factory=factory,
            description=description,
            version=version,
            author=author,
            tags=tags,
            specs=specs,
            entry_point=entry_point,
        )

        # Store schemes in metadata for later use
        if "schemes" in kwargs:
            metadata.schemes = kwargs["schemes"]

        return metadata

    def register(
        self,
        provider_class: type[FileProtocolProvider],
        name: Optional[str] = None,
        **kwargs,
    ) -> None:
        """Register a protocol provider.

        Args:
            provider_class: Provider class
            name: Optional override name
            **kwargs: Additional metadata
        """
        super().register(name or provider_class.__provider_name__, provider_class, **kwargs)
        self._rebuild_scheme_map()

    def get_provider_for_uri(self, uri: str) -> Optional[FileProtocolProvider]:
        """Get appropriate provider for a URI.

        Args:
            uri: URI to handle (e.g., "https://example.com/file.json")

        Returns:
            Provider instance or None if no provider handles this scheme
        """
        scheme = self._extract_scheme(uri)

        # Check scheme map
        if scheme in self._scheme_map:
            provider_name = self._scheme_map[scheme]
            provider_class = self.get(provider_name)
            # Instantiate the provider
            return provider_class()

        # Fallback: if no scheme, assume file://
        if scheme is None:
            if "file" in self._scheme_map:
                provider_name = self._scheme_map["file"]
                provider_class = self.get(provider_name)
                # Instantiate the provider
                return provider_class()

        return None

    def get_supported_schemes(self) -> List[str]:
        """Get list of all supported URI schemes.

        Returns:
            List of supported scheme strings
        """
        return sorted(self._scheme_map.keys())

    def _rebuild_scheme_map(self) -> None:
        """Rebuild the scheme -> provider mapping."""
        self._scheme_map.clear()

        for provider_name, metadata in self._plugins.items():
            # Get schemes from provider class
            provider_class = metadata.factory
            if hasattr(provider_class, "schemes"):
                schemes = provider_class.schemes()
                for scheme in schemes:
                    if scheme in self._scheme_map:
                        logger.warning(
                            f"Scheme '{scheme}' already mapped to provider "
                            f"'{self._scheme_map[scheme]}', overwriting with '{provider_name}'"
                        )
                    self._scheme_map[scheme] = provider_name
                    logger.debug(f"Mapped scheme '{scheme}' to provider '{provider_name}'")

    def _extract_scheme(self, uri: str) -> Optional[str]:
        """Extract scheme from URI.

        Args:
            uri: URI string

        Returns:
            Scheme string (lowercase) or None if no scheme found
        """
        from urllib.parse import urlparse

        parsed = urlparse(uri)
        return parsed.scheme.lower() if parsed.scheme else None

    def discover_plugins(self) -> None:
        """Discover protocol providers from entry points."""
        super().discover_plugins(self.ENTRY_POINT_GROUP)
        self._rebuild_scheme_map()
