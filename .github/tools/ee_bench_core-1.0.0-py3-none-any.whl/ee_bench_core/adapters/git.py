"""Git adapter for repository operations.

This module provides a unified interface for Git operations including
cloning repositories, checking out commits, and managing repository state.
"""

import logging
from pathlib import Path

from .process_manager import LocalProcessManager

logger = logging.getLogger(__name__)


class GitAdapter:
    """Adapter for Git operations.

    Provides methods for cloning repositories, checking out commits,
    resetting repository state, and querying repository information.
    """

    def __init__(self):
        """Initialize Git adapter."""
        self.process_manager = LocalProcessManager(debug_output=False)

    def clone_repository(
        self, repo_url: str, target_dir: Path, https_fallback: bool = True
    ) -> None:
        """Clone a Git repository.

        Args:
            repo_url: URL of the repository to clone (SSH or HTTPS)
            target_dir: Directory to clone repository into
            https_fallback: If True, try HTTPS if SSH clone fails

        Raises:
            RuntimeError: If cloning fails
        """
        if target_dir.exists():
            logger.info(f"Repository already exists: {target_dir}")
            return

        logger.info(f"Cloning repository: {repo_url}")
        result = self.process_manager.run_command(
            ["git", "clone", repo_url, str(target_dir)]
        )

        if result.returncode != 0:
            if https_fallback:
                logger.warning("SSH clone failed, trying HTTPS...")
                https_url = self._convert_to_https(repo_url)
                result = self.process_manager.run_command(
                    ["git", "clone", https_url, str(target_dir)]
                )
                if result.returncode != 0:
                    raise RuntimeError(
                        f"Failed to clone repository with both SSH and HTTPS: {result.stderr}"
                    )
            else:
                raise RuntimeError(f"Failed to clone repository: {result.stderr}")

        logger.info(f"Successfully cloned repository to: {target_dir}")

    def checkout_commit(self, repo_dir: Path, commit: str) -> None:
        """Checkout a specific commit in a repository.

        Args:
            repo_dir: Path to the repository
            commit: Commit hash to checkout

        Raises:
            RuntimeError: If checkout fails
        """
        if not repo_dir.exists():
            raise RuntimeError(f"Repository directory does not exist: {repo_dir}")

        logger.info(f"Checking out commit: {commit}")
        result = self.process_manager.run_command(
            ["git", "checkout", commit], cwd=repo_dir
        )

        if result.returncode != 0:
            raise RuntimeError(f"Failed to checkout commit {commit}: {result.stderr}")

    def reset_repository(self, repo_dir: Path) -> None:
        """Reset repository to a clean state.

        Performs git reset --hard HEAD and git clean -fd to remove
        all uncommitted changes and untracked files.

        Args:
            repo_dir: Path to the repository

        Raises:
            RuntimeError: If reset fails
        """
        if not repo_dir.exists():
            raise RuntimeError(f"Repository directory does not exist: {repo_dir}")

        logger.info("Resetting repository to clean state...")

        result = self.process_manager.run_command(
            ["git", "reset", "--hard", "HEAD"], cwd=repo_dir
        )
        if result.returncode != 0:
            raise RuntimeError(f"Failed to reset repository: {result.stderr}")

        result = self.process_manager.run_command(["git", "clean", "-fd"], cwd=repo_dir)
        if result.returncode != 0:
            raise RuntimeError(f"Failed to clean repository: {result.stderr}")

        logger.info("Repository reset successful")

    def get_current_commit(self, repo_dir: Path) -> str:
        """Get the current commit hash of a repository.

        Args:
            repo_dir: Path to the repository

        Returns:
            Current commit hash (full SHA-1)

        Raises:
            RuntimeError: If unable to get commit hash
        """
        if not repo_dir.exists():
            raise RuntimeError(f"Repository directory does not exist: {repo_dir}")

        result = self.process_manager.run_command(
            ["git", "rev-parse", "HEAD"], cwd=repo_dir
        )

        if result.returncode != 0:
            raise RuntimeError(f"Failed to get current commit: {result.stderr}")

        return result.stdout.strip()

    def has_changes(self, repo_dir: Path) -> bool:
        """Check if repository has uncommitted changes.

        Args:
            repo_dir: Path to the repository

        Returns:
            True if there are uncommitted changes, False otherwise

        Raises:
            RuntimeError: If unable to check status
        """
        if not repo_dir.exists():
            raise RuntimeError(f"Repository directory does not exist: {repo_dir}")

        result = self.process_manager.run_command(
            ["git", "status", "--porcelain"], cwd=repo_dir
        )

        if result.returncode != 0:
            raise RuntimeError(f"Failed to check repository status: {result.stderr}")

        return bool(result.stdout.strip())

    def _convert_to_https(self, repo_url: str) -> str:
        """Convert SSH repository URL to HTTPS.

        Args:
            repo_url: Repository URL (SSH or HTTPS)

        Returns:
            HTTPS repository URL
        """
        if repo_url.startswith("git@github.com:"):
            # Convert git@github.com:owner/repo.git to https://github.com/owner/repo.git
            path = repo_url[15:]  # Remove "git@github.com:"
            return f"https://github.com/{path}"
        else:
            return repo_url
