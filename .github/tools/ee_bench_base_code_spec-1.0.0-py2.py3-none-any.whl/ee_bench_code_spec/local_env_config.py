"""EE-bench local environment configuration.

This module provides the CodeLocalEnvironmentConfig class for local (non-Docker)
evaluation environments with EE-bench specific fields.
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

from ee_bench_core.adapters.local import LocalEnvironmentConfig


@dataclass
class CodeLocalEnvironmentConfig(LocalEnvironmentConfig):
    """Configuration for EE-bench local evaluation environments.

    Extends LocalEnvironmentConfig with EE-bench specific fields like
    repository information, project directory, and base commit.

    Attributes:
        workspace_dir: Local workspace directory path (from base class)
        env_vars: Environment variables for execution (from base class)
        repo: Repository name (owner/repo format)
        base_commit: Base commit hash
        project_dir: Project directory name relative to workspace_dir
        language: Programming language (e.g., "java", "python")
    """

    repo: Optional[str] = None
    """Repository name (owner/repo format)"""

    base_commit: Optional[str] = None
    """Base commit hash"""

    language: Optional[str] = None
    """Programming language"""

    def to_dict(self) -> Dict[str, Any]:
        """Convert environment config to dictionary format.

        Returns:
            Dictionary representation of the environment configuration
        """
        return {
            "sandbox_type": self.sandbox_type,
            "workspace_dir": str(self.workspace_dir),
            "env_vars": self.env_vars,
            "repo": self.repo,
            "base_commit": self.base_commit,
            "project_dir": self.project_dir,
            "language": self.language,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CodeLocalEnvironmentConfig":
        """Create CodeLocalEnvironmentConfig from dictionary.

        Args:
            data: Dictionary containing environment configuration

        Returns:
            CodeLocalEnvironmentConfig instance
        """
        return cls(
            workspace_dir=Path(data["workspace_dir"]),
            env_vars=data.get("env_vars", {}),
            repo=data.get("repo"),
            base_commit=data.get("base_commit"),
            project_dir=data.get("project_dir", "task_project"),
            language=data.get("language"),
        )
