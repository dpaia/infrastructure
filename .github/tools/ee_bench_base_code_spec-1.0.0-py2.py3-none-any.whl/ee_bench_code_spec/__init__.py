"""EE-bench specification implementation.

This package implements the EE-bench evaluation specification for
evaluating AI agents on software engineering tasks.
"""

from .config import CodeBenchmarkConfig
from .dataset import CodeDatasetManager
from .local_env_config import CodeLocalEnvironmentConfig

__all__ = [
    "CodeBenchmarkConfig",
    "CodeDatasetManager",
    "CodeLocalEnvironmentConfig",
    "CodePredictionsCollector",
]
