"""Gradle dependencies configurer for downloading and compiling Gradle projects.

This configurer downloads Gradle dependencies and compiles the project,
creating a dependencies image ready for evaluation.
"""


from ee_bench_core.core import EnvironmentConfig

from ee_bench_jvm_spec.jvm.base_dependencies_configurer import BaseDependenciesConfigurer
from ee_bench_jvm_spec.jvm.jvm_config import BuildSystem


class GradleDependenciesConfigurer(BaseDependenciesConfigurer):
    """Configurer that downloads Gradle dependencies and compiles project.

    This configurer runs on a cloned repository image and:
    - Downloads all Gradle dependencies
    - Compiles main and test source code
    - Produces a :dependencies image ready for evaluation

    Metadata:
        name: gradle_dependencies
        priority: 80 (after clone, before task setup)
        dependencies: after task_clone, before task_image
        specs: ["jvm"]
    """

    # Metadata for plugin discovery
    __configurer_name__ = "gradle_dependencies"
    __configurer_description__ = "Downloads Gradle dependencies and compiles project"
    __configurer_version__ = "1.0.0"
    __configurer_specs__ = ["jvm"]

    @property
    def build_system(self):
        """Return the BuildSystem enum for Gradle."""
        return BuildSystem.GRADLE

    @property
    def tool_name(self) -> str:
        """Return tool name."""
        return "gradle"

    def get_dependency_download_commands(self, env_config: EnvironmentConfig) -> list[str]:
        """Get commands to download Gradle dependencies.

        Returns:
            List of RUN commands for downloading dependencies with 'gradle' placeholder
        """
        # Always return command with "gradle" placeholder
        # Base class will replace it with the actual tool command (./gradlew or gradle)
        return [
            "gradle wrapper dependencies compileJava compileTestJava --no-daemon || true"
        ]

    # def generate_dockerfile(
    #     self,
    #     env_config: EnvironmentConfig,
    #     config: DatasetConfig,
    #     **kwargs,
    # ) -> str:
    #     """Generate Dockerfile with modules.json generation for dependencies image.
    #
    #     Overrides base class to add modules.json generation step before downloading dependencies.
    #
    #     Args:
    #         env_config: Environment configuration
    #         config: Dataset configuration
    #         **kwargs: Additional parameters
    #
    #     Returns:
    #         Dockerfile content as string
    #     """
    #     if not isinstance(env_config, DockerEnvironmentConfig):
    #         # Fall back to base implementation for non-Docker environments
    #         return super().generate_dockerfile(env_config, config, **kwargs)
    #
    #     base_image = env_config.image_name
    #     project_path = "/workspace/task_project"
    #     if hasattr(env_config, "project_path"):
    #         project_path = str(env_config.project_path)
    #     elif hasattr(env_config, "workspace_dir") and env_config.workspace_dir:
    #         project_path = str(env_config.workspace_dir)
    #
    #     # Get dependency download commands
    #     dependency_commands = self.get_dependency_download_commands(env_config)
    #
    #     # Read the generate-modules.gradle file and convert to echo commands
    #     script_path = Path(__file__).parent / "generate-modules.gradle"
    #     gradle_script_lines = script_path.read_text().splitlines()
    #
    #     # Build Dockerfile
    #     dockerfile = f"FROM {base_image}\n\nWORKDIR {project_path}\n\n"
    #
    #     # Add dependency download commands first (this initializes Gradle wrapper)
    #     dockerfile += f"# Download {self.tool_name.capitalize()} dependencies\n"
    #     for cmd in dependency_commands:
    #         dockerfile += f"RUN {cmd}\n"
    #
    #     # Add modules.json generation using Gradle init script (after wrapper initialization)
    #     # Note: Using gradle (not wrapper) since this runs in Docker with Gradle pre-installed
    #     # Using echo to write init script (heredoc doesn't work reliably in Dockerfiles)
    #     dockerfile += "\n# Generate modules.json for fast module detection\n"
    #
    #     # Write the init script using chained echo commands in a single RUN
    #     dockerfile += "RUN "
    #     first_line_written = False
    #     for i, line in enumerate(gradle_script_lines):
    #         # Skip empty lines and comments at the start for cleaner output
    #         if not line.strip() or (i < 2 and line.strip().startswith("//")):
    #             continue
    #
    #         # Escape single quotes in the line
    #         escaped_line = line.replace("'", "'\"'\"'")
    #
    #         # First line creates the file, subsequent lines append
    #         operator = ">" if not first_line_written else ">>"
    #
    #         if first_line_written:
    #             dockerfile += " && \\\n    "
    #         dockerfile += f"echo '{escaped_line}' {operator} /tmp/generate-modules.gradle"
    #         first_line_written = True
    #
    #     # Run the Gradle command to generate modules.json (chained with echo commands)
    #     dockerfile += " && \\\n    gradle --init-script /tmp/generate-modules.gradle generateModulesJson --no-daemon || true\n"
    #
    #     dockerfile += "\n"
    #     dockerfile += 'CMD ["/bin/bash"]\n'
    #
    #     return dockerfile
