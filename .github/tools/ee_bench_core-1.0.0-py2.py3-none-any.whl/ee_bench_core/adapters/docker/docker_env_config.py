"""Docker environment configuration.

This module provides base configuration for Docker-based environments.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional

from ee_bench_core.core.base_config import BaseEnvironmentConfig


@dataclass
class DockerEnvironmentConfig(BaseEnvironmentConfig):
    """Base configuration for Docker-based evaluation environments.

    This class provides common fields for Docker environments including
    container management, image tracking, and workspace configuration.
    """

    instance_id: str = ""
    """Unique identifier for the task instance"""

    image_name: Optional[str] = None
    """Docker image name/tag for the environment"""

    container_id: Optional[str] = None
    """Running container ID (if started)"""

    created_at: Optional[str] = None
    """ISO timestamp when environment was created"""

    related_images: Dict[str, str] = field(default_factory=dict)
    """Map of related image types to their names (e.g., 'base': 'base-image-name')"""

    labels: Dict[str, str] = field(default_factory=dict)
    """Docker labels for the environment image"""

    @property
    def sandbox_type(self) -> str:
        """Get the sandbox type identifier.

        Returns:
            Sandbox type string ('docker')
        """
        return "docker"

    def get_base_image(self) -> Optional[str]:
        """Get base image name if available.

        Returns:
            Base image name or None if not set
        """
        return self.related_images.get("base")

    def set_base_image(self, image_name: str) -> None:
        """Set base image name.

        Args:
            image_name: Base image name to store
        """
        self.related_images["base"] = image_name

    def to_dict(self) -> Dict[str, Any]:
        """Convert environment config to dictionary format.

        Returns:
            Dictionary representation of the environment configuration
        """
        return {
            "instance_id": self.instance_id,
            "image_name": self.image_name,
            "workspace_dir": str(self.workspace_dir) if self.workspace_dir else None,
            "project_dir": self.project_dir,
            "container_id": self.container_id,
            "created_at": self.created_at,
            "related_images": self.related_images,
            "labels": self.labels,
            "env_vars": self.env_vars,
            "configurers": self.configurers,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DockerEnvironmentConfig":
        """Create CodeEnvironmentConfig from dictionary.

        Args:
            data: Dictionary containing environment configuration

        Returns:
            CodeEnvironmentConfig instance
        """
        workspace_dir = data.get("workspace_dir")

        return cls(
            instance_id=data["instance_id"],
            image_name=data["image_name"],
            workspace_dir=Path(workspace_dir) if workspace_dir else None,
            project_dir=data.get("project_dir", "task_project"),
            container_id=data.get("container_id"),
            created_at=data.get("created_at"),
            related_images=data["related_images"],
            env_vars=data.get("env_vars", {}),
            configurers=data.get("configurers", {}),
        )
