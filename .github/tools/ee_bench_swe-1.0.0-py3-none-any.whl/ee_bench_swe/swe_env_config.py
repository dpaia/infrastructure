"""SWE-bench environment configuration.

This module provides the SweEnvironmentConfig class for Docker-based
evaluation environments.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional

from ee_bench_core.adapters.docker.docker_env_config import DockerEnvironmentConfig


@dataclass
class SweEnvironmentConfig(DockerEnvironmentConfig):
    """Configuration for a SWE-bench Docker environment.

    Extends DockerEnvironmentConfig with SWE-bench specific fields like
    repository information and language.
    """

    repo: Optional[str] = None
    """Repository name (owner/repo format)"""

    base_commit: Optional[str] = None
    """Base commit hash"""

    language: Optional[str] = None
    """Programming language"""

    project_dir: str = "task_project"
    """Project directory name relative to workspace_dir (default: task_project)"""

    @property
    def project_path(self) -> Path:
        """Get full path to project directory.

        Returns:
            Full path combining workspace_dir and project_dir
        """
        if self.workspace_dir:
            return self.workspace_dir / self.project_dir
        return Path(self.project_dir)

    def __post_init__(self):
        """Initialize related_images with base_image if provided."""
        # Support legacy base_image_name attribute
        if hasattr(self, '_base_image_name') and self._base_image_name:
            self.related_images["base"] = self._base_image_name

    @property
    def base_image_name(self) -> Optional[str]:
        """Get base image name for backwards compatibility.

        Returns:
            Base image name from related_images
        """
        return self.related_images.get("base")

    @base_image_name.setter
    def base_image_name(self, value: str) -> None:
        """Set base image name for backwards compatibility.

        Args:
            value: Base image name to set
        """
        self.related_images["base"] = value

    def to_dict(self) -> Dict[str, Any]:
        """Convert environment config to dictionary format.

        Returns:
            Dictionary representation of the environment configuration
        """
        return {
            "instance_id": self.instance_id,
            "image_name": self.image_name,
            "base_image_name": self.base_image_name,  # For backwards compatibility
            "workspace_dir": str(self.workspace_dir) if self.workspace_dir else None,
            "project_dir": self.project_dir,
            "repo": self.repo,
            "base_commit": self.base_commit,
            "language": self.language,
            "container_id": self.container_id,
            "created_at": self.created_at,
            "related_images": self.related_images,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SweEnvironmentConfig":
        """Create SweEnvironmentConfig from dictionary.

        Args:
            data: Dictionary containing environment configuration

        Returns:
            SweEnvironmentConfig instance
        """
        workspace_dir = data.get("workspace_dir")

        # Support both new related_images and legacy base_image_name
        related_images = data.get("related_images", {})
        if "base_image_name" in data and "base" not in related_images:
            related_images["base"] = data["base_image_name"]

        return cls(
            instance_id=data["instance_id"],
            image_name=data["image_name"],
            workspace_dir=Path(workspace_dir) if workspace_dir else None,
            project_dir=data.get("project_dir", "task_project"),
            repo=data.get("repo"),
            base_commit=data.get("base_commit"),
            language=data.get("language"),
            container_id=data.get("container_id"),
            created_at=data.get("created_at"),
            related_images=related_images,
        )
