"""Adapters for shared integrations across specifications.

This package contains reusable adapters for common operations like Docker,
Git, patch management, and test running. These adapters can be used by
any specification implementation.
"""

from .docker import DockerAdapter
from .docker.docker_process_manager import DockerProcessManager
from .docker.docker_sandbox import DockerSandbox
from .git import GitAdapter
from .junit_parser import parse_junit_report
from .patch import PatchAdapter, PatchCollectorAdapter
from .process_manager import LocalProcessManager, ProcessManager, ProcessResult
from .process_manager_factory import ProcessManagerFactory
from .sandbox_base import Sandbox, SandboxStatus
from .sandbox_factory import SandboxFactory
from .testrunner_base import TestResult, TestRunner

__all__ = [
    # Docker
    "DockerAdapter",
    "DockerProcessManager",
    "DockerSandbox",
    # Git
    "GitAdapter",
    # Patch
    "PatchAdapter",
    "PatchCollectorAdapter",
    # Process (legacy - use Sandbox instead)
    "ProcessManager",
    "ProcessResult",
    "LocalProcessManager",
    "ProcessManagerFactory",
    # Sandbox (new API)
    "Sandbox",
    "SandboxStatus",
    "SandboxFactory",
    # Test runners
    "TestRunner",
    "TestResult",
    # JUnit parser
    "parse_junit_report",
]
