"""Helper utilities for environment configuration loading and building.

This module provides reusable helper functions for loading pre-configured
environments or building ad-hoc environment configurations.
"""

import logging
from pathlib import Path
from typing import Dict, List, Optional

from ..environment_serializer import EnvironmentSerializerManager
from ..models import EnvironmentConfig

logger = logging.getLogger(__name__)


def load_or_build_environments(
    instance_ids: Optional[List[str]] = None, **kwargs
) -> tuple[Dict[str, EnvironmentConfig], List[str]]:
    """Load pre-configured environments or build ad-hoc environment config.

    This is a helper function to consolidate environment loading/building logic
    used across multiple orchestration methods. It also validates parameters and
    adjusts instance_ids for ad-hoc mode.

    Args:
        instance_ids: Optional list of instance IDs to filter (for pre-configured mode)
        **kwargs: Parameters including:
                 - environment_config_path: Path to pre-configured environment file
                 - sandbox: Sandbox type (docker/local) for ad-hoc mode
                 - container_id: Docker container ID for ad-hoc mode
                 - container_image: Docker image for ad-hoc mode
                 - workspace_dir: Workspace directory for ad-hoc mode
                 - project_dir: Project directory for local mode
                 - env_vars: Environment variables dictionary

    Returns:
        Tuple of (environments, adjusted_instance_ids):
        - environments: Dict mapping instance_id to EnvironmentConfig
          - Pre-configured mode (with filtering): {instance_id: EnvironmentConfig, ...} filtered by instance_ids
          - Pre-configured mode (no filtering): {instance_id: EnvironmentConfig, ...} all environments
          - Ad-hoc mode: {"adhoc": EnvironmentConfig}
        - adjusted_instance_ids: List of instance IDs (adjusted for ad-hoc mode if needed)

    Raises:
        ValueError: If required parameters are missing or invalid
        FileNotFoundError: If environment_config_path file not found
    """
    env_serializer = EnvironmentSerializerManager()
    environment_config_path = kwargs.get("environment_config_path")
    sandbox = kwargs.get("sandbox")
    container_id = kwargs.get("container_id")
    container_image = kwargs.get("container_image")
    workspace_dir = kwargs.get("workspace_dir")
    cli_env_vars = kwargs.get("env_vars", {})

    environments: Dict[str, EnvironmentConfig] = {}
    adjusted_instance_ids = instance_ids or []

    # Validate parameters based on mode
    if environment_config_path:
        # Pre-configured mode: require instance_ids for filtering
        if instance_ids and not instance_ids:
            raise ValueError(
                "instance_ids must be provided when using environment_config_path"
            )
    elif sandbox and workspace_dir:
        # Ad-hoc mode: both sandbox and workspace_dir must be provided
        # Force instance_ids to ['adhoc'] for ad-hoc mode
        if not instance_ids:
            adjusted_instance_ids = ["adhoc"]
        elif instance_ids != ["adhoc"]:
            logger.warning(
                f"Ad-hoc mode ignores provided instance_ids {instance_ids}; using single 'adhoc' instance"
            )
            adjusted_instance_ids = ["adhoc"]
    else:
        # Neither pre-configured mode nor ad-hoc mode - return empty results
        # This happens when:
        # - No environment_config_path provided AND
        # - Either sandbox or workspace_dir (or both) missing
        logger.debug(
            "No valid environment configuration provided. "
            "Provide either environment_config_path OR (sandbox + workspace_dir)."
        )
        return {}, adjusted_instance_ids

    if environment_config_path:
        # Pre-configured mode: load environments from file
        logger.debug(
            f"Loading pre-configured environments from {environment_config_path}"
        )
        try:
            environments = env_serializer.load_from_file(Path(environment_config_path))
            if workspace_dir:
                for env in environments.values():
                    if hasattr(env, "workspace_dir"):
                        env.workspace_dir = Path(workspace_dir)

            if container_id:
                for env in environments.values():
                    if hasattr(env, "container_id"):
                        env.container_id = container_id

            if container_image:
                for env in environments.values():
                    if hasattr(env, "image_name"):
                        env.image_name = container_image

            if cli_env_vars:
                for env in environments.values():
                    if hasattr(env, "env_vars"):
                        env.env_vars.update(cli_env_vars)

            logger.info(
                f"Loaded {len(environments)} pre-configured environment(s) "
                f"from {environment_config_path}"
            )
        except FileNotFoundError:
            logger.warning(
                f"Environment config file not found: {environment_config_path}. "
                f"Will create environments from scratch."
            )
        except Exception as e:
            logger.warning(
                f"Failed to load environment configs from {environment_config_path}: {e}. "
                f"Will create environments from scratch."
            )

    elif sandbox and workspace_dir:
        # Ad-hoc mode: build environment from parameters
        logger.info("Ad-hoc mode: building environment from parameters")

        # Build environment config based on sandbox type
        if sandbox == "local":
            from ee_bench_core.adapters.local.local_env_config import (
                LocalEnvironmentConfig,
            )

            ad_hoc_env_config = LocalEnvironmentConfig(
                workspace_dir=Path(workspace_dir),
                project_dir=kwargs.get("project_dir", "task_project"),
                env_vars=cli_env_vars,
            )

        elif sandbox == "docker":
            from ee_bench_core.adapters.docker.docker_env_config import (
                DockerEnvironmentConfig,
            )
            from ee_bench_core.adapters import DockerAdapter

            if not container_id and not container_image:
                raise ValueError(
                    "Either --container-id or --container-image is required for docker sandbox in ad-hoc mode"
                )

            # Handle ephemeral container creation
            if not container_id and container_image:
                logger.info(
                    f"Starting ephemeral container from image: {container_image}"
                )
                docker_adapter = DockerAdapter()

                # Create and start long-running container using run_container with detach=True
                container_id = docker_adapter.run_container(
                    image=container_image,
                    working_dir=workspace_dir,
                    detach=True,
                )
                logger.info(f"Started ephemeral container: {container_id}")

                # Store container_id in kwargs so cleanup can happen
                kwargs["_ephemeral_container_id"] = container_id

            ad_hoc_env_config = DockerEnvironmentConfig(
                instance_id="adhoc",
                image_name=container_image,
                workspace_dir=Path(workspace_dir) if workspace_dir else None,
                container_id=container_id,
                env_vars=cli_env_vars,
            )

        else:
            raise ValueError(f"Unsupported sandbox type: {sandbox}")

        logger.info(f"Created ad-hoc environment config with sandbox={sandbox}")

        # Return ad-hoc environment with "adhoc" key
        environments["adhoc"] = ad_hoc_env_config

    # Filter by instance_ids if provided (only for pre-configured mode)
    if adjusted_instance_ids and environment_config_path and environments:
        filtered_environments = {
            iid: environments[iid]
            for iid in adjusted_instance_ids
            if iid in environments
        }
        # Validate all instance_ids were found
        missing = [iid for iid in adjusted_instance_ids if iid not in environments]
        if missing:
            raise ValueError(f"Instance IDs not found in environment config: {missing}")
        return filtered_environments, adjusted_instance_ids

    return environments, adjusted_instance_ids
