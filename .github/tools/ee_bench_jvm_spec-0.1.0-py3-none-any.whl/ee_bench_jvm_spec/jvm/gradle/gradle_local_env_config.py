"""Gradle-specific local environment configuration."""

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ee_bench_jvm_spec.jvm.jvm_local_env_config import JvmCodeLocalEnvironmentConfig


@dataclass
class GradleLocalEnvironmentConfig(JvmCodeLocalEnvironmentConfig):
    """Configuration for Gradle local evaluation environments.

    Extends JvmCodeLocalEnvironmentConfig with Gradle-specific fields.

    Attributes:
        Inherited from JvmCodeLocalEnvironmentConfig:
            workspace_dir: Local workspace directory path
            env_vars: Environment variables for execution
            repo: Repository name (owner/repo format)
            base_commit: Base commit hash
            project_dir: Project directory name
            language: Programming language (should be "java")
            java_home: Path to JDK installation
            java_version: Java version string
            gradle_home: Path to Gradle installation
            gradle_version: Gradle version string
            build_system: Build system being used (should be "gradle")

        Gradle-specific attributes:
            gradle_wrapper_path: Path to Gradle wrapper (./gradlew) if available
            gradle_opts: Gradle options (e.g., "-Xmx2g")
            use_wrapper: Whether to use Gradle wrapper instead of system Gradle
    """

    gradle_wrapper_path: Path | None = None
    """Path to Gradle wrapper (./gradlew) if available"""

    gradle_opts: str | None = None
    """Gradle options (e.g., '-Xmx2g')"""

    use_wrapper: bool = False
    """Whether to use Gradle wrapper instead of system Gradle"""

    def __post_init__(self):
        """Set build_system to gradle."""
        super().__post_init__() if hasattr(super(), "__post_init__") else None
        self.build_system = "gradle"
        self.language = "java"

    @property
    def gradle_command(self) -> str:
        """Get the Gradle command to use (wrapper or system).

        Returns:
            Gradle command string (e.g., "./gradlew" or "gradle")
        """
        if self.use_wrapper and self.gradle_wrapper_path:
            return str(self.gradle_wrapper_path)
        return "gradle"

    def to_dict(self) -> dict[str, Any]:
        """Convert environment config to dictionary format.

        Returns:
            Dictionary representation of the environment configuration
        """
        result = super().to_dict()
        result.update(
            {
                "gradle_wrapper_path": (
                    str(self.gradle_wrapper_path) if self.gradle_wrapper_path else None
                ),
                "gradle_opts": self.gradle_opts,
                "use_wrapper": self.use_wrapper,
            }
        )
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "GradleLocalEnvironmentConfig":
        """Create GradleLocalEnvironmentConfig from dictionary.

        Args:
            data: Dictionary containing environment configuration

        Returns:
            GradleLocalEnvironmentConfig instance
        """
        return cls(
            workspace_dir=Path(data["workspace_dir"]),
            env_vars=data.get("env_vars", {}),
            repo=data.get("repo"),
            base_commit=data.get("base_commit"),
            project_dir=data.get("project_dir", "task_project"),
            language=data.get("language", "java"),
            java_home=Path(data["java_home"]) if data.get("java_home") else None,
            java_version=data.get("java_version"),
            maven_home=Path(data["maven_home"]) if data.get("maven_home") else None,
            maven_version=data.get("maven_version"),
            gradle_home=Path(data["gradle_home"]) if data.get("gradle_home") else None,
            gradle_version=data.get("gradle_version"),
            build_system=data.get("build_system", "gradle"),
            gradle_wrapper_path=(
                Path(data["gradle_wrapper_path"]) if data.get("gradle_wrapper_path") else None
            ),
            gradle_opts=data.get("gradle_opts"),
            use_wrapper=data.get("use_wrapper", False),
        )
