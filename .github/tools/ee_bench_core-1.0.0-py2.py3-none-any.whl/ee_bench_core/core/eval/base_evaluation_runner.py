"""Base evaluation runner implementation using evaluator pipelines.

This module provides BaseEvaluationRunner which implements the EvaluationRunner
interface using the new evaluator pipeline architecture.
"""

import logging
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ee_bench_core.core.abc_types import (
    DatasetConfig,
    EnvironmentConfig,
    EvaluationRunner,
)
from .evaluator import Evaluator
from ee_bench_core.core.eval.evaluator_runner import (
    EvaluationRunner as PipelineRunner,
    PipelineEvaluationResult,
)
from ee_bench_core.core.models import EvaluationResult, ResultStatus

if TYPE_CHECKING:
    from ee_bench_core.adapters import Sandbox
    from ee_bench_core.core.base_spec import BaseEvalSpec
    from ee_bench_core.core.eval.score_evaluator import FinalScore

logger = logging.getLogger(__name__)


class BaseEvaluationRunner(EvaluationRunner):
    """Base evaluation runner using evaluator pipeline.

    This runner implements the EvaluationRunner interface by delegating to
    the new PipelineRunner (evaluator pipeline) architecture.
    """

    def __init__(
        self,
        spec: "BaseEvalSpec",
        evaluators: List[Evaluator],
        max_workers: int = 1,
        default_timeout: int = 1800,
        report_manager: Optional[Any] = None,
    ):
        """Initialize base evaluation runner.

        Args:
            spec: Evaluation specification that created this runner
            evaluators: List of evaluators to execute in pipeline
            max_workers: Maximum number of parallel workers for async evaluators
            default_timeout: Default timeout in seconds for evaluator execution
            report_manager: Optional report manager for tracking results
        """
        super().__init__(report_manager)
        self.spec = spec
        self.evaluators = evaluators
        self.max_workers = max_workers
        self.default_timeout = default_timeout

        # Create pipeline runner
        self.pipeline_runner = PipelineRunner(
            evaluators=evaluators,
            max_workers=max_workers,
            default_timeout=default_timeout,
        )

    def run_evaluation(
        self,
        config: DatasetConfig,
        sandbox: "Sandbox",
        timeout: int = 1800,
        run_id: str = "default",
        **kwargs,
    ) -> EvaluationResult:
        """Run evaluation for a task using evaluator pipeline.

        Args:
            config: Dataset configuration
            sandbox: Sandbox instance with environment configuration
                    (env_config accessible via sandbox.env_config if needed)
            timeout: Maximum execution time in seconds
            run_id: Unique identifier for the evaluation run
            **kwargs: Additional spec-specific parameters
                Common kwargs:
                - test_runner: Test runner instance
                - patch_adapter: Patch adapter instance
                - docker_adapter: Docker adapter instance
                - prediction_patch: Prediction patch content

        Returns:
            EvaluationResult with outcome

        Raises:
            EvaluationError: If evaluation fails
        """
        logger.debug(
            f"Running evaluation for {config.instance_id} using evaluator pipeline "
            f"(run_id={run_id}, evaluators={len(self.evaluators)})"
        )

        # Get env_config from sandbox
        env_config = sandbox.env_config

        # Run pipeline evaluation, passing sandbox explicitly
        pipeline_result: PipelineEvaluationResult = self.pipeline_runner.run_evaluation(spec=self.spec, sandbox=sandbox,
                                                                                        config=config, run_id=run_id,
                                                                                        timeout=timeout, **kwargs)

        # Convert PipelineEvaluationResult to EvaluationResult
        # This is a concrete implementation that wraps the pipeline result
        evaluation_result = PipelineEvaluationResultAdapter(
            pipeline_result=pipeline_result, config=config, env_config=env_config
        )

        # Report result to ReportManager if available
        if self.report_manager:
            self.report_manager.set_result(config.instance_id, evaluation_result)

        return evaluation_result


class PipelineEvaluationResultAdapter(EvaluationResult):
    """Adapter that wraps PipelineEvaluationResult as EvaluationResult.

    This allows the pipeline result to be used wherever EvaluationResult
    is expected, implementing the abstract interface.
    """

    def __init__(
        self,
        pipeline_result: PipelineEvaluationResult,
        config: DatasetConfig,
        env_config: Optional[EnvironmentConfig] = None,
        score: Optional["FinalScore"] = None,
    ):
        """Initialize adapter.

        Args:
            pipeline_result: Pipeline evaluation result to wrap
            config: Dataset configuration for context
        """
        self._pipeline_result = pipeline_result
        self._config = config
        self._env_config = env_config
        self._score = score

    @property
    def instance_id(self) -> str:
        """Get the unique identifier for the evaluated task."""
        return self._pipeline_result.instance_id

    @property
    def result(self) -> ResultStatus:
        """Get the result status of the evaluation."""
        return self._pipeline_result.result

    @property
    def reason(self) -> str:
        """Get the reason for success or failure."""
        return self._pipeline_result.message

    @property
    def execution_time(self) -> float:
        """Get the execution time in seconds."""
        return self._pipeline_result.duration

    @property
    def score(self) -> "FinalScore":
        return self._score

    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary format."""
        return {
            "instance_id": self._pipeline_result.instance_id,
            "environment": self._env_config.to_dict() if self._env_config else None,
            "result": self._pipeline_result.result.value,
            "successful": self._pipeline_result.successful,
            "duration": self._pipeline_result.duration,
            "message": self._pipeline_result.message,
            "error": self._pipeline_result.error,
            "score": self._score.to_dict() if self._score else None,
            "evaluations": self._pipeline_result.evaluations,
        }
