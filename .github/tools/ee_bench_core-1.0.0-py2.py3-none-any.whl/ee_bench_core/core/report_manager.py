"""Report management for async evaluation tracking.

This module provides the report manager implementation and the
SummaryReport data structure for tracking evaluation progress.
"""

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

from .abc_types import ReportManager as AbstractReportManager
from .models import ResultStatus, Reportable
from .utils.io import read_json_file, write_json_file

logger = logging.getLogger(__name__)


@dataclass
class SummaryReport:
    """Summary evaluation report structure.

    Tracks the overall progress and results of an evaluation run.
    Uses a flexible status_counts dictionary to support any status categories.
    """

    spec_name: str = ""
    """Name of the specification being evaluated"""

    run_id: str = ""
    """Unique identifier for run"""

    report_type: str = "evaluation"
    """Type of report (e.g., 'evaluation', 'environment_preparation')"""

    total_items: int = 0
    """Total number of items (tasks/environments) in this report"""

    status_counts: Dict[ResultStatus, int] = field(default_factory=dict)
    """Counts by status (e.g., {'success': 5, 'failed': 2, 'skipped': 1})"""

    results: Dict[str, Reportable] = field(default_factory=dict)
    """Mapping of instance_id to result dictionary"""

    completed: bool = False
    """Whether the evaluation run is completed"""

    started_at: Optional[str] = None
    """ISO timestamp when evaluation started"""

    completed_at: Optional[str] = None
    """ISO timestamp when evaluation completed"""

    def to_dict(self) -> Dict[str, Any]:
        """Convert report to dictionary format.

        Returns:
            Dictionary representation of the report.
            Includes both new format (status_counts) and legacy format (explicit counts)
            for backward compatibility.
        """
        # Convert results - handle both Reportable objects and plain dicts
        results_dict = {}
        for instance_id, result in self.results.items():
            if hasattr(result, "to_dict"):
                results_dict[instance_id] = result.to_dict()
            else:
                # Already a dict
                results_dict[instance_id] = result

        return {
            # New format
            "spec_name": self.spec_name,
            "run_id": self.run_id,
            "report_type": self.report_type,
            "total_items": self.total_items,
            "status_counts": {
                status.value: count for status, count in self.status_counts.items()
            },
            "results": results_dict,
            "completed": self.completed,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SummaryReport":
        """Create a SummaryReport from a dictionary.

        Supports both new format (status_counts) and legacy format (explicit counts)
        for backward compatibility. If both are present, new format takes precedence.

        Args:
            data: Dictionary containing report data

        Returns:
            SummaryReport instance
        """
        # Convert string keys back to ResultStatus enums
        status_counts_raw = data["status_counts"]
        status_counts = {
            ResultStatus(status_str): count
            for status_str, count in status_counts_raw.items()
        }
        total_items = data.get("total_items", 0)

        return cls(
            spec_name=data.get("spec_name", ""),
            run_id=data.get("run_id", ""),
            report_type=data.get("report_type", "evaluation"),
            total_items=total_items,
            status_counts=status_counts,
            results=data.get("results", {}),
            completed=data.get("completed", False),
            started_at=data.get("started_at"),
            completed_at=data.get("completed_at"),
        )


class ReportManager(AbstractReportManager):
    """Report manager with file persistence.

    Provides thread-safe management of evaluation reports with atomic file writes.
    Reports are stored in report_dir/{report_name}.json format.

    Supports protocol-based reporting - any object implementing the Reportable protocol
    (with to_dict() and result() methods) can be reported.
    """

    def __init__(
        self,
        report_name: str,
        report_dir: Path,
        spec_name: str,
        report_type: str = "evaluation",
        run_id: Optional[str] = None,
    ):
        """Initialize report manager.

        Args:
            report_dir: Directory where report files are stored
            spec_name: Name of the specification being evaluated
            report_type: Type of report (e.g., 'evaluation', 'environment_preparation')
        """
        self.report_dir = Path(report_dir)
        self.spec_name = spec_name
        self.report_type = report_type
        self.report_name = report_name
        self.run_id = run_id

        # Ensure report directory exists
        self.report_dir.mkdir(parents=True, exist_ok=True)

        # Try to load existing report, otherwise create new one
        report_path = self._get_report_path()
        if report_path.exists():
            try:
                data = read_json_file(report_path)
                self.summary_report = SummaryReport.from_dict(data)
                logger.debug(f"Loaded existing report from {report_path}")
            except Exception as e:
                logger.warning(
                    f"Failed to load existing report from {report_path}: {e}"
                )
                # Create new report if loading fails
                self.summary_report = SummaryReport(
                    spec_name=spec_name,
                    report_type=report_type,
                    run_id=run_id,
                    started_at=datetime.now(timezone.utc).isoformat(),
                )
        else:
            # Create new report
            self.summary_report = SummaryReport(
                spec_name=spec_name,
                report_type=report_type,
                run_id=run_id,
                started_at=datetime.now(timezone.utc).isoformat(),
            )

    def _get_report_path(self) -> Path:
        """Get the file path for a specific run_id's report.

        Returns:
            Path to the report file
        """
        return self.report_dir / f"{self.report_name}.json"

    def _write_report(self, report: SummaryReport) -> None:
        """Write report to file atomically.

        Args:
            run_id: Unique identifier for the evaluation run
            report: Report to write

        Uses write_json_file which performs atomic writes to prevent
        corruption from concurrent access.
        """
        report_path = self._get_report_path()

        try:
            write_json_file(report_path, report.to_dict(), indent=2)
            logger.debug(f"Wrote report to {report_path}")
        except Exception as e:
            logger.error(f"Failed to write report to {report_path}: {e}")
            raise

    def set_result(self, instance_id: str, result: Reportable) -> None:
        """Set result for a task instance (protocol-based).

        This method is thread-safe and can be called asynchronously
        from multiple evaluations running in parallel or from external
        evaluation services. Accepts any object implementing the Reportable
        protocol (with to_dict() and result() methods).

        Args:
            instance_id: Task instance identifier
            result: Result object (must implement Reportable protocol)

        Raises:
            TypeError: If result doesn't implement Reportable protocol
        """

        report = self.summary_report

        # Get new result status
        result_status = result.result

        # Check if result already exists
        if instance_id in report.results:
            logger.warning(
                f"Result for instance {instance_id} already exists. "
                f"Overwriting with new result."
            )
            # Decrement old status count
            old_result = report.results[instance_id]
            # Handle both Reportable objects and plain dicts from loaded reports
            if hasattr(old_result, "result"):
                old_result_status = old_result.result
            else:
                # old_result is a dict from loaded report
                status_str = old_result.get("status")
                old_result_status = (
                    ResultStatus(status_str) if status_str else ResultStatus.FAILED
                )

            if old_result_status and old_result_status in report.status_counts:
                report.status_counts[old_result_status] -= 1
                # Remove key if count reaches zero
                if report.status_counts[old_result_status] <= 0:
                    del report.status_counts[old_result_status]

        # Store new result
        report.results[instance_id] = result

        # Increment new status count
        if result_status not in report.status_counts:
            report.status_counts[result_status] = 0
        report.status_counts[result_status] += 1

        # Always infer total_items from actual results count
        report.total_items = len(report.results)

        # Write report
        self._write_report(report)
        logger.debug(f"Set result for {instance_id}")

    def get_report(self) -> SummaryReport:
        """Get current report snapshot for a specific run.

        Loads the report from report_dir/{report_name}.json file.

        Returns:
            Current report state (deep copy)
        """
        report_path = self._get_report_path()

        if not report_path.exists():
            # Return empty report if file doesn't exist
            return SummaryReport(
                spec_name=self.spec_name,
                run_id=self.run_id,
                report_type=self.report_type,
            )

        try:
            data = read_json_file(report_path)
            return SummaryReport.from_dict(data)
        except Exception as e:
            logger.warning(f"Failed to load report from {report_path}: {e}")
            return SummaryReport(
                spec_name=self.spec_name,
                run_id=self.run_id,
                report_type=self.report_type,
            )

    def mark_completed(self) -> None:
        """Mark the evaluation run as completed."""
        report = self.summary_report
        report.completed = True
        report.completed_at = datetime.now(timezone.utc).isoformat()
        self._write_report(report)
        logger.info("Marked report as completed")
