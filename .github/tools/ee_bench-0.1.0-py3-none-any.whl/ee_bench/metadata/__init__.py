"""ee_bench.metadata - Metadata enrichment provider for ee_bench.generator.

This package provides enrichment providers that extract metadata fields
from ``<!--METADATA-->`` blocks and markdown ``##`` sections in text
(e.g. PR bodies).
"""

from ee_bench.metadata.provider import MetadataProvider
from ee_bench.metadata.section_provider import SectionProvider

__version__ = "0.1.0"

__all__ = [
    "MetadataProvider",
    "SectionProvider",
]
