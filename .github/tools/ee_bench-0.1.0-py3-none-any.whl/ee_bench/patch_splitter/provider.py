"""PatchSplitterProvider - splits unified diffs into source and test patches."""

from __future__ import annotations

import fnmatch
import logging
import re
from typing import Any

from ee_bench.generator import Provider

# Patterns that identify test files across common languages/frameworks
_TEST_PATTERNS = [
    r"^tests?/",
    r"/test/",
    r"/tests/",
    r"_test\.",
    r"Test\.",
    r"Tests\.",
    r"/src/test/",
    r"/main/test/",
    r"/spec/",
    r"/specs/",
    r"_spec\.",
    r"Spec\.",
    r"__tests__",
    r"__test__",
    r"_test_",
    r"test_",
]

logger = logging.getLogger(__name__)


def is_test_file(file_path: str) -> bool:
    """Determine whether *file_path* belongs to a test directory or follows a test-file naming convention."""
    return any(re.search(p, file_path, re.IGNORECASE) for p in _TEST_PATTERNS)


def _is_excluded(file_path: str, exclude_paths: list[str]) -> bool:
    """Check if *file_path* starts with any of the *exclude_paths* prefixes."""
    return any(file_path.startswith(prefix) for prefix in exclude_paths)


def _matches_any_glob(file_path: str, patterns: list[str]) -> bool:
    """Check if *file_path* matches any of the glob *patterns*.

    Uses :func:`fnmatch.fnmatch` with ``*`` matching ``/`` (the default on
    POSIX), so ``test/*`` matches ``test/foo/bar.py``.
    """
    return any(fnmatch.fnmatch(file_path, p) for p in patterns)


def split_patch(
    patch: str,
    exclude_paths: list[str] | None = None,
    test_patterns: list[str] | None = None,
    source_patterns: list[str] | None = None,
) -> tuple[str, str]:
    """Split a unified diff into ``(source_patch, test_patch)``.

    Args:
        patch: Full unified diff.
        exclude_paths: File path prefixes to exclude from both patches
            (e.g. ``[".ee-bench/"]`` to drop infrastructure files).
        test_patterns: Glob patterns for files that belong in the test patch.
            Overrides the heuristic, but is overridden by *source_patterns*.
        source_patterns: Glob patterns for files that belong in the source patch.
            Highest priority — overrides both *test_patterns* and the heuristic.
    """
    if not patch or not patch.strip():
        return ("", "")

    parts = re.split(r"(diff --git )", patch)

    file_diffs: list[str] = []
    for i in range(1, len(parts), 2):
        if i + 1 < len(parts):
            file_diffs.append(parts[i] + parts[i + 1])

    if not file_diffs:
        return (patch, "")

    exclude = exclude_paths or []
    source_diffs: list[str] = []
    test_diffs: list[str] = []

    for diff in file_diffs:
        match = re.search(r"diff --git a/(.*?) b/", diff)
        if not match:
            source_diffs.append(diff)
            continue

        file_path = match.group(1)
        if exclude and _is_excluded(file_path, exclude):
            continue

        # Classification precedence:
        # 1. source_patterns match → source (highest priority)
        # 2. test_patterns match → test
        # 3. Fall through to heuristic
        if source_patterns and _matches_any_glob(file_path, source_patterns):
            source_diffs.append(diff)
        elif test_patterns and _matches_any_glob(file_path, test_patterns):
            test_diffs.append(diff)
        elif is_test_file(file_path):
            test_diffs.append(diff)
        else:
            source_diffs.append(diff)

    if not source_diffs and test_diffs and not exclude:
        return (patch, "")

    source_patch = "\n".join(source_diffs).lstrip("\n")
    test_patch = "\n".join(test_diffs).lstrip("\n")

    if source_patch and not source_patch.endswith("\n"):
        source_patch += "\n"
    if test_patch and not test_patch.endswith("\n"):
        test_patch += "\n"

    return (source_patch, test_patch)


class PatchSplitterProvider(Provider):
    """Provider that splits a full patch into source and test parts."""

    def provide(
        self, item=None, *, patch="", exclude_paths=None,
        test_patterns=None, source_patterns=None, **kwargs,
    ) -> dict[str, str]:
        """Split a patch into source and test patches.

        Args:
            item: Item dict (unused after explicit-param migration).
            patch: Full unified diff to split.
            exclude_paths: File path prefixes to drop from both patches
                (e.g. ``[".ee-bench/"]``).
            test_patterns: Glob patterns for files that belong in the test patch.
            source_patterns: Glob patterns for files that belong in the source patch.
            **kwargs: Ignored.

        Returns:
            Dict with 'patch' (source-only) and 'test_patch' (test-only).
        """

        logger.warning("test_patterns: %s", test_patterns)
        logger.warning("source_patterns: %s", source_patterns)

        source_patch, test_patch = split_patch(
            patch,
            exclude_paths=exclude_paths,
            test_patterns=test_patterns,
            source_patterns=source_patterns,
        )
        logger.warning("source_patch: %s", source_patch)
        logger.warning("test_patch: %s", test_patch)
        return {"patch": source_patch, "test_patch": test_patch}
