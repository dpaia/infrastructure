"""SweBenchProEvalGenerator — transforms raw Dockerfiles + scripts into EE-bench format."""

from __future__ import annotations

import json
import logging
import re
from typing import Any

from jinja2 import Environment, StrictUndefined

from ee_bench.generator.interfaces import Provider

logger = logging.getLogger(__name__)

# Regex to match ENV directives in Dockerfile
_ENV_PATTERN = re.compile(
    r'^ENV\s+(\w+)=("(?:[^"\\]|\\.)*"|\'(?:[^\'\\]|\\.)*\'|\S+)',
    re.MULTILINE,
)
# Alternative: ENV KEY VALUE (without =)
_ENV_SPACE_PATTERN = re.compile(
    r'^ENV\s+(\w+)\s+(.+)$',
    re.MULTILINE,
)
# Regex to match ENTRYPOINT and CMD directives
_ENTRYPOINT_CMD_PATTERN = re.compile(
    r'^(ENTRYPOINT|CMD)\s+.*$',
    re.MULTILINE,
)
# Regex to match git clone URLs in Dockerfile
_GIT_CLONE_PATTERN = re.compile(
    r'(git\s+clone\s+)https://github\.com/[\w.-]+/[\w.-]+(?:\.git)?(\s)',
)
# Regex to strip the FROM line (used when merging instance dockerfile onto base)
_FROM_LINE_PATTERN = re.compile(r'^FROM\s+\S+.*$\n?', re.MULTILINE)
# 40-char hex strings that look like git commit hashes
_COMMIT_HASH_PATTERN = re.compile(r'\b[0-9a-f]{40}\b')

RUN_SH_TEMPLATE = r"""#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="${EE_BENCH_PROJECT_ROOT:-{{ project_root }}}"
EVAL_DIR="/ee-bench/eval"
SUBMISSION_DIR="/ee-bench/submission"

# --- Environment from Dockerfile (rendered from dockerfile_env_vars) ---
{{ env_exports }}

# --- Reset to base commit (only if EE_BENCH_RESET is set) ---
cd "$PROJECT_ROOT"
if [ -n "${EE_BENCH_RESET:-}" ]; then
  git reset --hard "{{ base_commit }}" 2>/dev/null
  git checkout "{{ base_commit }}" 2>/dev/null
  git clean -fd 2>/dev/null
fi

# --- Fetch commits referenced by before_repo_set_cmd ---
{% for commit in commits_to_fetch %}
git fetch origin {{ commit }} 2>/dev/null || true
{% endfor %}
# --- before_repo_set_cmd (from HF metadata, may be empty) ---
{{ before_repo_set_cmd }}

# --- Apply evaluation data (test patch) ---
if [ -f "$EVAL_DIR/test_patch.diff" ]; then
  git apply -v "$EVAL_DIR/test_patch.diff" 2>/dev/null || true
fi

# --- Apply candidate submission ---
if [ -f "$SUBMISSION_DIR/patch.diff" ]; then
  git apply -v "$SUBMISSION_DIR/patch.diff" 2>/dev/null || true
fi

# --- Run tests via SWE-bench Pro run script ---
{% if selected_test_files %}
bash "$EVAL_DIR/scripts/run_script.sh" "{{ selected_test_files }}" \
  > /tmp/stdout.log 2> /tmp/stderr.log || true
{% else %}
bash "$EVAL_DIR/scripts/run_script.sh" \
  > /tmp/stdout.log 2> /tmp/stderr.log || true
{% endif %}

# --- Parse results ---
python3 "$EVAL_DIR/scripts/parser.py" /tmp/stdout.log /tmp/stderr.log /tmp/output.json

# --- Convert parser output to EE-bench JSON v2.0 format ---
python3 -c "
import json, sys, datetime
with open('/tmp/output.json') as f:
    data = json.load(f)
stdout = open('/tmp/stdout.log').read()
stderr = open('/tmp/stderr.log').read()

passed = [t for t in data.get('tests', []) if t['status'] == 'PASSED']
failed = [t for t in data.get('tests', []) if t['status'] in ('FAILED', 'ERROR')]
skipped = [t for t in data.get('tests', []) if t['status'] == 'SKIPPED']

summary = {
    'total': len(data.get('tests', [])),
    'passed': len(passed),
    'failed': len(failed),
    'errors': 0,
    'skipped': len(skipped),
}
passed_tests = [{'name': t['name']} for t in passed]
failed_tests = [{'name': t['name']} for t in failed]

result = {
    'schema_version': '2.0',
    'status': 'success',
    'timestamp': datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
    'criteria': [
        {
            'criterion': 'patch_applied',
            'status': 'pass',
        },
        {
            'criterion': 'compilation',
            'status': 'pass',
        },
        {
            'criterion': 'tests',
            'status': 'pass' if not failed else 'fail',
            'summary': summary,
            'passed_tests': passed_tests,
            'failed_tests': failed_tests,
        },
    ],
    'stdout': stdout,
    'stderr': stderr,
    # Deprecated v1.0 fields for backward compat
    'patch_applied': True,
    'compile_success': True,
    'summary': summary,
    'passed_tests': passed_tests,
    'failed_tests': failed_tests,
}
print(json.dumps(result))
"
"""


class SweBenchProEvalGenerator(Provider):
    """SWE-bench Pro benchmark provider (formerly Generator).

    Takes raw Dockerfiles and run scripts, produces:
    - ``dockerfile``: Modified instance Dockerfile (string)
    - ``eval``: Dict of ``{filename: content}`` for the eval directory
    """

    def provide(
        self,
        item=None,
        *,
        dockerfile_raw="",
        dockerfile_base="",
        target_repo_url="",
        base_commit="",
        before_repo_set_cmd="",
        selected_test_files_to_run="",
        run_script="",
        parser_script="",
        project_root="/app",
        **kwargs,
    ) -> dict[str, Any]:
        """Transform raw Dockerfiles + scripts into EE-bench format.

        Args:
            item: Item dict (unused after explicit-param migration).
            dockerfile_raw: Raw instance Dockerfile.
            dockerfile_base: Raw base Dockerfile.
            target_repo_url: URL of the fork (for git clone replacement).
            base_commit: Base commit hash.
            before_repo_set_cmd: Pre-test setup command.
            selected_test_files_to_run: Comma-separated test paths.
            run_script: Content of run_script.sh.
            parser_script: Content of parser.py.
            project_root: Container working directory.
            **kwargs: Ignored.

        Returns:
            Dict with 'dockerfile' and 'eval' keys.
        """
        # --- Dockerfile transformation ---
        dockerfile = self._transform_dockerfile(
            dockerfile_raw, dockerfile_base, target_repo_url
        )
        # Extract ENV variables from both Dockerfiles
        env_vars = self._extract_env_vars(dockerfile_base)
        env_vars.update(self._extract_env_vars(dockerfile_raw))

        # --- Render run.sh ---
        env_exports = self._build_env_exports(env_vars)
        test_files_str = self._normalize_test_files(selected_test_files_to_run)

        # Extract commit hashes from before_repo_set_cmd that aren't the base_commit
        # (those commits may not be in the shallow clone and need fetching)
        commits_to_fetch = self._extract_commit_hashes(
            before_repo_set_cmd, exclude={base_commit} if base_commit else set()
        )

        run_sh = self._render_run_sh(
            env_exports=env_exports,
            base_commit=base_commit,
            before_repo_set_cmd=before_repo_set_cmd,
            selected_test_files=test_files_str,
            project_root=project_root,
            commits_to_fetch=commits_to_fetch,
        )

        # --- Assemble eval dict ---
        eval_dict: dict[str, str] = {
            "run.sh": run_sh,
        }
        if run_script:
            eval_dict["scripts/run_script.sh"] = run_script
        if parser_script:
            eval_dict["scripts/parser.py"] = parser_script

        return {
            "dockerfile": dockerfile,
            "eval": eval_dict,
        }

    @staticmethod
    def _extract_env_vars(dockerfile: str) -> dict[str, str]:
        """Extract ENV variable assignments from a Dockerfile."""
        env_vars: dict[str, str] = {}
        if not dockerfile:
            return env_vars

        for match in _ENV_PATTERN.finditer(dockerfile):
            key = match.group(1)
            value = match.group(2)
            if (value.startswith('"') and value.endswith('"')) or \
               (value.startswith("'") and value.endswith("'")):
                value = value[1:-1]
            env_vars[key] = value

        for match in _ENV_SPACE_PATTERN.finditer(dockerfile):
            key = match.group(1)
            value = match.group(2).strip()
            if key not in env_vars:
                env_vars[key] = value

        return env_vars

    @staticmethod
    def _build_env_exports(env_vars: dict[str, str]) -> str:
        """Build shell export lines from ENV variables."""
        if not env_vars:
            return ""
        lines = []
        for key, value in env_vars.items():
            escaped = value.replace('"', '\\"')
            lines.append(f'export {key}="{escaped}"')
        return "\n".join(lines)

    @staticmethod
    def _normalize_test_files(value: str) -> str:
        """Normalize selected_test_files_to_run to comma-separated string."""
        if not value:
            return ""
        value = value.strip()
        if value.startswith("["):
            try:
                import json
                parsed = json.loads(value)
                if isinstance(parsed, list):
                    return ",".join(str(v) for v in parsed if v)
            except (json.JSONDecodeError, TypeError):
                pass
        return value

    @staticmethod
    def _transform_dockerfile(
        raw: str, base: str, target_repo_url: str
    ) -> str:
        """Transform raw + base Dockerfile into EE-bench format.

        When both are provided, merges them: base provides the real FROM/deps/git
        clone foundation; instance provides ENV vars and build steps (FROM stripped).
        Git clone URL replacement is applied to the base portion.
        """
        if not raw and not base:
            return ""

        if raw and base:
            # Merge mode: base as foundation + instance content without its FROM
            base_clean = _ENTRYPOINT_CMD_PATTERN.sub("", base)
            if target_repo_url:
                base_clean = _GIT_CLONE_PATTERN.sub(
                    rf"\g<1>{target_repo_url}\g<2>",
                    base_clean,
                )
            raw_without_from = _FROM_LINE_PATTERN.sub("", raw)
            raw_clean = _ENTRYPOINT_CMD_PATTERN.sub("", raw_without_from)
            dockerfile = base_clean.rstrip() + "\n\n" + raw_clean.strip() + "\n"
        else:
            dockerfile = raw if raw else base
            dockerfile = _ENTRYPOINT_CMD_PATTERN.sub("", dockerfile)
            if target_repo_url:
                dockerfile = _GIT_CLONE_PATTERN.sub(
                    rf"\g<1>{target_repo_url}\g<2>",
                    dockerfile,
                )

        while "\n\n\n" in dockerfile:
            dockerfile = dockerfile.replace("\n\n\n", "\n\n")

        dockerfile = dockerfile.rstrip() + "\n\n"
        dockerfile += 'LABEL ee-bench.type="codegen"\n'
        dockerfile += 'LABEL ee-bench.version="1.0"\n'
        dockerfile += 'RUN rm -rf /app/.ee-bench/ 2>/dev/null || true\n'

        return dockerfile

    @staticmethod
    def _extract_commit_hashes(text: str, exclude: set[str] | None = None) -> list[str]:
        """Extract 40-char hex commit hashes from *text*, excluding known ones."""
        exclude = exclude or set()
        return sorted(set(_COMMIT_HASH_PATTERN.findall(text)) - exclude)

    @staticmethod
    def _render_run_sh(
        env_exports: str,
        base_commit: str,
        before_repo_set_cmd: str,
        selected_test_files: str,
        project_root: str,
        commits_to_fetch: list[str] | None = None,
    ) -> str:
        """Render run.sh from the template."""
        env = Environment(undefined=StrictUndefined)
        tmpl = env.from_string(RUN_SH_TEMPLATE)
        return tmpl.render(
            env_exports=env_exports,
            base_commit=base_commit,
            before_repo_set_cmd=before_repo_set_cmd,
            selected_test_files=selected_test_files,
            project_root=project_root,
            commits_to_fetch=commits_to_fetch or [],
        )
