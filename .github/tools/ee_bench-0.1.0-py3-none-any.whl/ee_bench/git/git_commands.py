"""Low-level subprocess wrappers for git commands."""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)


class GitCommandError(Exception):
    """Raised when a git subprocess fails."""

    def __init__(self, cmd: list[str], returncode: int, stderr: str):
        self.cmd = cmd
        self.returncode = returncode
        self.stderr = stderr
        super().__init__(
            f"git command failed (rc={returncode}): {' '.join(cmd)}\n{stderr}"
        )


def _run(args: list[str], cwd: Path | None = None) -> subprocess.CompletedProcess[str]:
    """Run a git command and return the result."""
    logger.debug("git %s (cwd=%s)", " ".join(args), cwd)
    result = subprocess.run(
        ["git", *args],
        cwd=cwd,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise GitCommandError(["git", *args], result.returncode, result.stderr.strip())
    return result


def git_clone(
    remote_url: str,
    target_dir: Path | str,
    *,
    treeless: bool = True,
    no_checkout: bool = False,
) -> None:
    """Clone a remote repository."""
    args = ["clone"]
    if treeless:
        args += ["--filter=blob:none"]
    if no_checkout:
        args.append("--no-checkout")
    args += [remote_url, str(target_dir)]
    _run(args)


def git_fetch(cwd: Path, remote: str, refspec: str) -> None:
    """Fetch a refspec from a remote."""
    _run(["fetch", remote, refspec], cwd=cwd)


def git_branch_create(cwd: Path, branch_name: str, start_point: str) -> None:
    """Create a new branch at start_point."""
    _run(["branch", branch_name, start_point], cwd=cwd)


def git_checkout(cwd: Path, ref: str) -> None:
    """Checkout a ref (branch or commit)."""
    _run(["checkout", ref], cwd=cwd)


def git_clean(cwd: Path) -> None:
    """Remove untracked files and directories."""
    _run(["clean", "-fdx"], cwd=cwd)


def git_reset_hard(cwd: Path, ref: str) -> None:
    """Hard reset to a ref."""
    _run(["reset", "--hard", ref], cwd=cwd)


def git_add(cwd: Path, paths: list[str], *, force: bool = False) -> None:
    """Stage files for commit. Use force=True for .gitignore'd paths."""
    args = ["add"]
    if force:
        args.append("-f")
    args.extend(paths)
    _run(args, cwd=cwd)


def git_commit(cwd: Path, message: str) -> str:
    """Create a commit. Returns the commit SHA."""
    _run(["commit", "-m", message, "--allow-empty"], cwd=cwd)
    return git_rev_parse(cwd, "HEAD")


def git_push(
    cwd: Path, remote: str, refspecs: list[str], *, force: bool = False
) -> None:
    """Push refspecs to a remote."""
    args = ["push", remote]
    if force:
        args.append("--force")
    args += refspecs
    _run(args, cwd=cwd)


def git_default_branch(cwd: Path) -> str:
    """Return the default branch name (e.g. 'main' or 'master') for origin."""
    result = _run(["symbolic-ref", "refs/remotes/origin/HEAD"], cwd=cwd)
    # Output is like "refs/remotes/origin/main"
    return result.stdout.strip().removeprefix("refs/remotes/origin/")


def git_rev_parse(cwd: Path, ref: str) -> str:
    """Resolve a ref to a SHA."""
    result = _run(["rev-parse", ref], cwd=cwd)
    return result.stdout.strip()


def git_branch_exists(cwd: Path, branch_name: str) -> bool:
    """Check if a local branch exists."""
    try:
        _run(["rev-parse", "--verify", f"refs/heads/{branch_name}"], cwd=cwd)
        return True
    except GitCommandError:
        return False


def git_object_exists(cwd: Path, sha: str) -> bool:
    """Check if a git object exists in the local store."""
    try:
        _run(["cat-file", "-e", sha], cwd=cwd)
        return True
    except GitCommandError:
        return False


def git_apply(cwd: Path, patch_text: str, *, three_way: bool = True) -> None:
    """Apply a patch from stdin."""
    args = ["apply"]
    if three_way:
        args.append("--3way")
    args.append("-")
    logger.debug("git apply (cwd=%s, 3way=%s, %d bytes)", cwd, three_way, len(patch_text))
    result = subprocess.run(
        ["git", *args],
        cwd=cwd,
        input=patch_text,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise GitCommandError(
            ["git", *args], result.returncode, result.stderr.strip()
        )


def git_remote_add(cwd: Path, name: str, url: str) -> None:
    """Add a remote."""
    _run(["remote", "add", name, url], cwd=cwd)


def git_update_index_chmod(cwd: Path, path: str, *, executable: bool = True) -> None:
    """Update the executable bit on a file in the index."""
    mode = "+x" if executable else "-x"
    _run(["update-index", f"--chmod={mode}", path], cwd=cwd)
