"""Git adapter for repository operations.

This module provides a unified interface for Git operations including
cloning repositories, checking out commits, and managing repository state.
"""

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Optional, Union

if TYPE_CHECKING:
    from .sandbox_base import Sandbox

logger = logging.getLogger(__name__)


class GitAdapter:
    """Adapter for Git operations.

    Provides methods for cloning repositories, checking out commits,
    resetting repository state, and querying repository information.
    """

    def clone_repository(
        self,
        sandbox: "Sandbox",
        repo_url: str,
        target_dir: Path,
        https_fallback: bool = True,
    ) -> None:
        """Clone a Git repository.

        Args:
            repo_url: URL of the repository to clone (SSH or HTTPS)
            target_dir: Directory to clone repository into
            https_fallback: If True, try HTTPS if SSH clone fails

        Raises:
            RuntimeError: If cloning fails
        """
        if target_dir.exists():
            logger.debug(f"Repository already exists: {target_dir}")
            return

        logger.debug(f"Cloning repository: {repo_url}")
        result = sandbox.run_command(["git", "clone", repo_url, str(target_dir)])

        if result.returncode != 0:
            if https_fallback:
                logger.warning("SSH clone failed, trying HTTPS...")
                https_url = self._convert_to_https(repo_url)
                result = sandbox.run_command(
                    ["git", "clone", https_url, str(target_dir)]
                )
                if result.returncode != 0:
                    raise RuntimeError(
                        f"Failed to clone repository with both SSH and HTTPS: {result.stderr}"
                    )
            else:
                raise RuntimeError(f"Failed to clone repository: {result.stderr}")

        logger.debug(f"Successfully cloned repository to: {target_dir}")

    def checkout_commit(self, sandbox: "Sandbox", repo_dir: Path, commit: str) -> None:
        """Checkout a specific commit in a repository.

        Args:
            repo_dir: Path to the repository
            commit: Commit hash to checkout

        Raises:
            RuntimeError: If checkout fails
        """
        if not repo_dir.exists():
            raise RuntimeError(f"Repository directory does not exist: {repo_dir}")

        logger.debug(f"Checking out commit: {commit}")
        result = sandbox.run_command(["git", "checkout", commit], cwd=repo_dir)

        if result.returncode != 0:
            raise RuntimeError(f"Failed to checkout commit {commit}: {result.stderr}")

    def reset_repository(self, sandbox: "Sandbox", repo_dir: Path) -> None:
        """Reset repository to a clean state.

        Performs git reset --hard HEAD and git clean -fd to remove
        all uncommitted changes and untracked files.

        Args:
            repo_dir: Path to the repository

        Raises:
            RuntimeError: If reset fails
        """
        if not repo_dir.exists():
            raise RuntimeError(f"Repository directory does not exist: {repo_dir}")

        logger.debug("Resetting repository to clean state...")

        result = sandbox.run_command(["git", "reset", "--hard", "HEAD"], cwd=repo_dir)
        if result.returncode != 0:
            raise RuntimeError(f"Failed to reset repository: {result.stderr}")

        result = sandbox.run_command(["git", "clean", "-fd"], cwd=repo_dir)
        if result.returncode != 0:
            raise RuntimeError(f"Failed to clean repository: {result.stderr}")

        logger.debug("Repository reset successful")

    def get_current_commit(self, sandbox: "Sandbox", repo_dir: Path) -> str:
        """Get the current commit hash of a repository.

        Args:
            repo_dir: Path to the repository

        Returns:
            Current commit hash (full SHA-1)

        Raises:
            RuntimeError: If unable to get commit hash
        """
        if not repo_dir.exists():
            raise RuntimeError(f"Repository directory does not exist: {repo_dir}")

        result = sandbox.run_command(["git", "rev-parse", "HEAD"], cwd=repo_dir)

        if result.returncode != 0:
            raise RuntimeError(f"Failed to get current commit: {result.stderr}")

        return result.stdout.strip()

    def has_changes(self, sandbox: "Sandbox", repo_dir: Path) -> bool:
        """Check if repository has uncommitted changes.

        Args:
            repo_dir: Path to the repository

        Returns:
            True if there are uncommitted changes, False otherwise

        Raises:
            RuntimeError: If unable to check status
        """
        if not repo_dir.exists():
            raise RuntimeError(f"Repository directory does not exist: {repo_dir}")

        result = sandbox.run_command(["git", "status", "--porcelain"], cwd=repo_dir)

        if result.returncode != 0:
            raise RuntimeError(f"Failed to check repository status: {result.stderr}")

        return bool(result.stdout.strip())

    def get_diff(
        self,
        sandbox: "Sandbox",
        repo_dir: Union[Path, str, None] = None,
        timeout: Optional[int] = None,
        include_untracked: bool = True,
        base_commit: Optional[str] = None,
        exclude_build_files: bool = True,
        **kwargs,
    ) -> str:
        """Get git diff output from a repository.

        This method extracts the current diff (changes) from a git repository.
        Supports both local execution and execution inside Docker containers.

        Args:
            repo_dir: Path to the repository (optional if env_config is provided)
            env_config: Optional EnvironmentConfig to extract repo_dir and use process manager factory
            container_id: Optional Docker container ID for containerized execution
                         (deprecated: prefer passing env_config instead)
            timeout: Optional timeout in seconds for the git command
            include_untracked: If True, stage all changes (including untracked files) before diff.
                             This allows capturing new files added during evaluation. (default: True)
            base_commit: Optional base commit to compare against (e.g., "HEAD", "abc123", "main").
                        If provided, compares working tree against this commit.
                        If None, compares against staging area (default behavior).
            exclude_build_files: If True, exclude build tool wrappers (gradlew, mvnw) and build directories
                               from staging. Note: .gitignore patterns are respected automatically by git. (default: True)
            **kwargs: Additional parameters passed to ProcessManagerFactory (e.g., auto_start)

        Returns:
            Git diff output as string (empty string if no changes)

        Raises:
            ValueError: If repo_dir cannot be determined
            RuntimeError: If git diff command fails

        Examples:
            # Get all changes including untracked files (default)
            diff = adapter.get_diff(env_config)

            # Get changes against specific commit
            diff = adapter.get_diff(env_config, base_commit="HEAD")
            diff = adapter.get_diff(env_config, base_commit="abc123def")

            # Get only tracked file changes (no untracked files)
            diff = adapter.get_diff(env_config, include_untracked=False)

            # Include build files in diff
            diff = adapter.get_diff(env_config, exclude_build_files=False)
        """
        # Determine repo_dir from env_config if not provided directly

        env_config = sandbox.env_config

        if repo_dir is None:
            if env_config is None:
                raise ValueError("Either repo_dir or env_config must be provided")
            repo_dir = self._determine_project_path(env_config)

        # Check if directory exists before trying to run git commands
        check_dir_cmd = ["test", "-d", str(repo_dir)]
        check_result = sandbox.run_command(check_dir_cmd, timeout=5, **kwargs)
        if check_result.returncode != 0:
            logger.error(
                f"Project directory {repo_dir} does not exist in container. "
                f"Cannot collect git diff."
            )
            return ""

        # Get build file exclusion patterns if enabled (without .gitignore patterns)
        # We don't include .gitignore patterns for git add because git respects .gitignore naturally
        exclusion_patterns = (
            self._get_build_file_exclusions() if exclude_build_files else []
        )

        # If base_commit is specified, compare against that commit
        if base_commit:
            logger.debug(f"Getting diff against base commit: {base_commit}")

            # If include_untracked, we need to stage files first
            if include_untracked:
                logger.debug("Staging all changes including untracked files for diff")
                add_cmd = ["git", "-C", str(repo_dir), "add", "-A", "--"]
                # Add current directory as the pathspec base
                add_cmd.append(".")
                # Add exclusion patterns if enabled
                if exclusion_patterns:
                    add_cmd.extend(exclusion_patterns)
                    logger.debug(
                        f"Excluding {len(exclusion_patterns)} build tool patterns from staging"
                    )

                add_result = sandbox.run_command(add_cmd, timeout=timeout, **kwargs)
                if add_result.returncode != 0:
                    # Check if error is just about ignored files (which we're intentionally excluding)
                    if "ignored by one of your .gitignore files" in add_result.stderr:
                        logger.debug(
                            f"Some files are in .gitignore and were skipped (expected): {add_result.stderr.split('hint:')[0].strip()}"
                        )
                    else:
                        logger.warning(
                            f"Failed to stage files: {add_result.stderr}. "
                            f"Will continue with unstaged diff only."
                        )

                # Compare staged changes against base commit
                cmd = [
                    "git",
                    "-C",
                    str(repo_dir),
                    "diff",
                    "--cached",
                    base_commit,
                    "--no-color",
                ]
            else:
                # Compare working tree (tracked files only) against base commit
                cmd = ["git", "-C", str(repo_dir), "diff", base_commit, "--no-color"]
                # Add exclusion patterns to diff command if enabled
                if exclusion_patterns:
                    cmd.extend(exclusion_patterns)

        else:
            # No base_commit: compare against staging area (original behavior)
            # If include_untracked is True, stage all changes first (including new files)
            # This allows git diff --cached to show everything
            if include_untracked:
                logger.debug("Staging all changes including untracked files for diff")
                add_cmd = ["git", "-C", str(repo_dir), "add", "-A", "--"]
                # Add current directory as the pathspec base
                add_cmd.append(".")
                # Add exclusion patterns if enabled
                if exclusion_patterns:
                    add_cmd.extend(exclusion_patterns)
                    logger.debug(
                        f"Excluding {len(exclusion_patterns)} build tool patterns from staging"
                    )

                add_result = sandbox.run_command(add_cmd, timeout=timeout, **kwargs)
                if add_result.returncode != 0:
                    # Check if error is just about ignored files (which we're intentionally excluding)
                    if "ignored by one of your .gitignore files" in add_result.stderr:
                        logger.debug(
                            f"Some files are in .gitignore and were skipped (expected): {add_result.stderr.split('hint:')[0].strip()}"
                        )
                    else:
                        logger.warning(
                            f"Failed to stage files: {add_result.stderr}. "
                            f"Will continue with unstaged diff only."
                        )

            # Get the appropriate diff command
            if include_untracked:
                # Show staged changes (includes everything after git add -A)
                cmd = ["git", "-C", str(repo_dir), "diff", "--cached", "--no-color"]
            else:
                # Show only unstaged changes to tracked files
                cmd = ["git", "-C", str(repo_dir), "diff", "--no-color"]
                # Add exclusion patterns to diff command if enabled
                if exclusion_patterns:
                    cmd.extend(exclusion_patterns)

        result = sandbox.run_command(cmd, timeout=timeout, **kwargs)

        # git diff returns 0 for no changes, 1 for changes (in some versions)
        # Only error on codes >= 2
        if result.returncode not in (0, 1):
            logger.debug(f"git diff returned code {result.returncode}, continuing")

        return result.stdout or ""

    def _parse_gitignore(
        self, sandbox: "Sandbox", repo_dir: Union[Path, str]
    ) -> list[str]:
        """Parse .gitignore file and convert patterns to git pathspec exclusions.

        Args:
            sandbox: Sandbox to execute commands in
            repo_dir: Path to the repository

        Returns:
            List of git pathspec exclusion patterns from .gitignore

        Note:
            - Skips comments (lines starting with #)
            - Skips empty lines
            - Skips negation patterns (lines starting with !)
            - Converts .gitignore patterns to :(exclude) pathspec format
        """
        gitignore_path = Path(repo_dir) / ".gitignore"

        # Try to read .gitignore file
        try:
            result = sandbox.run_command(["cat", str(gitignore_path)])
            if result.returncode != 0:
                logger.debug(f"No .gitignore found at {gitignore_path}")
                return []

            gitignore_content = result.stdout
        except Exception as e:
            logger.debug(f"Failed to read .gitignore: {e}")
            return []

        exclusions = []
        for line in gitignore_content.splitlines():
            line = line.strip()

            # Skip empty lines and comments
            if not line or line.startswith("#"):
                continue

            # Skip negation patterns (these would need special handling)
            if line.startswith("!"):
                continue

            # Remove trailing slashes for consistency
            pattern = line.rstrip("/")

            # Remove leading slash - in .gitignore it means "relative to repo root",
            # but in git pathspec it would mean "absolute path from filesystem root"
            if pattern.startswith("/"):
                pattern = pattern[1:]

            # Convert to git pathspec exclusion format
            exclusions.append(f":(exclude){pattern}")

        logger.debug(f"Loaded {len(exclusions)} exclusion patterns from .gitignore")
        return exclusions

    def _get_build_file_exclusions(self) -> list[str]:
        """Get list of pathspec exclusion patterns for build tool files and directories.

        Returns:
            List of git pathspec exclusion patterns (e.g., ":(exclude)gradlew")

        Note:
            Patterns exclude common build tool files that should not be part of
            code changes, even if they're not in .gitignore:
            - Gradle wrapper files: gradlew, gradlew.bat, gradle/wrapper/*
            - Maven wrapper files: mvnw, mvnw.cmd, .mvn/wrapper/*
            - Build directories: build/, target/, out/, .gradle/, .idea/, .vscode/

            This method does NOT include .gitignore patterns since git naturally
            respects .gitignore during add operations.
        """
        return [
            # Gradle build tool files
            ":(exclude)gradlew",
            ":(exclude)gradlew.bat",
            ":(exclude)gradle/wrapper/*",
            # Maven build tool files
            ":(exclude)mvnw",
            ":(exclude)mvnw.cmd",
            ":(exclude).mvn/wrapper/*",
            # Build output directories (common patterns that might not be in .gitignore)
            ":(exclude)build",
            ":(exclude)build/**",
            ":(exclude)*/build",
            ":(exclude)*/build/**",
            ":(exclude)target",
            ":(exclude)target/**",
            ":(exclude)*/target",
            ":(exclude)*/target/**",
            ":(exclude)out",
            ":(exclude)out/**",
            ":(exclude)*/out",
            ":(exclude)*/out/**",
            # IDE and build cache directories
            ":(exclude).gradle",
            ":(exclude).gradle/**",
            ":(exclude).idea",
            ":(exclude).idea/**",
            ":(exclude).vscode",
            ":(exclude).vscode/**",
        ]

    def _get_exclusion_patterns(
        self, sandbox: "Sandbox", repo_dir: Union[Path, str]
    ) -> list[str]:
        """Get list of pathspec exclusion patterns for build files, directories, and .gitignore.

        Args:
            sandbox: Sandbox to execute commands in
            repo_dir: Path to the repository

        Returns:
            List of git pathspec exclusion patterns (e.g., ":(exclude)gradlew")

        Note:
            Patterns exclude:
            - Gradle wrapper files: gradlew, gradlew.bat, gradle/wrapper/*
            - Maven wrapper files: mvnw, mvnw.cmd, .mvn/wrapper/*
            - Build directories: build/, target/, out/, .gradle/, .idea/
            - Patterns from .gitignore file in the repository
        """
        exclusions = self._get_build_file_exclusions()

        # Add patterns from .gitignore
        gitignore_patterns = self._parse_gitignore(sandbox, repo_dir)
        exclusions.extend(gitignore_patterns)

        return exclusions

    def _determine_project_path(self, env_config) -> str:
        """Determine project path from environment config.

        Args:
            env_config: Environment configuration

        Returns:
            Project path as string

        Raises:
            ValueError: If project_path cannot be determined
        """
        project_path = None
        if hasattr(env_config, "project_path") and env_config.project_path:
            try:
                project_path = str(env_config.project_path)
            except Exception:
                project_path = None

        if (
            not project_path
            and hasattr(env_config, "workspace_dir")
            and env_config.workspace_dir
        ):
            # Check if project_dir is specified
            if hasattr(env_config, "project_dir") and env_config.project_dir:
                project_path = str(
                    Path(env_config.workspace_dir) / env_config.project_dir
                )
            else:
                # Fallback to default project dir name
                project_path = str(Path(env_config.workspace_dir) / "task_project")

        if not project_path:
            raise ValueError("Cannot determine project_path from environment config")

        return project_path

    def _convert_to_https(self, repo_url: str) -> str:
        """Convert SSH repository URL to HTTPS.

        Args:
            repo_url: Repository URL (SSH or HTTPS)

        Returns:
            HTTPS repository URL
        """
        if repo_url.startswith("git@github.com:"):
            # Convert git@github.com:owner/repo.git to https://github.com/owner/repo.git
            path = repo_url[15:]  # Remove "git@github.com:"
            return f"https://github.com/{path}"
        else:
            return repo_url
