"""Base implementation of EvalSpec with common orchestration methods.

This module provides BaseEvalSpec which implements high-level orchestration
methods (prepare_environment, run_evaluation) that work across all specification
types by delegating to the abstract getter methods.

Includes support for dependency injection containers for managing component
lifecycles and dependencies.
"""

import logging
import multiprocessing
from abc import abstractmethod
from pathlib import Path
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from . import ResultStatus
from .abc_types import (
    CommandRunner,
    DatasetManager,
    EnvironmentManager,
    EnvironmentTools,
    EvalSpec,
    EvaluationRunner,
    ReportManager,
)
from .environment_serializer import EnvironmentSerializerManager
from .eval import Evaluator, BaseEvaluationRunner, EnvironmentConfigurer
from .models import (
    CommandExecutionResult,
    DatasetConfig,
    EnvironmentConfig,
    EnvironmentPreparationResult,
    EnvironmentConfigReportable,
    PredictionsEntry,
)
from .predictions_serializer import PredictionsSerializer
from .report_manager import ReportManager as DefaultReportManager
from .utils.concurrency import run_threadpool, run_sequential
from .utils.environment_helper import load_or_build_environments
from .utils.report_manager_helper import get_or_create_report_manager

if TYPE_CHECKING:
    from dependency_injector.containers import DeclarativeContainer
    from ee_bench_core.adapters import Sandbox
    from .eval import ScoreEvaluator

logger = logging.getLogger(__name__)


class BaseEvalSpec(EvalSpec):
    """Base evaluation specification with common orchestration logic.

    This class provides default implementations for high-level orchestration
    methods (prepare_environment, run_evaluation) that work across all
    specification types. Subclasses must implement the abstract getter methods
    to provide spec-specific components.

    The orchestration methods handle:
    - Loading datasets
    - Iterating over instance IDs
    - Setting up environments (parallel or sequential)
    - Running evaluations (parallel or sequential)
    - Collecting results via ReportManager

    Dependency Injection Support:
    - Subclasses can optionally provide ApplicationContainer and SpecContainer
    - Provides common DI patterns (configure_for_evaluation, container access)
    - Backward compatible (DI is optional)
    """

    def __init__(self, report_manager: Optional[ReportManager] = None):
        """Initialize base specification.

        Args:
            report_manager: Optional report manager for tracking evaluation results

        Raises:
            NotImplementedError: If subclass doesn't implement initialize_containers()
                or doesn't create self.container
        """
        self.report_manager = report_manager

        # DI container attributes
        self.app_container: Optional["DeclarativeContainer"] = None
        self.container: Optional["DeclarativeContainer"] = None
        self.env_serializer = EnvironmentSerializerManager()
        self.predictions_serializer = PredictionsSerializer()
        self._configured = False

        # Call subclass initialization (REQUIRED)
        self.initialize_containers()

        # Verify container was created
        if not self.has_container():
            raise NotImplementedError(
                f"{self.__class__.__name__} must implement initialize_containers() "
                f"and create self.container. See JvmCodeEvalSpec for example:\n\n"
                f"def initialize_containers(self):\n"
                f"    self.app_container = ApplicationContainer.create_with_defaults()\n"
                f"    self.container = MySpecContainer()\n"
                f"    self.container.app.override(self.app_container)"
            )

    # Required abstract properties from EvalSpec

    @property
    @abstractmethod
    def name(self) -> str:
        """Get the canonical name of this specification."""
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        """Get a human-readable description of this specification."""
        pass

    # Abstract getter methods for spec-specific components
    # Subclasses must implement these to provide concrete implementations

    @abstractmethod
    def get_dataset_manager(self, **kwargs) -> DatasetManager:
        """Create a dataset manager instance.

        Args:
            **kwargs: Spec-specific initialization parameters

        Returns:
            DatasetManager implementation
        """
        pass

    @abstractmethod
    def get_environment_manager(
        self, config: Optional[DatasetConfig] = None, **kwargs
    ) -> EnvironmentManager:
        """Create an environment manager instance.

        Args:
            config: Optional dataset configuration for the task.
                   When None, returns a minimal environment manager that can be used
                   for deserialization operations.
            **kwargs: Spec-specific initialization parameters

        Returns:
            EnvironmentManager implementation

        Note:
            Default behavior (if not overridden) should return BaseEnvironmentManager
            with configurers from get_configurers(). Example:

            def get_environment_manager(self, config=None, **kwargs):
                from ee_bench_core.core.environment_manager import BaseEnvironmentManager
                configurers = self.get_configurers(config, **kwargs) if config else []
                return BaseEnvironmentManager(
                    spec=self,
                    configurers=configurers,
                    enable_plugins=kwargs.get("enable_plugins", True),
                    **kwargs
                )
        """
        pass

    def get_configurers(
        self, config: Optional[DatasetConfig] = None, **kwargs
    ) -> List["EnvironmentConfigurer"]:
        """Get environment configurers for this specification.

        Subclasses should override this to provide spec-specific configurers
        that build Docker images, install tools, etc.

        The configurers returned here will be used by BaseEnvironmentManager
        to build the evaluation environment in a composable way.

        Args:
            config: Optional dataset configuration (may be None during discovery)
            **kwargs: Additional parameters that may affect configurer selection

        Returns:
            List of EnvironmentConfigurer instances

        Example:
            def get_configurers(self, config=None, **kwargs):
                from my_configurers import (
                    JvmBaseImageConfigurer,
                    MavenConfigurer,
                    TaskImageConfigurer,
                )

                # Determine build tool
                build_tool = "maven"
                if config:
                    build_tool = getattr(config, "build_tool", "maven")

                configurers = [
                    JvmBaseImageConfigurer(
                        default_jdk_version=kwargs.get("jvm_version", "24")
                    ),
                ]

                # Add build tool configurer
                if build_tool == "maven":
                    configurers.append(MavenConfigurer())
                else:
                    configurers.append(GradleConfigurer())

                # Add task configurer
                configurers.append(TaskImageConfigurer())

                return configurers

        Note:
            Plugin configurers are automatically discovered and added by
            BaseEnvironmentManager if enable_plugins=True. You don't need
            to include plugin configurers in this list.
        """
        # Default implementation: return empty list (rely on plugins)
        # Subclasses should override to provide spec-specific configurers
        return []

    @abstractmethod
    def get_evaluators(
        self,
        config: DatasetConfig,
        env_config: EnvironmentConfig,
        enable_plugins: bool = True,
        **kwargs,
    ) -> List[Evaluator]:
        """Get list of evaluators for this specification.

        Args:
            config: Dataset configuration for the task
            env_config: Environment configuration
            enable_plugins: If True, auto-discover and load plugin evaluators (default: True)
            **kwargs: Spec-specific initialization parameters

        Returns:
            List of Evaluator instances to run in pipeline

        Note:
            Subclasses should call load_plugin_evaluators(enable_plugins) to automatically
            load applicable plugin evaluators for this spec.
        """
        pass

    def load_plugin_evaluators(self, enable_plugins: bool = True) -> List[Evaluator]:
        """Load plugin evaluators applicable to this spec.

        This is a helper method that subclasses can call from get_evaluators()
        to automatically discover and load plugin evaluators registered for this spec.

        Args:
            enable_plugins: If True, discover and load plugins; if False, return empty list

        Returns:
            List of plugin evaluator instances applicable to this spec

        Example:
            def get_evaluators(self, config, env_config, enable_plugins=True, **kwargs):
                # Get standard evaluators
                evaluators = self.container.evaluators()

                # Load plugins
                plugin_evaluators = self.load_plugin_evaluators(enable_plugins)
                evaluators.extend(plugin_evaluators)

                return evaluators
        """
        if not enable_plugins:
            return []

        from .eval import get_global_registry

        registry = get_global_registry()

        # Discover plugins if not already done
        registry.discover_plugins()

        # Get plugin evaluators for this spec
        plugin_evaluators = []
        for metadata in registry.list_for_spec(self.name):
            try:
                # Create evaluator instance (no-arg constructor)
                evaluator = metadata.factory()
                plugin_evaluators.append(evaluator)
                logger.info(
                    f"Loaded plugin evaluator '{metadata.name}' for spec '{self.name}'"
                )
            except Exception as e:
                logger.warning(
                    f"Failed to instantiate plugin evaluator '{metadata.name}' for spec '{self.name}': {e}",
                    exc_info=True,
                )

        if plugin_evaluators:
            logger.info(
                f"Loaded {len(plugin_evaluators)} plugin evaluator(s) for spec '{self.name}'"
            )

        return plugin_evaluators

    def get_evaluation_runner(
        self, config: DatasetConfig, env_config: EnvironmentConfig, **kwargs
    ) -> EvaluationRunner:
        """Create an evaluation runner instance.

        Default implementation returns BaseEvaluationRunner using evaluators
        from get_evaluators(). Subclasses can override for custom behavior.

        Args:
            config: Dataset configuration for the task
            env_config: Environment configuration
            **kwargs: Spec-specific initialization parameters including:
                     - report_manager: Report manager instance
                     - max_workers: Maximum parallel workers
                     - timeout: Default timeout

        Returns:
            EvaluationRunner implementation
        """

        # Get evaluators from spec (env_config removed from kwargs to avoid duplicate)
        evaluators = self.get_evaluators(config, env_config, **kwargs)

        # Extract runner parameters
        max_workers = kwargs.get("max_workers", 1)
        default_timeout = kwargs.get("timeout", 1800)
        report_manager = kwargs.get("report_manager", self.report_manager)

        # Create and return BaseEvaluationRunner
        return BaseEvaluationRunner(
            spec=self,
            evaluators=evaluators,
            max_workers=max_workers,
            default_timeout=default_timeout,
            report_manager=report_manager,
        )

    def get_score_evaluator(self, **kwargs) -> "ScoreEvaluator":
        """Get score evaluator for calculating final scores.

        Default implementation returns BaseScoreEvaluator which:
        - Aggregates scores from all evaluators with max_score > 0
        - Skips evaluators with status SKIPPED
        - Calculates normalized score (0-100): (sum(scores) / sum(max_scores)) * 100
        - Provides detailed breakdown of individual evaluator scores

        Subclasses can override to provide custom scoring logic.

        Args:
            **kwargs: Spec-specific parameters

        Returns:
            ScoreEvaluator instance

        Example:
            # Custom scoring with weights
            def get_score_evaluator(self, **kwargs):
                from my_spec.custom_scorer import WeightedScoreEvaluator
                return WeightedScoreEvaluator(
                    weights={"test_validation": 0.7, "security": 0.3}
                )
        """
        from .eval import BaseScoreEvaluator

        return BaseScoreEvaluator()

    # Optional DI container methods
    # Subclasses can override these to provide container-based dependency management

    @abstractmethod
    def initialize_containers(self) -> None:
        """Initialize DI containers (REQUIRED).

        Subclasses MUST override this to initialize app_container and container.
        This method is called automatically during __init__.

        Example:
            def initialize_containers(self):
                from di.application_container import ApplicationContainer
                from specs.my_spec.my_container import MySpecContainer

                self.app_container = ApplicationContainer.create_with_defaults()
                self.container = MySpecContainer()
                self.container.app.override(self.app_container)

        Raises:
            NotImplementedError: If subclass doesn't implement this method
        """
        pass

    @abstractmethod
    def configure_for_evaluation(
        self, config: DatasetConfig, env_config: EnvironmentConfig, **kwargs
    ) -> None:
        """Configure DI container for specific evaluation instance (REQUIRED).

        This method configures the spec-level DI container with runtime parameters
        based on the task configuration and environment. MUST set self._configured = True.

        Subclasses MUST override this to configure their container with
        runtime parameters (execution_mode, build_system, predictions_mode, etc.).

        Args:
            config: Dataset configuration for the task
            env_config: Environment configuration
            **kwargs: Additional runtime parameters

        Example:
            def configure_for_evaluation(self, config, env_config, **kwargs):
                execution_mode = "docker" if env_config.container_id else "local"
                build_system = "maven" if config.is_maven else "gradle"

                self.container.config.from_dict({
                    "execution_mode": execution_mode,
                    "build_system": build_system,
                    # ... other config
                })

                self._configured = True

        Raises:
            NotImplementedError: If subclass doesn't implement this method
        """
        pass

    def has_container(self) -> bool:
        """Check if spec uses DI containers.

        Returns:
            True if container is initialized, False otherwise
        """
        return self.container is not None

    @abstractmethod
    def get_environment_tools(
        self, config: DatasetConfig, **kwargs
    ) -> EnvironmentTools:
        """Create environment tools instance.

        Args:
            config: Dataset configuration for the task
            **kwargs: Spec-specific initialization parameters

        Returns:
            EnvironmentTools implementation
        """
        pass

    def get_report_manager(
        self,
        report_name: str,
        report_dir: Optional[Path] = None,
        rewrite_reports: bool = False,
        run_id: Optional[str] = None,
    ) -> ReportManager:
        """Create a report manager for tracking evaluation results.

        Args:
            report_name: Name for the report (e.g. "evaluation" or "evaluation_results")
            report_dir: Directory where reports are stored (default: ./reports)
            rewrite_reports: If True, delete existing report file before starting
            run_id: Optional run_id

        Returns:
            ReportManager instance configured for this evaluation run
        """
        # Use default report directory if not specified
        if report_dir is None:
            report_dir = Path.cwd() / "reports"

        # Use custom report name if provided, otherwise use run_id
        filename = f"{report_name}.json"
        report_path = report_dir / filename

        # Create report manager
        report_manager = DefaultReportManager(
            report_dir=report_dir,
            spec_name=self.name,
            report_name=report_name,
            run_id=run_id,
        )

        # If rewrite_reports is True, delete existing report file
        if rewrite_reports:
            if report_path.exists():
                logger.info(f"Rewriting report: deleting existing file {report_path}")
                report_path.unlink()

        return report_manager

    # High-level orchestration methods

    @staticmethod
    def parse_env_vars(env_vars_list: Optional[List[str]]) -> Dict[str, str]:
        """Parse environment variables from CLI format to dictionary.

        Args:
            env_vars_list: List of environment variables in KEY=VALUE format

        Returns:
            Dictionary of environment variables

        Raises:
            ValueError: If any env var is not in KEY=VALUE format

        Example:
            >>> parse_env_vars(["FOO=bar", "BAZ=qux"])
            {'FOO': 'bar', 'BAZ': 'qux'}
        """
        if not env_vars_list:
            return {}

        env_dict = {}
        for env_var in env_vars_list:
            if "=" not in env_var:
                raise ValueError(
                    f"Invalid environment variable format: '{env_var}'. "
                    f"Expected format: KEY=VALUE"
                )
            key, value = env_var.split("=", 1)
            env_dict[key] = value

        return env_dict

    def prepare_environment(
        self, dataset_name: str, instance_ids: List[str], **kwargs
    ) -> EnvironmentPreparationResult:
        """Prepare environments for multiple task instances.

        This method orchestrates environment preparation across multiple tasks:
        1. Load dataset
        2. Get dataset instances
        3. Create environment manager
        4. Setup environment for each instance (parallel or sequential)
        5. Write environment preparation report

        Args:
            dataset_name: Name of the dataset
            instance_ids: List of instance IDs to prepare
            **kwargs: Additional parameters
                     - max_workers: Number of parallel workers (-1 for sequential)
                     - report_dir: Directory where reports are stored
                     - rewrite_reports: If True, delete existing report before starting
                     - report_name: Custom name for the report file
                     - Other spec-specific parameters

        Returns:
            EnvironmentPreparationResult containing:
            - successful_ids: Set of successfully prepared instance IDs
            - failed_ids: Set of failed instance IDs
            - environments: Dict mapping instance_id to EnvironmentConfig
            - errors: Dict mapping failed instance_id to error message
        """
        max_workers = kwargs.get("max_workers", 1)
        logger.info(
            f"Preparing environments for {len(instance_ids)} instances from {dataset_name} "
            f"(max_workers={max_workers})"
        )

        # Parse CLI env_vars and add to kwargs
        cli_env_vars = self.parse_env_vars(kwargs.get("env_vars"))
        if cli_env_vars:
            logger.info(f"Adding {len(cli_env_vars)} environment variable(s) from CLI")
            kwargs["env_vars"] = cli_env_vars

        # Get or create report manager using helper
        report_name = kwargs.get("report_name", "environment")
        report_manager = get_or_create_report_manager(
            spec=self,
            run_id=report_name,
            **kwargs,
        )

        # Get dataset manager (only pass working_dir, not orchestration params)
        working_dir = kwargs.get("working_dir", ".")
        dataset_manager = self.get_dataset_manager(working_dir=working_dir)

        # Storage for results
        environments: Dict[str, EnvironmentConfig] = {}
        errors: Dict[str, str] = {}

        # Create preparation function that returns EnvironmentConfig
        def prepare_single_environment(instance_id: str) -> EnvironmentConfig:
            """Prepare environment for a single instance.

            Returns:
                EnvironmentConfig for the prepared environment

            Raises:
                Exception: On any failure (captured by orchestration layer)
            """
            logger.info(f"Preparing environment for {instance_id}")

            # Get dataset config (include dataset_name for path resolution)
            config = dataset_manager.get_dataset_instance(
                instance_id=instance_id, dataset_name=dataset_name, **kwargs
            )

            # Get environment manager for this config
            env_manager = self.get_environment_manager(config, **kwargs)

            # Setup environment
            try:
                env_config = env_manager.setup_environment(config=config, **kwargs)
                report_manager.set_result(
                    instance_id, EnvironmentConfigReportable(env_config)
                )
            except Exception as e:
                logger.error(f"Failed create environment: {e}")
                report_manager.set_result(
                    instance_id,
                    EnvironmentConfigReportable(
                        error=str(e), status=ResultStatus.FAILED
                    ),
                )
                raise

            logger.info(f"Environment prepared for {instance_id}")

            return env_config

        # Prepare payloads (each instance_id as a tuple)
        payloads = [(instance_id,) for instance_id in instance_ids]

        # Run preparation (parallel or sequential)
        if max_workers == -1:
            succeeded, failed = run_sequential(prepare_single_environment, payloads)
        else:
            succeeded, failed = run_threadpool(
                prepare_single_environment, payloads, max_workers
            )

        # Process successful results
        for payload, result in succeeded:
            instance_id = payload[0]
            environments[instance_id] = result

        # Process failures
        for payload, error in failed:
            instance_id = payload[0]
            error_msg = str(error)
            errors[instance_id] = error_msg
            logger.error(
                f"Failed to prepare environment for {instance_id}: {error_msg}"
            )

        # Write environment configs to file (convert to dicts for JSON serialization)
        environment_config_file = kwargs.get("output_path") or "environment_config.json"

        # Create result object
        result = EnvironmentPreparationResult(
            successful_ids=set(environments.keys()),
            failed_ids=set(errors.keys()),
            environments=environments,
            errors=errors,
            total_count=len(instance_ids),
            environment_config_file=environment_config_file,
        )

        report_manager.mark_completed()

        # Log summary
        logger.info(
            f"Environment preparation complete: {result.success_count}/{result.total_count} succeeded, "
            f"{result.failure_count} failed (success rate: {result.success_rate:.1f}%)"
        )

        if result.failure_count > 0:
            logger.warning(f"Failed instance IDs: {list(result.failed_ids)}")

        # Save environment configs using EnvironmentSerializerManager
        self.env_serializer.save_to_file(
            result.environments, Path(environment_config_file)
        )

        return result

    # Note: _cleanup_environments has been removed.
    # Per-instance cleanup is now handled by with_sandbox helper.
    # For bulk cleanup operations, use cleanup_sandboxes from ee_bench_core.core.utils

    def run_evaluation(
        self, dataset_name: str, instance_ids: List[str], run_id: str, **kwargs
    ) -> Dict[str, Any]:
        """Run evaluations for multiple task instances.

        This method orchestrates evaluation across multiple tasks:
        1. Create report manager (if not provided)
        2. Load dataset
        3. Get dataset instances
        4. Create evaluation runner
        5. Run evaluation for each instance (parallel or sequential)
        6. Report results to ReportManager

        Args:
            dataset_name: Name of the dataset
            instance_ids: List of instance IDs to evaluate
            run_id: Unique identifier for this evaluation run
            **kwargs: Additional parameters
                     - max_workers: Number of parallel workers (-1 for sequential)
                     - timeout: Evaluation timeout in seconds
                     - report_dir: Directory where reports are stored
                     - rewrite_reports: If True, delete existing report before starting
                     - report_name: Custom name for the report file
                     - Other spec-specific parameters

        Returns:
            Report dictionary from ReportManager containing:
            - results: Dict mapping instance_id to result details
            - completed: Boolean indicating if run is complete
            - total_tasks: Total number of tasks
            - Other report metadata

        Raises:
            Exception: If any evaluation fails
        """
        max_workers = kwargs.get("max_workers", 1)
        logger.info(
            f"Running evaluation for {len(instance_ids)} instances from {dataset_name} "
            f"(run_id={run_id}, max_workers={max_workers})"
        )

        # Parse CLI env_vars and add to kwargs
        cli_env_vars = self.parse_env_vars(kwargs.get("env_vars"))
        if cli_env_vars:
            logger.info(f"Adding {len(cli_env_vars)} environment variable(s) from CLI")
            kwargs["env_vars"] = cli_env_vars

        # Get or create report manager using helper
        report_manager = get_or_create_report_manager(
            spec=self,
            run_id=run_id,
            existing_report_manager=self.report_manager,
            **kwargs,
        )

        # Get dataset manager (only pass working_dir, not orchestration params)
        working_dir = kwargs.get("working_dir", ".")
        dataset_manager = self.get_dataset_manager(working_dir=working_dir)

        # Load or build environments using helper
        # Note: Sandboxes are created and managed per-instance in evaluate_single_instance
        environments, _ = load_or_build_environments(**kwargs)

        # If no instance IDs provided, load all instances from the dataset
        if not instance_ids:
            logger.info("No instance IDs provided, loading all instances from dataset")
            try:
                dataset_configs = dataset_manager.list_dataset_instances(
                    dataset_name=dataset_name, **kwargs
                )
                instance_ids = [config.instance_id for config in dataset_configs]
                logger.info(f"Loaded {len(instance_ids)} instances from dataset")
            except Exception as e:
                logger.error(f"Failed to load dataset instances: {e}")
                raise

        # Create evaluation function
        def evaluate_single_instance(instance_id: str) -> None:
            """Evaluate a single instance."""
            logger.info(f"Running evaluation for {instance_id}")

            try:
                # Get dataset config (include dataset_name for path resolution)
                # Filter out dataset_name from kwargs to avoid duplicate argument error
                from ee_bench_core.core.utils import exclude_keys
                dataset_kwargs = exclude_keys(kwargs, "dataset_name")

                config = dataset_manager.get_dataset_instance(
                    instance_id=instance_id, dataset_name=dataset_name, **dataset_kwargs
                )

                # Check if we have a pre-configured environment for this instance
                if instance_id in environments:
                    logger.info(f"Using pre-configured environment for {instance_id} ")
                    env_config = environments[instance_id]
                elif "adhoc" in environments:
                    # Use ad-hoc environment config
                    logger.info(f"Using ad-hoc environment for {instance_id}")
                    env_config = environments["adhoc"]
                else:
                    # Get environment manager to get env config
                    env_manager = self.get_environment_manager(config, **kwargs)

                    # Setup environment (or get existing)
                    env_config = env_manager.setup_environment(config=config, **kwargs)

                # Define evaluation function that uses sandbox
                # Need to return both result and eval_runner for score calculation
                eval_runner = self.get_evaluation_runner(
                    config, env_config, **kwargs
                )
                eval_timeout = kwargs.get("timeout", 1800)

                def run_with_sandbox(sandbox: "Sandbox", **_):
                    """Execute evaluation with managed sandbox."""
                    nonlocal eval_runner

                    # Get evaluation runner for this config
                    # Pass sandbox explicitly, report_manager via kwargs
                    eval_kwargs = dict(kwargs)
                    if report_manager:
                        eval_kwargs["report_manager"] = report_manager

                    # Run evaluation (sandbox lifecycle managed by with_sandbox)
                    return eval_runner.run_evaluation(
                        config=config,
                        sandbox=sandbox,
                        run_id=run_id,
                        timeout=eval_timeout,
                        **kwargs,
                    )

                # Execute with managed sandbox lifecycle
                from ee_bench_core.core.utils import with_sandbox

                from ee_bench_core.core.utils import exclude_keys

                cleanup_requested = kwargs.get("cleanup", False)
                result = with_sandbox(
                    env_config=env_config,
                    func=run_with_sandbox,
                    cleanup=cleanup_requested,
                    **exclude_keys(kwargs, "cleanup"),
                )

                # Calculate final score from evaluator results
                # Get evaluators and results from the evaluation runner
                if eval_runner and hasattr(eval_runner, "pipeline_runner"):
                    # BaseEvaluationRunner has a pipeline_runner attribute
                    pipeline_runner = eval_runner.pipeline_runner
                    evaluators = pipeline_runner.evaluators

                    # Get the actual EvaluatorResult objects from the pipeline runner's last execution
                    # The evaluator results are stored in the shared_context during pipeline execution
                    # We need to reconstruct them from the pipeline result's evaluations dict
                    from .eval import EvaluatorResult, EvaluatorStatus

                    evaluator_results = []
                    if (
                        hasattr(result, "_pipeline_result")
                        and result._pipeline_result.evaluations
                    ):
                        for (
                            eval_name,
                            eval_dict,
                        ) in result._pipeline_result.evaluations.items():
                            # Reconstruct EvaluatorResult from dict
                            evaluator_results.append(
                                EvaluatorResult(
                                    evaluator_name=eval_dict.get(
                                        "evaluator_name", eval_name
                                    ),
                                    status=EvaluatorStatus(
                                        eval_dict.get("status", "success")
                                    ),
                                    message=eval_dict.get("message", ""),
                                    score=eval_dict.get("score", 0.0),
                                    score_breakdown=eval_dict.get("score_breakdown"),
                                    data=eval_dict.get("data", {}),
                                    error=eval_dict.get("error"),
                                )
                            )

                    # Import EvaluationContext for calculate_score
                    from .eval import EvaluationContext

                    context = EvaluationContext(
                        shared_data={},
                        results={r.evaluator_name: r for r in evaluator_results},
                    )

                    final_score = self.get_score_evaluator(**kwargs).calculate_score(
                        evaluators=evaluators,
                        results=evaluator_results,
                        env_config=env_config,
                        config=config,
                        context=context,
                    )

                    result._score = final_score
                else:
                    # Fallback: if result doesn't have pipeline_runner, skip scoring
                    result._score = None

                # Report result to ReportManager if available
                if report_manager:
                    report_manager.set_result(instance_id, result)

                logger.info(f"Evaluation completed for {instance_id}: {result.result}")

            except Exception as e:
                # Handle environment setup or evaluation errors
                logger.error(f"Failed to evaluate {instance_id}: {e}", exc_info=True)

                # Create an error result
                from ee_bench_core.core.eval import PipelineEvaluationResult
                from ee_bench_core.core.eval.base_evaluation_runner import (
                    PipelineEvaluationResultAdapter,
                )
                from ee_bench_core.core.models import ResultStatus

                # Create minimal config if we don't have one yet
                if "config" not in locals():
                    try:
                        config = dataset_manager.get_dataset_instance(
                            instance_id=instance_id, dataset_name=dataset_name, **kwargs
                        )
                    except Exception:
                        # If we can't even get config, create a minimal mock

                        config = type(
                            "MinimalConfig", (), {"instance_id": instance_id}
                        )()

                # Create minimal env_config if we don't have one yet
                if "env_config" not in locals():
                    # Create a minimal mock env_config
                    env_config = None

                # Create error result
                error_result = PipelineEvaluationResult(
                    instance_id=instance_id,
                    result=ResultStatus.FAILED,
                    successful=False,
                    duration=0.0,
                    message=f"Environment setup or evaluation failed: {str(e)}",
                    evaluations={},
                    error=str(e),
                )

                # Wrap as EvaluationResult
                result = PipelineEvaluationResultAdapter(
                    error_result, config, env_config
                )

                # Report error result to ReportManager if available
                if report_manager:
                    report_manager.set_result(instance_id, result)

                logger.info(f"Evaluation failed for {instance_id}: {result.result}")

                # Re-raise to mark as failed in concurrent execution
                raise

        # Prepare payloads (each instance_id as a tuple)
        payloads = [(instance_id,) for instance_id in instance_ids]

        try:
            # Run evaluation (parallel or sequential)
            if max_workers == -1:
                succeeded, failed = run_sequential(evaluate_single_instance, payloads)
            else:
                succeeded, failed = run_threadpool(
                    evaluate_single_instance, payloads, max_workers
                )

            # Mark evaluation run as completed (even if there were failures)
            if report_manager:
                report_manager.mark_completed()

            if failed:
                # failed is now list of (payload, exception) tuples
                failed_ids = [payload[0] for payload, _ in failed]
                logger.error(
                    f"Failed to evaluate {len(failed)} instances: {failed_ids}"
                )
                raise Exception(f"Failed to evaluate instances: {failed_ids}")

            logger.info(f"Successfully completed {len(succeeded)} evaluations")

            # Return the report from report manager
            if report_manager:
                report = report_manager.get_report()
                logger.debug(f"Returning report for run_id={run_id}")
                return report
            else:
                # If no report manager, return minimal summary
                return {
                    "run_id": run_id,
                    "completed": True,
                    "total_tasks": len(instance_ids),
                    "message": "Evaluation completed without report manager"
                }
        finally:
            pass  # No cleanup needed - sandboxes managed per-instance

    def get_command_runner(self, env_config: EnvironmentConfig) -> CommandRunner:
        """Create a command runner for the given environment.

        Default implementation returns BaseCommandRunner that automatically
        selects LocalProcessManager or DockerProcessManager based on env_config type.

        Args:
            env_config: Environment configuration (Docker or Local)

        Returns:
            CommandRunner instance configured for the environment
        """
        from .command_runner import BaseCommandRunner

        return BaseCommandRunner()

    def run_commands(
        self, instance_ids: List[str], commands: List[str], **kwargs
    ) -> Dict[str, Any]:
        """Run one or more commands for multiple task instances.

        This method orchestrates command execution across multiple tasks:
        1. Create report manager (if not provided)
        2. Load pre-configured environments
        3. For each instance:
           - Get environment configuration
           - Create command runner
           - Execute command(s) in sequence
           - Report result for each command
        4. Return report

        Args:
            instance_ids: List of instance IDs to run commands for
            commands: Shell command(s) to execute - list of strings (multiple commands)
            **kwargs: Additional parameters including:
                     - stop_on_error: Stop execution if a command fails (default: True)
                     - max_workers: Number of parallel workers (-1 for sequential)
                     - timeout: Command timeout in seconds (default: 300)
                     - environment_config_path: Path to pre-configured environment file
                     - sandbox: Sandbox type (docker/local) for ad-hoc mode
                     - container_id: Docker container ID for ad-hoc mode
                     - container_image: Docker image for ad-hoc mode
                     - workspace_dir: Workspace directory for ad-hoc mode
                     - report_dir: Directory where reports are stored
                     - rewrite_reports: If True, delete existing report before starting
                     - report_name: Custom name for the report file

        Returns:
            Report dictionary from ReportManager containing command execution results

        Raises:
            ValueError: If instance_ids provided without environment_config_path
            Exception: If command execution fails
        """
        max_workers = kwargs.get("max_workers", 1)
        timeout = kwargs.get("timeout", 300)

        stop_on_error = kwargs.get("stop_on_error", True)

        # Parse CLI env_vars and add to kwargs
        cli_env_vars = self.parse_env_vars(kwargs.get("env_vars"))
        if cli_env_vars:
            logger.info(f"Adding {len(cli_env_vars)} environment variable(s) from CLI")
            kwargs["env_vars"] = cli_env_vars

        logger.info(
            f"Running command for {len(instance_ids)} instance(s) "
            f"(max_workers={max_workers}, timeout={timeout})"
        )
        logger.debug(f"Commands: {commands}")

        # Get or create report manager using helper
        report_manager = get_or_create_report_manager(
            spec=self,
            existing_report_manager=self.report_manager,
            **kwargs,
        )

        # Load or build environments using helper
        environments, _ = load_or_build_environments(instance_ids, **kwargs)
        if not instance_ids:
            instance_ids = ["adhoc"]

        # Track results when no report_manager (for no-report mode)
        from .models import MultiCommandExecutionResult

        collected_results: Dict[str, Any] = {}

        # Create command execution function
        def execute_command_for_instance(instance_id: str) -> None:
            """Execute one or more commands for a single instance."""
            is_multi_command = len(commands) > 1

            if is_multi_command:
                logger.info(f"Executing {len(commands)} commands for {instance_id}")
            else:
                logger.info(f"Executing command for {instance_id}")

            try:
                env_config = environments[instance_id]

                # Define execution function that uses sandbox
                def run_with_sandbox(sandbox: "Sandbox", **_):
                    """Execute commands with managed sandbox."""
                    # Get command runner
                    command_runner = self.get_command_runner(env_config)

                    # Filter out parameters that are passed explicitly to avoid duplicates
                    from ee_bench_core.core.utils import exclude_keys

                    exec_kwargs = exclude_keys(
                        kwargs, "timeout", "commands", "stop_on_error"
                    )

                    # Execute commands in sequence
                    command_results = []
                    for idx, cmd in enumerate(commands, 1):
                        if is_multi_command:
                            logger.info(
                                f"[{instance_id}] Executing command {idx}/{len(commands)}: {cmd}"
                            )

                        # Execute single command with sandbox
                        result = command_runner.run_command(
                            command=cmd,
                            sandbox=sandbox,
                            timeout=timeout,
                            instance_id=instance_id,
                            **exec_kwargs,
                        )

                        command_results.append(result)

                        # Log individual command result
                        logger.info(
                            f"[{instance_id}] Command {idx}/{len(commands)} completed: "
                            f"exit_code={result.exit_code}, successful={result.successful}"
                        )

                        # Stop on error if configured
                        if stop_on_error and not result.successful:
                            logger.warning(
                                f"[{instance_id}] Stopping execution after command {idx} failure "
                                f"(stop_on_error=True)"
                            )
                            break

                    return command_results

                # Execute with managed sandbox lifecycle
                from ee_bench_core.core.utils import with_sandbox

                from ee_bench_core.core.utils import exclude_keys

                cleanup_requested = kwargs.get("cleanup", False)
                command_results = with_sandbox(
                    env_config=env_config,
                    func=run_with_sandbox,
                    cleanup=cleanup_requested,
                    **exclude_keys(kwargs, "cleanup"),
                )

                # Create appropriate result object
                if is_multi_command:
                    # Wrap in MultiCommandExecutionResult
                    final_result = MultiCommandExecutionResult(
                        instance_id=instance_id,
                        commands=commands,
                        results=command_results,
                        stop_on_error=stop_on_error,
                        environment=env_config,
                    )

                    logger.info(
                        f"Multi-command execution completed for {instance_id}: "
                        f"{final_result.commands_successful}/{len(commands)} successful, "
                        f"total_duration={final_result.total_duration:.2f}s"
                    )
                else:
                    # Single command: use the CommandExecutionResult directly
                    final_result = command_results[0]

                    logger.info(
                        f"Command execution completed for {instance_id}: "
                        f"exit_code={final_result.exit_code}, successful={final_result.successful}"
                    )

                # Report result or collect it
                if report_manager:
                    report_manager.set_result(instance_id, final_result)
                else:
                    collected_results[instance_id] = final_result

            except Exception as e:
                logger.error(
                    f"Failed to execute command for {instance_id}: {e}", exc_info=True
                )

                # Create error result
                error_result = CommandExecutionResult(
                    instance_id=instance_id,
                    command=commands[0] if commands else "",
                    exit_code=-1,
                    stdout="",
                    stderr="",
                    duration=0.0,
                    error=str(e),
                    environment=environments.get(instance_id),
                )

                # Report error result or collect it
                if report_manager:
                    report_manager.set_result(instance_id, error_result)
                else:
                    collected_results[instance_id] = error_result

                # Re-raise to mark as failed
                raise

        # Prepare payloads
        payloads = [(instance_id,) for instance_id in instance_ids]

        # Execute commands (parallel or sequential)
        if max_workers == -1:
            succeeded, failed = run_sequential(execute_command_for_instance, payloads)
        else:
            succeeded, failed = run_threadpool(
                execute_command_for_instance, payloads, max_workers
            )

        # Mark run as completed
        if report_manager:
            report_manager.mark_completed()

        if failed:
            failed_ids = [payload[0] for payload, _ in failed]
            logger.error(
                f"Failed to execute command for {len(failed)} instances: {failed_ids}"
            )
            raise Exception(f"Failed to execute command for instances: {failed_ids}")

        logger.info(f"Successfully executed command for {len(succeeded)} instance(s)")

        # Return report
        if report_manager:
            report = report_manager.get_report()
            logger.debug("Returning report")
            return report
        else:
            # Return collected results for no-report mode
            # Convert CommandExecutionResult objects to dicts
            results_dict = {}
            for instance_id, cmd_result in collected_results.items():
                results_dict[instance_id] = cmd_result.to_dict()

            return {
                "completed": True,
                "total_tasks": len(instance_ids),
                "results": results_dict,
                "message": "Command execution completed without report manager",
            }

    def get_base_cli_parameters(self, command: str) -> List[Dict[str, Any]]:
        """Get base CLI parameters common to all specs.

        Args:
            command: Command name (e.g., "prepare_environment", "run_evaluation")

        Returns:
            List of parameter definitions for Click options
        """
        # Calculate default max_workers as 75% of CPU cores
        cpu_count = multiprocessing.cpu_count()
        default_max_workers = max(1, int(cpu_count * 0.75))

        # Base parameters common to all commands
        base_params = [
            {
                "names": ["--max-workers"],
                "type": int,
                "default": default_max_workers,
                "help": f"Maximum number of parallel workers (default: {default_max_workers}, 75% of {cpu_count} cores; "
                f"use -1 for sequential)",
            },
            {
                "names": ["--report-dir"],
                "type": str,
                "default": None,
                "help": "Directory where evaluation reports are stored (default: ./reports)",
            },
            {
                "names": ["--rewrite-reports"],
                "is_flag": True,
                "default": False,
                "help": "Delete existing report file before starting evaluation",
            },
            {
                "names": ["--report-name"],
                "type": str,
                "default": None,
                "help": "Custom name for the report file (default: {run_id}.json)",
            },
            {
                "names": ["--env-vars"],
                "type": str,
                "multiple": True,
                "default": None,
                "help": "Environment variables to set (format: KEY=VALUE). Can be specified multiple times.",
            },
        ]

        # Add command-specific parameters
        # Normalize command name (handle both hyphens and underscores)
        normalized_command = command.replace("_", "-")

        if normalized_command == "prepare-environment":
            base_params.extend(
                [
                    {
                        "names": ["--output-path"],
                        "type": str,
                        "default": None,
                        "help": "Path for the environment config file (default: environment-config.json)",
                    },
                    {
                        "names": ["--environment-config-path"],
                        "type": str,
                        "default": None,
                        "help": "Path to existing environment config JSON file to build upon (for incremental builds)",
                    },
                ]
            )
        elif normalized_command == "run-evaluation":
            base_params.extend(
                [
                    {
                        "names": ["--environment-config-path"],
                        "type": str,
                        "default": None,
                        "help": "Path to pre-configured environment config file from prepare-environment command",
                    },
                    {
                        "names": ["--sandbox"],
                        "type": str,
                        "default": None,
                        "help": "Sandbox type: 'docker' or 'local' (for ad-hoc mode without environment_config_path)",
                    },
                    {
                        "names": ["--container-id"],
                        "type": str,
                        "default": None,
                        "help": "Docker container ID (ad-hoc mode)",
                    },
                    {
                        "names": ["--container-image"],
                        "type": str,
                        "default": None,
                        "help": "Docker image for ephemeral container (ad-hoc mode)",
                    },
                    {
                        "names": ["--workspace-dir"],
                        "type": str,
                        "default": None,
                        "help": "Workspace directory path (ad-hoc mode)",
                    },
                    {
                        "names": ["--project-dir"],
                        "type": str,
                        "default": None,
                        "help": "Project directory relative to workspace (ad-hoc mode, default: task_project)",
                    },
                    {
                        "names": ["--file"],
                        "type": str,
                        "default": None,
                        "help": "Path to file with predictions",
                    },
                    {
                        "names": ["--cleanup"],
                        "is_flag": True,
                        "default": False,
                        "help": "Cleanup environment after evaluation (stop/remove containers for docker, remove workspace for local)",
                    },
                ]
            )
        elif normalized_command == "run-command":
            base_params.extend(
                [
                    {
                        "names": ["--timeout"],
                        "type": int,
                        "default": 300,
                        "help": "Command timeout in seconds (default: 300)",
                    },
                    {
                        "names": ["--environment-config-path"],
                        "type": str,
                        "default": None,
                        "help": "Path to pre-configured environment config file (pre-configured mode)",
                    },
                    {
                        "names": ["--sandbox"],
                        "type": str,
                        "default": None,
                        "help": "Sandbox type: 'docker' or 'local' (required for ad-hoc mode)",
                    },
                    {
                        "names": ["--container-id"],
                        "type": str,
                        "default": None,
                        "help": "Docker container ID (ad-hoc mode)",
                    },
                    {
                        "names": ["--container-image"],
                        "type": str,
                        "default": None,
                        "help": "Docker image for ephemeral container (ad-hoc mode)",
                    },
                    {
                        "names": ["--workspace-dir"],
                        "type": str,
                        "default": None,
                        "help": "Workspace directory path (required for ad-hoc mode)",
                    },
                    {
                        "names": ["--stdin"],
                        "type": str,
                        "default": None,
                        "help": "Input to send to command via stdin",
                    },
                    {
                        "names": ["--stdin-file"],
                        "type": str,
                        "default": None,
                        "help": "File to read stdin input from",
                    },
                    {
                        "names": ["--stop-on-error"],
                        "is_flag": True,
                        "default": True,
                        "help": "Stop execution if a command fails (default: True, only applies when multiple --command options provided)",
                    },
                    {
                        "names": ["--script"],
                        "type": str,
                        "default": None,
                        "help": "Path to shell script file to execute (takes precedence over --command)",
                    },
                    {
                        "names": ["--script-content"],
                        "type": str,
                        "default": None,
                        "help": "Shell script content to execute directly (takes precedence over --command if --script not provided)",
                    },
                    {
                        "names": ["--start"],
                        "is_flag": True,
                        "default": False,
                        "help": "Automatically start stopped Docker containers before command execution",
                    },
                ]
            )
        elif normalized_command == "collect-predictions":
            base_params.extend(
                [
                    {
                        "names": ["--timeout"],
                        "type": int,
                        "default": 300,
                        "help": "Per-instance collection timeout in seconds (default: 300)",
                    },
                    {
                        "names": ["--environment-config-path"],
                        "type": str,
                        "default": None,
                        "help": "Path to pre-configured environment config file (pre-configured mode)",
                    },
                    {
                        "names": ["--sandbox"],
                        "type": str,
                        "default": None,
                        "help": "Sandbox type: 'docker' or 'local' (required for ad-hoc mode)",
                    },
                    {
                        "names": ["--container-id"],
                        "type": str,
                        "default": None,
                        "help": "Docker container ID (ad-hoc mode)",
                    },
                    {
                        "names": ["--container-image"],
                        "type": str,
                        "default": None,
                        "help": "Docker image for ephemeral container (ad-hoc mode)",
                    },
                    {
                        "names": ["--workspace-dir"],
                        "type": str,
                        "default": None,
                        "help": "Workspace directory path (required for ad-hoc mode)",
                    },
                    {
                        "names": ["--project-dir"],
                        "type": str,
                        "default": None,
                        "help": "Project directory relative to workspace (ad-hoc mode, default: task_project)",
                    },
                    {
                        "names": ["--output-path"],
                        "type": str,
                        "default": None,
                        "help": "Path for predictions JSON file (list-only)",
                    },
                    {
                        "names": ["--overwrite"],
                        "is_flag": True,
                        "default": False,
                        "help": "Overwrite output file if it exists",
                    },
                    {
                        "names": ["--include-empty"],
                        "is_flag": True,
                        "default": True,
                        "help": "Include entries with empty predictions (default: True)",
                    },
                    {
                        "names": ["--start"],
                        "is_flag": True,
                        "default": False,
                        "help": "Automatically start stopped Docker containers before prediction collection",
                    },
                    {
                        "names": ["--cleanup"],
                        "is_flag": True,
                        "default": False,
                        "help": "Cleanup environment after prediction collection (stop/remove containers for docker, remove workspace for local)",
                    },
                    {
                        "names": ["--base-commit"],
                        "type": str,
                        "default": None,
                        "help": "Base commit to compare against (e.g., 'HEAD', 'abc123'). If not specified, compares against staging area.",
                    },
                    {
                        "names": ["--predictions"],
                        "type": str,
                        "default": None,
                        "help": "Explicitly select predictions collector by name (e.g., 'git_diff', 'agent', 'gold', 'json'). "
                        "If not specified, collector is auto-selected based on other parameters.",
                    },
                    {
                        "names": ["--file"],
                        "type": str,
                        "default": None,
                        "help": "Path to predictions file (e.g., predictions.json) for file-based collectors. ",
                    },
                    {
                        "names": ["--agent"],
                        "type": str,
                        "default": None,
                        "help": "Agent name for agent-based predictions collection (e.g., 'claude_code', 'gemini'). ",
                    },
                    {
                        "names": ["--agent-config-path"],
                        "type": str,
                        "default": None,
                        "help": "Path to agent configuration file (JSON).",
                    },
                    {
                        "names": ["--agent-opts"],
                        "type": str,
                        "multiple": True,
                        "default": None,
                        "help": "Agent options in KEY=VALUE format (e.g., API_KEY=xxx). Can be specified multiple times.",
                    },
                ]
            )

        return base_params

    # ---- Collect Predictions (list-only) ----
    def get_predictions_collector_provider(self, **kwargs):
        """Get predictions collector provider for this spec.

        Default implementation returns BasePredictionsCollectorProvider which selects
        appropriate collector based on CLI parameters (--agent, --predictions-path, etc.).
        Subclasses can override to provide spec-specific providers.

        Args:
            **kwargs: Parameters including:
                - agent: Agent name for agent-based collection
                - agent_config_path: Path to agent configuration
                - predictions_path: Path to predictions file or special value

        Returns:
            PredictionsCollectorProvider instance

        Examples:
            # Code spec returns CodePredictionsCollectorProvider
            def get_predictions_collector_provider(self, **kwargs):
                from ee_bench_code_spec.collectors import CodePredictionsCollectorProvider
                return CodePredictionsCollectorProvider()
        """
        from .predictions_collector_provider import BasePredictionsCollectorProvider

        return BasePredictionsCollectorProvider()

    def collect_predictions(
        self, instance_ids: List[str], **kwargs
    ) -> List[Dict[str, Any]]:
        """Collect predictions for multiple task instances and return list-only output.

        Args:
            instance_ids: List of instance IDs
            **kwargs: Orchestration parameters including:
                - environment_config_path | sandbox + workspace_dir (+ docker params) for ad-hoc
                - timeout, max_workers
                - include_empty: include entries with empty predictions (default True)
                - output_path: path to write predictions JSON (optional)
                - overwrite: overwrite output file if exists (default False)
                - env_vars: environment variables from CLI
        """
        max_workers = kwargs.get("max_workers", 1)
        timeout = kwargs.get("timeout", 300)
        include_empty = kwargs.get("include_empty", True)

        # Parse CLI env_vars and add to kwargs
        cli_env_vars = self.parse_env_vars(kwargs.get("env_vars"))
        if cli_env_vars:
            kwargs["env_vars"] = cli_env_vars

        logger.info(
            f"Collecting predictions for {len(instance_ids)} instance(s)"
            f"(max_workers={max_workers}, timeout={timeout})"
        )

        # Get dataset manager for loading dataset configs
        working_dir = kwargs.get("working_dir", ".")
        dataset_manager = self.get_dataset_manager(working_dir=working_dir)
        dataset_name = kwargs.get("dataset_name")

        # Load or build environments (validates parameters and adjusts instance_ids)
        # Note: Sandboxes are created and managed per-instance in collect_single
        environments, instance_ids = load_or_build_environments(
            instance_ids=instance_ids, **kwargs
        )

        predictions_collector_provider = self.get_predictions_collector_provider(**kwargs)


        # Per-instance collection function
        results: List[PredictionsEntry] = []

        def collect_single(iid: str) -> PredictionsEntry:
            if iid not in environments:
                available_keys = list(environments.keys())
                raise KeyError(
                    f"Instance ID '{iid}' not found in environments. "
                    f"Available keys: {available_keys}. "
                    f"This may indicate a mismatch between instance_ids and loaded environments."
                )

            env_config = environments[iid]

            collector = predictions_collector_provider.get_collector(
                spec=self, env_config=env_config, **kwargs
            )

            try:
                # Get dataset config for this instance
                # Filter out dataset_name from kwargs to avoid duplicate argument error
                from ee_bench_core.core.utils import exclude_keys
                dataset_kwargs = exclude_keys(kwargs, "dataset_name")

                config = dataset_manager.get_dataset_instance(
                    instance_id=iid, dataset_name=dataset_name, **dataset_kwargs
                )

                # Define collection function that uses sandbox
                def run_with_sandbox(sandbox: "Sandbox", **_):
                    """Execute collection with managed sandbox."""
                    # Filter out timeout and dataset_name from kwargs to avoid duplicate argument error
                    from ee_bench_core.core.utils import exclude_keys

                    collect_kwargs = exclude_keys(kwargs, "timeout", "dataset_name")

                    # Pass sandbox explicitly to collector
                    return collector.collect(
                        iid, sandbox, config, timeout=timeout, **collect_kwargs
                    )

                # Execute with managed sandbox lifecycle
                from ee_bench_core.core.utils import with_sandbox

                from ee_bench_core.core.utils import exclude_keys

                cleanup_requested = kwargs.get("cleanup", False)
                return with_sandbox(
                    env_config=env_config,
                    func=run_with_sandbox,
                    cleanup=cleanup_requested,
                    **exclude_keys(kwargs, "cleanup"),
                )

            except Exception as e:
                return PredictionsEntry(
                    instance_id=iid,
                    prediction="",
                    status=ResultStatus.FAILED,
                    error=str(e),
                )

        # Prepare payloads
        payloads = [(iid,) for iid in instance_ids]

        try:
            # Run in parallel or sequential
            if max_workers == -1:
                succeeded, failed = run_sequential(
                    lambda iid: collect_single(iid), payloads
                )
            else:
                succeeded, failed = run_threadpool(
                    lambda iid: collect_single(iid), payloads, max_workers
                )

            # Accumulate
            for payload, entry in succeeded:
                results.append(entry)
            for payload, err in failed:
                iid = payload[0]
                # err is exception; convert to error entry
                results.append(
                    PredictionsEntry(
                        instance_id=iid,
                        prediction="",
                        status=ResultStatus.FAILED,
                        error=str(err),
                    )
                )

            # Filter empties if requested
            if not include_empty:
                results = [e for e in results if not e.is_empty()]

            # Write to file if requested using PredictionsSerializer
            output_path = kwargs.get("output_path")
            if output_path:
                overwrite = kwargs.get("overwrite", False)
                output_file = Path(output_path)

                # Use PredictionsSerializer to save (handles merge/overwrite)
                self.predictions_serializer.save_to_file(
                    items=results,
                    file_path=output_file,
                    overwrite=overwrite,
                )

            # Serialize results to list format for return
            serialized_results = [e.to_list_item() for e in results]

            # Return serialized list
            return serialized_results
        finally:
            pass  # No cleanup needed - sandboxes managed per-instance

    def start_environments(self, instance_ids: List[str], **kwargs) -> Dict[str, Any]:
        """Start environments from config file or ad-hoc configuration.

        For local environments: just writes/updates config file without starting anything.
        For Docker environments: starts containers and writes/updates config with container IDs.

        Args:
            instance_ids: List of instance IDs to start environments for
            **kwargs: Additional parameters including:
                - output_path: Path to write environment config file (default: environment_config.json)
                - environment_config_path: Path to existing environment config (pre-configured mode)
                - sandbox: Sandbox type (docker/local) for ad-hoc mode
                - workspace_dir: Workspace directory for ad-hoc mode
                - container_image: Docker image for ad-hoc Docker mode
                - project_dir: Project directory relative to workspace
                - env_vars: Environment variables dictionary

        Returns:
            Dictionary with results
        """
        output_path = kwargs.get("output_path", "environment_config.json")

        logger.info(f"Starting environments (output_path={output_path})")

        # Parse CLI env_vars
        cli_env_vars = self.parse_env_vars(kwargs.get("env_vars"))
        if cli_env_vars:
            kwargs["env_vars"] = cli_env_vars

        # Load or build environments
        environments, instance_ids = load_or_build_environments(
            instance_ids=instance_ids, **kwargs
        )

        # Track results
        total = len(environments)
        started = 0
        skipped = 0
        failed = 0
        container_ids = {}

        # Process each environment
        for instance_id, env_config in environments.items():
            try:
                sandbox = SandboxFactory.create(env_config)
                sandbox.start()
                started += 1

            except Exception as e:
                logger.error(f"Failed to start sandbox for {instance_id}: {e}")
                failed += 1

        # Write updated environment config to file
        logger.info(f"Writing environment config to: {output_path}")
        self.env_serializer.save_to_file(environments, Path(output_path))

        # Return results
        result = {
            "total": total,
            "started": started,
            "skipped": skipped,
            "failed": failed,
            "config_file": output_path,
        }

        return result
