"""ee_bench.module_test — build-system-agnostic test name enrichment provider."""

from ee_bench.module_test.provider import ModuleTestProvider

__all__ = ["ModuleTestProvider"]
__version__ = "0.1.0"
