"""Predictions serialization manager.

This module provides centralized management for serializing and deserializing
predictions to/from JSON files in list format.
"""

import logging
from typing import Any, Dict, Optional

from .base_serializer import BaseSerializerManager
from .models import PredictionResult, ResultStatus

logger = logging.getLogger(__name__)


class PredictionsSerializer(BaseSerializerManager[PredictionResult]):
    """Manager for serializing and deserializing predictions.

    This class provides centralized functionality for:
    - Saving predictions to JSON files (list format)
    - Loading predictions from JSON files
    - Merging predictions by instance_id when file exists
    - Converting between PredictionResult objects and dictionaries

    The predictions are stored in list format:
    [
        {"instance_id": "task-1", "prediction": "...", "status": "ok"},
        {"instance_id": "task-2", "prediction": "...", "status": "ok"}
    ]
    """

    def __init__(self):
        """Initialize predictions serializer manager."""

    def to_dict(self, item: PredictionResult) -> Dict[str, Any]:
        """Convert a PredictionsEntry to dictionary.

        Args:
            item: Predictions entry object

        Returns:
            Dictionary representation using to_list_item() format

        Raises:
            TypeError: If item cannot be serialized
        """
        try:
            return item.to_list_item()
        except Exception as e:
            logger.error(f"Failed to serialize PredictionsEntry: {e}")
            raise TypeError(f"Cannot serialize PredictionsEntry: {e}") from e

    def from_dict(self, data: Dict[str, Any]) -> PredictionResult:
        """Convert a dictionary to PredictionsEntry.

        Args:
            data: Dictionary containing prediction data with keys:
                 - instance_id: Unique identifier
                 - prediction: Prediction content (typically git diff)
                 - status: Status string (e.g., "success", "failed", "skipped")
                 - error: Optional error message

        Returns:
            PredictionsEntry instance

        Raises:
            ValueError: If data format is invalid
        """
        try:
            # Parse status
            status_value = data.get("status")
            if status_value:
                if isinstance(status_value, str):
                    status = ResultStatus(status_value)
                else:
                    status = status_value
            else:
                status = None

            return PredictionResult(
                instance_id=data.get("instance_id", ""),
                prediction=data.get("prediction", ""),
                status=status,
                error=data.get("error"),
            )
        except Exception as e:
            logger.error(f"Failed to deserialize PredictionsEntry: {e}")
            raise ValueError(f"Invalid prediction data format: {e}") from e

    def get_collection_type(self) -> str:
        """Get the collection type for predictions.

        Returns:
            "list" - predictions are stored as a JSON list
        """
        return "list"

    def get_item_key(self, item: PredictionResult) -> str:
        """Get the unique key for a prediction entry.

        Args:
            item: PredictionsEntry to extract key from

        Returns:
            The instance_id of the entry
        """
        return item.instance_id

    def _extract_key_from_dict(self, item_dict: Dict[str, Any]) -> Optional[str]:
        """Extract the key from a dictionary representation of a prediction.

        Args:
            item_dict: Dictionary representation of a prediction

        Returns:
            The instance_id field value, or None if not present
        """
        return item_dict.get("instance_id")
