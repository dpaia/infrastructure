"""Per-repo C# build/test configs translated from swebench_matterhorn."""

from __future__ import annotations

# Keys: (repo, env_setup_version) for install, (repo, run_tests_version) for test.
# test_framework is a per-instance field (e.g. "net8.0") interpolated at render time.

REPO_CONFIGS: dict[str, dict[str, dict[str, str]]] = {
    "App-vNext/Polly": {
        "1.0": {
            "install": (
                'dotnet add "./test/Polly.Core.Tests/Polly.Core.Tests.csproj" package JUnitTestLogger\n'
                'dotnet build'
            ),
            "test_project": "./test/Polly.Core.Tests/Polly.Core.Tests.csproj",
            "test_logger": "junit;LogFilePath=$ARTIFACTS_DIR/tests.log",
            "parser": "junit_xml",
        },
    },
    "devlooped/moq": {
        "1.0": {
            "install": (
                'rm -rf "./tests/Moq.Tests/MockRepositoryFixture.cs"\n'
                'dotnet add "./tests/Moq.Tests/Moq.Tests.csproj" package JUnitTestLogger\n'
                'dotnet build'
            ),
            "test_project": "./tests/Moq.Tests/Moq.Tests.csproj",
            "test_logger": "junit;LogFilePath=$ARTIFACTS_DIR/tests.log",
            "parser": "junit_xml",
        },
    },
    "spectreconsole/spectre.console": {
        "1.0": {
            "install": (
                'dotnet add "./test/Spectre.Console.Analyzer.Tests/Spectre.Console.Analyzer.Tests.csproj" '
                'package JUnitTestLogger\n'
                'dotnet build "./src/Spectre.Console.sln"'
            ),
            "test_project": "./test/Spectre.Console.Analyzer.Tests/Spectre.Console.Analyzer.Tests.csproj",
            "test_logger": "junit;LogFilePath=$ARTIFACTS_DIR/tests.log",
            "parser": "junit_xml",
        },
        "1.1": {
            "install": (
                'dotnet add "./test/Spectre.Console.Tests/Spectre.Console.Tests.csproj" '
                'package JUnitTestLogger\n'
                'dotnet build "./src/Spectre.Console.sln"'
            ),
            "test_project": "./test/Spectre.Console.Tests/Spectre.Console.Tests.csproj",
            "test_logger": "junit;LogFilePath=$ARTIFACTS_DIR/tests.log",
            "parser": "junit_xml",
        },
        "1.2": {
            "install": (
                'dotnet add "./test/Spectre.Console.Cli.Tests/Spectre.Console.Cli.Tests.csproj" '
                'package JUnitTestLogger\n'
                'dotnet build "./src/Spectre.Console.sln"'
            ),
            "test_project": "./test/Spectre.Console.Cli.Tests/Spectre.Console.Cli.Tests.csproj",
            "test_logger": "junit;LogFilePath=$ARTIFACTS_DIR/tests.log",
            "parser": "junit_xml",
        },
        "1.3": {
            "install": (
                'dotnet add "./src/Tests/Spectre.Console.Tests/Spectre.Console.Tests.csproj" '
                'package JUnitTestLogger\n'
                'dotnet build "./src/Spectre.Console.sln"'
            ),
            "test_project": "./src/Tests/Spectre.Console.Tests/Spectre.Console.Tests.csproj",
            "test_logger": "junit;LogFilePath=$ARTIFACTS_DIR/tests.log",
            "parser": "junit_xml",
        },
    },
    "fluentassertions/fluentassertions": {
        "1.0": {
            "install": (
                'dotnet add "./Tests/FluentAssertions.Specs/FluentAssertions.Specs.csproj" '
                'package JUnitTestLogger\n'
                'dotnet build -p:TreatWarningsAsErrors=false -p:EnforceCodeStyleInBuild=false -p:EnableNETAnalyzers=false'
            ),
            "test_project": "./Tests/FluentAssertions.Specs/FluentAssertions.Specs.csproj",
            "test_logger": "junit;LogFilePath=$ARTIFACTS_DIR/tests.log",
            "build_flags": "-p:TreatWarningsAsErrors=false -p:EnforceCodeStyleInBuild=false -p:EnableNETAnalyzers=false",
            "parser": "junit_xml",
        },
        "1.1": {
            "install": (
                'dotnet add "./Tests/FluentAssertions.Equivalency.Specs/FluentAssertions.Equivalency.Specs.csproj" '
                'package JUnitTestLogger\n'
                'dotnet build -p:TreatWarningsAsErrors=false -p:EnforceCodeStyleInBuild=false -p:EnableNETAnalyzers=false'
            ),
            "test_project": "./Tests/FluentAssertions.Equivalency.Specs/FluentAssertions.Equivalency.Specs.csproj",
            "test_logger": "junit;LogFilePath=$ARTIFACTS_DIR/tests.log",
            "build_flags": "-p:TreatWarningsAsErrors=false -p:EnforceCodeStyleInBuild=false -p:EnableNETAnalyzers=false",
            "parser": "junit_xml",
        },
    },
    "dotnet/BenchmarkDotNet": {
        "1.0": {
            "install": (
                'rm -rf "./tests/BenchmarkDotNet.Tests/Environments/HostEnvironmentInfoTests.cs"\n'
                'dotnet add "./tests/BenchmarkDotNet.Tests/BenchmarkDotNet.Tests.csproj" '
                'package JUnitTestLogger\n'
                'dotnet build "./BenchmarkDotNet.sln" -p:TreatWarningsAsErrors=false'
            ),
            "test_project": "./tests/BenchmarkDotNet.Tests/BenchmarkDotNet.Tests.csproj",
            "test_logger": "junit;LogFilePath=$ARTIFACTS_DIR/tests.log",
            "build_flags": "-p:TreatWarningsAsErrors=false",
            "parser": "junit_xml",
        },
        "1.1": {
            "install": (
                'rm -rf "./tests/BenchmarkDotNet.Tests/Environments/HostEnvironmentInfoTests.cs"\n'
                'dotnet add "./tests/BenchmarkDotNet.Tests/BenchmarkDotNet.Tests.csproj" '
                'package JUnitTestLogger\n'
                'dotnet build "./BenchmarkDotNet.sln"'
            ),
            "test_project": "./tests/BenchmarkDotNet.Tests/BenchmarkDotNet.Tests.csproj",
            "test_logger": "junit;LogFilePath=$ARTIFACTS_DIR/tests.log",
            "parser": "junit_xml",
        },
    },
    "dotnet/efcore": {
        "1.0": {
            "install": (
                'git submodule update --init --recursive\n'
                'rm -rf ./test/EFCore.Specification.Tests/CustomConvertersTestBase.cs\n'
                'rm -rf ./test/EFCore.InMemory.FunctionalTests/CustomConvertersInMemoryTest.cs\n'
                'dotnet build ./test/EFCore.Tests/EFCore.Tests.csproj -p:TreatWarningsAsErrors=false'
            ),
            "test_project": "./test/EFCore.Tests/EFCore.Tests.csproj",
            "test_logger": "trx;LogFileName=$ARTIFACTS_DIR/tests.log",
            "build_flags": "-p:TreatWarningsAsErrors=false",
            "parser": "trx",
        },
        "1.1": {
            "install": (
                'git submodule update --init --recursive\n'
                'rm -rf ./test/EFCore.Specification.Tests/CustomConvertersTestBase.cs\n'
                'rm -rf ./test/EFCore.InMemory.FunctionalTests/CustomConvertersInMemoryTest.cs\n'
                'dotnet build ./test/EFCore.Relational.Tests/EFCore.Relational.Tests.csproj -p:TreatWarningsAsErrors=false'
            ),
            "test_project": "./test/EFCore.Relational.Tests/EFCore.Relational.Tests.csproj",
            "test_logger": "trx;LogFileName=$ARTIFACTS_DIR/tests.log",
            "build_flags": "-p:TreatWarningsAsErrors=false",
            "parser": "trx",
        },
    },
    "jellyfin/jellyfin": {
        "1.0": {
            "install": (
                'cd MediaBrowser.Model\n'
                'dotnet add package System.Text.Json --version 8.0.5\n'
                'cd ..\n'
                'cd Emby.Server.Implementations\n'
                'dotnet add package Microsoft.Extensions.Caching.Memory --version 9.0.0\n'
                'cd ..\n'
                'cd tests\n'
                'cd Jellyfin.Server.Tests\n'
                'dotnet add package Microsoft.Extensions.Options --version 9.0.0\n'
                'cd ..\n'
                'cd ..\n'
                'dotnet add "./tests/Jellyfin.Model.Tests/Jellyfin.Model.Tests.csproj" '
                'package JUnitTestLogger\n'
                'dotnet build'
            ),
            "test_project": "./tests/Jellyfin.Model.Tests/Jellyfin.Model.Tests.csproj",
            "test_logger": "junit;LogFilePath=$ARTIFACTS_DIR/tests.log",
            "parser": "junit_xml",
        },
        "1.1": {
            "install": (
                'cd MediaBrowser.Model\n'
                'dotnet add package System.Text.Json --version 8.0.5\n'
                'cd ..\n'
                'cd Emby.Server.Implementations\n'
                'dotnet add package Microsoft.Extensions.Caching.Memory --version 9.0.0\n'
                'cd ..\n'
                'cd tests\n'
                'cd Jellyfin.Server.Tests\n'
                'dotnet add package Microsoft.Extensions.Options --version 9.0.0\n'
                'cd ..\n'
                'cd ..\n'
                'dotnet add "./tests/Jellyfin.Naming.Tests/Jellyfin.Naming.Tests.csproj" '
                'package JUnitTestLogger\n'
                'dotnet build'
            ),
            "test_project": "./tests/Jellyfin.Naming.Tests/Jellyfin.Naming.Tests.csproj",
            "test_logger": "junit;LogFilePath=$ARTIFACTS_DIR/tests.log",
            "parser": "junit_xml",
        },
        "1.2": {
            "install": (
                'cd MediaBrowser.Model\n'
                'dotnet add package System.Text.Json --version 8.0.5\n'
                'cd ..\n'
                'cd Emby.Server.Implementations\n'
                'dotnet add package Microsoft.Extensions.Caching.Memory --version 9.0.0\n'
                'cd ..\n'
                'cd tests\n'
                'cd Jellyfin.Server.Tests\n'
                'dotnet add package Microsoft.Extensions.Options --version 9.0.0\n'
                'cd ..\n'
                'cd ..\n'
                'dotnet add '
                '"./tests/Jellyfin.Server.Implementations.Tests/Jellyfin.Server.Implementations.Tests.csproj" '
                'package JUnitTestLogger\n'
                'dotnet build'
            ),
            "test_project": "./tests/Jellyfin.Server.Implementations.Tests/Jellyfin.Server.Implementations.Tests.csproj",
            "test_logger": "junit;LogFilePath=$ARTIFACTS_DIR/tests.log",
            "parser": "junit_xml",
        },
    },
    "restsharp/RestSharp": {
        "1.0": {
            "install": (
                'dotnet add "./test/RestSharp.Tests/RestSharp.Tests.csproj" '
                'package JUnitTestLogger --version 1.0.0\n'
                'dotnet build'
            ),
            "test_project": "./test/RestSharp.Tests/RestSharp.Tests.csproj",
            "test_logger": "junit;LogFilePath=$ARTIFACTS_DIR/tests.log",
            "parser": "junit_xml",
        },
        "1.1": {
            "install": (
                'dotnet add "./test/RestSharp.IntegrationTests/RestSharp.IntegrationTests.csproj" '
                'package JUnitTestLogger\n'
                'dotnet build'
            ),
            "test_project": "./test/RestSharp.IntegrationTests/RestSharp.IntegrationTests.csproj",
            "test_logger": "junit;LogFilePath=$ARTIFACTS_DIR/tests.log",
            "parser": "junit_xml",
        },
    },
    "gitextensions/gitextensions": {
        "1.0": {
            "install": (
                'git submodule update --init --recursive\n'
                'dotnet add '
                '"./tests/app/UnitTests/GitCommands.Tests/GitCommands.Tests.csproj" '
                'package JUnitTestLogger\n'
                'dotnet build '
                '"./tests/app/UnitTests/GitCommands.Tests/GitCommands.Tests.csproj"'
            ),
            "test_project": "./tests/app/UnitTests/GitCommands.Tests/GitCommands.Tests.csproj",
            "test_logger": "junit;LogFilePath=$ARTIFACTS_DIR/tests.log",
            "parser": "junit_xml",
        },
    },
}


def get_config(repo: str, env_version: str, run_version: str) -> dict[str, str]:
    """Return resolved config for a given repo and version pair.

    Falls back to the highest available version if exact match not found.
    """
    repo_cfg = REPO_CONFIGS.get(repo)
    if not repo_cfg:
        raise KeyError(f"No config for repo: {repo}")

    # Resolve install from env_setup_version
    install_cfg = repo_cfg.get(env_version)
    if not install_cfg:
        # Fall back to highest version
        install_cfg = repo_cfg[max(repo_cfg)]

    # Resolve test from run_tests_version
    run_cfg = repo_cfg.get(run_version)
    if not run_cfg:
        run_cfg = repo_cfg[max(repo_cfg)]

    return {
        "install": install_cfg["install"],
        "test_project": run_cfg["test_project"],
        "test_logger": run_cfg["test_logger"],
        "build_flags": run_cfg.get("build_flags", ""),
        "parser": run_cfg["parser"],
    }


def get_latest_config(repo: str) -> dict[str, str]:
    """Return the latest (highest version) config for a repo."""
    repo_cfg = REPO_CONFIGS.get(repo)
    if not repo_cfg:
        raise KeyError(f"No config for repo: {repo}")
    latest = repo_cfg[max(repo_cfg)]
    return {
        "install": latest["install"],
        "test_project": latest["test_project"],
        "test_logger": latest["test_logger"],
        "build_flags": latest.get("build_flags", ""),
        "parser": latest["parser"],
    }
