"""Global application container for shared dependencies.

This module defines the ApplicationContainer which manages application-wide
singleton dependencies like DockerAdapter and provides factories for
per-run dependencies like ReportManager.
"""

from pathlib import Path

from dependency_injector import containers, providers

from ee_bench_core.adapters.docker import DockerAdapter
from ee_bench_core.core.report_manager import ReportManager


class ApplicationContainer(containers.DeclarativeContainer):
    """Global application dependencies container.

    This container manages application-wide dependencies that are shared
    across all specifications and evaluation runs. It serves as the parent
    container for all spec-specific containers.

    Singletons:
        - docker_adapter: Single DockerAdapter instance for all Docker operations

    Factories:
        - report_manager: New ReportManager instance per evaluation run
    """

    # Configuration provider for dynamic settings
    config = providers.Configuration()

    # Singleton: One DockerAdapter for entire application
    # This ensures we reuse the same Docker client connection
    docker_adapter = providers.Singleton(DockerAdapter)

    # Factory: New ReportManager per run_id
    # Each evaluation run gets its own report manager
    report_manager = providers.Factory(
        ReportManager,
        report_dir=config.report_dir,
        spec_name=config.spec_name,
    )

    @classmethod
    def create_with_defaults(cls) -> "ApplicationContainer":
        """Create container with default configuration.

        Returns:
            Configured ApplicationContainer instance
        """
        container = cls()
        container.config.from_dict(
            {
                "report_dir": str(Path.cwd() / "reports"),
                "spec_name": "default",
            }
        )
        return container
