"""Factory functions for creating EE-bench evaluator configurations.

This module provides factory functions for creating evaluators with
dependency injection. All dependencies must be provided via constructor.

Use DI containers (like JvmCodeContainer) to create evaluators automatically.
"""

from typing import List

from ee_bench_core.adapters.eval import TestRunnerEvaluator, PatchApplierEvaluator
from ee_bench_core.core import EvaluatorDependency, PositionConstraint
from .eval import PredictionEvaluator, ProjectResetEvaluator


# ============================================================================
# Pipeline Factories (with dependency injection)
# ============================================================================


def create_standard_pipeline(test_runner, patch_adapter) -> List:
    """Create standard EE-bench evaluation pipeline with dependency injection.

    This factory creates evaluators with pre-configured dependencies injected
    via constructor. All dependencies are REQUIRED.

    Pipeline stages:
    1. Baseline evaluation (all tests should pass)
    2. Test patch application (apply test patch)
    3. Fail-to-pass validation (fail_to_pass tests should fail)
    4. Reset project to original state (discard test patch changes)
    5. Prediction application (apply AI/agent patch)
    6. Apply test patch again (for testing with prediction)
    7. All tests checking (pass_to_pass and fail_to_pass should now pass)

    Note: Code formatters are applied via plugin system after patches are applied.

    Args:
        test_runner: Pre-configured TestRunner (MavenTestRunner/GradleTestRunner)
        patch_adapter: Pre-configured PatchAdapter

    Returns:
        List of evaluators with injected dependencies

    Note:
        PredictionsCollector is obtained from spec.get_predictions_collector_provider()
        at runtime, not injected during pipeline creation.

    Example:
        >>> # From DI container
        >>> container = JvmCodeContainer.create_for_evaluation(...)
        >>> test_runner = container.test_runner()
        >>> patch_adapter = container.patch_adapter()
        >>>
        >>> # Create pipeline with injected dependencies
        >>> evaluators = create_standard_pipeline(
        ...     test_runner=test_runner,
        ...     patch_adapter=patch_adapter,
        ... )

    Note:
        Prefer using container.evaluators() directly instead of calling
        this factory manually. The container handles all dependency injection
        automatically.
    """

    # Create evaluators with injected dependencies
    evaluators = [
        # Stage 1: Baseline evaluation
        TestRunnerEvaluator(
            name="baseline_evaluation",
            test_getter=lambda config, context: config.pass_to_pass,
            expect_pass=True,
            dependencies=EvaluatorDependency(position=PositionConstraint.FIRST, priority=100),
            is_terminal=True,
            description="Run baseline tests to verify initial state",
            test_runner=test_runner,
        ),
        # Stage 2: Test patch application
        PatchApplierEvaluator(
            name="test_patch_application",
            patch_getter=lambda config, context: config.test_patch,
            dependencies=EvaluatorDependency(after=["baseline_evaluation"]),
            is_terminal=True,
            description="Apply test patch from dataset",
            patch_adapter=patch_adapter,
            can_skip_patch=True,
        ),
        # Stage 3: Fail-to-pass validation
        TestRunnerEvaluator(
            name="fail_to_pass_validation",
            test_getter=lambda config, context: config.fail_to_pass,
            expect_pass=False,  # Tests should fail
            dependencies=EvaluatorDependency(after=["test_patch_application"]),
            is_terminal=True,
            description="Validate fail_to_pass tests fail with test patch",
            test_runner=test_runner,
        ),
        # Stage 4: Reset project to original state
        ProjectResetEvaluator(
            name="project_reset",
            dependencies=EvaluatorDependency(after=["fail_to_pass_validation"]),
            is_terminal=True,
            description="Reset project to original state (discard test patch)",
        ),
        # Stage 5: Prediction application
        PredictionEvaluator(
            name="prediction_application",
            patch_adapter=patch_adapter,
            dependencies=EvaluatorDependency(after=["project_reset"]),
            is_terminal=True,
            description="Apply prediction patch from AI/agent",
        ),
        # Stage 6: Apply test patch again
        PatchApplierEvaluator(
            name="test_patch_reapplication",
            patch_getter=lambda config, context: config.test_patch,
            dependencies=EvaluatorDependency(after=["prediction_application"]),
            is_terminal=True,
            description="Reapply test patch to test prediction with tests",
            patch_adapter=patch_adapter,
            can_skip_patch=True,
        ),
        # Stage 7 & 8: Fail-to-pass and Pass-to-pass checking
        TestRunnerEvaluator(
            name="all_tests_validation",
            test_getter=lambda config, context: config.fail_to_pass
            + config.pass_to_pass,
            expect_pass=True,  # Tests should now pass
            dependencies=EvaluatorDependency(after=["test_patch_reapplication"]),
            is_terminal=True,
            description="Verify fail_to_pass and pass_to_pass tests now pass after prediction",
            test_runner=test_runner,
            max_score=100.0,  # Primary scoring evaluator
        ),
    ]

    return evaluators


def create_minimal_pipeline(test_runner, patch_adapter, base_test_score = 100) -> List:
    """Create minimal EE-bench evaluation pipeline with dependency injection.

    This factory creates evaluators with pre-configured dependencies injected
    via constructor. All dependencies are REQUIRED.

    Pipeline stages:
    1. Prediction application (apply AI/agent patch)
    2. Fail-to-pass checking (fail_to_pass should pass)
    3. Pass-to-pass checking (pass_to_pass should pass)

    Args:
        test_runner: Pre-configured TestRunner
        patch_adapter: Pre-configured PatchAdapter

    Returns:
        List of evaluators with injected dependencies

    Note:
        PredictionsCollector is obtained from spec.get_predictions_collector_provider()
        at runtime, not injected during pipeline creation.
    """
    return [
        PredictionEvaluator(
            name="prediction_application",
            patch_adapter=patch_adapter,
            dependencies=EvaluatorDependency(position=PositionConstraint.FIRST),
            is_terminal=True,
            description="Apply prediction patch from AI/agent",
        ),
        PatchApplierEvaluator(
            name="test_patch_application",
            patch_getter=lambda config, context: config.test_patch,
            dependencies=EvaluatorDependency(after=["prediction_application"]),
            is_terminal=False,
            description="Apply test patch to test prediction with tests",
            patch_adapter=patch_adapter,
            can_skip_patch=True,
        ),
        TestRunnerEvaluator(
            name="all_tests_validation",
            test_getter=lambda config, context: config.fail_to_pass
            + config.pass_to_pass,
            expect_pass=True,  # Tests should pass
            dependencies=EvaluatorDependency(after=["prediction_application"]),
            is_terminal=False,
            description="Verify all tests now pass after prediction",
            test_runner=test_runner,  # Pass through injected dependency
            max_score=base_test_score,  # Primary scoring evaluator
        ),
    ]

def create_minimal_pipeline_test_already_applied(test_runner, patch_adapter, base_test_score = 100) -> List:
    """Create minimal EE-bench evaluation pipeline with dependency injection.

    This factory creates evaluators with pre-configured dependencies injected
    via constructor. All dependencies are REQUIRED.

    Pipeline stages:
    1. Prediction application (apply AI/agent patch)
    2. Fail-to-pass checking (fail_to_pass should pass)
    3. Pass-to-pass checking (pass_to_pass should pass)

    Args:
        test_runner: Pre-configured TestRunner
        patch_adapter: Pre-configured PatchAdapter

    Returns:
        List of evaluators with injected dependencies

    Note:
        PredictionsCollector is obtained from spec.get_predictions_collector_provider()
        at runtime, not injected during pipeline creation.
    """
    return [
        PredictionEvaluator(
            name="prediction_application",
            patch_adapter=patch_adapter,
            dependencies=EvaluatorDependency(position=PositionConstraint.FIRST),
            is_terminal=True,
            description="Apply prediction patch from AI/agent",
        ),
        TestRunnerEvaluator(
            name="all_tests_validation",
            test_getter=lambda config, context: config.fail_to_pass + config.pass_to_pass,
            expect_pass=True,  # Tests should pass
            dependencies=EvaluatorDependency(after=["prediction_application"]),
            is_terminal=False,
            description="Verify all tests now pass after prediction",
            test_runner=test_runner,  # Pass through injected dependency
            max_score=base_test_score,  # Primary scoring evaluator
        ),
    ]
