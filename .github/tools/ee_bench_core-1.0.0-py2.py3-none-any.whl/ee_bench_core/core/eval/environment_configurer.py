"""Environment configurer interface for evaluation framework.

This module provides the abstract EnvironmentConfigurer interface for
preparing evaluation environments before evaluation starts. Configurers
can be discovered as plugins to install tools, set up authentication, etc.
"""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, List, Optional, Union

if TYPE_CHECKING:
    from ..abc_types import DatasetConfig, EnvironmentConfig
    from ..base_spec import BaseEvalSpec

from .evaluator import DependencyPosition


class EnvironmentConfigurer(ABC):
    """Abstract base class for environment configuration.

    Environment configurers prepare the evaluation environment before
    evaluations run. They can install tools, set up authentication,
    configure services, etc.

    Configurers are discovered via entry points and can be enabled/disabled
    per evaluation run.

    Configurers support dependency management and execution ordering using
    the DependencyPosition specification which allows:
    - Dependencies: Declare which configurers must run before/after this one
    - Priority: Fine-tune execution order within same dependency level

    Metadata Attributes:
        Configurers can define metadata as class attributes for plugin discovery:

        __configurer_name__: str
            Unique identifier (default: uses name property)
        __configurer_description__: str
            Human-readable description (default: uses description property)
        __configurer_version__: str
            Version string (e.g., "1.0.0")
        __configurer_author__: str
            Author or organization name
        __configurer_tags__: List[str]
            Tags for categorization (e.g., ["security", "tool"])
        __configurer_specs__: List[str]
            Spec names this applies to (empty = all specs)

    Example:
        class MyConfigurer(EnvironmentConfigurer):
            __configurer_name__ = "my_tool"
            __configurer_description__ = "Installs my custom tool"
            __configurer_version__ = "1.0.0"
            __configurer_specs__ = ["jvm"]

            @property
            def name(self) -> str:
                return "my_tool"

            @property
            def dependencies(self) -> Optional[Union[List[str], DependencyPosition]]:
                return DependencyPosition(
                    after=["base_image"],
                    priority=150  # Lower runs first
                )

            def configure(self, spec, env_config, config, **kwargs):
                # Implementation
                pass
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique identifier for this configurer.

        Returns:
            Configurer name (must be unique within registry)
        """
        pass

    @property
    def description(self) -> str:
        """Human-readable description of what this configurer does.

        Returns:
            Description string
        """
        return f"Environment configurer: {self.name}"

    @property
    def specs(self) -> Optional[list[str]]:
        """List of spec names this configurer applies to.

        If None or empty, applies to all specs.

        Returns:
            List of spec names (e.g., ["jvm", "python"]) or None for all
        """
        return None

    @property
    def dependencies(self) -> Optional[Union[List[str], DependencyPosition]]:
        """Dependency specification for this configurer.

        Dependencies define execution order. The environment manager will
        use topological sorting to determine the correct sequence.

        Returns:
            - None: No dependencies (can run first)
            - List[str]: List of configurer names that must run before this one
            - DependencyPosition: Full dependency specification with after/before/priority

        Examples:
            # Simple dependencies - legacy format
            @property
            def dependencies(self) -> Optional[List[str]]:
                return ["jvm_base_image"]

            # Full dependency specification with priority
            @property
            def dependencies(self) -> Optional[Union[List[str], DependencyPosition]]:
                return DependencyPosition(
                    after=["jvm_base_image"],
                    priority=50  # Lower runs first
                )

            # Dependencies with "before" constraint
            @property
            def dependencies(self) -> Optional[Union[List[str], DependencyPosition]]:
                return DependencyPosition(
                    before=["final_cleanup"],  # Must run before cleanup
                    priority=100
                )

            # No dependencies - can run first
            @property
            def dependencies(self) -> Optional[Union[List[str], DependencyPosition]]:
                return None
        """
        return None

    @abstractmethod
    def configure(
        self,
        spec: "BaseEvalSpec",
        env_config: "EnvironmentConfig",
        config: "DatasetConfig",
        **kwargs,
    ) -> "EnvironmentConfig":
        """Configure the environment and optionally return modified configuration.

        This method is called once before the evaluation pipeline starts,
        allowing configurers to prepare the environment. It can:
        - Install tools, configure settings in existing environment
        - Create enhanced Docker images with additional tools
        - Return modified environment configuration

        Args:
            spec: Evaluation specification providing dependencies and configuration
            env_config: Environment configuration (e.g., DockerEnvironmentConfig)
            config: Dataset configuration for the task being evaluated
            **kwargs: Additional configurer-specific parameters
                - Configuration passed from CLI/config file
                - Tool-specific credentials and settings

        Returns:
            EnvironmentConfig: Either the same env_config or a modified version.
            For example, a new DockerEnvironmentConfig with a different image_name
            if the configurer created an enhanced Docker image with additional tools.

        Raises:
            Exception: If environment configuration fails

        Examples:
            # Example 1: Install tool in existing sandbox (return same config)
            def configure(self, spec, env_config, config, **kwargs):
                from ee_bench_core.adapters import SandboxFactory

                # Create sandbox from env_config
                sandbox = SandboxFactory.create_sandbox(env_config)
                sandbox.run_command("npm install -g snyk")
                return env_config  # Return unchanged

            # Example 2: Create enhanced image (return new config)
            def configure(self, spec, env_config, config, **kwargs):
                # Build new image with Snyk pre-installed
                new_image = self._build_enhanced_image(env_config.image_name)

                # Return new config with updated image
                from copy import copy
                new_config = copy(env_config)
                new_config.image_name = new_image
                return new_config
        """
        pass

    def should_configure(
        self,
        spec: "BaseEvalSpec",
        env_config: "EnvironmentConfig",
        config: "DatasetConfig",
        **kwargs,
    ) -> tuple[bool, Optional[str]]:
        """Check if this configurer should run for this environment.

        This method is called before configure() to allow configurers to
        skip execution based on the environment state or configuration.

        Args:
            spec: Evaluation specification
            env_config: Environment configuration
            config: Dataset configuration
            **kwargs: Additional parameters

        Returns:
            Tuple of (should_configure, reason):
            - should_configure: True if configurer should run
            - reason: Optional explanation if False

        Examples:
            # Skip if tool already installed
            if self._is_tool_installed(env_config):
                return False, "Tool already installed"

            # Skip if credentials not provided
            if not kwargs.get("snyk_token"):
                return False, "No authentication token provided"

            # Run configurer
            return True, None
        """
        return True, None
