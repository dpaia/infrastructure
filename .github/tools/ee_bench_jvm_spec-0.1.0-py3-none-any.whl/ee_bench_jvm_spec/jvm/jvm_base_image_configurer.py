"""JVM base image configurer for building JDK-based Docker images.

This configurer builds base Docker images with JDK and system tools installed,
which other configurers can then enhance with build tools like Maven or Gradle.
"""

import logging

from ee_bench_core.adapters.docker import (
    DockerEnvironmentConfig,
    DockerEnvironmentConfigurer,
)
from ee_bench_core.core import DependencyPosition, PositionConstraint
from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig

logger = logging.getLogger(__name__)


class JvmBaseImageConfigurer(DockerEnvironmentConfigurer):
    """Configurer that builds JVM base images with JDK and system tools.

    This configurer creates base Docker images with:
    - Eclipse Temurin JDK (specified version)
    - System dependencies (git, wget, curl, unzip, patch, jq, build tools)
    - SSH configuration for GitHub access

    The image serves as a foundation for Maven/Gradle configurers to add
    build tools on top.

    Metadata:
        name: jvm_base_image
        priority: 10 (base infrastructure - runs early)
        dependencies: None (runs first)
        specs: ["jvm"]
    """

    # Metadata for plugin discovery
    __configurer_name__ = "base_image"
    __configurer_description__ = "Builds JVM base image with JDK"
    __configurer_version__ = "1.0.0"
    __configurer_specs__ = ["jvm"]
    __configurer_priority__ = 10  # Base infrastructure - runs early
    __configurer_dependencies__ = [
        DependencyPosition(position=PositionConstraint.FIRST, priority=10)
    ]  # No dependencies

    def __init__(self, default_jdk_version: str = "24", namespace: str = "ee-bench", **kwargs):
        """Initialize JVM base image configurer.

        Args:
            default_jdk_version: Default JDK version to use (default: "24")
            namespace: Docker image namespace (default: "ee-bench")
            **kwargs: Additional parameters (ignored, for compatibility)
        """
        super().__init__()
        self.default_jdk_version = default_jdk_version
        self.namespace = namespace

    @property
    def name(self) -> str:
        return "base_image"

    @property
    def description(self) -> str:
        return "Builds JVM base image with JDK and system tools"

    @property
    def specs(self) -> list[str] | None:
        return ["jvm"]

    @property
    def dependencies(self) -> DependencyPosition | None:
        return DependencyPosition(position=PositionConstraint.FIRST, priority=10)

    def should_configure(
        self,
        spec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        **kwargs,
    ) -> tuple[bool, str | None]:
        """Check if this configurer should run.

        Only runs for Docker environments (DockerEnvironmentConfig).

        Args:
            spec: Evaluation specification
            env_config: Environment configuration
            config: Dataset configuration
            **kwargs: Additional parameters

        Returns:
            Tuple of (should_configure, reason)
        """
        # Only configure Docker environments
        if not isinstance(env_config, DockerEnvironmentConfig):
            return (
                False,
                f"Not a Docker environment (type: {type(env_config).__name__})",
            )

        return True, None

    def configure(
        self,
        spec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        **kwargs,
    ) -> EnvironmentConfig:
        """Build JVM base image and update env_config.

        Args:
            spec: Evaluation specification
            env_config: Environment configuration
            config: Dataset configuration
            **kwargs: Additional parameters (jvm_version, version, etc.)

        Returns:
            Updated EnvironmentConfig with base image name set

        Raises:
            EnvironmentError: If image build fails
        """
        force = kwargs.get("force", False)
        jdk_version = self._get_jdk_version(config, **kwargs)
        image_name = self._get_image_name(jdk_version)

        # Build image with labels
        labels = {
            f"{self.namespace}.image-type": "base",
            f"{self.namespace}.language": "jvm",
            f"{self.namespace}.jdk-version": jdk_version,
            f"{self.namespace}.configurer": self.name,
        }

        # Check if image already exists
        if not force and self.image_exists(image_name):
            logger.info(f"JVM base image {image_name} already exists, skipping build")
        else:
            logger.info(f"Building JVM base image: {image_name} (JDK {jdk_version})")

            # Generate Dockerfile
            dockerfile_content = self.generate_dockerfile(
                env_config, config, jdk_version=jdk_version, **kwargs
            )
            self.build_image(dockerfile_content, image_name, labels)

            logger.info(f"Successfully built JVM base image: {image_name}")

        # Update env_config
        if not isinstance(env_config, DockerEnvironmentConfig):
            env_config = DockerEnvironmentConfig.from_dict(env_config.to_dict())
        else:
            new_labels = env_config.labels.copy()
            new_labels.update(labels)
            labels = new_labels

        env_config.image_name = image_name
        env_config.labels = labels
        env_config.related_images["jvm"] = image_name

        return env_config

    def generate_dockerfile(
        self,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        **kwargs,
    ) -> str:
        """Generate Dockerfile for JVM base image.

        Args:
            env_config: Environment configuration
            config: Dataset configuration
            **kwargs: Additional parameters (jdk_version required)

        Returns:
            Dockerfile content as string
        """
        jdk_version = kwargs.get("jdk_version", self.default_jdk_version)

        return f"""FROM eclipse-temurin:{jdk_version}-jdk

# Install system dependencies
RUN apt-get update && apt-get install -y \\
    git \\
    wget \\
    curl \\
    unzip \\
    patch \\
    jq \\
    openssh-client \\
    ca-certificates \\
    build-essential \\
    && rm -rf /var/lib/apt/lists/*

# Set up SSH for git clone
RUN mkdir -p /root/.ssh && ssh-keyscan github.com >> /root/.ssh/known_hosts

WORKDIR /workspace
"""

    def _get_jdk_version(self, config: DatasetConfig, **kwargs) -> str:
        """Get JDK version from config or kwargs.

        Priority: kwargs['version'] > kwargs['jvm_version'] > config.jvm_version > default

        The CLI parameter `--jvm-version` (passed as kwargs['jvm_version']) should override
        the dataset's jvm_version field, allowing users to test with different JVM versions.

        Args:
            config: Dataset configuration
            **kwargs: Additional parameters

        Returns:
            JDK version string
        """
        # Highest priority: explicit version parameter
        if kwargs.get("version"):
            return str(kwargs["version"])

        # Second priority: config.jvm_version (from dataset instance)
        if hasattr(config, "jvm_version") and config.jvm_version:
            return str(config.jvm_version)

        # Third priority: jvm_version parameter (global default)
        if kwargs.get("jvm_version"):
            return str(kwargs["jvm_version"])

        # Fallback to default
        return self.default_jdk_version

    def _get_image_name(self, jdk_version: str) -> str:
        """Get base image name.

        Format: {namespace}-base:jvm-jdk{version}

        Args:
            jdk_version: JDK version

        Returns:
            Docker image name with tag
        """
        return f"{self.namespace}-jdk{jdk_version}:base"
