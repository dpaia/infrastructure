"""Base class for dependencies configurers (Maven/Gradle).

This module provides an abstract base class that extracts common logic
for downloading dependencies and compiling projects in both Docker and local modes.
"""

import logging
from abc import ABC, abstractmethod
from pathlib import Path

from ee_bench_code_spec.config import CodeBenchmarkConfig
from ee_bench_code_spec.env_config import CodeEnvironmentConfig
from ee_bench_code_spec.local_env_config import CodeLocalEnvironmentConfig

from ee_bench_core.adapters import SandboxFactory
from ee_bench_core.adapters.docker import DockerAdapter, DockerEnvironmentConfig
from ee_bench_core.adapters.local import LocalEnvironmentConfig
from ee_bench_core.adapters.process_manager_factory import ProcessManagerFactory
from ee_bench_core.core import DependencyPosition
from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig
from ee_bench_core.core.eval import EnvironmentConfigurer

logger = logging.getLogger(__name__)


class BaseDependenciesConfigurer(EnvironmentConfigurer, ABC):
    """Abstract base class for dependencies configurers.

    This class extracts common logic for downloading dependencies and
    compiling projects (Maven, Gradle, etc.) in both Docker and local modes.

    Subclasses only need to implement tool-specific methods:
    - build_system property (returns BuildSystem enum)
    - tool_name property (returns tool name string)
    - get_dependency_download_commands() (returns commands to download dependencies)

    Common functionality handled by base class:
    - Build system verification
    - CodeBenchmarkConfig validation
    - Environment type detection (Docker vs Local)
    - Docker: Image building with dependencies
    - Local: Direct dependency download on host
    - Environment config updates
    """

    def __init__(self, namespace: str = "ee-bench", **kwargs):
        """Initialize dependencies configurer.

        Args:
            namespace: Docker image namespace (default: "ee-bench")
            **kwargs: Additional parameters (ignored, for compatibility)
        """
        self.namespace = namespace
        self.docker_adapter = DockerAdapter()

    @property
    @abstractmethod
    def build_system(self):
        """Return the BuildSystem enum for this tool.

        Returns:
            BuildSystem enum (e.g., BuildSystem.MAVEN or BuildSystem.GRADLE)
        """
        pass

    @property
    @abstractmethod
    def tool_name(self) -> str:
        """Return the tool name in lowercase.

        Returns:
            Tool name (e.g., "maven" or "gradle")
        """
        pass

    @abstractmethod
    def get_dependency_download_commands(self, env_config: EnvironmentConfig) -> list[str]:
        """Get commands to download dependencies.

        Returns:
            List of RUN commands for downloading dependencies
        """
        pass

    @property
    def name(self) -> str:
        """Return configurer name."""
        return f"{self.tool_name}_dependencies"

    @property
    def description(self) -> str:
        """Return configurer description."""
        return f"Downloads {self.tool_name.capitalize()} dependencies and compiles project"

    @property
    def specs(self) -> list[str] | None:
        """Return supported spec names."""
        return ["jvm"]

    @property
    def dependencies(self) -> DependencyPosition | None:
        """Return dependency configuration."""
        # Run after build tool (maven/gradle) and after task_image
        return DependencyPosition(after=[self.tool_name, "task_image"])

    def should_configure(
        self,
        spec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        **kwargs,
    ) -> tuple[bool, str | None]:
        """Check if dependencies should be downloaded.

        Args:
            spec: Evaluation specification
            env_config: Environment configuration
            config: Dataset configuration
            **kwargs: Additional parameters

        Returns:
            Tuple of (should_configure, reason)
        """
        if not isinstance(config, CodeBenchmarkConfig):
            return False, "Not a code benchmark task"

        # Only configure for matching build system
        from ee_bench_jvm_spec.jvm import JvmCodeEvalSpec

        build_system = JvmCodeEvalSpec.get_build_system(config, **kwargs)
        if build_system != self.build_system:
            return False, f"Build tool is {build_system.name}"

        # Check environment type
        is_docker = isinstance(env_config, DockerEnvironmentConfig)
        is_local = isinstance(env_config, (LocalEnvironmentConfig, CodeLocalEnvironmentConfig))

        if not (is_docker or is_local):
            return False, "Not a Docker or Local environment"

        # Docker-specific checks
        if is_docker and not env_config.image_name:
            return False, "No base image available"

        return True, None

    def configure(
        self,
        spec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        **kwargs,
    ) -> EnvironmentConfig:
        """Download dependencies and compile project.

        Args:
            spec: Evaluation specification
            env_config: Environment configuration
            config: Dataset configuration
            **kwargs: Additional parameters

        Returns:
            Updated EnvironmentConfig with dependencies downloaded

        Raises:
            EnvironmentError: If dependency download/image build fails
        """
        if not isinstance(config, CodeBenchmarkConfig):
            return env_config

        # Check environment type and dispatch to appropriate method
        if isinstance(env_config, DockerEnvironmentConfig):
            return self._configure_docker(env_config, config, **kwargs)
        if isinstance(env_config, (LocalEnvironmentConfig, CodeLocalEnvironmentConfig)):
            return self._configure_local(env_config, config, **kwargs)
        logger.warning(f"Unsupported environment type: {type(env_config).__name__}")
        return env_config

    def _configure_docker(
        self,
        env_config: DockerEnvironmentConfig,
        config: CodeBenchmarkConfig,
        **kwargs,
    ) -> EnvironmentConfig:
        """Configure dependencies for Docker environment.

        Args:
            env_config: Docker environment configuration
            config: Code benchmark configuration
            **kwargs: Additional parameters

        Returns:
            Updated environment config with dependencies image
        """
        base_image = env_config.image_name
        dependencies_image = self._get_dependencies_image_name(config)

        labels = env_config.labels.copy() if env_config.labels else {}
        labels.update(
            {
                f"{self.namespace}.image-type": "dependencies",
                f"{self.namespace}.build-tool": self.tool_name,
                f"{self.namespace}.instance-id": config.instance_id,
                f"{self.namespace}.base-image": base_image,
                f"{self.namespace}.configurer": self.name,
            }
        )

        force = kwargs.get("force", False) or kwargs.get("force_rebuild", False)

        if not force and self._image_exists(dependencies_image):
            logger.info(f"Dependencies image {dependencies_image} already exists, skipping build")
        else:
            logger.info(
                f"Building {self.tool_name.capitalize()} dependencies image: {dependencies_image} from {base_image}"
            )

            # Generate Dockerfile
            dockerfile_content = self.generate_dockerfile(env_config, config, **kwargs)
            self._build_image(dockerfile_content, dependencies_image, labels, nocache=force)

            logger.info(
                f"Successfully built {self.tool_name.capitalize()} dependencies image: {dependencies_image}"
            )

        env_config = CodeEnvironmentConfig.from_dict(env_config.to_dict())
        # Update env_config
        env_config.image_name = dependencies_image
        env_config.labels = labels
        env_config.related_images["dependencies"] = dependencies_image

        return env_config

    def _configure_local(
        self,
        env_config: LocalEnvironmentConfig,
        config: CodeBenchmarkConfig,
        **kwargs,
    ) -> EnvironmentConfig:
        """Configure dependencies for local environment.

        Runs dependency download commands directly on the host.

        Args:
            env_config: Local environment configuration
            config: Code benchmark configuration
            **kwargs: Additional parameters

        Returns:
            Updated environment config
        """
        logger.info(f"Downloading {self.tool_name.capitalize()} dependencies in local mode")

        # Get project path
        project_path = Path("/workspace/task_project")
        if hasattr(env_config, "project_path"):
            project_path = Path(env_config.project_path)
        elif hasattr(env_config, "workspace_dir") and env_config.workspace_dir:
            project_path = Path(env_config.workspace_dir) / "task_project"

        logger.debug(f"Project path: {project_path}")

        # Get the build tool command from config
        tool_cmd = self._get_local_tool_command(env_config, project_path)
        logger.info(f"Using {self.tool_name} command: {tool_cmd}")

        local_sandbox = SandboxFactory.create_sandbox(env_config)

        # Get dependency download commands (these contain 'mvn' or 'gradle' placeholders)
        dependency_commands = self.get_dependency_download_commands(env_config)

        # Run commands
        for cmd_template in dependency_commands:
            # Replace tool name with actual command (e.g., mvn -> ./mvnw)
            cmd = cmd_template.replace(self.tool_name, tool_cmd, 1)
            logger.info(f"Running: {cmd}")
            try:
                # Use shell=True since commands contain shell syntax (|| true)
                result = local_sandbox.run_command(
                    cmd=cmd,
                    cwd=project_path,
                    timeout=600,  # 10 minute timeout for dependency downloads
                    env_config=env_config,
                    shell=True,
                )

                if result.returncode != 0:
                    logger.warning(f"Command failed with exit code {result.returncode}: {cmd}")
                    logger.debug(f"stdout: {result.stdout}")
                    logger.debug(f"stderr: {result.stderr}")
                    # Don't raise - dependencies commands have || true
                else:
                    logger.info(f"Successfully completed: {cmd}")

            except Exception as e:
                logger.error(f"Error running dependency command '{cmd}': {e}")
                # Don't raise - allow evaluation to continue

        logger.info(f"{self.tool_name.capitalize()} dependencies download completed")

        return env_config

    def _get_local_tool_command(
        self, env_config: LocalEnvironmentConfig, project_path: Path
    ) -> str:
        """Get the tool command to use for local execution.

        Args:
            env_config: Local environment configuration
            project_path: Path to the project directory

        Returns:
            Tool command string (e.g., "./mvnw", "mvn", "./gradlew", "gradle")
        """
        # Check for wrapper in project
        if self.tool_name == "maven":
            wrapper_path = project_path / "mvnw"
            if wrapper_path.exists():
                return "./mvnw"
        elif self.tool_name == "gradle":
            wrapper_path = project_path / "gradlew"
            if wrapper_path.exists():
                return "./gradlew"

        # Fall back to system tool
        return self.tool_name

    def generate_dockerfile(
        self,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        **kwargs,
    ) -> str:
        """Generate Dockerfile for dependencies image.

        Args:
            env_config: Environment configuration
            config: Dataset configuration
            **kwargs: Additional parameters

        Returns:
            Dockerfile content as string

        Raises:
            ValueError: If config is not CodeBenchmarkConfig or env_config is not DockerEnvironmentConfig
        """
        if not isinstance(config, CodeBenchmarkConfig):
            raise ValueError("Config must be CodeBenchmarkConfig")

        if not isinstance(env_config, DockerEnvironmentConfig):
            raise ValueError("env_config must be DockerEnvironmentConfig")

        base_image = env_config.image_name

        project_path = "/workspace/task_project"
        if hasattr(env_config, "project_path"):
            project_path = str(env_config.project_path)
        elif hasattr(env_config, "workspace_dir") and env_config.workspace_dir:
            project_path = str(env_config.workspace_dir)

        logger.debug(f"Project path: {project_path}")

        # Get tool-specific commands
        dependency_commands = self.get_dependency_download_commands(env_config)

        # Build Dockerfile
        dockerfile = f"FROM {base_image}\n\nWORKDIR {project_path}\n\n"

        # Add dependency download commands
        dockerfile += f"# Download {self.tool_name.capitalize()} dependencies\n"
        for cmd in dependency_commands:
            dockerfile += f"RUN {cmd}\n"

        dockerfile += "\n"

        dockerfile += '\nCMD ["/bin/bash"]\n'

        return dockerfile

    def _get_dependencies_image_name(self, config: CodeBenchmarkConfig) -> str:
        """Generate dependencies image name.

        Args:
            config: Code benchmark configuration

        Returns:
            Docker image name with tag
        """
        # Sanitize instance ID for Docker image name
        sanitized_id = config.instance_id.replace("_", "-").replace("__", "-").lower()
        sanitized_id = "".join(c for c in sanitized_id if c.isalnum() or c in ".-")
        return f"{self.namespace}-{sanitized_id}:dependencies"

    def _image_exists(self, image_name: str) -> bool:
        """Check if Docker image exists.

        Args:
            image_name: Name of the Docker image

        Returns:
            True if image exists, False otherwise
        """
        return self.docker_adapter.image_exists(image_name)

    def _build_image(
        self, dockerfile_content: str, image_name: str, labels: dict, **kwargs
    ) -> None:
        """Build Docker image.

        Args:
            dockerfile_content: Dockerfile content
            image_name: Name for the built image
            labels: Labels to apply to the image
            **kwargs: Additional build parameters (e.g., nocache=True)

        Raises:
            EnvironmentError: If image build fails
        """
        self.docker_adapter.build_image(
            dockerfile_content=dockerfile_content,
            tag=image_name,
            labels=labels,
            **kwargs,
        )
