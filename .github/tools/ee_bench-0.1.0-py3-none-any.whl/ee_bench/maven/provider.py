"""MavenProvider — detects Maven projects and enriches test names for multi-module."""

from __future__ import annotations

import re
from typing import Any

from ee_bench.generator.build_utils import (
    detect_maven_build_system,
    extract_maven_modules_from_tree,
    extract_module_map,
)
from ee_bench.generator.interfaces import Provider

_TEST_SRC_PATTERN = re.compile(
    r"^(?P<module>.+?)/src/test/(?:java|kotlin)/(?P<class_path>.+?)\.(?:java|kt)$"
)


def _enhance_module_map_from_tree(
    test_patch: str, tree_modules: dict[str, str],
) -> dict[str, str]:
    """Build a class_fqn -> module_prefix map using tree-based module info."""
    if not test_patch:
        return {}

    diff_header = re.compile(r"^diff --git a/(.+?) b/(.+?)$", re.MULTILINE)
    module_map: dict[str, str] = {}

    for match in diff_header.finditer(test_patch):
        path = match.group(2)
        m = _TEST_SRC_PATTERN.match(path)
        if not m:
            continue
        module_dir = m.group("module")
        class_fqn = m.group("class_path").replace("/", ".")
        if module_dir in tree_modules:
            notation = tree_modules[module_dir]
            if notation:
                module_map[class_fqn] = notation
    return module_map


class MavenProvider(Provider):
    """Build-system provider for Maven projects (base/fallback layer)."""

    def provide(self, item=None, *, repo_tree=None, test_patch="", **kwargs) -> dict[str, Any]:
        """Detect Maven build system and compute module map.

        Args:
            item: Item dict (unused after explicit-param migration).
            repo_tree: Repository file tree (list of paths).
            test_patch: Unified diff of test files.
            **kwargs: Ignored.

        Returns:
            Dict with build_system, is_maven, module_map.
        """
        is_maven = (
            isinstance(repo_tree, list)
            and detect_maven_build_system(repo_tree)
        )

        if not is_maven:
            return {"build_system": "", "is_maven": False, "module_map": {}}
        module_map: dict[str, str] = {}
        if test_patch:
            module_map = extract_module_map(test_patch)
        if not module_map and isinstance(repo_tree, list):
            tree_modules = extract_maven_modules_from_tree(repo_tree)
            if tree_modules:
                module_map = _enhance_module_map_from_tree(test_patch, tree_modules)

        return {
            "build_system": "maven",
            "is_maven": True,
            "module_map": module_map,
        }
