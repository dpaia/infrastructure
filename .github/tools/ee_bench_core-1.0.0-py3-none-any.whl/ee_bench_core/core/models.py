"""Base models and data structures for the evaluation framework."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Optional, Set


class ResultStatus(Enum):
    """Enumeration of possible evaluation result statuses."""

    SUCCESS = "success"
    """Evaluation passed successfully"""

    FAILED = "failed"
    """Evaluation failed"""

    SKIPPED = "skipped"
    """Evaluation was skipped"""


class DatasetConfig(ABC):
    """Abstract base class for dataset configuration.

    Each specification should implement this interface to provide
    task-specific configuration data.
    """

    @property
    @abstractmethod
    def instance_id(self) -> str:
        """Get the unique identifier for this task instance.

        Returns:
            Unique instance identifier
        """
        pass

    @abstractmethod
    def present(self) -> str:
        """Generate a human-readable presentation of this configuration.

        Returns:
            Formatted string representation for display
        """
        pass

    @abstractmethod
    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary format.

        Returns:
            Dictionary representation of the configuration
        """
        pass


class EnvironmentConfig(ABC):
    """Abstract base class for environment configuration.

    Represents the configured evaluation environment (e.g., Docker image,
    workspace paths, etc.).
    """

    @abstractmethod
    def to_dict(self) -> Dict[str, Any]:
        """Convert environment config to dictionary format.

        Returns:
            Dictionary representation of the environment configuration
        """
        pass


class EvaluationResult(ABC):
    """Abstract base class for evaluation results.

    Each specification should implement this interface to provide
    evaluation outcomes in their preferred format.
    """

    @property
    @abstractmethod
    def instance_id(self) -> str:
        """Get the unique identifier for the evaluated task.

        Returns:
            Task instance identifier
        """
        pass

    @property
    @abstractmethod
    def result(self) -> ResultStatus:
        """Get the result status of the evaluation.

        Returns:
            ResultStatus enum value (SUCCESS, FAILED, or SKIPPED)
        """
        pass

    @property
    def successful(self) -> bool:
        """Check if the evaluation was successful.

        Returns:
            True if evaluation passed, False otherwise

        Note:
            This property is provided for backward compatibility.
            Prefer using the result property which returns ResultStatus enum.
        """
        return self.result == ResultStatus.SUCCESS

    @property
    @abstractmethod
    def reason(self) -> str:
        """Get the reason for success or failure.

        Returns:
            Human-readable explanation of the result
        """
        pass

    @abstractmethod
    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary format.

        Returns:
            Dictionary representation of the evaluation result
        """
        pass

    @property
    def execution_time(self) -> float:
        """Get the execution time in seconds.

        Returns:
            Execution time (default: 0.0)
        """
        return 0.0


@dataclass
class EvaluationContext:
    """Context object containing all information needed for evaluation.

    This is passed between components during the evaluation process.
    Spec-specific parameters (like prediction patches) should be passed
    via extra_params.
    """

    instance_id: str
    """Unique identifier for the task instance"""

    dataset_config: DatasetConfig
    """Configuration loaded from the dataset"""

    env_config: EnvironmentConfig
    """Environment configuration (Docker image, paths, etc.)"""

    timeout: int = 1800
    """Maximum execution time in seconds (default: 30 minutes)"""

    force_rebuild: bool = False
    """Whether to force rebuilding the environment"""

    work_dir: Optional[Path] = None
    """Working directory for evaluation"""

    extra_params: Dict[str, Any] = field(default_factory=dict)
    """Additional spec-specific parameters (e.g., prediction_patch for SWE)"""

    def to_dict(self) -> Dict[str, Any]:
        """Convert context to dictionary format.

        Returns:
            Dictionary representation of the evaluation context
        """
        return {
            "instance_id": self.instance_id,
            "dataset_config": self.dataset_config.to_dict(),
            "env_config": self.env_config.to_dict(),
            "timeout": self.timeout,
            "force_rebuild": self.force_rebuild,
            "work_dir": str(self.work_dir) if self.work_dir else None,
            "extra_params": self.extra_params,
        }


@dataclass
class EnvironmentPreparationResult:
    """Result of preparing evaluation environments for multiple instances.

    Provides structured information about which environments were successfully
    prepared and which failed, along with detailed error information.
    """

    successful_ids: Set[str] = field(default_factory=set)
    """Set of instance IDs that were successfully prepared"""

    failed_ids: Set[str] = field(default_factory=set)
    """Set of instance IDs that failed to prepare"""

    environments: Dict[str, EnvironmentConfig] = field(default_factory=dict)
    """Mapping of instance_id to EnvironmentConfig for successful preparations"""

    errors: Dict[str, str] = field(default_factory=dict)
    """Mapping of instance_id to error message for failed preparations"""

    total_count: int = 0
    """Total number of instances requested"""

    @property
    def success_count(self) -> int:
        """Number of successfully prepared environments."""
        return len(self.successful_ids)

    @property
    def failure_count(self) -> int:
        """Number of failed environment preparations."""
        return len(self.failed_ids)

    @property
    def success_rate(self) -> float:
        """Success rate as a percentage (0-100)."""
        if self.total_count == 0:
            return 0.0
        return (self.success_count / self.total_count) * 100

    @property
    def all_successful(self) -> bool:
        """Whether all environment preparations succeeded."""
        return self.failure_count == 0 and self.success_count == self.total_count

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation.

        Returns:
            Dictionary with all result information
        """
        return {
            "successful_ids": list(self.successful_ids),
            "failed_ids": list(self.failed_ids),
            "environments": {
                instance_id: env.to_dict()
                for instance_id, env in self.environments.items()
            },
            "errors": self.errors,
            "total_count": self.total_count,
            "success_count": self.success_count,
            "failure_count": self.failure_count,
            "success_rate": self.success_rate,
            "all_successful": self.all_successful,
        }
