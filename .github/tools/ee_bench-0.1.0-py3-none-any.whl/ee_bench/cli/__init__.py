"""ee_bench.cli - Command-line interface for ee_bench.generator.

This package provides the `ee-dataset` CLI tool for generating datasets
using the ee_bench.generator plugin architecture.
"""

__version__ = "0.1.0"
