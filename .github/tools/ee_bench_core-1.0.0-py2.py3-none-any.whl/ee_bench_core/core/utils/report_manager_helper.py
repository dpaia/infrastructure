"""Helper utilities for report manager creation and management.

This module provides reusable helper functions for creating and managing
report managers across different orchestration methods.
"""

import logging
from pathlib import Path
from typing import Optional

from ..abc_types import ReportManager

logger = logging.getLogger(__name__)


def get_or_create_report_manager(
    spec,
    run_id: Optional[str] = None,
    existing_report_manager: Optional[ReportManager] = None,
    no_report: bool = False,
    **kwargs,
) -> Optional[ReportManager]:
    """Get existing or create new report manager.

    This is a helper function to consolidate report manager creation logic
    used across multiple orchestration methods.

    Args:
        spec: The specification instance (needed for get_report_manager method)
        run_id: Unique identifier for the run
        existing_report_manager: Existing report manager instance (if any)
        no_report: If True, skip report manager creation
        **kwargs: Additional parameters including:
                 - report_dir: Directory where reports are stored
                 - rewrite_reports: If True, delete existing report before starting
                 - report_name: Custom name for the report file (default: run_id)

    Returns:
        ReportManager instance, or None if no_report is True or already exists
    """

    # Skip creation if no_report mode
    if no_report:
        return None

    # Return existing report manager if provided
    if existing_report_manager is not None:
        logger.debug("Using existing report manager")
        return existing_report_manager

    # Check if custom report_name is provided
    report_name = kwargs.get("report_name")

    # Generate default run_id if not provided
    # If report_name is explicitly provided, use it as run_id
    if run_id is None:
        if report_name:
            # Use custom report_name as run_id
            run_id = report_name
            logger.debug(f"Using report_name as run_id: {run_id}")
        else:
            # Generate default run_id with timestamp
            from datetime import datetime

            run_id = f"run_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            logger.debug(f"Generated default run_id: {run_id}")
            # Also use as report_name
            report_name = run_id

    # Parse report parameters from kwargs
    report_dir = kwargs.get("report_dir")
    if report_dir is not None:
        report_dir = Path(report_dir)
    rewrite_reports = kwargs.get("rewrite_reports", False)

    # If report_name still not set, use run_id
    if not report_name:
        report_name = run_id

    # Create and return report manager
    report_manager = spec.get_report_manager(
        report_dir=report_dir,
        rewrite_reports=rewrite_reports,
        report_name=report_name,
        run_id=run_id,
    )
    logger.debug(f"Created report manager for run {run_id}")
    return report_manager
