"""Test runner evaluator implementation.

This module provides a parametrized evaluator for running tests with
configurable test selection and expected outcomes.
"""

import logging
from typing import Callable, List, Optional, Union

from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig, EvalSpec
from ee_bench_core.core.eval.evaluator import (
    EvaluationContext,
    Evaluator,
    EvaluatorDependency,
    EvaluatorResult,
    EvaluatorStatus,
)

logger = logging.getLogger(__name__)


class TestRunnerEvaluator(Evaluator):
    """Parametrized evaluator for running tests.

    This evaluator accepts a callback function that determines which tests to run
    and validates that the test outcome matches expectations.

    REQUIRES dependency injection: test_runner MUST be injected via constructor.
    Use DI container to create evaluators with proper dependencies injected.
    """

    def __init__(
        self,
        name: str,
        test_getter: Callable[[DatasetConfig, EvaluationContext], List[str]],
        expect_pass: bool,
        dependencies: Optional[Union[List[str], EvaluatorDependency]] = None,
        is_terminal: bool = False,
        description: Optional[str] = None,
        test_runner=None,
        timeout: Optional[int] = None,
        retry_count: int = 1,
    ):
        """Initialize test runner evaluator.

        Args:
            name: Unique name for this evaluator
            test_getter: Function that returns list of test names to run
                Signature: (config: DatasetConfig, context: EvaluationContext) -> List[str]
            expect_pass: Whether tests are expected to pass (True) or fail (False)
            dependencies: Optional dependency specification
            is_terminal: Whether failure should stop the pipeline
            description: Human-readable description
            test_runner: REQUIRED TestRunner instance (MUST be injected via DI)
            timeout: Optional custom timeout in seconds (None to use runner default)
            retry_count: Number of retry attempts (default: 1, no retries)
        """
        self._name = name
        self._test_getter = test_getter
        self._expect_pass = expect_pass
        self._dependencies = dependencies
        self._is_terminal = is_terminal
        self._description = description or (
            f"Run tests from {test_getter.__name__} "
            f"(expect {'pass' if expect_pass else 'fail'})"
        )
        self._test_runner = test_runner  # Store injected dependency
        self._timeout = timeout
        self._retry_count = retry_count

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return self._description

    @property
    def dependencies(self) -> Optional[Union[List[str], EvaluatorDependency]]:
        return self._dependencies

    @property
    def is_terminal(self) -> bool:
        return self._is_terminal

    @property
    def timeout(self) -> Optional[int]:
        return self._timeout

    @property
    def retry_count(self) -> int:
        return self._retry_count

    @property
    def test_getter(self) -> Callable[[DatasetConfig, EvaluationContext], List[str]]:
        """Get the test getter function."""
        return self._test_getter

    @property
    def expect_pass(self) -> bool:
        """Get whether tests are expected to pass."""
        return self._expect_pass

    def evaluate(
        self,
        spec: EvalSpec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        run_id: str,
        shared_context: EvaluationContext,
        **kwargs,
    ) -> EvaluatorResult:
        """Run tests using test_getter function and validate expected outcome.

        Args:
            spec: Evaluation spec (may provide test_runner if not injected)
            env_config: Environment configuration
            config: Dataset configuration
            run_id: Evaluation run ID
            shared_context: Shared context
            **kwargs: Additional parameters

        Returns:
            EvaluatorResult with test execution outcome
        """
        # test_runner MUST be injected via constructor (DI pattern)
        if not self._test_runner:
            return EvaluatorResult(
                evaluator_name=self.name,
                status=EvaluatorStatus.ERROR,
                message="test_runner must be injected via constructor",
                error=(
                    "TestRunnerEvaluator requires test_runner to be provided at initialization. "
                    "Use DI container to create evaluators with injected dependencies. "
                    "See JvmSweContainer.evaluators() for example."
                ),
            )

        test_runner = self._test_runner

        try:
            # Get test names using provided function
            test_names = self._test_getter(config, shared_context)

            if not test_names:
                return EvaluatorResult(
                    evaluator_name=self.name,
                    status=EvaluatorStatus.SKIPPED,
                    message="No tests to run",
                    error="test_getter returned empty list",
                )

            # Get project path from env_config (workspace_dir / project_dir)
            # Default to /workspace/task_project if not available
            project_path = "/workspace/task_project"
            if hasattr(env_config, "project_path"):
                project_path = str(env_config.project_path)
            elif hasattr(env_config, "workspace_dir") and env_config.workspace_dir:
                # Fallback for configs without project_path property
                project_path = str(env_config.workspace_dir)

            # Run tests
            logger.debug(f"Running {len(test_names)} tests in {project_path}")
            test_result = test_runner.run_tests(
                test_classes=test_names, project_dir=project_path, env_config=env_config
            )

            # Check if outcome matches expectation
            outcome_matches = test_result.success == self._expect_pass

            if outcome_matches:
                status_msg = "passed" if self._expect_pass else "failed"
                return EvaluatorResult(
                    evaluator_name=self.name,
                    status=EvaluatorStatus.SUCCESS,
                    message=f"Tests {status_msg} as expected",
                    data={
                        "test_count": len(test_names),
                        "passed": test_result.passed_tests,
                        "failed": test_result.failed_tests,
                        "expected_pass": self._expect_pass,
                        "actual_pass": test_result.success,
                        "test_result": test_result.to_dict(),
                    },
                )
            else:
                expected_msg = "pass" if self._expect_pass else "fail"
                actual_msg = "passed" if test_result.success else "failed"
                return EvaluatorResult(
                    evaluator_name=self.name,
                    status=EvaluatorStatus.FAILED,
                    message=f"Tests {actual_msg} but expected to {expected_msg}",
                    data={
                        "test_count": len(test_names),
                        "passed": test_result.passed_tests,
                        "failed": test_result.failed_tests,
                        "expected_pass": self._expect_pass,
                        "actual_pass": test_result.success,
                        "test_result": test_result.to_dict(),
                    },
                )

        except Exception as e:
            logger.error(f"Error running tests: {e}", exc_info=True)
            return EvaluatorResult(
                evaluator_name=self.name,
                status=EvaluatorStatus.ERROR,
                message="Exception while running tests",
                error=str(e),
            )
