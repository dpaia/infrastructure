"""LocalGitConfigurer and PatchApplier providers for local git operations."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from ee_bench.generator.interfaces import Provider

from ee_bench.git.git_commands import (
    GitCommandError,
    git_add,
    git_apply,
    git_branch_create,
    git_branch_exists,
    git_checkout,
    git_clean,
    git_clone,
    git_commit,
    git_default_branch,
    git_fetch,
    git_object_exists,
    git_push,
    git_remote_add,
    git_reset_hard,
    git_rev_parse,
)

logger = logging.getLogger(__name__)


class LocalGitConfigurer(Provider):
    """Manages local git checkouts, branches, commits, and pushes.

    Clones fork repos locally and caches them for reuse across instances
    in the same repo. Does NOT apply patches or write files — those are
    handled by PatchApplier and normal file I/O in the import script.
    """

    def __init__(self, base_dir: str | Path):
        self._base_dir = Path(base_dir)
        self._base_dir.mkdir(parents=True, exist_ok=True)
        self._checkouts: dict[str, Path] = {}

    def provide(
        self,
        item: Any = None,
        *,
        fork_repo: str = "",
        upstream_repo: str = "",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Ensure fork is cloned locally. Returns clone_dir and fork_repo.

        Clones on first call for a given fork_repo, returns cached path
        on subsequent calls. Adds upstream remote if upstream_repo is provided.
        """
        if not fork_repo:
            raise ValueError("fork_repo is required")

        if fork_repo in self._checkouts:
            return {
                "clone_dir": self._checkouts[fork_repo],
                "fork_repo": fork_repo,
            }

        repo_name = fork_repo.split("/")[-1]
        clone_dir = self._base_dir / repo_name

        if clone_dir.exists():
            logger.info("Reusing existing checkout: %s", clone_dir)
        else:
            logger.info("Cloning %s -> %s", fork_repo, clone_dir)
            git_clone(f"git@github.com:{fork_repo}.git", clone_dir)

        if upstream_repo:
            try:
                git_remote_add(clone_dir, "upstream", f"git@github.com:{upstream_repo}.git")
                logger.info("Added upstream remote: %s", upstream_repo)
            except GitCommandError:
                # Remote already exists
                pass

        self._checkouts[fork_repo] = clone_dir
        return {
            "clone_dir": clone_dir,
            "fork_repo": fork_repo,
        }

    def default_branch(self, clone_dir: Path) -> str:
        """Return the default branch name (e.g. 'main' or 'master')."""
        return git_default_branch(clone_dir)

    def fetch_commit(self, clone_dir: Path, sha: str) -> None:
        """Ensure commit SHA exists locally. Fetches from upstream if needed."""
        if git_object_exists(clone_dir, sha):
            logger.debug("Commit %s already exists locally", sha[:12])
            return

        # Try fetching from upstream first, then origin
        for remote in ("upstream", "origin"):
            try:
                git_fetch(clone_dir, remote, sha)
                if git_object_exists(clone_dir, sha):
                    logger.info("Fetched commit %s from %s", sha[:12], remote)
                    return
            except GitCommandError:
                continue

        raise GitCommandError(
            ["fetch", sha], 1, f"Could not fetch commit {sha} from any remote"
        )

    def create_branch(self, clone_dir: Path, branch: str, start_point: str) -> None:
        """Create branch at start_point. No-op if already exists at same commit."""
        if git_branch_exists(clone_dir, branch):
            existing_sha = git_rev_parse(clone_dir, f"refs/heads/{branch}")
            target_sha = git_rev_parse(clone_dir, start_point)
            if existing_sha == target_sha:
                logger.debug("Branch %s already at %s", branch, target_sha[:12])
                return
            # Branch exists but points to wrong commit — reset it
            logger.info("Resetting branch %s to %s", branch, target_sha[:12])
            git_checkout(clone_dir, branch)
            git_reset_hard(clone_dir, start_point)
            return

        logger.info("Creating branch %s at %s", branch, start_point[:12])
        git_branch_create(clone_dir, branch, start_point)

    def checkout(self, clone_dir: Path, ref: str) -> None:
        """Checkout a branch or commit. Cleans the worktree first."""
        git_checkout(clone_dir, ref)
        git_clean(clone_dir)

    def commit(self, clone_dir: Path, paths: list[str], message: str, *, force: bool = False) -> str:
        """Stage paths, commit, return SHA. Use force=True for .gitignore'd paths."""
        git_add(clone_dir, paths, force=force)
        return git_commit(clone_dir, message)

    def push(
        self, clone_dir: Path, branches: list[str], *, force: bool = False
    ) -> None:
        """Push branches to origin."""
        git_push(clone_dir, "origin", branches, force=force)


class PatchApplier(Provider):
    """Applies unified diff patches to a local worktree using git apply."""

    def provide(
        self,
        item: Any = None,
        *,
        clone_dir: Path | str = "",
        patch: str = "",
        test_patch: str = "",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Apply patch(es) to the worktree.

        Returns dict with status and list of applied patches.
        """
        if not clone_dir:
            raise ValueError("clone_dir is required")
        clone_dir = Path(clone_dir)

        applied = []

        if patch:
            logger.info("Applying golden patch (%d bytes)", len(patch))
            git_apply(clone_dir, patch)
            applied.append("patch")

        if test_patch:
            logger.info("Applying test patch (%d bytes)", len(test_patch))
            git_apply(clone_dir, test_patch)
            applied.append("test_patch")

        return {
            "status": "applied" if applied else "no_patches",
            "patches_applied": applied,
        }
