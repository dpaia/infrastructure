"""Data classes for the scripting API."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Filter:
    """A single filter condition for providers that support filtering."""

    field: str
    eq: str | None = None
    contains: str | None = None
    in_: list[str] | None = None


@dataclass
class FileSpec:
    """Specification for a file to fetch from a repository."""

    path: str
    field: str


@dataclass
class AttachmentFile:
    """Specification for a file to upload as a GitHub attachment."""

    path: str
    field: str | None = None
    mode: str = "100644"


@dataclass
class ProjectConfig:
    """Specification for a GitHub project to add a PR to."""

    name: str = ""
    id: str = ""
