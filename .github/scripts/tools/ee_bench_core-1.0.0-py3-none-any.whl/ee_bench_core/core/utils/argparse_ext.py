"""Extended argument parsing utilities for spec-specific parameters."""

import json
import shlex
from typing import Any, Dict, List


def parse_extra_args(args: List[str]) -> Dict[str, Any]:
    """Parse extra arguments into a dictionary.

    Parses command-line arguments in the format:
    - --key=value or --key value for string values
    - --flag for boolean flags
    - Multiple values: --key val1 --key val2 creates list

    Args:
        args: List of argument strings (e.g., sys.argv[1:])

    Returns:
        Dictionary mapping parameter names to values

    Examples:
        >>> parse_extra_args(['--verbose', '--max-workers', '4', '--tag', 'a', '--tag', 'b'])
        {'verbose': True, 'max_workers': '4', 'tag': ['a', 'b']}
    """
    result: Dict[str, Any] = {}
    i = 0

    while i < len(args):
        arg = args[i]

        # Skip non-flag arguments (including single-dash arguments)
        if not arg.startswith("--"):
            i += 1
            continue

        # Handle --key=value format
        if "=" in arg:
            key, value = arg[2:].split("=", 1)
            key = key.replace("-", "_")
            # Skip if key is empty (edge case: just "--")
            if key:
                _add_value(result, key, value)
            i += 1
            continue

        # Handle --key value or --flag format
        key = arg[2:].replace("-", "_")

        # Skip if key is empty (edge case: just "--")
        if not key:
            i += 1
            continue

        # Check if next arg is a value or another flag/option
        if i + 1 < len(args) and not args[i + 1].startswith("-"):
            value = args[i + 1]
            _add_value(result, key, value)
            i += 2
        else:
            # Standalone flag
            result[key] = True
            i += 1

    return result


def _add_value(result: Dict[str, Any], key: str, value: str) -> None:
    """Add value to result dictionary, handling duplicate keys.

    Args:
        result: Result dictionary to update
        key: Parameter key
        value: Parameter value
    """
    if key in result:
        # Key already exists - convert to list or append to existing list
        existing = result[key]
        if isinstance(existing, list):
            existing.append(value)
        else:
            result[key] = [existing, value]
    else:
        result[key] = value


def parse_docker_opts(docker_opts_str: str) -> Dict[str, Any]:
    """Parse docker options from JSON or command-line format.

    Accepts two input formats:
    1. JSON: {"memory": "2g", "cpus": "2", "env": ["VAR=value"]}
    2. CLI style: --memory 2g --cpus 2 -e VAR=value -v /path:/path

    Args:
        docker_opts_str: Docker options as JSON string or CLI arguments

    Returns:
        Dictionary of parsed docker options

    Raises:
        ValueError: If input cannot be parsed

    Examples:
        >>> parse_docker_opts('{"memory": "2g", "cpus": "2"}')
        {'memory': '2g', 'cpus': '2'}

        >>> parse_docker_opts('--memory 2g --cpus 2')
        {'memory': '2g', 'cpus': '2'}

        >>> parse_docker_opts('--env VAR1=val1 --env VAR2=val2')
        {'env': ['VAR1=val1', 'VAR2=val2']}

        >>> parse_docker_opts('-e VAR=val -v /host:/container')
        {'e': ['VAR=val'], 'v': ['/host:/container']}
    """
    if not docker_opts_str or not docker_opts_str.strip():
        return {}

    docker_opts_str = docker_opts_str.strip()

    # Try JSON first
    if docker_opts_str.startswith("{"):
        try:
            return json.loads(docker_opts_str)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON format for docker-opts: {e}")

    # Parse as CLI arguments
    try:
        # Use shlex to properly handle quoted strings
        args = shlex.split(docker_opts_str)
        return _parse_docker_cli_args(args)
    except ValueError as e:
        raise ValueError(f"Invalid CLI format for docker-opts: {e}")


def _parse_docker_cli_args(args: List[str]) -> Dict[str, Any]:
    """Parse Docker CLI-style arguments including single-dash options.

    Supports both single-dash (-e, -v, -p) and double-dash (--memory, --cpus) options.

    Args:
        args: List of argument strings

    Returns:
        Dictionary mapping parameter names to values
    """
    result: Dict[str, Any] = {}
    i = 0

    while i < len(args):
        arg = args[i]

        # Skip non-flag arguments
        if not arg.startswith("-"):
            i += 1
            continue

        # Handle --key=value format
        if arg.startswith("--") and "=" in arg:
            key, value = arg[2:].split("=", 1)
            key = key.replace("-", "_")
            if key:
                _add_value(result, key, value)
            i += 1
            continue

        # Handle --key or -k format
        if arg.startswith("--"):
            key = arg[2:].replace("-", "_")
        elif arg.startswith("-"):
            key = arg[1:]  # Keep single-char flags as-is (e.g., 'e', 'v', 'p')
        else:
            i += 1
            continue

        # Skip if key is empty
        if not key:
            i += 1
            continue

        # Check if next arg is a value or another flag/option
        if i + 1 < len(args) and not args[i + 1].startswith("-"):
            value = args[i + 1]
            _add_value(result, key, value)
            i += 2
        else:
            # Standalone flag
            result[key] = True
            i += 1

    return result
