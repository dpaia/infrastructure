"""Base EE-bench specification dependency injection container.

This module defines the base CodeContainer that provides common dependencies
for all EE-bench format evaluations.
"""

from typing import List

from ee_bench_code_spec.evaluator_factory import (
    create_minimal_pipeline,
    create_minimal_pipeline_test_already_applied,
)
from ee_bench_core.di.base_container import BaseContainer


def _create_evaluators_pipeline(
    test_runner,
    patch_adapter,
    evaluators_pipeline="gold",
    base_test_score=100,
    regression_score=25,
) -> List:
    """Create EE-bench evaluator pipeline with injected dependencies.

    This is a wrapper for the DI factory function to work with dependency-injector.

    Args:
        test_runner: Injected TestRunner
        patch_adapter: Injected PatchAdapter
        evaluators_pipeline: Pipeline type ("standard", "minimal_with_test_patch", "minimal")
        base_test_score: Score for passing tests (default: 100)
        regression_score: Penalty score for regressions (default: 25)

    Returns:
        List of evaluators with all dependencies injected

    Note:
        PredictionsCollector is obtained from spec.get_predictions_collector_provider()
        at runtime, not provided to this function.

        The pipeline is selected based on evaluators_pipeline.

        Regression detection is automatically included in minimal pipelines.
        regression_score controls the penalty for regressions (default: 25 points).
    """
    from ee_bench_code_spec.evaluator_factory import create_standard_pipeline

    match evaluators_pipeline:
        case "standard":
            return create_standard_pipeline(
                test_runner=test_runner, patch_adapter=patch_adapter
            )
        case "minimal_with_test_patch":
            return create_minimal_pipeline(
                test_runner=test_runner,
                patch_adapter=patch_adapter,
                base_test_score=base_test_score,
                regression_score=regression_score,
            )
        case "minimal":
            return create_minimal_pipeline_test_already_applied(
                test_runner=test_runner,
                patch_adapter=patch_adapter,
                base_test_score=base_test_score,
                regression_score=regression_score,
            )
        case _:
            return create_minimal_pipeline(
                test_runner=test_runner,
                patch_adapter=patch_adapter,
                base_test_score=base_test_score,
                regression_score=regression_score,
            )


class CodeContainer(BaseContainer):
    """Base container for EE-bench specifications.

    Extends BaseContainer with EE-bench specific dependencies:
    - TestRunner (ABSTRACT - must be provided by language-specific container)
    - Evaluators pipeline (uses TestRunner, PatchAdapter, PredictionsCollector)

    Inherits from BaseContainer:
    - ProcessManager (local or docker)
    - PatchAdapter (with ProcessManager)

    Language-specific containers (JvmCodeContainer, PythonCodeContainer, etc.)
    MUST extend this and provide concrete TestRunner implementation.

    Configuration keys (in addition to BaseContainer):
        - predictions_mode: "gold", "json", or "agent" (for evaluation runtime)
        - predictions_path: Path to predictions file or "gold"/"agent"
        - build_system: Build system for test runner selection (language-specific)

    Note: PredictionsCollector is NOT managed by DI container.
          Use spec.get_predictions_collector_provider().get_collector(**kwargs) instead.
    """

    pass
