"""Unified EE-bench codegen generators."""

from __future__ import annotations

import json
from typing import Any

from ee_bench.generator.clock import now_iso8601_utc
from ee_bench.generator.interfaces import Provider
from ee_bench.generator.tag_utils import filter_tags


def _get_from(data_dicts: list[dict[str, Any] | None], key: str, default: Any = None) -> Any:
    """Look up key across multiple dicts, returning the first non-None match."""
    for d in data_dicts:
        if d and key in d:
            val = d[key]
            if val is not None:
                return val
    return default


def _json_parse(value: Any) -> Any:
    """Parse JSON string to list/dict, or return as-is if already parsed."""
    if isinstance(value, (list, dict)):
        return value
    if isinstance(value, str):
        try:
            return json.loads(value)
        except (json.JSONDecodeError, ValueError):
            pass
    return value


class EEBenchCodegenUnifiedGenerator(Provider):
    """Produces the nested unified format for the evaluation harness.

    Structure::

        {
          "instance_id": "...",
          "language": "java",
          "jvm_version": "24",
          "environment": {
            "files": {"Dockerfile": "...", ...},
            "docker": {"run_params": "..."},
            "project_root": "/repo"
          },
          "eval": {
            "files": {"run.sh": "...", "test_patch.diff": "..."}
          },
          "verify": {
            "files": {"patch.diff": "..."}
          },
          "fail_to_pass": [...],
          "pass_to_pass": [...],
        }

    File entries live under a ``"files"`` sub-key so consumers can
    unambiguously distinguish files from inline data.

    All fields from ``ee_bench_config`` (parsed ``metadata.json``) are
    passed through as top-level record fields, preserving original key
    casing.  ``environment``-level config is merged into the
    ``environment`` section alongside ``files``.  Fields under
    ``expected`` are promoted to top-level (no wrapper).
    """

    def provide(
        self,
        item=None,
        *,
        sections=None,
        patches=None,
        environment=None,
        build=None,
        tests=None,
        version="",
        skip_empty_fields=True,
        **kwargs,
    ) -> dict[str, Any]:
        """Produce a single unified record from item and enrichment dicts.

        Args:
            item: Primary item dict (from HuggingFace or GitHub provider).
            sections: Dict from SectionProvider (problem_statement, hints_text).
            patches: Dict from PatchSplitterProvider (patch, test_patch).
            environment: Dict from EEBenchEnvironmentProvider (environment_files, eval, etc.).
            build: Dict from Gradle/Maven provider (build_system, module_map).
            tests: Dict from ModuleTestProvider (FAIL_TO_PASS, PASS_TO_PASS).
            version: Version string override.
            skip_empty_fields: Remove empty fields from output.
            **kwargs: Additional fields merged into lookup.

        Returns:
            Nested record dict.
        """
        item = item or {}
        sources = [kwargs, tests, environment, build, patches, sections, item]

        computed = self._compute_fields(sources, version, kwargs)

        record: dict[str, Any] = {
            "instance_id": computed["instance_id"],
            "pr_number": _get_from(sources, "number", None),
            "repo": computed["repo"],
            "base_commit": _get_from(sources, "base_commit", ""),
            "problem_statement": computed["problem_statement"],
            "hints_text": _get_from(sources, "hints_text", ""),
            "version": computed["version"],
            "created_at": computed["created_at"],
            "build_system": _get_from(sources, "build_system", ""),
            "project_root": _get_from(sources, "project_root", ""),
        }

        # --- environment section ---
        env_files = _get_from(sources, "environment_files", {}) or {}
        env_section: dict[str, Any] = {"files": env_files}
        ee_bench_config = _get_from(sources, "ee_bench_config", {}) or {}
        # Merge all non-file config from ee_bench_config["environment"]
        for k, v in (ee_bench_config.get("environment") or {}).items():
            if k != "files":
                env_section[k] = v
        record["environment"] = env_section

        # --- eval section ---
        eval_files = dict(_get_from(sources, "eval", {}) or {})
        test_patch = _get_from(sources, "test_patch", "")
        if test_patch:
            eval_files["test_patch.diff"] = test_patch
        record["eval"] = {"files": eval_files}

        # --- verify section ---
        verify_patch = _get_from(sources, "patch", "")
        verify_files = {"patch.diff": verify_patch} if verify_patch else {}
        record["verify"] = {"files": verify_files}

        # --- metadata.json passthrough ---
        # All fields from ee_bench_config (metadata.json) are copied to the record
        # as top-level fields, preserving their original keys and casing.
        # Fields under "expected" are promoted to top-level (no wrapper).
        ee_bench_config = _get_from(sources, "ee_bench_config", {}) or {}

        for k, v in ee_bench_config.items():
            if k not in record or record[k] in ("", None):
                record[k] = _json_parse(v)

        if skip_empty_fields:
            record = {k: v for k, v in record.items() if v not in ("", {}, [], None)}

        return record

    @staticmethod
    def _compute_fields(
        sources: list[dict[str, Any] | None],
        version: str,
        opts: dict[str, Any],
    ) -> dict[str, Any]:
        """Compute derived fields shared across mappings."""
        item = sources[-1] or {}  # Last source is the primary item
        owner = item.get("owner", "unknown")
        repo_name = item.get("repo", "unknown")
        number = item.get("number", 0)

        instance_id = _get_from(sources, "instance_id", "")
        if not instance_id:
            safe_repo = repo_name.replace("-", "__")
            instance_id = f"{owner}__{safe_repo}-{number}"

        problem_statement = _get_from(sources, "problem_statement", "")
        if not problem_statement:
            problem_statement = _get_from(sources, "description", "")

        repo_url = _get_from(sources, "repo_url", "")
        repo = _get_from(sources, "repo", "")
        if repo and "/" not in repo and owner != "unknown":
            repo = f"{owner}/{repo}"
        elif not repo and repo_url:
            repo = repo_url.removeprefix("https://github.com/").removeprefix("http://github.com/")
        if repo.endswith(".git"):
            repo = repo[:-4]

        created_at = _get_from(sources, "created_at", "") or now_iso8601_utc()

        if not version:
            version = str(opts.get("version", "") or _get_from(sources, "version", ""))

        labels = _get_from(sources, "labels", [])
        tags_cfg = opts.get("tags", {})
        exclude_patterns = tags_cfg.get("exclude") or opts.get("exclude", [])
        include_patterns = tags_cfg.get("include", [])
        tags = filter_tags(labels, exclude=exclude_patterns, include=include_patterns) if isinstance(labels, list) else labels

        return {
            "instance_id": instance_id,
            "problem_statement": problem_statement,
            "repo": repo,
            "created_at": created_at,
            "version": version,
            "tags": tags,
            "number": number,
            "owner": owner,
        }


class EEBenchCodegenFlatGenerator(Provider):
    """Produces the original flat format — all fields as top-level keys."""

    def provide(
        self,
        item=None,
        *,
        sections=None,
        patches=None,
        environment=None,
        build=None,
        tests=None,
        version="",
        skip_empty_fields=True,
        **kwargs,
    ) -> dict[str, Any]:
        """Produce a single flat record from item and enrichment dicts.

        Same args as EEBenchCodegenUnifiedGenerator.provide().

        Returns:
            Flat record dict.
        """
        item = item or {}
        sources = [kwargs, tests, environment, build, patches, sections, item]

        computed = EEBenchCodegenUnifiedGenerator._compute_fields(sources, version, kwargs)
        build_system = _get_from(sources, "build_system", "")

        record: dict[str, Any] = {
            "instance_id": computed["instance_id"],
            "patch": _get_from(sources, "patch", ""),
            "test_patch": _get_from(sources, "test_patch", ""),
            "problem_statement": computed["problem_statement"],
            "hints_text": _get_from(sources, "hints_text", ""),
            "repo": computed["repo"],
            "base_commit": _get_from(sources, "base_commit", ""),
            "version": computed["version"],
            "repo_language": _get_from(sources, "repo_language", ""),
            "fail_to_pass": _get_from(sources, "FAIL_TO_PASS", "[]"),
            "pass_to_pass": _get_from(sources, "PASS_TO_PASS", "[]"),
            "environment_setup_commit": _get_from(sources, "environment_setup_commit", ""),
            "requirements": _get_from(sources, "requirements", ""),
            "interface": _get_from(sources, "interface", ""),
            "issue_specificity": _get_from(sources, "issue_specificity", ""),
            "issue_categories": _get_from(sources, "issue_categories", ""),
            "dockerhub_tag": _get_from(sources, "dockerhub_tag", ""),
            "before_repo_set_cmd": _get_from(sources, "before_repo_set_cmd", ""),
            "selected_test_files_to_run": _get_from(sources, "selected_test_files_to_run", ""),
            "created_at": computed["created_at"],
            "checksum": _get_from(sources, "checksum", ""),
            "dataset": _get_from(sources, "dataset", ""),
            "run_script_name": _get_from(sources, "run_script_name", ""),
            "parser_name": _get_from(sources, "parser_name", ""),
            "build_system": build_system,
            "is_maven": _get_from(sources, "is_maven", build_system == "maven"),
            "issue_numbers": json.dumps([str(computed["number"])]),
            "tags": json.dumps(computed["tags"]) if isinstance(computed["tags"], list) else computed["tags"],
        }

        if skip_empty_fields:
            record = {k: v for k, v in record.items() if v not in ("", {}, [], None)}

        return record
