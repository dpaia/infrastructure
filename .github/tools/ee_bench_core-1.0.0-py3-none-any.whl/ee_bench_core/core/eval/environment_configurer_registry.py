"""Environment configurer plugin registry for dynamic discovery and registration.

This module provides a registry system for environment configurers that allows:
- Registering configurers by name (programmatically or via decorator)
- Discovering configurers from entry points (plugins)
- Retrieving configurer factories by name
- Listing all available configurers with metadata
"""

import logging
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Type
from importlib.metadata import entry_points

from .environment_configurer import EnvironmentConfigurer
from ..config import get_config

logger = logging.getLogger(__name__)


@dataclass
class EnvironmentConfigurerMetadata:
    """Metadata about a registered environment configurer.

    Attributes:
        name: Unique identifier for the configurer
        factory: Factory function or class that creates the configurer
        description: Human-readable description
        version: Version string (e.g., "1.0.0")
        author: Author or organization name
        tags: List of tags for categorization (e.g., ["security", "snyk"])
        specs: List of spec names this configurer applies to (empty = all specs)
        entry_point: Entry point name if loaded from plugin (None if programmatic)
    """

    name: str
    factory: Callable[..., EnvironmentConfigurer]
    description: str = ""
    version: str = "1.0.0"
    author: str = ""
    tags: List[str] = field(default_factory=list)
    specs: List[str] = field(default_factory=list)
    entry_point: Optional[str] = None

    def to_dict(self) -> Dict:
        """Convert metadata to dictionary for serialization."""
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "author": self.author,
            "tags": self.tags,
            "specs": self.specs,
            "entry_point": self.entry_point,
        }


class EnvironmentConfigurerRegistry:
    """Registry for environment configurer plugins.

    The registry allows:
    1. Programmatic registration via register() or @register_configurer decorator
    2. Automatic discovery from entry points (ee_bench.environment_configurers)
    3. Retrieval of configurer factories by name
    4. Listing all available configurers with metadata

    Example:
        >>> registry = EnvironmentConfigurerRegistry()
        >>>
        >>> # Register programmatically
        >>> registry.register(
        ...     name="snyk_configurer",
        ...     factory=SnykEnvironmentConfigurer,
        ...     description="Configures Snyk security scanner"
        ... )
        >>>
        >>> # Or use decorator
        >>> @registry.register_configurer(
        ...     name="custom_tool",
        ...     description="Configures custom tool"
        ... )
        ... class CustomToolConfigurer(EnvironmentConfigurer):
        ...     pass
        >>>
        >>> # Get configurer factory
        >>> factory = registry.get("snyk_configurer")
        >>> configurer = factory(name="snyk")
        >>>
        >>> # List all configurers
        >>> for metadata in registry.list():
        ...     print(f"{metadata.name}: {metadata.description}")
    """

    def __init__(self, auto_discover: bool = False):
        """Initialize registry.

        Args:
            auto_discover: If True, automatically discover configurers from entry points
        """
        self._configurers: Dict[str, EnvironmentConfigurerMetadata] = {}

        if auto_discover:
            self.discover_plugins()

    def register(
        self,
        name: str,
        factory: Callable[..., EnvironmentConfigurer],
        description: str = "",
        version: str = "1.0.0",
        author: str = "",
        tags: Optional[List[str]] = None,
        specs: Optional[List[str]] = None,
        replace: bool = False,
    ) -> None:
        """Register an environment configurer factory.

        Args:
            name: Unique identifier for the configurer
            factory: Factory function or class that creates EnvironmentConfigurer instances
            description: Human-readable description
            version: Version string
            author: Author or organization name
            tags: List of tags for categorization
            specs: List of spec names this configurer applies to (empty = all specs)
            replace: If True, replace existing registration (default: False, raises error)

        Raises:
            ValueError: If name is already registered and replace=False
        """
        # Check if configurer is disabled in configuration
        config = get_config()
        if not config.is_configurer_enabled(name):
            logger.info(f"Environment configurer '{name}' is disabled in configuration, skipping registration")
            return

        if name in self._configurers and not replace:
            raise ValueError(
                f"Environment configurer '{name}' is already registered. "
                f"Use replace=True to override."
            )

        metadata = EnvironmentConfigurerMetadata(
            name=name,
            factory=factory,
            description=description,
            version=version,
            author=author,
            tags=tags or [],
            specs=specs or [],
        )

        self._configurers[name] = metadata
        logger.debug(f"Registered environment configurer '{name}' (version {version})")

    def register_configurer(
        self,
        name: str,
        description: str = "",
        version: str = "1.0.0",
        author: str = "",
        tags: Optional[List[str]] = None,
        specs: Optional[List[str]] = None,
        replace: bool = False,
    ):
        """Decorator for registering environment configurer classes.

        Args:
            name: Unique identifier for the configurer
            description: Human-readable description
            version: Version string
            author: Author or organization name
            tags: List of tags for categorization
            specs: List of spec names this configurer applies to (empty = all specs)
            replace: If True, replace existing registration

        Returns:
            Decorator function that registers the class

        Example:
            >>> registry = EnvironmentConfigurerRegistry()
            >>>
            >>> @registry.register_configurer(
            ...     name="snyk",
            ...     description="Snyk security scanner configurer",
            ...     tags=["security", "snyk"],
            ...     specs=["swe-jvm", "swe-python"]
            ... )
            ... class SnykConfigurer(EnvironmentConfigurer):
            ...     def configure(self, ...):
            ...         pass
        """

        def decorator(cls: Type[EnvironmentConfigurer]) -> Type[EnvironmentConfigurer]:
            self.register(
                name=name,
                factory=cls,
                description=description,
                version=version,
                author=author,
                tags=tags,
                specs=specs,
                replace=replace,
            )
            return cls

        return decorator

    def get(self, name: str) -> Callable[..., EnvironmentConfigurer]:
        """Get environment configurer factory by name.

        Args:
            name: Configurer name

        Returns:
            Factory function or class

        Raises:
            KeyError: If configurer not found
        """
        if name not in self._configurers:
            available = ", ".join(self._configurers.keys())
            raise KeyError(
                f"Environment configurer '{name}' not found. "
                f"Available configurers: {available or 'none'}"
            )

        return self._configurers[name].factory

    def get_metadata(self, name: str) -> EnvironmentConfigurerMetadata:
        """Get metadata for an environment configurer.

        Args:
            name: Configurer name

        Returns:
            EnvironmentConfigurerMetadata instance

        Raises:
            KeyError: If configurer not found
        """
        if name not in self._configurers:
            raise KeyError(f"Environment configurer '{name}' not found")

        return self._configurers[name]

    def has(self, name: str) -> bool:
        """Check if configurer is registered.

        Args:
            name: Configurer name

        Returns:
            True if registered, False otherwise
        """
        return name in self._configurers

    def list(
        self, tags: Optional[List[str]] = None, spec: Optional[str] = None
    ) -> List[EnvironmentConfigurerMetadata]:
        """List all registered configurers, optionally filtered by tags and/or spec.

        Args:
            tags: Optional list of tags to filter by (configurers must have at least one matching tag)
            spec: Optional spec name to filter by (configurers with empty specs list match all specs)

        Returns:
            List of EnvironmentConfigurerMetadata instances matching criteria
        """
        configurers = list(self._configurers.values())

        if tags:
            configurers = [
                meta for meta in configurers if any(tag in meta.tags for tag in tags)
            ]

        if spec:
            configurers = [
                meta for meta in configurers if not meta.specs or spec in meta.specs
            ]

        return configurers

    def list_for_spec(self, spec_name: str) -> List[EnvironmentConfigurerMetadata]:
        """List all configurers applicable to a specific spec.

        This is a convenience method that filters configurers by spec.
        A configurer is applicable if:
        - Its specs list is empty (universal configurer), OR
        - The spec_name is in its specs list

        Args:
            spec_name: Name of the specification (e.g., "swe-jvm", "swe-python")

        Returns:
            List of EnvironmentConfigurerMetadata instances applicable to the spec

        Example:
            >>> registry = EnvironmentConfigurerRegistry()
            >>> registry.discover_plugins()
            >>>
            >>> # Get configurers for JVM SWE spec
            >>> jvm_configurers = registry.list_for_spec("swe-jvm")
            >>> for meta in jvm_configurers:
            ...     print(f"{meta.name}: {meta.specs}")
        """
        return self.list(spec=spec_name)

    def unregister(self, name: str) -> None:
        """Unregister a configurer.

        Args:
            name: Configurer name

        Raises:
            KeyError: If configurer not found
        """
        if name not in self._configurers:
            raise KeyError(f"Environment configurer '{name}' not found")

        del self._configurers[name]
        logger.debug(f"Unregistered environment configurer '{name}'")

    def clear(self) -> None:
        """Clear all registered configurers."""
        self._configurers.clear()
        logger.debug("Cleared all registered environment configurers")

    def discover_plugins(self, group: str = "ee_bench.environment_configurers") -> int:
        """Discover and register configurers from entry points.

        This method scans for entry points in the specified group and loads
        configurer factories from them. Entry points should be defined in
        pyproject.toml or setup.py:

        [project.entry-points."ee_bench.environment_configurers"]
        snyk_configurer = "snyk_plugin.configurer:SnykEnvironmentConfigurer"

        Args:
            group: Entry point group name (default: "ee_bench.environment_configurers")

        Returns:
            Number of configurers discovered and registered
        """
        count = 0

        try:
            # Python 3.10+ API
            eps = entry_points(group=group)
        except TypeError:
            # Python 3.9 fallback
            eps = entry_points().get(group, [])

        for ep in eps:
            try:
                # Load the entry point
                factory = ep.load()

                # Extract metadata from factory if available
                name = getattr(factory, "__configurer_name__", ep.name)
                description = getattr(factory, "__configurer_description__", "")
                version = getattr(factory, "__configurer_version__", "1.0.0")
                author = getattr(factory, "__configurer_author__", "")
                tags = getattr(factory, "__configurer_tags__", [])
                specs = getattr(factory, "__configurer_specs__", [])

                # Register (don't replace existing)
                if not self.has(name):
                    metadata = EnvironmentConfigurerMetadata(
                        name=name,
                        factory=factory,
                        description=description,
                        version=version,
                        author=author,
                        tags=tags,
                        specs=specs,
                        entry_point=ep.name,
                    )
                    self._configurers[name] = metadata
                    count += 1
                    spec_info = (
                        f" (specs: {', '.join(specs)})" if specs else " (all specs)"
                    )
                    logger.info(
                        f"Discovered environment configurer '{name}' from entry point '{ep.name}'{spec_info}"
                    )
                else:
                    logger.debug(
                        f"Skipping entry point '{ep.name}': configurer '{name}' already registered"
                    )

            except Exception as e:
                logger.error(
                    f"Failed to load environment configurer from entry point '{ep.name}': {e}",
                    exc_info=True,
                )

        logger.info(f"Discovered {count} environment configurers from entry points")
        return count


# Global registry instance
_global_registry: Optional[EnvironmentConfigurerRegistry] = None


def get_global_registry() -> EnvironmentConfigurerRegistry:
    """Get the global environment configurer registry instance.

    Returns:
        Global EnvironmentConfigurerRegistry instance (created if needed)
    """
    global _global_registry
    if _global_registry is None:
        _global_registry = EnvironmentConfigurerRegistry(auto_discover=False)
    return _global_registry


def register_configurer(
    name: str,
    description: str = "",
    version: str = "1.0.0",
    author: str = "",
    tags: Optional[List[str]] = None,
    specs: Optional[List[str]] = None,
    replace: bool = False,
):
    """Decorator for registering configurers in the global registry.

    This is a convenience function that uses the global registry.

    Args:
        name: Unique identifier for the configurer
        description: Human-readable description
        version: Version string
        author: Author or organization name
        tags: List of tags for categorization
        specs: List of spec names this configurer applies to (empty = all specs)
        replace: If True, replace existing registration

    Returns:
        Decorator function

    Example:
        >>> @register_configurer(
        ...     name="my_tool",
        ...     description="My custom tool configurer",
        ...     tags=["tool"],
        ...     specs=["swe-jvm"]
        ... )
        ... class MyToolConfigurer(EnvironmentConfigurer):
        ...     pass
    """
    registry = get_global_registry()
    return registry.register_configurer(
        name=name,
        description=description,
        version=version,
        author=author,
        tags=tags,
        specs=specs,
        replace=replace,
    )
