"""Environment configurer plugin registry for dynamic discovery and registration.

This module provides a registry system for environment configurers that allows:
- Registering configurers by name (programmatically or via decorator)
- Discovering configurers from entry points (plugins)
- Retrieving configurer factories by name
- Listing all available configurers with metadata
"""

import logging
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional

from .environment_configurer import EnvironmentConfigurer
from .base_plugin_registry import (
    BasePluginRegistry,
    PluginMetadata,
    create_global_registry_accessors,
)
from ..config import get_config

logger = logging.getLogger(__name__)


@dataclass
class EnvironmentConfigurerMetadata(PluginMetadata[EnvironmentConfigurer]):
    """Metadata about a registered environment configurer.

    Attributes:
        name: Unique identifier for the configurer
        factory: Factory function or class that creates the configurer
        description: Human-readable description
        version: Version string (e.g., "1.0.0")
        author: Author or organization name
        tags: List of tags for categorization (e.g., ["security", "snyk"])
        specs: List of spec names this configurer applies to (empty = all specs)
        entry_point: Entry point name if loaded from plugin (None if programmatic)
    """

    pass


class EnvironmentConfigurerRegistry(BasePluginRegistry[EnvironmentConfigurer]):
    """Registry for environment configurer plugins.

    The registry allows:
    1. Programmatic registration via register() or @register_configurer decorator
    2. Automatic discovery from entry points (ee_bench.environment_configurers)
    3. Retrieval of configurer factories by name
    4. Listing all available configurers with metadata

    Example:
        >>> registry = EnvironmentConfigurerRegistry()
        >>>
        >>> # Register programmatically
        >>> registry.register(
        ...     name="snyk_configurer",
        ...     factory=SnykEnvironmentConfigurer,
        ...     description="Configures Snyk security scanner"
        ... )
        >>>
        >>> # Or use decorator
        >>> @registry.register_configurer(
        ...     name="custom_tool",
        ...     description="Configures custom tool"
        ... )
        ... class CustomToolConfigurer(EnvironmentConfigurer):
        ...     pass
        >>>
        >>> # Get configurer factory
        >>> factory = registry.get("snyk_configurer")
        >>> configurer = factory(name="snyk")
        >>>
        >>> # List all configurers
        >>> for metadata in registry.list():
        ...     print(f"{metadata.name}: {metadata.description}")
    """

    def _get_plugin_type_name(self) -> str:
        """Get the name of this plugin type for logging and error messages."""
        return "environment configurer"

    def _is_plugin_enabled(self, name: str) -> bool:
        """Check if configurer should be enabled based on configuration."""
        config = get_config()
        return config.is_configurer_enabled(name)

    def _get_metadata_attributes(self) -> Dict[str, str]:
        """Get attribute names for extracting configurer metadata from factories."""
        return {
            "name": "__configurer_name__",
            "description": "__configurer_description__",
            "version": "__configurer_version__",
            "author": "__configurer_author__",
            "tags": "__configurer_tags__",
            "specs": "__configurer_specs__",
        }

    def _create_metadata(
        self,
        name: str,
        factory: Callable[..., EnvironmentConfigurer],
        description: str,
        version: str,
        author: str,
        tags: List[str],
        specs: List[str],
        entry_point: Optional[str] = None,
        **kwargs,
    ) -> EnvironmentConfigurerMetadata:
        """Create configurer-specific metadata instance."""
        return EnvironmentConfigurerMetadata(
            name=name,
            factory=factory,
            description=description,
            version=version,
            author=author,
            tags=tags,
            specs=specs,
            entry_point=entry_point,
        )

    def register_configurer(
        self,
        name: str,
        description: str = "",
        version: str = "1.0.0",
        author: str = "",
        tags: Optional[List[str]] = None,
        specs: Optional[List[str]] = None,
        replace: bool = False,
    ):
        """Decorator for registering environment configurer classes.

        Args:
            name: Unique identifier for the configurer
            description: Human-readable description
            version: Version string
            author: Author or organization name
            tags: List of tags for categorization
            specs: List of spec names this configurer applies to (empty = all specs)
            replace: If True, replace existing registration

        Returns:
            Decorator function that registers the class

        Example:
            >>> registry = EnvironmentConfigurerRegistry()
            >>>
            >>> @registry.register_configurer(
            ...     name="snyk",
            ...     description="Snyk security scanner configurer",
            ...     tags=["security", "snyk"],
            ...     specs=["jvm", "python"]
            ... )
            ... class SnykConfigurer(EnvironmentConfigurer):
            ...     def configure(self, ...):
            ...         pass
        """
        return self.register_plugin(
            name=name,
            description=description,
            version=version,
            author=author,
            tags=tags,
            specs=specs,
            replace=replace,
        )

    def discover_plugins(self, group: str = "ee_bench.environment_configurers") -> int:
        """Discover and register configurers from entry points.

        This method scans for entry points in the specified group and loads
        configurer factories from them. Entry points should be defined in
        pyproject.toml or setup.py:

        [project.entry-points."ee_bench.environment_configurers"]
        snyk_configurer = "snyk_plugin.configurer:SnykEnvironmentConfigurer"

        Args:
            group: Entry point group name (default: "ee_bench.environment_configurers")

        Returns:
            Number of configurers discovered and registered
        """
        return super().discover_plugins(group)


# Global registry accessor functions created using the factory pattern
# This eliminates code duplication across multiple registry types
(
    get_global_registry,
    _register_plugin_generic,
    list_configurers,
) = create_global_registry_accessors(EnvironmentConfigurerRegistry)


def register_configurer(
    name: str,
    description: str = "",
    version: str = "1.0.0",
    author: str = "",
    tags: Optional[List[str]] = None,
    specs: Optional[List[str]] = None,
    replace: bool = False,
):
    """Decorator for registering configurers in the global registry.

    This is a convenience function that uses the global registry.

    Args:
        name: Unique identifier for the configurer
        description: Human-readable description
        version: Version string
        author: Author or organization name
        tags: List of tags for categorization
        specs: List of spec names this configurer applies to (empty = all specs)
        replace: If True, replace existing registration

    Returns:
        Decorator function

    Example:
        >>> @register_configurer(
        ...     name="my_tool",
        ...     description="My custom tool configurer",
        ...     tags=["tool"],
        ...     specs=["jvm"]
        ... )
        ... class MyToolConfigurer(EnvironmentConfigurer):
        ...     pass
    """
    registry = get_global_registry()
    return registry.register_configurer(
        name=name,
        description=description,
        version=version,
        author=author,
        tags=tags,
        specs=specs,
        replace=replace,
    )
