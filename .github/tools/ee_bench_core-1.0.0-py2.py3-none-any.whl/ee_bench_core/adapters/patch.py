"""Patch adapters for applying and collecting git patches.

This module provides unified interfaces for patch operations including
applying patches to repositories and collecting patches from workspaces.
"""

import logging
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Dict, Optional

if TYPE_CHECKING:
    from .sandbox_base import Sandbox
    from ee_bench_core.core.abc_types import EnvironmentConfig

logger = logging.getLogger(__name__)

class PatchAdapter:
    """Adapter for applying unified diff patches to working directories."""

    def __init__(self):
        """Initialize patch adapter."""

    def _normalize_patch_newlines(self, patch_content: str) -> str:
        """Normalize excessive newlines in patches.

        Some datasets contain patches with excessive blank lines between file sections,
        violating git patch format. This method fixes:
        - Multiple consecutive blank lines between patches (reduces to 1)
        - Lines with only whitespace before diff headers
        - Ensures proper spacing around diff headers

        Args:
            patch_content: Original patch content

        Returns:
            Normalized patch content with correct newline spacing

        Note:
            Git patches should have exactly one blank line between file sections.
            Excessive newlines cause "corrupt patch at line N" errors.
        """
        import re

        # First pass: Replace 3+ consecutive newlines with 2 newlines (1 blank line)
        # This handles the common case of \n\n\n\n -> \n\n
        normalized = re.sub(r"\n{3,}", "\n\n", patch_content)

        # Second pass: Clean up any lines with only whitespace before diff headers
        # Pattern: newline + line with only whitespace + one or more newlines + "diff --git"
        # Replace with: newline + newline (one blank line) + "diff --git"
        normalized = re.sub(r"\n[ \t]+\n+(?=diff --git)", "\n\n", normalized)

        # Third pass: Fix ANY content followed by blank line(s) before diff header
        # Ensure exactly one blank line before each diff header, regardless of what precedes it
        # Pattern: any non-newline content + newline + 1+ blank lines + diff header
        # Replace with: content + newline + single blank line + diff header
        normalized = re.sub(r"([^\n]+\n)\n+(?=diff --git)", r"\1\n", normalized)

        # Fourth pass: Ensure single blank line before diff headers
        # This catches any remaining cases of excessive newlines before diff headers
        # Pattern: newline + any amount of whitespace and newlines + "diff --git"
        normalized = re.sub(r"\n(?:[ \t]*\n)+(?=diff --git)", "\n\n", normalized)

        # Fifth pass: Remove trailing whitespace from context lines that precede blank lines
        # Pattern: line ending with spaces/tabs + newline + blank line
        normalized = re.sub(r"[ \t]+(\n\n)", r"\1", normalized)

        # Sixth pass: Final safety - ensure NO line that is ONLY a space exists before diff headers
        # This handles the specific case of context line " \n" immediately before "\ndiff --git"
        # Replace " \n\ndiff" with "\n\ndiff"
        normalized = re.sub(r" \n\n(?=diff --git)", "\n\n", normalized)

        return normalized

    def _deduplicate_hunks(self, patch_content: str) -> str:
        """Remove duplicate hunks from a patch while preserving valid structure.

        Some datasets contain patches with duplicate hunks (same hunk repeated multiple times).
        This method detects and removes duplicates while preserving valid patch structure.

        Key improvements:
        - Parses patch into file sections (headers + hunks)
        - Deduplicates hunks within each file section separately
        - Skips file sections where all hunks are duplicates (avoids orphaned headers)
        - Preserves original order of unique hunks
        - Preserves trailing newline if present in original

        Args:
            patch_content: Original patch content

        Returns:
            Deduplicated patch content with valid structure

        Note:
            A hunk is considered duplicate if it has the same header (@@ lines) and content.
            Only the first occurrence of each unique hunk within a file is kept.
            File sections with no unique hunks are omitted entirely to avoid invalid patches.
        """
        # Remember if original ended with newline (will be preserved)
        ends_with_newline = patch_content.endswith("\n")

        lines = patch_content.split("\n")

        # First pass: Parse patch into file sections
        file_sections = []  # List of (header_lines, hunk_list)
        current_headers = []
        current_hunks = []
        current_hunk_lines = []
        in_hunk = False

        for line in lines:
            # Start of new file section
            if line.startswith("diff --git"):
                # Save previous file section if any
                if current_headers or current_hunks:
                    if current_hunk_lines:
                        current_hunks.append(current_hunk_lines)
                    file_sections.append((current_headers, current_hunks))

                # Start new file section
                current_headers = [line]
                current_hunks = []
                current_hunk_lines = []
                in_hunk = False

            # File metadata lines
            elif not in_hunk and (
                line.startswith("---")
                or line.startswith("+++")
                or line.startswith("index ")
                or line.startswith("new file mode")
                or line.startswith("deleted file mode")
                or line.startswith("old mode")
                or line.startswith("new mode")
                or line.startswith("copy from")
                or line.startswith("copy to")
                or line.startswith("rename from")
                or line.startswith("rename to")
                or line.startswith("similarity index")
                or line.startswith("dissimilarity index")
            ):
                current_headers.append(line)

            # Start of hunk
            elif line.startswith("@@"):
                # Save previous hunk if any
                if current_hunk_lines:
                    current_hunks.append(current_hunk_lines)

                # Start new hunk
                current_hunk_lines = [line]
                in_hunk = True

            # Hunk content line
            elif in_hunk:
                # Only add non-empty lines or lines that start with diff markers
                # Skip trailing blank lines that would break hunk signatures
                if line.strip() or line.startswith(('+', '-', ' ', '\\')):
                    current_hunk_lines.append(line)
                else:
                    # This is a blank line, might be end of hunk or between hunks
                    # Don't add it to avoid breaking signatures for duplicate detection
                    # If next line starts a new section, this was inter-hunk whitespace
                    pass

            # Other lines (blank lines, comments, etc.)
            else:
                # Blank lines between file sections or at beginning/end
                if current_hunk_lines:
                    # We were in a hunk but hit a blank line - hunk might be ending
                    # Don't add the blank line; it will be inter-hunk whitespace
                    pass
                elif current_headers and not in_hunk:
                    # Blank line after headers before first hunk - ignore
                    pass
                else:
                    # Preserve other lines (e.g., patch headers)
                    if not current_headers and not current_hunks:
                        current_headers.append(line)

        # Save last file section
        if current_hunk_lines:
            current_hunks.append(current_hunk_lines)
        if current_headers or current_hunks:
            file_sections.append((current_headers, current_hunks))

        # Second pass: Deduplicate hunks within each file section and rebuild patch
        result_lines = []
        total_duplicates = 0

        for headers, hunks in file_sections:
            seen_in_file = set()
            unique_hunks = []

            # Deduplicate hunks within this file
            for hunk_lines in hunks:
                hunk_signature = "\n".join(hunk_lines)
                if hunk_signature not in seen_in_file:
                    unique_hunks.append(hunk_lines)
                    seen_in_file.add(hunk_signature)
                else:
                    total_duplicates += 1

            # Only output file section if it has at least one unique hunk
            # This prevents creating invalid patches with headers but no hunks
            if unique_hunks:
                # Add file headers
                result_lines.extend(headers)
                # Add unique hunks
                for hunk_lines in unique_hunks:
                    result_lines.extend(hunk_lines)

        if total_duplicates > 0:
            logger.warning(
                f"Removed {total_duplicates} duplicate hunk(s) from patch. "
                f"This indicates a data quality issue that should be fixed in the dataset."
            )

        result = "\n".join(result_lines)

        # Preserve trailing newline if original had one
        if ends_with_newline and not result.endswith("\n"):
            result += "\n"

        return result

    def _apply_patch_from_temp_file(
        self, sandbox: "Sandbox", patch_content: str, working_path: Path, dry_run: bool
    ) -> bool:
        """Apply patch from a temporary file (for large patches).

        This method writes the patch to a temp file in the container and applies from file.
        This avoids stdin truncation issues with Docker's socket buffer limitations.

        Args:
            sandbox: Sandbox instance
            patch_content: The patch content to apply
            working_path: Working directory path
            dry_run: Whether to do dry-run validation

        Returns:
            True on success, False on failure
        """
        # Use a temp file in /tmp
        temp_patch_path = "/tmp/ee_bench_patch_temp.patch"

        try:
            # Write patch to temp file using sandbox API
            logger.debug(
                f"Writing patch to {temp_patch_path} ({len(patch_content)} bytes)"
            )
            if not sandbox.copy_file_to_sandbox(
                patch_content, temp_patch_path, mode=0o644
            ):
                logger.error("Failed to write patch to temp file")
                return False

            logger.debug(f"Patch written to {temp_patch_path}")

            # Try applying from file with different commands
            # Adjust commands to read from file instead of stdin
            file_apply_cmds = [
                ["git", "apply", "--verbose", temp_patch_path],
                ["git", "apply", "--verbose", "--3way", temp_patch_path],
                ["patch", "--verbose", "-p1", "-i", temp_patch_path],
                ["git", "apply", "--verbose", "--reject", temp_patch_path],
                ["patch", "--verbose", "--force", "-p1", "-i", temp_patch_path],
            ]

            for apply_cmd in file_apply_cmds:
                logger.debug(f"Trying file-based patch command: {apply_cmd}")

                # Build command with dry-run flag if needed
                if dry_run:
                    if apply_cmd[0] == "git":
                        # git apply uses --check for dry-run
                        cmd = [apply_cmd[0], apply_cmd[1], "--check"] + apply_cmd[2:]
                    else:
                        # patch command uses --dry-run before -i flag
                        # Find position of -i flag
                        if "-i" in apply_cmd:
                            i_idx = apply_cmd.index("-i")
                            cmd = apply_cmd[:i_idx] + ["--dry-run"] + apply_cmd[i_idx:]
                        else:
                            # No -i flag, just add --dry-run before the filename
                            cmd = apply_cmd[:-1] + ["--dry-run", apply_cmd[-1]]
                else:
                    cmd = apply_cmd

                result = sandbox.run_command(cmd, cwd=working_path, log_prefix="     ")

                if result.returncode == 0:
                    if dry_run:
                        logger.debug("Patch validation successful (dry-run)")
                    else:
                        logger.debug("Patch applied successfully from file")
                    return True
                else:
                    logger.debug(f"Failed to apply patch from file: {apply_cmd}")

            logger.error("File-based patch application failed")
            return False

        finally:
            # Cleanup: remove temp patch file
            cleanup_result = sandbox.run_command(
                ["rm", "-f", temp_patch_path], cwd=working_path
            )
            if cleanup_result.returncode == 0:
                logger.debug(f"Cleaned up temp patch file {temp_patch_path}")
            else:
                logger.warning(
                    f"Failed to cleanup temp patch file: {cleanup_result.stderr}"
                )

    def apply_patch(
        self,
        sandbox: "Sandbox",
        patch_content: Optional[str],
        working_dir: str = "/workspace/task_project",
        dry_run: bool = True,
        env_config: Optional["EnvironmentConfig"] = None,
    ) -> bool:
        """Apply patch with optional dry-run validation.

        Args:
            sandbox: Sandbox instance
            patch_content: The unified diff patch text to apply
            working_dir: Working directory where patch will be applied
            dry_run: If True, validates with --dry-run first; if False, applies for real
            env_config: Optional EnvironmentConfig for execution context

        Returns:
            True on success, False on failure
            :param sandbox:
        """
        if not patch_content:
            logger.error("Patch content is empty")
            return True

        # Normalize patch: ensure it ends with a newline
        # Git patches must end with either a newline or "\ No newline at end of file" marker
        # Some agents produce truncated patches without proper endings
        if not patch_content.endswith("\n"):
            logger.debug(
                "Patch doesn't end with newline, adding one for proper formatting"
            )
            patch_content = patch_content + "\n"

        # # Normalize excessive newlines FIRST (data quality issue in some datasets)
        # # This ensures patch structure is clean before deduplication parses it
        # patch_content = self._normalize_patch_newlines(patch_content)
        #
        # Remove duplicate hunks (data quality issue in some datasets)
        patch_content = self._deduplicate_hunks(patch_content)

        working_path = Path(working_dir)
        patch_size = len(patch_content)
        logger.debug(
            f"Applying patch (dry_run={dry_run}, size={patch_size} bytes) to {working_path}"
        )

        # Always use file-based patch application to avoid stdin truncation issues
        # Docker socket has buffer limitations that can truncate stdin around 4-5KB
        # File-based approach is more reliable for patches of any size
        logger.debug("Using file-based patch application")
        return self._apply_patch_from_temp_file(
            sandbox, patch_content, working_path, dry_run
        )

    def apply_patch_from_file(
        self,
        sandbox: "Sandbox",
        patch_file: str,
        working_dir: str = "/workspace/task_project",
        dry_run: bool = True,
        env_config: Optional["EnvironmentConfig"] = None,
    ) -> bool:
        """Apply patch from a file path.

        Args:
            sandbox: Sandbox instance
            patch_file: Path to the patch file
            working_dir: Working directory where patch will be applied
            dry_run: Whether to validate or actually apply
            env_config: Optional EnvironmentConfig for execution context

        Returns:
            True on success; False if file missing or application fails
        """
        patch_path = Path(patch_file)
        if not patch_path.exists():
            logger.error(f"Patch file not found: {patch_file}")
            return False
        patch_content = patch_path.read_text()
        return self.apply_patch(
            sandbox, patch_content, working_dir, dry_run=dry_run, env_config=env_config
        )


class PatchCollectorAdapter:
    """Adapter for collecting git patches from container workspaces."""

    def __init__(self, working_dir: str = "/workspace/task_project"):
        """Initialize patch collector adapter.

        Args:
            working_dir: Directory where the project is located
        """
        self.working_dir = Path(working_dir)

    def collect_patch(
        self, sandbox: "Sandbox", output_dir: str, patch_name: Optional[str] = None
    ) -> str:
        """Generate git patch and save to mounted volume.

        Args:
            sandbox: Sandbox instance
            output_dir: Directory to save the patch file
            patch_name: Optional name for the patch file

        Returns:
            Path to the generated patch file

        Raises:
            RuntimeError: If not a git repository or git diff fails
        """
        if not patch_name:
            patch_name = f"solution-{datetime.now().strftime('%Y%m%d-%H%M%S')}.patch"

        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        patch_path = output_path / patch_name

        # Verify we're in a git repository
        if not (self.working_dir / ".git").exists():
            raise RuntimeError(f"Not a git repository: {self.working_dir}")

        logger.debug(f"Collecting git patch from {self.working_dir}")
        logger.debug(f"Saving patch to {patch_path}")

        # Generate patch using git diff from HEAD
        result = sandbox.run_command(["git", "diff", "HEAD"], cwd=self.working_dir)

        if result.returncode != 0:
            raise RuntimeError(f"Git diff failed with return code {result.returncode}")

        # Write patch content to file
        patch_path.write_text(result.stdout)

        # Check if patch file has content
        if patch_path.stat().st_size == 0:
            logger.warning("Generated patch is empty - no changes detected")
        else:
            logger.debug(f"Generated patch with {patch_path.stat().st_size} bytes")

        return str(patch_path)

    def collect_staged_patch(
        self, sandbox: "Sandbox", output_dir: str, patch_name: Optional[str] = None
    ) -> str:
        """Generate git patch from staged changes only.

        Args:
            output_dir: Directory to save the patch file
            patch_name: Optional name for the patch file

        Returns:
            Path to the generated patch file

        Raises:
            RuntimeError: If git diff --cached fails
        """
        if not patch_name:
            patch_name = f"staged-{datetime.now().strftime('%Y%m%d-%H%M%S')}.patch"

        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        patch_path = output_path / patch_name

        logger.debug(f"Collecting staged git patch from {self.working_dir}")

        # Generate patch using git diff --cached
        result = sandbox.run_command(["git", "diff", "--cached"], cwd=self.working_dir)

        if result.returncode != 0:
            raise RuntimeError(
                f"Git diff --cached failed with return code {result.returncode}"
            )

        # Write patch content to file
        patch_path.write_text(result.stdout)

        return str(patch_path)

    def get_git_status(self, sandbox: "Sandbox") -> Dict[str, any]:
        """Get current git status information.

        Args:
            sandbox: Sandbox instance for executing commands

        Returns:
            Dictionary with git status information including:
            - status_lines: List of status lines from git status --porcelain
            - branch: Current branch name
            - commit: Current commit hash
            - has_changes: Boolean indicating if there are uncommitted changes
            - error: Error message if git command fails
        """
        try:
            # Get status summary
            status_result = sandbox.run_command(
                ["git", "status", "--porcelain"], cwd=self.working_dir
            )

            # Get current branch
            branch_result = sandbox.run_command(
                ["git", "branch", "--show-current"], cwd=self.working_dir
            )

            # Get current commit hash
            commit_result = sandbox.run_command(
                ["git", "rev-parse", "HEAD"], cwd=self.working_dir
            )

            return {
                "status_lines": status_result.stdout.strip().split("\n")
                if status_result.stdout.strip()
                else [],
                "branch": branch_result.stdout.strip(),
                "commit": commit_result.stdout.strip(),
                "has_changes": bool(status_result.stdout.strip()),
            }
        except Exception as e:
            logger.error(f"Failed to get git status: {e}")
            return {"error": str(e)}
