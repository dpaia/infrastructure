"""Local Gradle configurer for verifying Gradle installation on the host system."""

import logging
import re
import subprocess
from pathlib import Path

from ee_bench_core.adapters.local import LocalEnvironmentConfig
from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig
from ee_bench_core.core.errors import EnvironmentError

from ee_bench_jvm_spec.jvm.base_local_build_tool_configurer import (
    BaseLocalBuildToolConfigurer,
)
from ee_bench_jvm_spec.jvm.jvm_config import BuildSystem
from ee_bench_jvm_spec.jvm.jvm_local_env_config import JvmCodeLocalEnvironmentConfig

from .gradle_local_env_config import GradleLocalEnvironmentConfig

logger = logging.getLogger(__name__)


class LocalGradleConfigurer(BaseLocalBuildToolConfigurer):
    """Configurer that verifies Gradle installation on local system.

    This configurer checks that Gradle is installed on the host system
    and sets GRADLE_HOME in env_vars if not already set.

    For local execution of Gradle projects, the user must have Gradle installed.
    This configurer verifies the installation and sets up environment variables.

    Metadata:
        name: local_gradle
        priority: 150 (runs after local_jvm and local_task_setup)
        dependencies: after local_jvm, local_task_setup
        specs: ["jvm"]
    """

    __configurer_name__ = "local_gradle"
    __configurer_description__ = "Verifies local Gradle installation"
    __configurer_version__ = "1.0.0"
    __configurer_specs__ = ["jvm"]

    @property
    def build_system(self):
        """Return the BuildSystem enum for Gradle."""
        return BuildSystem.GRADLE

    @property
    def tool_name(self) -> str:
        """Return tool name."""
        return "gradle"

    def get_download_url(self) -> str:
        """Return Gradle download URL."""
        return "https://gradle.org/install/"

    def parse_version_from_output(self, version_output: str) -> str | None:
        """Parse Gradle version from output.

        Args:
            version_output: Output from gradle -version

        Returns:
            Version string or None
        """
        version_match = re.search(r"Gradle (\S+)", version_output)
        return version_match.group(1) if version_match else None

    def check_for_wrapper(
        self, env_config: LocalEnvironmentConfig, config: DatasetConfig
    ) -> tuple[str, str] | None:
        """Check for Gradle wrapper (gradlew) in project.

        Args:
            env_config: Environment configuration
            config: Dataset configuration

        Returns:
            Tuple of (wrapper_path, version) if found, None otherwise
        """
        workspace_dir = Path(env_config.workspace_dir).resolve()
        project_dir = workspace_dir / "task_project"
        gradlew_path = project_dir / "gradlew"

        if not gradlew_path.exists():
            return None

        # Gradle wrapper found
        logger.info(f"Found Gradle wrapper at {gradlew_path}")

        # Make sure it's executable
        gradlew_path.chmod(0o755)

        # Get Gradle version from wrapper
        try:
            result = subprocess.run(
                [str(gradlew_path), "-version"],
                cwd=project_dir,
                capture_output=True,
                text=True,
                check=True,
                timeout=30,
            )
            version_output = result.stdout
            logger.debug(f"Gradle wrapper version output: {version_output}")

            # Parse version
            version = self.parse_version_from_output(version_output)
            if not version:
                version = "wrapper"

            logger.info(f"Using Gradle wrapper version: {version}")
            return (str(gradlew_path), version)

        except subprocess.CalledProcessError as e:
            logger.warning(f"Gradle wrapper found but failed to execute: {e.stderr}")
            logger.info("Falling back to checking for system Gradle installation")
        except subprocess.TimeoutExpired:
            logger.warning("Gradle wrapper execution timed out")
            logger.info("Falling back to checking for system Gradle installation")

        return None

    def configure(
        self,
        spec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        **kwargs,
    ) -> EnvironmentConfig:
        """Verify Gradle installation and upgrade to GradleLocalEnvironmentConfig.

        Args:
            spec: Evaluation specification
            env_config: Environment configuration (should be JvmCodeLocalEnvironmentConfig)
            config: Dataset configuration
            **kwargs: Additional parameters

        Returns:
            GradleLocalEnvironmentConfig with Gradle-specific fields populated

        Raises:
            EnvironmentError: If Gradle is not installed
        """
        if not isinstance(env_config, LocalEnvironmentConfig):
            return env_config

        logger.info("Verifying local Gradle installation")

        # Upgrade to GradleLocalEnvironmentConfig if not already
        if not isinstance(env_config, GradleLocalEnvironmentConfig):
            if isinstance(env_config, JvmCodeLocalEnvironmentConfig):
                # Upgrade from JvmCodeLocalEnvironmentConfig
                env_config = GradleLocalEnvironmentConfig(
                    workspace_dir=env_config.workspace_dir,
                    env_vars=env_config.env_vars.copy(),
                    repo=env_config.repo,
                    base_commit=env_config.base_commit,
                    project_dir=env_config.project_dir,
                    language=env_config.language,
                    java_home=env_config.java_home,
                    java_version=env_config.java_version,
                    maven_home=env_config.maven_home,
                    maven_version=env_config.maven_version,
                    gradle_home=env_config.gradle_home,
                    gradle_version=env_config.gradle_version,
                    build_system=env_config.build_system,
                )
                logger.debug(
                    "Upgraded JvmCodeLocalEnvironmentConfig to GradleLocalEnvironmentConfig"
                )
            else:
                logger.warning(
                    f"Expected JvmCodeLocalEnvironmentConfig, got {type(env_config).__name__}"
                )
                return env_config

        # Check for wrapper first
        wrapper_result = self.check_for_wrapper(env_config, config)
        if wrapper_result:
            wrapper_path, version = wrapper_result
            logger.info(f"Using Gradle wrapper: {wrapper_path}")

            # Set Gradle-specific fields
            env_config.gradle_wrapper_path = Path(wrapper_path)
            env_config.gradle_version = version
            env_config.use_wrapper = True

            # Also set env_vars for backward compatibility
            env_config.env_vars["GRADLE_WRAPPER"] = wrapper_path
            env_config.env_vars["GRADLE_VERSION"] = version

            logger.info(f"Local Gradle configuration complete: wrapper {version}")
            return env_config

        # No wrapper - check for system installation
        logger.info("No Gradle wrapper found, checking for system Gradle installation")

        import shutil

        tool_path = shutil.which("gradle")
        if not tool_path:
            raise EnvironmentError(
                "Gradle not found in PATH and no wrapper in project.\n"
                "Please install Gradle or ensure the project includes a Gradle wrapper.\n"
                f"Download from: {self.get_download_url()}"
            )

        # Get version
        try:
            result = subprocess.run(
                ["gradle", "-version"],
                capture_output=True,
                text=True,
                check=True,
            )
            version_output = result.stdout
            logger.debug(f"Gradle version output: {version_output}")
        except subprocess.CalledProcessError as e:
            raise EnvironmentError(f"Failed to get Gradle version: {e}")

        # Parse version
        version = self.parse_version_from_output(version_output)
        if not version:
            logger.warning(f"Could not parse Gradle version from: {version_output}")
            version = "unknown"

        logger.info(f"Found Gradle version: {version} at {tool_path}")

        # Find GRADLE_HOME
        gradle_home = env_config.env_vars.get("GRADLE_HOME")
        if not gradle_home:
            gradle_home = self.find_tool_home(tool_path, version_output)
            if gradle_home:
                logger.info(f"Detected GRADLE_HOME: {gradle_home}")
            else:
                logger.warning("Could not automatically detect GRADLE_HOME")

        # Set Gradle-specific fields
        if gradle_home:
            env_config.gradle_home = Path(gradle_home)
            env_config.env_vars["GRADLE_HOME"] = gradle_home

        env_config.gradle_version = version
        env_config.env_vars["GRADLE_VERSION"] = version
        env_config.use_wrapper = False

        logger.info(f"Local Gradle configuration complete: Gradle {version}")

        return env_config
