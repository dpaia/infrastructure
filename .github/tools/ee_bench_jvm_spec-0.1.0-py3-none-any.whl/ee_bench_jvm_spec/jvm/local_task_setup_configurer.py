"""Local task setup configurer for cloning repositories to local workspace."""

import json
import logging
import subprocess
from pathlib import Path

from ee_bench_code_spec.config import CodeBenchmarkConfig
from ee_bench_code_spec.local_env_config import CodeLocalEnvironmentConfig
from ee_bench_core.core import DependencyPosition
from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig
from ee_bench_core.core.errors import EnvironmentError
from ee_bench_core.core.eval import EnvironmentConfigurer

logger = logging.getLogger(__name__)


class LocalTaskSetupConfigurer(EnvironmentConfigurer):
    """Configurer that sets up task workspace with cloned repository.

    This configurer is the local equivalent of TaskImageConfigurer.
    It clones the repository to the local workspace, checks out the base
    commit, and writes task configuration files.

    For local execution, repositories are cloned directly to the workspace
    directory on the host system.

    Metadata:
        name: local_task_setup
        priority: 100 (runs after build tool configurers)
        dependencies: after local_maven or local_gradle
        specs: ["jvm"]
    """

    __configurer_name__ = "local_task_setup"
    __configurer_description__ = "Clones repository and sets up local task workspace"
    __configurer_version__ = "1.0.0"
    __configurer_specs__ = ["jvm"]

    def __init__(self, **kwargs):
        """Initialize local task setup configurer.

        Args:
            **kwargs: Additional parameters
        """
        pass

    @property
    def name(self) -> str:
        """Return configurer name."""
        return "local_task_setup"

    @property
    def description(self) -> str:
        """Return configurer description."""
        return "Clones repository and sets up local task workspace"

    @property
    def specs(self) -> list[str] | None:
        """Return specs this configurer applies to."""
        return ["jvm"]

    @property
    def dependencies(self) -> list[str] | DependencyPosition | None:
        """Return dependency specification."""
        # Priority 100 ensures this runs after build tool configurers (priority 50)
        # and local_jvm (priority 10)
        return DependencyPosition(before=["task_image"], priority=100)

    def should_configure(
        self,
        spec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        **kwargs,
    ) -> tuple[bool, str | None]:
        """Check if this configurer should run.

        Only runs for local environments with code benchmark tasks.

        Args:
            spec: Evaluation specification
            env_config: Environment configuration
            config: Dataset configuration
            **kwargs: Additional parameters

        Returns:
            Tuple of (should_configure, reason)
        """
        # Only configure local environments
        if not isinstance(env_config, CodeLocalEnvironmentConfig):
            return (
                False,
                f"Not a local environment (type: {type(env_config).__name__})",
            )

        # Only for code benchmark tasks
        if not isinstance(config, CodeBenchmarkConfig):
            return False, "Not a code benchmark task"

        return True, None

    def configure(
        self,
        spec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        **kwargs,
    ) -> EnvironmentConfig:
        """Clone repository and set up local workspace.

        Args:
            spec: Evaluation specification
            env_config: Environment configuration (CodeLocalEnvironmentConfig)
            config: Dataset configuration (CodeBenchmarkConfig)
            **kwargs: Additional parameters

        Returns:
            Updated EnvironmentConfig

        Raises:
            EnvironmentError: If repository cloning or setup fails
        """
        if not isinstance(env_config, CodeLocalEnvironmentConfig):
            return env_config

        if not isinstance(config, CodeBenchmarkConfig):
            return env_config

        logger.info(f"Setting up local workspace for {config.instance_id}")

        workspace_dir = env_config.workspace_dir
        project_dir_name = kwargs.get("project_dir", "task_project")
        project_path = workspace_dir / project_dir_name

        # Set project_dir in config (used by project_path property)
        env_config.project_dir = project_dir_name

        # Set repo and base_commit from dataset config
        env_config.repo = config.repo
        env_config.base_commit = config.base_commit

        # Check if repository already exists
        force = kwargs.get("force_rebuild", False)
        if project_path.exists() and not force:
            logger.info(f"Repository already exists at {project_path}, skipping clone")
        else:
            # Clone repository
            self._clone_repository(config, project_path, force)

        # Checkout base commit
        self._checkout_commit(config, project_path)

        # Write task configuration files
        self._write_task_files(config, workspace_dir)

        logger.info(f"Local workspace setup complete: {project_path}")

        return env_config

    def _clone_repository(
        self, config: CodeBenchmarkConfig, project_path: Path, force: bool = False
    ) -> None:
        """Clone the repository to project_path.

        Args:
            config: Code benchmark configuration
            project_path: Path where to clone the repository
            force: Whether to remove existing directory first

        Raises:
            EnvironmentError: If git clone fails
        """
        # Remove existing directory if force=True
        if force and project_path.exists():
            logger.info(f"Removing existing directory: {project_path}")
            import shutil

            shutil.rmtree(project_path)

        # Ensure parent directory exists
        project_path.parent.mkdir(parents=True, exist_ok=True)

        # Build repository URL
        repo = config.repo if config.repo.endswith(".git") else f"{config.repo}.git"
        repo_url = f"https://github.com/{repo}"

        logger.info(f"Cloning repository: {repo_url} to {project_path}")

        try:
            subprocess.run(
                ["git", "clone", repo_url, str(project_path)],
                check=True,
                capture_output=True,
                text=True,
            )
            logger.info(f"Successfully cloned repository to {project_path}")
        except subprocess.CalledProcessError as e:
            logger.error(f"Git clone failed: {e.stderr}")
            raise EnvironmentError(f"Failed to clone repository {repo_url}: {e.stderr}") from e

    def _checkout_commit(self, config: CodeBenchmarkConfig, project_path: Path) -> None:
        """Checkout the base commit.

        Args:
            config: Code benchmark configuration
            project_path: Path to the cloned repository

        Raises:
            EnvironmentError: If git checkout fails
        """
        logger.info(f"Checking out commit: {config.base_commit}")

        try:
            subprocess.run(
                ["git", "checkout", config.base_commit],
                cwd=project_path,
                check=True,
                capture_output=True,
                text=True,
            )
            logger.info(f"Successfully checked out {config.base_commit}")
        except subprocess.CalledProcessError as e:
            logger.error(f"Git checkout failed: {e.stderr}")
            raise EnvironmentError(
                f"Failed to checkout commit {config.base_commit}: {e.stderr}"
            ) from e

    def _write_task_files(self, config: CodeBenchmarkConfig, workspace_dir: Path) -> None:
        """Write task configuration files to workspace.

        Args:
            config: Code benchmark configuration
            workspace_dir: Workspace directory path

        Raises:
            EnvironmentError: If writing files fails
        """
        try:
            # Get raw instance data if available, otherwise create from config
            task_config_data = (
                config._raw_instance
                if hasattr(config, "_raw_instance") and config._raw_instance
                else config.to_dict()
            )

            # Write task-config.json
            # task_config_file = workspace_dir / "task-config.json"
            # with open(task_config_file, "w") as f:
            #     json.dump([task_config_data], f, indent=2)
            # logger.debug(f"Wrote task configuration to {task_config_file}")

            # Write task.txt with problem statement
            # task_file = workspace_dir / "task.txt"
            # with open(task_file, "w") as f:
            #     f.write(config.problem_statement)
            # logger.debug(f"Wrote task description to {task_file}")

        except Exception as e:
            logger.error(f"Failed to write task files: {e}")
            raise EnvironmentError(f"Failed to write task files: {e}") from e
