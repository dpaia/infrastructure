"""Code Specific predictions collector for extracting predictions from environments."""

from __future__ import annotations

import logging
from typing import Optional, TYPE_CHECKING

from ee_bench_core.adapters.git import GitAdapter
from ee_bench_core.core.predictions_collector import PredictionsCollector
from ee_bench_core.core.models import EnvironmentConfig, PredictionResult
from ee_bench_code_spec.config import CodeBenchmarkConfig

if TYPE_CHECKING:
    from ee_bench_core.core.models import DatasetConfig

logger = logging.getLogger(__name__)


class CodePredictionsCollector(PredictionsCollector):
    """Code implementation of PredictionsCollector using git diff.

    Collects predictions by running git diff in the environment's project directory.
    Supports both Docker and local execution environments via GitAdapter.
    """

    def __init__(self, git_adapter: Optional[GitAdapter] = None, **kwargs):
        """Initialize predictions collector.

        Args:
            git_adapter: Optional GitAdapter instance to use for git operations.
                        If not provided, a default GitAdapter is created.
            **kwargs: Additional keyword arguments (ignored for compatibility)
        """
        self.git_adapter = git_adapter or GitAdapter()

    def collect(
        self,
        instance_id: str,
        sandbox: "Sandbox",
        config: "DatasetConfig",
        timeout: Optional[int] = None,
        **kwargs,
    ) -> PredictionResult:
        """Collect prediction by running git diff in the environment.

        Collects all changes including untracked files, excluding build artifacts.
        Respects .gitignore patterns automatically.

        Args:
            instance_id: Unique identifier for the task instance
            sandbox: Sandbox containing the environment configuration
            config: Dataset configuration for the task instance.
                   Contains task-specific information like base_commit, test commands, etc.
            timeout: Optional timeout in seconds
            **kwargs: Additional parameters passed to GitAdapter including:
                     - base_commit: Base commit to compare against (e.g., "HEAD", "abc123").
                                   If not provided, uses config.base_commit or compares against HEAD.

        Returns:
            PredictionResult with instance_id, prediction (git diff output), and status
        """
        try:
            # Determine base_commit from CodeBenchmarkConfig

            # Extract base_commit from kwargs to avoid duplicate keyword argument
            base_commit = None

            # Only determine from config if not explicitly provided
            if isinstance(config, CodeBenchmarkConfig):
                base_commit = config.base_commit
                logger.debug(
                    f"Using base_commit from CodeBenchmarkConfig: {config.base_commit}"
                )

            # Use GitAdapter to get diff (passes env_config to extract project path and container_id)
            prediction = self.git_adapter.get_diff(
                sandbox=sandbox,
                timeout=timeout,
                base_commit=base_commit,
                **kwargs,
            )

            # Don't set explicit status - let PredictionResult.__post_init__ handle it:
            # - If prediction is empty, status will auto-set to SKIPPED
            # - If prediction has content, status remains None (can be set later if needed)
            return PredictionResult(
                instance_id=instance_id,
                prediction=prediction,
            )
        except Exception as e:
            logger.error(f"Failed to collect prediction for {instance_id}: {e}")
            raise
