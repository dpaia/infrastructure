"""JVM local environment initializer configurer."""

import logging
from pathlib import Path
from typing import TYPE_CHECKING

from ee_bench_core.core.eval import DependencyPosition, EnvironmentConfigurer

if TYPE_CHECKING:
    from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig
    from ee_bench_core.core.base_spec import BaseEvalSpec

from .jvm_local_env_config import JvmCodeLocalEnvironmentConfig

logger = logging.getLogger(__name__)


class JvmLocalEnvironmentInitializer(EnvironmentConfigurer):
    """Creates initial JvmCodeLocalEnvironmentConfig for JVM local sandbox mode.

    This configurer runs FIRST (priority=-1000) and creates the JVM-specific
    local environment config instance that subsequent configurers will enhance.

    It only runs when --sandbox local is specified for JVM specs.

    Metadata:
        name: jvm_local_environment_initializer
        priority: -1000 (runs first)
        specs: ["jvm"]
    """

    __configurer_name__ = "jvm_local_environment_initializer"
    __configurer_description__ = "Creates initial JvmCodeLocalEnvironmentConfig"
    __configurer_version__ = "1.0.0"
    __configurer_specs__ = ["jvm"]

    def __init__(self, workspace_base_dir: Path | None = None, **kwargs):
        """Initialize JVM local environment initializer.

        Args:
            workspace_base_dir: Base directory for workspaces (default: ./workspaces)
            **kwargs: Additional parameters
        """
        self.workspace_base_dir = workspace_base_dir or Path("./workspaces")

    @property
    def name(self) -> str:
        """Return configurer name."""
        return "jvm_local_environment_initializer"

    @property
    def description(self) -> str:
        """Return configurer description."""
        return "Creates initial JvmCodeLocalEnvironmentConfig for JVM local sandbox"

    @property
    def specs(self) -> list[str] | None:
        """Return specs this configurer applies to."""
        return ["jvm"]

    @property
    def dependencies(self) -> list[str] | DependencyPosition | None:
        """Return dependency specification.

        Returns:
            DependencyPosition with highest priority (lowest number) to run first
        """
        # Run FIRST - high priority (just after docker_environment_initializer at -1000)
        # Priority -1050 places it near docker_environment_initializer (-1000)
        return DependencyPosition(priority=-1050)

    def should_configure(
        self,
        spec: "BaseEvalSpec",
        env_config: "EnvironmentConfig",
        config: "DatasetConfig",
        **kwargs,
    ) -> tuple[bool, str | None]:
        """Check if JVM local environment should be initialized.

        Args:
            spec: Evaluation specification
            env_config: Environment configuration (will be None initially)
            config: Dataset configuration
            **kwargs: Additional parameters including 'sandbox'

        Returns:
            Tuple of (should_configure, reason)
        """
        # Check sandbox parameter
        sandbox = kwargs.get("sandbox", "docker")

        if sandbox != "local":
            return False, f"Sandbox is '{sandbox}', not 'local'"

        # Don't re-initialize if already created
        if isinstance(env_config, JvmCodeLocalEnvironmentConfig):
            return False, "JvmCodeLocalEnvironmentConfig already initialized"

        return True, None

    def configure(
        self,
        spec: "BaseEvalSpec",
        env_config: "EnvironmentConfig",
        config: "DatasetConfig",
        **kwargs,
    ) -> "EnvironmentConfig":
        """Create initial JvmCodeLocalEnvironmentConfig.

        Args:
            spec: Evaluation specification
            env_config: Existing environment config (may be None)
            config: Dataset configuration
            **kwargs: Additional parameters

        Returns:
            New JvmCodeLocalEnvironmentConfig instance
        """
        logger.info(f"Initializing JVM local environment for {config.instance_id}")

        # Create workspace directory path
        workspace_dir = self.workspace_base_dir / config.instance_id
        workspace_dir.mkdir(parents=True, exist_ok=True)

        # Create initial JVM local environment config
        # Subsequent configurers will populate:
        # - java_home, java_version (LocalJvmConfigurer)
        # - maven_home, maven_version OR gradle_home, gradle_version (build tool configurers)
        # - env_vars with runtime environment variables
        jvm_config = JvmCodeLocalEnvironmentConfig(
            workspace_dir=workspace_dir,
            env_vars={},  # Will be populated by subsequent configurers
            language="java",  # JVM spec is for Java
        )

        logger.debug(f"Created JvmCodeLocalEnvironmentConfig: {jvm_config.to_dict()}")
        logger.info(f"JVM local workspace created at: {workspace_dir}")

        return jvm_config
