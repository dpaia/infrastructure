"""ee_bench.maven - Maven build-system provider for ee_bench.generator."""

from ee_bench.maven.provider import MavenProvider

__version__ = "0.1.0"

__all__ = ["MavenProvider"]
