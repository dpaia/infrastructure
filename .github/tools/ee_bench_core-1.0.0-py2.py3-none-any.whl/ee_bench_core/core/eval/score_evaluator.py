"""Score calculation and aggregation for evaluation results.

This module provides the ScoreEvaluator interface and BaseScoreEvaluator implementation
for calculating normalized scores across multiple evaluators.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from .evaluator import Evaluator, EvaluatorResult, EvaluatorStatus

if TYPE_CHECKING:
    from ..abc_types import DatasetConfig, EnvironmentConfig
    from .evaluation_context import EvaluationContext


@dataclass
class ScoreBreakdown:
    """Breakdown of score from a single evaluator.

    Attributes:
        evaluator_name: Name of the evaluator
        score: Score awarded by this evaluator
        max_score: Maximum score this evaluator could award
        percentage: Percentage score (score/max_score * 100)
        breakdown: Human-readable explanation
        status: Evaluator status
    """

    evaluator_name: str
    score: float
    max_score: float
    percentage: float
    breakdown: Optional[str] = None
    status: EvaluatorStatus = EvaluatorStatus.SUCCESS

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = {
            "evaluator_name": self.evaluator_name,
            "score": self.score,
            "max_score": self.max_score,
            "percentage": self.percentage,
            "status": self.status.value,
        }
        if self.breakdown:
            result["breakdown"] = self.breakdown
        return result


@dataclass
class FinalScore:
    """Final aggregated score across all evaluators.

    Attributes:
        total_score: Sum of all evaluator scores
        total_max_score: Sum of all max scores from scoring evaluators
        normalized_score: Normalized score from 0 to 100
        breakdown: List of score breakdowns from individual evaluators
        num_evaluators: Total number of evaluators that contributed to score
        num_skipped: Number of evaluators that were skipped
        num_failed: Number of evaluators that failed
    """

    total_score: float
    total_max_score: float
    normalized_score: float
    breakdown: List[ScoreBreakdown] = field(default_factory=list)
    num_evaluators: int = 0
    num_skipped: int = 0
    num_failed: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "total_score": self.total_score,
            "total_max_score": self.total_max_score,
            "normalized_score": self.normalized_score,
            "num_evaluators": self.num_evaluators,
            "num_skipped": self.num_skipped,
            "num_failed": self.num_failed,
            "breakdown": [b.to_dict() for b in self.breakdown],
        }

    def __str__(self) -> str:
        """Human-readable score summary."""
        parts = [
            f"Score: {self.normalized_score:.1f}/100",
            f"({self.total_score:.1f}/{self.total_max_score:.1f})",
        ]

        if self.num_failed > 0:
            parts.append(f"{self.num_failed} failed")
        if self.num_skipped > 0:
            parts.append(f"{self.num_skipped} skipped")

        summary = " - ".join(parts)

        # Add breakdown details
        if self.breakdown:
            breakdown_lines = ["", "Breakdown:"]
            for b in self.breakdown:
                status_icon = {
                    EvaluatorStatus.SUCCESS: "✓",
                    EvaluatorStatus.FAILED: "✗",
                    EvaluatorStatus.SKIPPED: "⊘",
                    EvaluatorStatus.ERROR: "!",
                }[b.status]

                line = f"  {status_icon} {b.evaluator_name}: {b.score:.1f}/{b.max_score:.1f}"
                if b.breakdown:
                    line += f" - {b.breakdown}"
                breakdown_lines.append(line)

            summary += "\n" + "\n".join(breakdown_lines)

        return summary


class ScoreEvaluator(ABC):
    """Abstract base class for score calculation.

    ScoreEvaluators aggregate scores from multiple evaluators and compute
    a final normalized score (0-100).
    """

    @abstractmethod
    def calculate_score(
        self,
        evaluators: List[Evaluator],
        results: List[EvaluatorResult],
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        context: EvaluationContext,
    ) -> FinalScore:
        """Calculate final score from evaluator results.

        Args:
            evaluators: List of evaluators that were run
            results: List of results from evaluators
            env_config: Environment configuration
            config: Dataset configuration
            context: Evaluation context with shared data

        Returns:
            FinalScore with aggregated score and breakdown
        """
        pass


class BaseScoreEvaluator(ScoreEvaluator):
    """Default implementation of score calculation.

    This evaluator:
    1. Collects scores from all evaluators with max_score > 0
    2. Skips evaluators with status SKIPPED
    3. Calculates normalized score: (sum(scores) / sum(max_scores)) * 100
    4. Provides detailed breakdown of individual evaluator scores
    """

    def calculate_score(
        self,
        evaluators: List[Evaluator],
        results: List[EvaluatorResult],
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        context: EvaluationContext,
    ) -> FinalScore:
        """Calculate final score from evaluator results.

        Args:
            evaluators: List of evaluators that were run
            results: List of results from evaluators
            env_config: Environment configuration
            config: Dataset configuration
            context: Evaluation context

        Returns:
            FinalScore with normalized score and breakdown
        """
        # Create mapping from evaluator name to evaluator instance
        evaluator_map = {e.name: e for e in evaluators}

        total_score = 0.0
        total_max_score = 0.0
        breakdown = []
        num_evaluators = 0
        num_skipped = 0
        num_failed = 0

        for result in results:
            evaluator = evaluator_map.get(result.evaluator_name)
            if not evaluator:
                continue

            # Skip if evaluator doesn't contribute to score (max_score == 0)
            if evaluator.max_score == 0:
                continue

            # Count status
            if result.status == EvaluatorStatus.SKIPPED:
                num_skipped += 1
                # Don't include skipped evaluators in score calculation
                continue
            elif result.status in (EvaluatorStatus.FAILED, EvaluatorStatus.ERROR):
                num_failed += 1

            # Skip if no score breakdown provided
            if result.score_breakdown is None:
                continue

            # Include in score calculation
            num_evaluators += 1
            score = result.score
            max_score = evaluator.max_score

            total_score += score
            total_max_score += max_score

            # Calculate percentage for this evaluator
            percentage = (score / max_score * 100) if max_score > 0 else 0.0

            breakdown.append(
                ScoreBreakdown(
                    evaluator_name=result.evaluator_name,
                    score=score,
                    max_score=max_score,
                    percentage=percentage,
                    breakdown=result.score_breakdown,
                    status=result.status,
                )
            )

        # Calculate normalized score
        normalized_score = (
            (total_score / total_max_score * 100) if total_max_score > 0 else 0.0
        )

        return FinalScore(
            total_score=total_score,
            total_max_score=total_max_score,
            normalized_score=normalized_score,
            breakdown=breakdown,
            num_evaluators=num_evaluators,
            num_skipped=num_skipped,
            num_failed=num_failed,
        )
