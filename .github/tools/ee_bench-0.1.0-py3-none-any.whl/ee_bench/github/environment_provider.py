"""EEBenchEnvironmentProvider — fetches .ee-bench/<type>/ files from GitHub."""

from __future__ import annotations

import base64
import json
import logging
from typing import Any

from ee_bench.generator import Provider
from ee_bench.generator.errors import ProviderError

logger = logging.getLogger(__name__)

_CODEGEN_BASE = ".ee-bench/codegen"

_EVAL_PREFIX = ".ee-bench/codegen/eval/"
_METADATA_PATH = ".ee-bench/codegen/metadata.json"
_DOCKERFILE_PATH = ".ee-bench/codegen/environment/Dockerfile"
_DOCKERFILE_LEGACY_PATH = ".ee-bench/codegen/Dockerfile"


def _type_paths(benchmark_type: str) -> dict[str, str]:
    """Return path templates for a given benchmark type."""
    base = f".ee-bench/{benchmark_type}"
    return {
        "base": base,
        "eval_prefix": f"{base}/eval/",
        "metadata": f"{base}/metadata.json",
        "dockerfile": f"{base}/environment/Dockerfile",
        "dockerfile_legacy": f"{base}/Dockerfile",
    }


def _parse_repo_url(repo_url: str) -> tuple[str, str]:
    """Parse 'https://github.com/owner/repo[.git]' -> (owner, repo_name)."""
    url = repo_url.rstrip("/")
    if url.endswith(".git"):
        url = url[:-4]
    for prefix in ("https://github.com/", "http://github.com/", "git@github.com:"):
        if url.startswith(prefix):
            url = url[len(prefix):]
            break
    parts = url.split("/", 1)
    if len(parts) == 2:
        return parts[0], parts[1]
    return "", url


def _is_inline(value: str) -> bool:
    """True if value is inline content (not a path or URL)."""
    if "\n" in value:
        return True
    for prefix in ("#!", "FROM ", "{"):
        if value.startswith(prefix):
            return True
    return False


def _is_url(value: str) -> bool:
    return value.startswith("http://") or value.startswith("https://")


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge *override* into *base*. Override values win for non-dict leaves."""
    result = dict(base)
    for key, val in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(val, dict):
            result[key] = _deep_merge(result[key], val)
        else:
            result[key] = val
    return result


def _test_list_has_values(value: Any) -> bool:
    """Return True when a metadata test-list value contains at least one test."""
    if value in (None, ""):
        return False
    if isinstance(value, list):
        return bool(value)
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
        except (json.JSONDecodeError, ValueError):
            return bool(value.strip())
        if isinstance(parsed, list):
            return bool(parsed)
        return bool(parsed)
    return bool(value)


def _expected_has_tests(value: Any) -> bool:
    """Return True when an expected block contains any expected test list."""
    if not isinstance(value, dict):
        return False
    for key in (
        "fail_to_pass",
        "FAIL_TO_PASS",
        "pass_to_pass",
        "PASS_TO_PASS",
        "fail_to_fail",
        "FAIL_TO_FAIL",
    ):
        if _test_list_has_values(value.get(key)):
            return True
    return False


class EEBenchEnvironmentProvider(Provider):
    """Enrichment provider that fetches .ee-bench/<type>/ files from GitHub.

    Resolves Dockerfiles, eval scripts, and build context files using a
    two-phase process:

    1. Build datapoint context from item fields (repo_url, base_commit,
       head_commit) plus computed values (owner, repo_name).
    2. Fetch files from GitHub in priority order, render as Jinja2 templates.
    """

    def __init__(self, **kwargs: Any) -> None:
        self._client: Any = None
        self._benchmark_type: str = "codegen"
        self._paths: dict[str, str] = _type_paths("codegen")
        self._file_cache: dict[tuple[str, str, str, str], str | None] = {}
        self._url_cache: dict[str, str] = {}
        self._resolved: dict[int, dict[str, Any]] = {}
        self._default_branch_cache: dict[str, str] = {}
        if kwargs:
            self.prepare(**kwargs)

    def prepare(self, **options: Any) -> None:
        from ee_bench.github.api import GitHubAPIClient

        token = options.get("github_token") or options.get("token")
        self._benchmark_type = options.get("benchmark_type", "codegen")
        self._paths = _type_paths(self._benchmark_type)
        self._client = GitHubAPIClient(token=token)
        self._file_cache = {}
        self._url_cache = {}
        self._resolved = {}
        self._default_branch_cache = {}

    def provide(self, item=None, *, repo_url="", base_commit="", head_commit="", **kwargs) -> dict[str, Any]:
        """Resolve environment files for a single item.

        Args:
            item: Item dict with repo_url, base_commit, head_commit fields.
            repo_url: Override repo URL.
            base_commit: Override base commit.
            head_commit: Override head commit.
            **kwargs: Additional context fields merged into item.

        Returns:
            Dict with environment_files, eval, ee_bench_config, project_root, etc.
        """
        if self._client is None:
            raise ProviderError("Provider not prepared. Call prepare() first.")

        merged = dict(item or {})
        if repo_url:
            merged["repo_url"] = repo_url
        if base_commit:
            merged["base_commit"] = base_commit
        if head_commit:
            merged["head_commit"] = head_commit
        merged.update(kwargs)

        try:
            result = self._resolve(merged)
            logger.info(
                "EEBenchEnvironmentProvider.provide result:\n%s",
                json.dumps(result, indent=2, default=str, sort_keys=True),
            )
            return result
        except Exception as exc:
            logger.warning("EEBenchEnvironmentProvider failed to resolve: %s", exc)
            return {}

    # ------------------------------------------------------------------
    # Core resolution
    # ------------------------------------------------------------------

    def _resolve(self, item: dict[str, Any]) -> dict[str, Any]:
        """Two-phase resolution for a single datapoint item."""
        repo_url = item.get("repo_url", "")
        base_commit = item.get("base_commit", "")
        head_commit = item.get("head_commit", "") or base_commit

        owner, repo_name = _parse_repo_url(repo_url)
        if not owner or not repo_name:
            logger.warning("Cannot parse owner/repo from repo_url: %s", repo_url)
            return {}

        # --- Phase 1: Build rendering context ---
        ctx: dict[str, Any] = dict(item)
        ctx["owner"] = owner
        ctx["repo_name"] = repo_name
        ctx["repo"] = f"{owner}/{repo_name}"

        default_branch = self._get_default_branch(owner, repo_name)

        # --- Fetch and merge metadata.json from main + PR branch ---
        ee_bench_config: dict[str, Any] = {}

        # Base: metadata.json from default branch
        if default_branch:
            base_meta_raw = self._fetch_file(owner, repo_name, self._paths["metadata"], default_branch)
            if base_meta_raw is not None:
                try:
                    rendered = self._render_template(base_meta_raw, ctx)
                    ee_bench_config = json.loads(rendered)
                except Exception as exc:
                    logger.warning("Failed to parse metadata.json from %s: %s", default_branch, exc)

        # Override: metadata.json from PR branch (deep-merged, PR wins)
        if head_commit:
            pr_meta_raw = self._fetch_file(owner, repo_name, self._paths["metadata"], head_commit)
            if pr_meta_raw is not None:
                try:
                    rendered = self._render_template(pr_meta_raw, ctx)
                    pr_config = json.loads(rendered)
                    ee_bench_config = _deep_merge(ee_bench_config, pr_config)
                except Exception as exc:
                    logger.warning("Failed to parse metadata.json from %s: %s", head_commit, exc)

        # Merge top-level scalar fields into ctx for subsequent rendering
        for k, v in ee_bench_config.items():
            if not isinstance(v, (str, int, float, bool, list, dict)):
                continue
            should_fill_missing = k not in ctx
            should_replace_empty_expected = (
                k == "expected"
                and not _expected_has_tests(ctx.get("expected"))
                and _expected_has_tests(v)
            )
            if should_fill_missing or should_replace_empty_expected:
                ctx[k] = v

        project_root = (
            ee_bench_config.get("environment", {}).get("project_root")
            or ee_bench_config.get("project_root")
            or "/repo"
        )
        ctx["project_root"] = project_root

        # --- Phase 2: Resolve files ---
        environment_files = self._resolve_environment_files(
            owner, repo_name, head_commit, default_branch, ee_bench_config, ctx
        )
        eval_files = self._resolve_eval_files(
            owner, repo_name, head_commit, default_branch, ee_bench_config, ctx
        )

        result: dict[str, Any] = {
            "environment_files": environment_files,
            "eval": eval_files,
            "ee_bench_config": ee_bench_config,
            "project_root": project_root,
        }
        # Expose all top-level metadata.json fields as individual fields
        for k, v in ee_bench_config.items():
            if k not in result:
                result[k] = v

        return result

    # ------------------------------------------------------------------
    # Dockerfile resolution
    # ------------------------------------------------------------------

    def _resolve_environment_files(
        self,
        owner: str,
        repo_name: str,
        head_commit: str,
        default_branch: str,
        ee_bench_config: dict[str, Any],
        ctx: dict[str, Any],
    ) -> dict[str, str]:
        """Collect all .ee-bench/codegen/ files (excl. metadata.json, eval/)."""
        files: dict[str, str] = {}

        # Walk default branch tree first (lower priority)
        if default_branch:
            tree_files = self._list_codegen_files(owner, repo_name, default_branch)
            for rel_path, content_raw in tree_files.items():
                rendered = self._render_template(content_raw, ctx)
                files[rel_path] = rendered

        # Walk PR branch tree (overrides default branch)
        if head_commit:
            tree_files = self._list_codegen_files(owner, repo_name, head_commit)
            for rel_path, content_raw in tree_files.items():
                rendered = self._render_template(content_raw, ctx)
                files[rel_path] = rendered

        # metadata.json["environment"]["files"] overrides (highest priority)
        env_files_cfg = ee_bench_config.get("environment", {}).get("files", {})
        for filename, value in env_files_cfg.items():
            content = self._resolve_value(value, owner, repo_name, head_commit, ctx)
            if content is not None:
                files[filename] = content

        # Dockerfile (priority order)
        dockerfile = self._resolve_dockerfile(
            owner, repo_name, head_commit, default_branch, ee_bench_config, ctx, files
        )
        if dockerfile is not None:
            files["Dockerfile"] = dockerfile

        return files

    def _resolve_dockerfile(
        self,
        owner: str,
        repo_name: str,
        head_commit: str,
        default_branch: str,
        ee_bench_config: dict[str, Any],
        ctx: dict[str, Any],
        existing_files: dict[str, str],
    ) -> str | None:
        """Priority order: metadata.json > PR branch > default branch > auto-generated."""
        # 1. metadata.json["environment"]["dockerfile"]
        df_value = ee_bench_config.get("environment", {}).get("dockerfile")
        if df_value:
            return self._resolve_value(df_value, owner, repo_name, head_commit, ctx)

        # 2. PR branch — check new path first, then legacy
        if head_commit:
            content = self._fetch_file(owner, repo_name, self._paths["dockerfile"], head_commit)
            if content is None:
                content = self._fetch_file(owner, repo_name, self._paths["dockerfile_legacy"], head_commit)
            if content is not None:
                return self._render_template(content, ctx)

        # 3. Repo default branch — check new path first, then legacy
        if default_branch:
            content = self._fetch_file(owner, repo_name, self._paths["dockerfile"], default_branch)
            if content is None:
                content = self._fetch_file(owner, repo_name, self._paths["dockerfile_legacy"], default_branch)
            if content is not None:
                return self._render_template(content, ctx)

        # 4. Check if already in existing_files (collected from tree walk)
        if "Dockerfile" in existing_files:
            return None  # Already present, don't overwrite

        # 5. Auto-generate from build system
        from ee_bench.github.build_system import detect_build_system
        from ee_bench.github.default_templates import get_default_dockerfile

        try:
            build_system = detect_build_system(self._client, owner, repo_name, head_commit or None)
            if build_system:
                template = get_default_dockerfile(build_system)
                return self._render_template(template, ctx)
        except Exception as exc:
            logger.debug("Could not auto-detect build system: %s", exc)

        return None

    # ------------------------------------------------------------------
    # Eval directory resolution
    # ------------------------------------------------------------------

    def _resolve_eval_files(
        self,
        owner: str,
        repo_name: str,
        head_commit: str,
        default_branch: str,
        ee_bench_config: dict[str, Any],
        ctx: dict[str, Any],
    ) -> dict[str, str]:
        """Collect .ee-bench/codegen/eval/ files (merged dict)."""
        eval_files: dict[str, str] = {}

        # Lower priority: default branch
        if default_branch:
            for rel_path, content_raw in self._list_eval_files(owner, repo_name, default_branch).items():
                eval_files[rel_path] = self._render_template(content_raw, ctx)

        # Higher priority: PR branch
        if head_commit:
            for rel_path, content_raw in self._list_eval_files(owner, repo_name, head_commit).items():
                eval_files[rel_path] = self._render_template(content_raw, ctx)

        # Highest priority: metadata.json["eval"]["files"] (with "evaluation" fallback)
        eval_cfg = ee_bench_config.get("eval") or ee_bench_config.get("evaluation") or {}
        eval_files_cfg = eval_cfg.get("files", {})
        for filename, value in eval_files_cfg.items():
            content = self._resolve_value(value, owner, repo_name, head_commit, ctx)
            if content is not None:
                eval_files[filename] = content

        # Auto-generate run.sh if not present
        if not eval_files.get("run.sh"):
            from ee_bench.github.build_system import detect_build_system
            from ee_bench.github.default_templates import get_default_run_sh

            try:
                build_system = detect_build_system(
                    self._client, owner, repo_name, head_commit or None
                )
                if build_system:
                    eval_files["run.sh"] = get_default_run_sh(build_system)
            except Exception as exc:
                logger.debug("Could not auto-generate run.sh: %s", exc)

        return eval_files

    # ------------------------------------------------------------------
    # Tree listing helpers
    # ------------------------------------------------------------------

    def _list_codegen_files(self, owner: str, repo_name: str, ref: str) -> dict[str, str]:
        """List all files in .ee-bench/<type>/ (excl. metadata.json and eval/) at ref."""
        p = self._paths
        base_prefix = p["base"] + "/"
        all_blobs = self._get_tree_blobs(owner, repo_name, ref)
        result: dict[str, str] = {}
        for blob_path in all_blobs:
            if not blob_path.startswith(base_prefix):
                continue
            if blob_path == p["metadata"]:
                continue
            if blob_path.startswith(p["eval_prefix"]):
                continue
            if blob_path in (p["dockerfile"], p["dockerfile_legacy"]):
                continue
            rel = blob_path[len(base_prefix):]
            content = self._fetch_file(owner, repo_name, blob_path, ref)
            if content is not None:
                result[rel] = content
        return result

    def _list_eval_files(self, owner: str, repo_name: str, ref: str) -> dict[str, str]:
        """List all files in .ee-bench/<type>/eval/ at ref."""
        eval_prefix = self._paths["eval_prefix"]
        all_blobs = self._get_tree_blobs(owner, repo_name, ref)
        result: dict[str, str] = {}
        for blob_path in all_blobs:
            if not blob_path.startswith(eval_prefix):
                continue
            rel = blob_path[len(eval_prefix):]
            content = self._fetch_file(owner, repo_name, blob_path, ref)
            if content is not None:
                result[rel] = content
        return result

    def _get_tree_blobs(self, owner: str, repo_name: str, ref: str) -> list[str]:
        """Return all blob paths in the repo tree at ref."""
        cache_key = (owner, repo_name, "__tree__", ref)
        if cache_key in self._file_cache:
            cached = self._file_cache[cache_key]
            return json.loads(cached) if cached else []

        try:
            from ee_bench.github.api import GitHubAPIError

            tree_data = self._client.get(
                f"/repos/{owner}/{repo_name}/git/trees/{ref}",
                recursive="true",
            )
            blobs = [
                item["path"]
                for item in tree_data.get("tree", [])
                if item.get("type") == "blob"
            ]
            self._file_cache[cache_key] = json.dumps(blobs)
            return blobs
        except Exception as exc:
            logger.debug("Could not list tree for %s/%s@%s: %s", owner, repo_name, ref, exc)
            self._file_cache[cache_key] = None
            return []

    # ------------------------------------------------------------------
    # File fetch helpers
    # ------------------------------------------------------------------

    def _fetch_file_with_fallback(
        self,
        owner: str,
        repo_name: str,
        path: str,
        head_commit: str,
        default_branch: str,
    ) -> str | None:
        """Try head_commit first, then default_branch."""
        if head_commit:
            content = self._fetch_file(owner, repo_name, path, head_commit)
            if content is not None:
                return content
        if default_branch:
            return self._fetch_file(owner, repo_name, path, default_branch)
        return None

    def _fetch_file(self, owner: str, repo_name: str, path: str, ref: str) -> str | None:
        """Fetch a file from GitHub API with caching. Returns None if not found."""
        cache_key = (owner, repo_name, path, ref)
        if cache_key in self._file_cache:
            return self._file_cache[cache_key]

        try:
            from ee_bench.github.api import GitHubAPIError

            data = self._client.get(
                f"/repos/{owner}/{repo_name}/contents/{path}",
                ref=ref,
            )
            if isinstance(data, dict) and data.get("encoding") == "base64":
                content = base64.b64decode(data["content"].replace("\n", "")).decode("utf-8", errors="replace")
                self._file_cache[cache_key] = content
                return content
            elif isinstance(data, dict) and data.get("encoding") == "none" and data.get("sha"):
                # Large file — fetch via blob API
                blob_data = self._client.get(
                    f"/repos/{owner}/{repo_name}/git/blobs/{data['sha']}"
                )
                if isinstance(blob_data, dict) and blob_data.get("encoding") == "base64":
                    content = base64.b64decode(blob_data["content"].replace("\n", "")).decode("utf-8", errors="replace")
                    self._file_cache[cache_key] = content
                    return content
            elif isinstance(data, dict) and "content" in data:
                content = data["content"]
                self._file_cache[cache_key] = content
                return content
        except Exception as exc:
            logger.debug("File not found %s/%s:%s@%s — %s", owner, repo_name, path, ref, exc)

        self._file_cache[cache_key] = None
        return None

    def _fetch_url(self, url: str) -> str | None:
        """Fetch URL content with caching."""
        if url in self._url_cache:
            return self._url_cache[url]
        try:
            import requests

            resp = requests.get(url, timeout=30)
            resp.raise_for_status()
            content = resp.text
            self._url_cache[url] = content
            return content
        except Exception as exc:
            logger.warning("Failed to fetch URL %s: %s", url, exc)
            self._url_cache[url] = None
            return None

    def _resolve_value(
        self,
        value: str,
        owner: str,
        repo_name: str,
        ref: str,
        ctx: dict[str, Any],
    ) -> str | None:
        """Resolve a metadata.json value: inline / URL / repo-relative path."""
        if _is_inline(value):
            return self._render_template(value, ctx)
        if _is_url(value):
            content = self._fetch_url(value)
            return self._render_template(content, ctx) if content else None
        # Repo-relative path
        content = self._fetch_file(owner, repo_name, value, ref)
        return self._render_template(content, ctx) if content else None

    # ------------------------------------------------------------------
    # Default branch lookup
    # ------------------------------------------------------------------

    def _get_default_branch(self, owner: str, repo_name: str) -> str:
        """Fetch default branch name for the repository."""
        key = f"{owner}/{repo_name}"
        if key in self._default_branch_cache:
            return self._default_branch_cache[key]
        try:
            repo_data = self._client.get(f"/repos/{owner}/{repo_name}")
            branch = repo_data.get("default_branch", "main")
            self._default_branch_cache[key] = branch
            return branch
        except Exception as exc:
            logger.debug("Could not fetch default branch for %s: %s", key, exc)
            self._default_branch_cache[key] = "main"
            return "main"

    # ------------------------------------------------------------------
    # Jinja2 rendering
    # ------------------------------------------------------------------

    @staticmethod
    def _render_template(template_str: str, ctx: dict[str, Any]) -> str:
        """Render a Jinja2 template with instance=ctx. Pass-through if no {{ }}."""
        if "{{" not in template_str:
            return template_str
        try:
            from jinja2 import ChainableUndefined, Environment

            env = Environment(keep_trailing_newline=True, undefined=ChainableUndefined)
            env.filters["tojson"] = json.dumps
            tmpl = env.from_string(template_str)
            return tmpl.render(instance=ctx)
        except Exception as exc:
            logger.warning("Template rendering failed: %s", exc)
            return template_str
