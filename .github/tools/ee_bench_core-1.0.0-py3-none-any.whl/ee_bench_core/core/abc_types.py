"""Abstract interfaces for the evaluation framework.

This module defines all the abstract base classes that specifications
must implement to integrate with the framework.
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, List, Optional

from .models import (
    DatasetConfig,
    EnvironmentConfig,
    EvaluationResult,
)


class DatasetManager(ABC):
    """Abstract interface for dataset management.

    Responsible for loading, parsing, and providing access to benchmark datasets.
    """

    @abstractmethod
    def get_dataset_instance(self, instance_id: str, **kwargs) -> DatasetConfig:
        """Retrieve a specific dataset instance by ID.

        Args:
            instance_id: Unique identifier for the task instance
            **kwargs: Additional spec-specific parameters

        Returns:
            DatasetConfig for the requested instance

        Raises:
            DatasetError: If instance not found or cannot be loaded
        """
        pass

    @abstractmethod
    def list_dataset_instances(
        self,
        dataset_name: Optional[str] = None,
        filters: Optional[Dict[str, Any]] = None,
        **kwargs,
    ) -> List[DatasetConfig]:
        """List all available dataset instances.

        Args:
            dataset_name: Optional name of specific dataset to list
            filters: Optional filters to apply (e.g., {"language": "java"})
            **kwargs: Additional spec-specific parameters

        Returns:
            List of DatasetConfig instances matching criteria
        """
        pass

    @abstractmethod
    def install_dataset(
        self, dataset_url: str, dataset_name: Optional[str] = None, **kwargs
    ) -> Path:
        """Download and install a dataset from a URL.

        Args:
            dataset_url: URL to download the dataset from
            dataset_name: Optional name to save the dataset as
            **kwargs: Additional spec-specific parameters

        Returns:
            Path to the installed dataset file

        Raises:
            DatasetError: If download or installation fails
        """
        pass


class EnvironmentManager(ABC):
    """Abstract interface for environment management.

    Responsible for setting up, managing, and cleaning up evaluation environments
    (e.g., Docker containers, virtual environments).
    """

    @abstractmethod
    def setup_environment(
        self, config: DatasetConfig, force: bool = False, **kwargs
    ) -> EnvironmentConfig:
        """Set up an evaluation environment for a task.

        Args:
            config: Dataset configuration for the task
            force: Whether to force rebuild if environment exists
            **kwargs: Additional spec-specific parameters

        Returns:
            EnvironmentConfig describing the prepared environment

        Raises:
            EnvironmentError: If environment setup fails
        """
        pass

    @abstractmethod
    def clean_environment(
        self, config: DatasetConfig | EnvironmentConfig, **kwargs
    ) -> None:
        """Clean up an evaluation environment.

        Args:
            config: Dataset or environment configuration to clean
            **kwargs: Additional spec-specific parameters

        Raises:
            EnvironmentError: If cleanup fails
        """
        pass

    @abstractmethod
    def list_environments(self, **kwargs) -> List[EnvironmentConfig]:
        """List all existing evaluation environments.

        Args:
            **kwargs: Additional spec-specific parameters

        Returns:
            List of EnvironmentConfig instances
        """
        pass


class ReportManager(ABC):
    """Abstract interface for report management.

    Responsible for tracking evaluation progress and managing results
    in an async/concurrent manner. Each report manager is associated
    with a specific evaluation run.
    """

    @abstractmethod
    def set_result(
        self, instance_id: str, result: EvaluationResult, run_id: str
    ) -> None:
        """Set evaluation result for a task instance.

        This method is thread-safe and can be called asynchronously
        from multiple evaluations running in parallel or from external
        evaluation services.

        Args:
            instance_id: Task instance identifier
            result: Evaluation result to record
            run_id: Unique identifier for the evaluation run
        """
        pass

    @abstractmethod
    def get_report(self, run_id: str) -> Any:
        """Get current report snapshot for a specific run.

        Args:
            run_id: Unique identifier for the evaluation run

        Returns:
            Current report state (implementation-specific format)
        """
        pass

    @abstractmethod
    def mark_completed(self, run_id: str) -> None:
        """Mark the evaluation run as completed.

        Args:
            run_id: Unique identifier for the evaluation run
        """
        pass


class EvaluationRunner(ABC):
    """Abstract interface for evaluation execution.

    Responsible for running evaluations and producing results.
    """

    def __init__(self, report_manager: Optional[ReportManager] = None):
        """Initialize evaluation runner.

        Args:
            report_manager: Optional report manager for async result updates
        """
        self.report_manager = report_manager

    @abstractmethod
    def run_evaluation(
        self,
        config: DatasetConfig,
        env_config: EnvironmentConfig,
        timeout: int = 1800,
        run_id: str = "default",
        **kwargs,
    ) -> EvaluationResult:
        """Run evaluation for a task.

        Args:
            config: Dataset configuration
            env_config: Environment configuration
            timeout: Maximum execution time in seconds
            run_id: Unique identifier for the evaluation run
            **kwargs: Additional spec-specific parameters

        Returns:
            EvaluationResult with outcome

        Raises:
            EvaluationError: If evaluation fails
        """
        pass

    def set_result(
        self, instance_id: str, result: EvaluationResult, run_id: str
    ) -> None:
        """Set result async via report manager.

        Args:
            instance_id: Task instance identifier
            result: Evaluation result
            run_id: Unique identifier for the evaluation run

        Raises:
            ValueError: If no report manager configured
        """
        if self.report_manager:
            self.report_manager.set_result(instance_id, result, run_id)
        else:
            raise ValueError("No report manager configured")


class EnvironmentTools(ABC):
    """Abstract interface for environment-specific tools.

    Provides in-container commands and utilities for evaluation tasks.
    Implementations should define CLI commands as methods that can be
    discovered and registered by the framework.
    """

    pass


class EvalSpec(ABC):
    """Abstract interface for evaluation specifications.

    Each benchmark specification must implement this interface to integrate
    with the framework. This is the main entry point for specs.
    """

    # Required properties

    @property
    @abstractmethod
    def name(self) -> str:
        """Get the canonical name of this specification.

        Returns:
            Spec name (e.g., "swe", "ee-swe-java")
        """
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        """Get a human-readable description of this specification.

        Returns:
            Description string
        """
        pass

    # Optional properties with defaults

    @property
    def version(self) -> str:
        """Get the version of this specification.

        Returns:
            Version string (default: "1.0.0")
        """
        return "1.0.0"

    @property
    def framework_version_min(self) -> Optional[str]:
        """Get the minimum framework version required.

        Returns:
            Minimum version string or None
        """
        return None

    # Required orchestration methods

    @abstractmethod
    def prepare_environment(
        self, dataset_name: str, instance_ids: List[str], **kwargs
    ) -> Any:
        """Prepare environments for multiple task instances.

        This method sets up evaluation environments (e.g., Docker images)
        for the specified task instances.

        Args:
            dataset_name: Name of the dataset
            instance_ids: List of instance IDs to prepare
            **kwargs: Additional parameters (may include max_workers, force_rebuild, etc.)

        Returns:
            EnvironmentPreparationResult with success/failure information and
            configured environments for successful preparations

        Raises:
            Exception: If critical failure occurs (implementation may choose to return
                      partial results instead of raising)
        """
        pass

    @abstractmethod
    def run_evaluation(
        self, dataset_name: str, instance_ids: List[str], run_id: str, **kwargs
    ) -> Any:
        """Run evaluations for multiple task instances.

        This method executes evaluations for the specified task instances
        and reports results to the ReportManager.

        Args:
            dataset_name: Name of the dataset
            instance_ids: List of instance IDs to evaluate
            run_id: Unique identifier for this evaluation run
            **kwargs: Additional parameters (may include max_workers, timeout, etc.)

        Returns:
            Evaluation results - implementation-specific format.
            BaseEvalSpec returns the report from ReportManager.

        Raises:
            Exception: If evaluation fails
        """
        pass

    @abstractmethod
    def get_cli_parameters(self, command: str) -> List[Dict[str, Any]]:
        """Get spec-specific CLI parameters for a command.

        Args:
            command: Command name (e.g., "prepare_environment", "run_evaluation")

        Returns:
            List of parameter definitions for Click options
            Each dict should have: names, type, default, help, etc.
        """
        pass
