"""EE-bench environment configuration.

This module provides the CodeEnvironmentConfig class for Docker-based
evaluation environments.
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

from ee_bench_core.adapters.docker.docker_env_config import DockerEnvironmentConfig


@dataclass
class CodeEnvironmentConfig(DockerEnvironmentConfig):
    """Configuration for a EE-bench Docker environment.

    Extends DockerEnvironmentConfig with EE-bench specific fields like
    repository information and language.
    """

    repo: Optional[str] = None
    """Repository name (owner/repo format)"""

    base_commit: Optional[str] = None
    """Base commit hash"""

    language: Optional[str] = None
    """Programming language"""

    @property
    def sandbox_type(self) -> str:
        """Get the sandbox type identifier.

        Returns:
            Sandbox type string ('docker')
        """
        return "docker"

    def __post_init__(self):
        """Initialize related_images with base_image if provided."""
        # Support legacy base_image_name attribute
        if hasattr(self, "_base_image_name") and self._base_image_name:
            self.related_images["base"] = self._base_image_name

    @property
    def base_image_name(self) -> Optional[str]:
        """Get base image name for backwards compatibility.

        Returns:
            Base image name from related_images
        """
        return self.related_images.get("base")

    @base_image_name.setter
    def base_image_name(self, value: str) -> None:
        """Set base image name for backwards compatibility.

        Args:
            value: Base image name to set
        """
        self.related_images["base"] = value

    def to_dict(self) -> Dict[str, Any]:
        """Convert environment config to dictionary format.

        Returns:
            Dictionary representation of the environment configuration
        """
        result = {
            "instance_id": self.instance_id,
            "image_name": self.image_name,
            "base_image_name": self.base_image_name,  # For backwards compatibility
            "workspace_dir": str(self.workspace_dir) if self.workspace_dir else None,
            "project_dir": self.project_dir,
            "repo": self.repo,
            "base_commit": self.base_commit,
            "language": self.language,
            "container_id": self.container_id,
            "created_at": self.created_at,
            "related_images": self.related_images,
            "labels": self.labels,
        }

        # Include env_vars from BaseEnvironmentConfig if present
        if hasattr(self, "env_vars"):
            result["env_vars"] = self.env_vars

        # Include configurers from BaseEnvironmentConfig if present
        if hasattr(self, "configurers"):
            result["configurers"] = self.configurers

        # Include any dynamic attributes that may have been added (e.g., agent_*)
        for attr in dir(self):
            if attr.startswith("agent_") or attr.startswith("mcp_"):
                value = getattr(self, attr, None)
                if value is not None and not callable(value):
                    result[attr] = value

        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CodeEnvironmentConfig":
        """Create CodeEnvironmentConfig from dictionary.

        Args:
            data: Dictionary containing environment configuration

        Returns:
            CodeEnvironmentConfig instance
        """
        workspace_dir = data.get("workspace_dir")

        instance = cls(
            instance_id=data["instance_id"],
            image_name=data["image_name"],
            workspace_dir=Path(workspace_dir) if workspace_dir else None,
            project_dir=data.get("project_dir", "task_project"),
            repo=data.get("repo"),
            base_commit=data.get("base_commit"),
            language=data.get("language"),
            container_id=data.get("container_id"),
            created_at=data.get("created_at"),
            related_images=data.get("related_images", {}),
        )

        # Restore env_vars and configurers from BaseEnvironmentConfig if present
        if "env_vars" in data:
            instance.env_vars = data["env_vars"]
        if "configurers" in data:
            instance.configurers = data["configurers"]

        # Restore labels if present
        if "labels" in data:
            instance.labels = data["labels"]

        # Restore any dynamic attributes (e.g., agent_*, mcp_*)
        for key, value in data.items():
            if key.startswith("agent_") or key.startswith("mcp_"):
                setattr(instance, key, value)

        return instance
