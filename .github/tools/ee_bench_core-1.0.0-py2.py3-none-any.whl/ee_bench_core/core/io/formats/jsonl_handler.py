"""JSONL (JSON Lines) format handler.

Handles line-delimited JSON with streaming support for large files.
"""

import json
import logging
from typing import Any, BinaryIO, Iterator

from .base import FormatHandler

logger = logging.getLogger(__name__)


class JsonlHandler(FormatHandler):
    """Format handler for JSONL (JSON Lines) files.

    JSONL format:
    - Each line is a valid JSON object
    - Lines are separated by newline characters
    - Supports streaming for memory-efficient processing

    Example:
        {"id": 1, "name": "Alice"}
        {"id": 2, "name": "Bob"}
        {"id": 3, "name": "Charlie"}
    """

    def __init__(self, ensure_ascii: bool = False):
        """Initialize JSONL handler.

        Args:
            ensure_ascii: Escape non-ASCII characters (default: False)
        """
        self.ensure_ascii = ensure_ascii

    @classmethod
    def formats(cls) -> list[str]:
        """Return supported format extensions.

        Returns:
            List containing "jsonl"
        """
        return ["jsonl"]

    def decode(self, content: bytes) -> list[Any]:
        """Decode JSONL bytes to list of Python objects.

        Args:
            content: JSONL bytes (UTF-8 encoded)

        Returns:
            List of decoded Python objects

        Raises:
            ValueError: If content is not valid JSONL
        """
        try:
            text = content.decode("utf-8")
            lines = text.strip().split("\n")

            results = []
            for i, line in enumerate(lines, start=1):
                line = line.strip()
                if not line:
                    # Skip empty lines
                    continue

                try:
                    obj = json.loads(line)
                    results.append(obj)
                except json.JSONDecodeError as e:
                    raise ValueError(f"Invalid JSON at line {i}: {e}") from e

            return results
        except UnicodeDecodeError as e:
            raise ValueError(f"Invalid UTF-8 encoding: {e}") from e

    def encode(self, data: list[Any]) -> bytes:
        """Encode list of Python objects to JSONL bytes.

        Args:
            data: List of Python objects to encode

        Returns:
            JSONL bytes (UTF-8 encoded)

        Raises:
            ValueError: If data cannot be serialized to JSON
        """
        if not isinstance(data, list):
            raise ValueError("JSONL data must be a list of objects")

        try:
            lines = []
            for i, item in enumerate(data):
                try:
                    line = json.dumps(item, ensure_ascii=self.ensure_ascii)
                    lines.append(line)
                except (TypeError, ValueError) as e:
                    raise ValueError(f"Cannot serialize item {i} to JSON: {e}") from e

            text = "\n".join(lines)
            if text:
                text += "\n"  # Add trailing newline

            return text.encode("utf-8")
        except Exception as e:
            raise ValueError(f"Cannot serialize to JSONL: {e}") from e

    def decode_stream(self, stream: BinaryIO) -> Iterator[Any]:
        """Decode JSONL from stream (supports true streaming).

        Yields one object per line without loading entire file into memory.

        Args:
            stream: Binary stream to read from

        Yields:
            Decoded Python objects, one per line

        Raises:
            ValueError: If stream content is not valid JSONL
        """
        line_num = 0
        try:
            for line_bytes in stream:
                line_num += 1

                # Decode line
                try:
                    line = line_bytes.decode("utf-8").strip()
                except UnicodeDecodeError as e:
                    raise ValueError(f"Invalid UTF-8 at line {line_num}: {e}") from e

                # Skip empty lines
                if not line:
                    continue

                # Parse JSON
                try:
                    obj = json.loads(line)
                    yield obj
                except json.JSONDecodeError as e:
                    raise ValueError(f"Invalid JSON at line {line_num}: {e}") from e
        except Exception as e:
            if isinstance(e, ValueError):
                raise
            raise ValueError(f"Error reading JSONL stream at line {line_num}: {e}") from e

    def encode_stream(self, items: Iterator[Any], stream: BinaryIO) -> None:
        """Encode items to JSONL stream (supports true streaming).

        Writes one JSON object per line without buffering all items.

        Args:
            items: Iterator of items to encode
            stream: Binary stream to write to

        Raises:
            ValueError: If items cannot be serialized to JSON
        """
        item_num = 0
        try:
            for item in items:
                item_num += 1

                # Encode item to JSON
                try:
                    line = json.dumps(item, ensure_ascii=self.ensure_ascii)
                except (TypeError, ValueError) as e:
                    raise ValueError(f"Cannot serialize item {item_num} to JSON: {e}") from e

                # Write line with newline
                line_bytes = (line + "\n").encode("utf-8")
                stream.write(line_bytes)
        except Exception as e:
            if isinstance(e, ValueError):
                raise
            raise ValueError(f"Error writing JSONL stream at item {item_num}: {e}") from e
