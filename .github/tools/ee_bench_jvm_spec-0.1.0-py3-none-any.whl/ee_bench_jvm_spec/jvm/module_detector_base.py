"""Base module detection for multi-module Java projects.

This module provides the base class for detecting which module a test class
belongs to in multi-module projects.
"""

import json
import logging
from pathlib import Path
from typing import TYPE_CHECKING, ClassVar

if TYPE_CHECKING:
    from ee_bench_core.adapters import Sandbox

logger = logging.getLogger(__name__)


class ModuleDetector:
    """Base class for module detection in multi-module projects.

    This class provides a flexible scoring system for build tool preference.
    Subclasses can specify which build files to prioritize by passing scoring
    weights to the constructor.
    """

    # Common test source roots to search
    TEST_ROOTS: ClassVar[list[str]] = [
        "src/test/java",
        "src/test/kotlin",
        "src/test/groovy",
        "src/integrationTest/java",
        "src/integrationTest/kotlin",
        "src/integrationTest/groovy",
        "src/it/java",
        "src/it/kotlin",
        "src/it/groovy",
    ]

    # File extensions to check
    FILE_EXTENSIONS: ClassVar[list[str]] = ["java", "kt", "groovy"]

    def __init__(
        self,
        primary_build_files: list[str] | None = None,
        secondary_build_files: list[str] | None = None,
    ):
        """Initialize module detector with build file preferences.

        Args:
            primary_build_files: Build files to strongly prefer (score -5 each)
            secondary_build_files: Build files to weakly prefer (score -1 each)
        """
        self.primary_build_files = primary_build_files or []
        self.secondary_build_files = secondary_build_files or []

    def detect_module(
        self, class_fqn: str, working_dir: Path, sandbox: "Sandbox | None" = None
    ) -> str | None:
        """Detect module directory for a given class FQN.

        Args:
            class_fqn: Fully qualified class name (e.g., com.example.MyTest)
            working_dir: Project root directory
            sandbox: Optional sandbox instance for container-aware file operations

        Returns:
            Relative module path (e.g., "." for root, "module-name" for submodule),
            or None if not found
        """
        if not class_fqn:
            return None

        # Try to find modules.json in workspace directory (parent of working_dir) first
        workspace_dir = working_dir.parent
        modules_json_path = workspace_dir / "modules.json"

        # Check if modules.json exists in workspace directory (container-aware if sandbox provided)
        modules_json_exists = False
        if sandbox:
            result = sandbox.run_command(
                cmd=["test", "-f", str(modules_json_path)],
                cwd=workspace_dir if workspace_dir.exists() else working_dir,
                timeout=5,
            )
            modules_json_exists = result.returncode == 0
        else:
            modules_json_exists = modules_json_path.exists()

        # If not in workspace, try working_dir for backward compatibility
        if not modules_json_exists:
            modules_json_path = working_dir / "modules.json"
            if sandbox:
                result = sandbox.run_command(
                    cmd=["test", "-f", str(modules_json_path)],
                    cwd=working_dir,
                    timeout=5,
                )
                modules_json_exists = result.returncode == 0
            else:
                modules_json_exists = modules_json_path.exists()

        if modules_json_exists:
            logger.debug(f"Found modules.json at {modules_json_path}, attempting to detect module using it")
            module = self._detect_module_from_json(
                class_fqn, working_dir, modules_json_path, sandbox
            )
            if module is not None:
                logger.debug(f"Module detected from modules.json: {module}")
                return module
            logger.debug("Failed to detect module from modules.json, falling back to file scanning")

        # Fallback to file system scanning
        return self._detect_module_fallback(class_fqn, working_dir, sandbox)

    def _detect_module_from_json(
        self,
        class_fqn: str,
        working_dir: Path,
        modules_json_path: Path,
        sandbox: "Sandbox | None" = None,
    ) -> str | None:
        """Detect module using modules.json file.

        Args:
            class_fqn: Fully qualified class name
            working_dir: Project root directory
            modules_json_path: Path to modules.json file
            sandbox: Optional sandbox instance for container-aware file operations

        Returns:
            Module path or None if not found
        """
        try:
            # Read modules.json (container-aware if sandbox provided)
            if sandbox:
                result = sandbox.run_command(
                    cmd=["cat", str(modules_json_path)],
                    cwd=working_dir,
                    timeout=5,
                )
                if result.returncode != 0:
                    logger.debug(f"Failed to read modules.json from container: {result.stderr}")
                    return None
                modules = json.loads(result.stdout)
            else:
                with open(modules_json_path) as f:
                    modules = json.load(f)

            class_name = class_fqn.split(".")[-1]
            package_name = ".".join(class_fqn.split(".")[:-1])
            pkg_path = package_name.replace(".", "/") if package_name else ""

            # Check each module from modules.json
            for module_name, _module_info in modules.items():
                if module_name == "root":
                    module_path = working_dir
                    module_rel = "."
                else:
                    module_path = working_dir / module_name
                    module_rel = module_name

                # Look for test files in this module's test directories
                for test_root in self.TEST_ROOTS:
                    for ext in self.FILE_EXTENSIONS:
                        if pkg_path:
                            test_file_path = (
                                module_path / test_root / pkg_path / f"{class_name}.{ext}"
                            )
                        else:
                            test_file_path = module_path / test_root / f"{class_name}.{ext}"

                        # Check if file exists (container-aware if sandbox provided)
                        file_exists = False
                        if sandbox:
                            result = sandbox.run_command(
                                cmd=["test", "-f", str(test_file_path)],
                                cwd=working_dir,
                                timeout=5,
                            )
                            file_exists = result.returncode == 0
                        else:
                            file_exists = test_file_path.exists()

                        if file_exists:
                            logger.debug(
                                f"Found test file {test_file_path} in module {module_name}"
                            )
                            return module_rel

            return None

        except (json.JSONDecodeError, FileNotFoundError, KeyError) as e:
            logger.debug(f"Error reading modules.json: {e}")
            return None

    def _detect_module_fallback(
        self, class_fqn: str, working_dir: Path, sandbox: "Sandbox | None" = None
    ) -> str | None:
        """Fallback module detection using file system scanning.

        Args:
            class_fqn: Fully qualified class name
            working_dir: Project root directory
            sandbox: Optional sandbox instance for container-aware file operations

        Returns:
            Module path or None if not found
        """
        class_name = class_fqn.split(".")[-1]
        package_name = ".".join(class_fqn.split(".")[:-1])
        pkg_path = package_name.replace(".", "/") if package_name else ""

        logger.debug(f"Detecting module for {class_fqn}")
        logger.debug(f"  class_name: {class_name}")
        logger.debug(f"  package_name: {package_name}")
        logger.debug(f"  pkg_path: {pkg_path}")
        logger.debug(f"  working_dir: {working_dir}")

        candidates: list[Path] = []

        # Use container-aware file finding if sandbox is provided
        if sandbox:
            candidates = self._find_files_in_container(
                sandbox, working_dir, class_name, pkg_path
            )
        else:
            # Fall back to local glob for non-container environments
            for root in self.TEST_ROOTS:
                for ext in self.FILE_EXTENSIONS:
                    # Try both with and without ** prefix to handle different nesting levels
                    patterns = []
                    if pkg_path:
                        patterns.append(f"**/{root}/{pkg_path}/{class_name}.{ext}")
                        # Also try direct subdirectory match
                        patterns.append(f"*/{root}/{pkg_path}/{class_name}.{ext}")
                        patterns.append(f"*/*/{root}/{pkg_path}/{class_name}.{ext}")
                    else:
                        patterns.append(f"**/{root}/{class_name}.{ext}")
                        patterns.append(f"*/{root}/{class_name}.{ext}")
                        patterns.append(f"*/*/{root}/{class_name}.{ext}")

                    for pattern in patterns:
                        logger.debug(f"  Trying glob pattern: {pattern}")
                        try:
                            matches = list(working_dir.glob(pattern))
                            logger.debug(f"    Found {len(matches)} matches")
                            for p in matches:
                                if p.is_file() and p not in candidates:
                                    logger.debug(f"      Candidate: {p}")
                                    candidates.append(p)
                        except Exception as e:
                            logger.debug(f"    Glob error: {e}")

        if not candidates:
            logger.debug(f"  No candidates found for {class_fqn}")
            return None

        # Score candidates and pick the best one
        best_mod = None
        best_score = 10**9
        logger.debug(f"  Scoring {len(candidates)} candidates")
        for p in candidates:
            parts = list(p.parts)
            try:
                idx = parts.index("src")
            except ValueError:
                logger.debug(f"    Skipping {p} - no 'src' in path")
                continue
            mod_path = Path(*parts[:idx])
            module_rel = "." if mod_path == working_dir else str(mod_path.relative_to(working_dir))

            score, has_build_file = self._score_module(mod_path, module_rel, sandbox)
            logger.debug(f"    Module: {module_rel}, Score: {score}, Path: {mod_path}, Has build file: {has_build_file}")

            if score < best_score or best_mod is None:
                best_score = score
                best_mod = module_rel

        logger.debug(f"  Best module: {best_mod} with score {best_score}")
        return best_mod

    def _find_files_in_container(
        self, sandbox: "Sandbox", working_dir: Path, class_name: str, pkg_path: str
    ) -> list[Path]:
        """Find test files inside container using find command.

        Args:
            sandbox: Sandbox instance for command execution
            working_dir: Project root directory
            class_name: Simple class name (e.g., "ProductServiceApiTests")
            pkg_path: Package path with slashes (e.g., "shop/microservices/core/product")

        Returns:
            List of Path objects for found test files
        """
        candidates: list[Path] = []

        for root in self.TEST_ROOTS:
            for ext in self.FILE_EXTENSIONS:
                # Build find command to search for the test file
                # Example: find . -type f -path "*/src/test/java/shop/microservices/core/product/ProductServiceApiTests.java"
                if pkg_path:
                    pattern = f"*/{root}/{pkg_path}/{class_name}.{ext}"
                else:
                    pattern = f"*/{root}/{class_name}.{ext}"

                cmd = ["find", ".", "-type", "f", "-path", pattern]
                logger.debug(f"  Container find command: {' '.join(cmd)}")

                try:
                    result = sandbox.run_command(
                        cmd=cmd,
                        cwd=working_dir,
                        timeout=10,
                    )

                    if result.returncode == 0 and result.stdout.strip():
                        # Parse find output (one file per line)
                        for line in result.stdout.strip().split("\n"):
                            if line.strip():
                                # Convert relative path to absolute
                                # find returns paths like "./microservices/product-service/src/test/java/..."
                                file_path = working_dir / line.lstrip("./")
                                if file_path not in candidates:
                                    logger.debug(f"    Found candidate: {file_path}")
                                    candidates.append(file_path)
                    else:
                        logger.debug(f"    No matches found for pattern {pattern}")

                except Exception as e:
                    logger.debug(f"    Find command error: {e}")

        logger.debug(f"  Total candidates found in container: {len(candidates)}")
        return candidates

    def _score_module(
        self, mod_path: Path, module_rel: str, sandbox: "Sandbox | None" = None
    ) -> tuple[int, bool]:
        """Score a module candidate (lower is better).

        Uses configured build file preferences to score modules.

        Args:
            mod_path: Absolute path to module
            module_rel: Relative module path
            sandbox: Optional sandbox instance for container-aware file checks

        Returns:
            Tuple of (score, has_build_file) where score is lower for better matches
            and has_build_file indicates if any build file was found
        """
        score = 0
        has_build_file = False

        # Check primary build files (strong preference)
        for build_file in self.primary_build_files:
            build_file_path = mod_path / build_file
            file_exists = False

            result = sandbox.run_command(
                cmd=["test", "-f", str(build_file_path)],
                cwd=mod_path.parent if mod_path.parent.exists() else mod_path,
                timeout=5,
            )
            file_exists = result.returncode == 0

            if file_exists:
                logger.debug(f"      Found primary build file: {build_file} in {mod_path}")
                score -= 5
                has_build_file = True

        # Check secondary build files (weak preference)
        for build_file in self.secondary_build_files:
            build_file_path = mod_path / build_file
            file_exists = False

            # Container-aware file existence check
            if sandbox:
                result = sandbox.run_command(
                    cmd=["test", "-f", str(build_file_path)],
                    cwd=mod_path.parent if mod_path.parent.exists() else mod_path,
                    timeout=5,
                )
                file_exists = result.returncode == 0
            else:
                file_exists = build_file_path.exists()

            if file_exists:
                logger.debug(f"      Found secondary build file: {build_file} in {mod_path}")
                score -= 1
                has_build_file = True

        # Prefer shallower modules
        depth = module_rel.count("/") if module_rel != "." else 0
        score += depth

        return score, has_build_file
