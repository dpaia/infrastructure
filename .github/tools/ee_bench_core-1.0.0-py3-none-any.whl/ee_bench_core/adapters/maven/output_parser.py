"""Maven console output parser.

This module provides functionality to parse Maven test execution console output
and extract test results when JUnit XML reports are not available.
"""

import logging
import re
from typing import Dict, List, Optional

from ee_bench_core.core.models import ResultStatus

from ..testrunner_base import TestResult

logger = logging.getLogger(__name__)


class MavenOutputParser:
    """Parser for Maven console output to extract test results."""

    # Regex patterns for Maven output
    RUNNING_CLASS_RE = re.compile(
        r"^\[(?:INFO|ERROR)\]\s+Running\s+(?P<class>[\w.$][\w\d_.$]*)\s*$"
    )
    TEST_SUMMARY_RE = re.compile(
        r"""^\[(?:INFO|ERROR)\]\s+Tests?\s+run:\s*(?P<run>\d+),
            \s*Failures:\s*(?P<fail>\d+),
            \s*Errors:\s*(?P<err>\d+),
            \s*Skipped:\s*(?P<skipped>\d+)
            (?:,\s*Time\s+elapsed:\s*(?P<time>[^ ]+))?
            (?:\s*s(?:ec(?:onds)?)?)?.*$
        """,
        re.VERBOSE,
    )
    FAILCASE_HEAD_RE = re.compile(
        r"""^(?P<method>[\w$][\w\d_$]*)\((?P<class>[\w.$][\w\d_.$]*)\)
            (?:\s+Time\s+elapsed\s+(?P<time>[\d\.: smμns]+)\s*s?)?
            \s+<<<\s+(?P<kind>FAILURE|ERROR)!\s*$
        """,
        re.VERBOSE,
    )
    ALT_FAIL_IN_CLASS_RE = re.compile(
        r"""^<<<\s+(?P<kind>FAILURE|ERROR)!\s+-\s+in\s+(?P<class>[\w.$][\w\d_.$]*)\s*$"""
    )
    NO_TESTS_RE = re.compile(
        r"\bNo tests to run\b|\bNo tests were executed\b", re.IGNORECASE
    )
    SUREFIRE_NO_TESTS_RE = re.compile(
        r"^\[(?:INFO|ERROR)\]\s+No tests were found", re.IGNORECASE
    )
    THERE_ARE_TEST_FAILURES_RE = re.compile(r"There are test failures", re.IGNORECASE)
    BUILD_FAILURE_RE = re.compile(r"^\[INFO\]\s+BUILD FAILURE\s*$", re.IGNORECASE)
    COMPILATION_ERROR_RE = re.compile(r"^\[ERROR\]\s+COMPILATION ERROR", re.IGNORECASE)
    COMPILATION_FAILURE_RE = re.compile(r"Compilation failure", re.IGNORECASE)
    REPORTS_PATH_RE = re.compile(
        r"Please refer to\s+(?P<path>.*?surefire-reports.*?)\s+for the individual test results\.",
        re.IGNORECASE,
    )
    SECTION_FENCE_RE = re.compile(r"^\[(INFO|ERROR|WARNING|DEBUG)\]\s+")

    def parse(self, stdout: str, class_fqn: str, execution_time: float) -> TestResult:
        """Parse Maven stdout output for a specific class.

        Args:
            stdout: Maven console output
            class_fqn: Fully qualified class name being tested
            execution_time: Execution time in seconds

        Returns:
            TestResult with parsed information
        """
        logger.debug(f"Parsing Maven stdout for class: {class_fqn}")
        logger.debug(f"Output length: {len(stdout)} characters")

        # Parse state
        current_class: Optional[str] = None
        summaries: List[Dict] = []
        cases: List[Dict] = []
        no_tests_lines: List[str] = []
        reports_paths: List[str] = []
        there_are_failures = False
        build_failure = False
        compilation_errors: List[str] = []

        collecting_case: Optional[Dict] = None
        case_buffer: List[str] = []

        def flush_case():
            nonlocal collecting_case, case_buffer
            if collecting_case is not None:
                # Trim trailing blanks
                while case_buffer and not case_buffer[-1].strip():
                    case_buffer.pop()
                if case_buffer:
                    collecting_case["failure_block"] = "\n".join(case_buffer)
                cases.append(collecting_case)
            collecting_case = None
            case_buffer = []

        # Parse lines
        line_count = 0
        for raw in stdout.splitlines():
            line = raw.rstrip("\n")
            line_count += 1

            # Running class context
            rc = self.RUNNING_CLASS_RE.match(line)
            if rc:
                current_class = rc.group("class")
                logger.debug(
                    f"[Line {line_count}] Found running class: {current_class}"
                )
                continue

            # Test summary lines
            ts = self.TEST_SUMMARY_RE.match(line)
            if ts:
                summary = {
                    "run": int(ts.group("run")),
                    "failures": int(ts.group("fail")),
                    "errors": int(ts.group("err")),
                    "skipped": int(ts.group("skipped")),
                    "time": ts.group("time"),
                    "raw": line,
                    "class": current_class,
                }
                summaries.append(summary)
                logger.debug(
                    f"[Line {line_count}] Found test summary: run={summary['run']}, "
                    f"failures={summary['failures']}, errors={summary['errors']}, "
                    f"skipped={summary['skipped']}, class={current_class}"
                )
                current_class = None
                continue

            # Individual failure headers
            fh = self.FAILCASE_HEAD_RE.match(line)
            if fh:
                flush_case()
                collecting_case = {
                    "class": fh.group("class"),
                    "method": fh.group("method"),
                    "kind": fh.group("kind"),
                }
                if fh.group("time"):
                    collecting_case["time"] = fh.group("time").strip()
                logger.debug(
                    f"[Line {line_count}] Found failure case header: "
                    f"{fh.group('method')}({fh.group('class')}) - {fh.group('kind')}"
                )
                case_buffer = []
                continue

            # Alternate header: <<< FAILURE! - in com.example.MyTest
            alt = self.ALT_FAIL_IN_CLASS_RE.match(line)
            if alt:
                flush_case()
                collecting_case = {
                    "class": alt.group("class"),
                    "method": None,
                    "kind": alt.group("kind"),
                }
                logger.debug(
                    f"[Line {line_count}] Found alternate failure header: "
                    f"{alt.group('kind')} in {alt.group('class')}"
                )
                case_buffer = []
                continue

            # While collecting a failure block, accumulate until a fenced maven log line
            if collecting_case is not None:
                if self.SECTION_FENCE_RE.match(
                    line
                ) and not self.FAILCASE_HEAD_RE.match(line):
                    logger.debug(
                        f"[Line {line_count}] Flushing failure case (section fence encountered)"
                    )
                    flush_case()
                else:
                    case_buffer.append(line)
                continue

            # No tests signals
            if self.NO_TESTS_RE.search(line) or self.SUREFIRE_NO_TESTS_RE.search(line):
                logger.debug(
                    f"[Line {line_count}] Found 'no tests' indicator: {line.strip()}"
                )
                no_tests_lines.append(line.strip())

            # Global hint for test failures
            if self.THERE_ARE_TEST_FAILURES_RE.search(line):
                logger.debug(
                    f"[Line {line_count}] Found 'there are test failures' indicator"
                )
                there_are_failures = True

            # Build failure
            if self.BUILD_FAILURE_RE.match(line):
                logger.debug(f"[Line {line_count}] Found BUILD FAILURE")
                build_failure = True

            # Compilation errors
            if self.COMPILATION_ERROR_RE.match(
                line
            ) or self.COMPILATION_FAILURE_RE.search(line):
                logger.debug(
                    f"[Line {line_count}] Found compilation error: {line.strip()}"
                )
                compilation_errors.append(line.strip())

            # Collect error details
            if line.startswith("[ERROR]") and not line.startswith("[ERROR] ----"):
                error_content = line[7:].strip()
                if (
                    error_content
                    and not error_content.startswith("To see the full")
                    and not error_content.startswith("Re-run Maven")
                    and not error_content.startswith("For more information")
                ):
                    if compilation_errors or build_failure:
                        compilation_errors.append(error_content)

            # Reports paths
            rp = self.REPORTS_PATH_RE.search(line)
            if rp:
                reports_path = rp.group("path").strip()
                logger.debug(f"[Line {line_count}] Found reports path: {reports_path}")
                reports_paths.append(reports_path)

        # Finalize any open collectors
        if collecting_case is not None:
            logger.debug("Flushing final failure case")
        flush_case()

        logger.debug(
            f"Parsing complete: {len(summaries)} summaries, {len(cases)} failure cases, "
            f"{len(no_tests_lines)} no-test indicators, build_failure={build_failure}, "
            f"{len(compilation_errors)} compilation errors"
        )

        # Aggregate for the requested class
        return self._aggregate_results(
            class_fqn,
            summaries,
            cases,
            no_tests_lines,
            reports_paths,
            there_are_failures,
            build_failure,
            compilation_errors,
            execution_time,
            stdout,
        )

    def _aggregate_results(
        self,
        target: str,
        summaries: List[Dict],
        cases: List[Dict],
        no_tests_lines: List[str],
        reports_paths: List[str],
        there_are_failures: bool,
        build_failure: bool,
        compilation_errors: List[str],
        execution_time: float,
        stdout: str,
    ) -> TestResult:
        """Aggregate parsed results into a TestResult.

        Args:
            target: Target class FQN
            summaries: List of test summary dictionaries
            cases: List of failure case dictionaries
            no_tests_lines: Lines indicating no tests
            reports_paths: Paths to report files
            there_are_failures: Whether failures were detected
            build_failure: Whether build failed
            compilation_errors: List of compilation error messages
            execution_time: Execution time in seconds
            stdout: Original stdout

        Returns:
            TestResult with aggregated information
        """
        logger.debug(f"Aggregating results for target class: {target}")

        # Select summaries relevant to the target class
        summaries_for_target = [s for s in summaries if s.get("class") == target]
        logger.debug(
            f"Found {len(summaries_for_target)} summaries directly matching target class"
        )

        if not summaries_for_target:
            classes_in_summaries = {s.get("class") for s in summaries if s.get("class")}
            logger.debug(
                f"No direct matches. Classes in summaries: {classes_in_summaries}"
            )
            if len(classes_in_summaries) == 1 and target in classes_in_summaries:
                summaries_for_target = [
                    s for s in summaries if s.get("class") == target
                ]
                logger.debug(
                    f"Single class in summaries matches target, using {len(summaries_for_target)} summaries"
                )
            elif len(summaries) > 0 and len(classes_in_summaries) <= 1:
                # Fallback: assume all summaries refer to the single invoked spec
                summaries_for_target = summaries
                logger.debug(
                    f"Fallback: using all {len(summaries_for_target)} summaries"
                )

        total_run = (
            sum(s["run"] for s in summaries_for_target) if summaries_for_target else 0
        )
        total_failures = (
            sum(s["failures"] + s["errors"] for s in summaries_for_target)
            if summaries_for_target
            else 0
        )
        total_skipped = (
            sum(s["skipped"] for s in summaries_for_target)
            if summaries_for_target
            else 0
        )
        logger.debug(
            f"Aggregated totals: run={total_run}, failures={total_failures}, skipped={total_skipped}"
        )

        # Failure cases for target class
        case_blocks_for_target: List[str] = []
        for c in cases:
            if c.get("class") == target:
                head = f"{c.get('method') or '<unknown method>'}({c.get('class')}) <<< {c.get('kind')}!"
                blk = c.get("failure_block")
                if blk:
                    case_blocks_for_target.append(f"{head}\n{blk}")
                else:
                    case_blocks_for_target.append(head)
        logger.debug(
            f"Found {len(case_blocks_for_target)} failure case blocks for target class"
        )

        details_lines: List[str] = []

        # Add build/compilation failures first
        if build_failure:
            details_lines.append("BUILD FAILURE detected")
        if compilation_errors:
            details_lines.append("Compilation errors:")
            details_lines.extend(compilation_errors[:20])
            if len(compilation_errors) > 20:
                details_lines.append(
                    f"... and {len(compilation_errors) - 20} more compilation errors"
                )

        if case_blocks_for_target:
            details_lines.extend(case_blocks_for_target)

        if summaries_for_target:
            for s in summaries_for_target:
                details_lines.append(
                    f"Summary: run={s['run']}, failures={s['failures']}, "
                    f"errors={s['errors']}, skipped={s['skipped']}"
                    + (f", time={s['time']}" if s.get("time") else "")
                )
                if s.get("raw"):
                    details_lines.append(s["raw"])

        if reports_paths:
            for p in reports_paths:
                details_lines.append(f"Reports: {p}")

        if no_tests_lines:
            details_lines.extend(no_tests_lines)

        # Build TestResult using new structure
        result = TestResult(execution_time=execution_time, raw_output=stdout)

        # Determine test status and add to result
        test_details = details_lines or [
            "No detailed information available from Maven output."
        ]

        # Check for build/compilation failures FIRST
        if build_failure or compilation_errors:
            logger.debug(
                f"Build/compilation failure detected: build_failure={build_failure}, "
                f"compilation_errors={len(compilation_errors)}"
            )
            reason = "Build/compilation failure"
            if compilation_errors:
                reason = compilation_errors[0] if compilation_errors else reason
            result.add_test(
                test_name=target,
                status=ResultStatus.FAILED,
                reason=reason,
                execution_time=execution_time,
                details=test_details,
            )
        elif no_tests_lines or (summaries_for_target and total_run == 0):
            logger.debug(
                f"No tests executed: no_tests_lines={len(no_tests_lines)}, total_run={total_run}"
            )
            result.add_test(
                test_name=target,
                status=ResultStatus.SKIPPED,
                reason="No tests executed",
                execution_time=execution_time,
                details=test_details,
            )
        else:
            if total_failures > 0 or case_blocks_for_target or there_are_failures:
                logger.debug(
                    f"Test failed: total_failures={total_failures}, "
                    f"case_blocks={len(case_blocks_for_target)}, there_are_failures={there_are_failures}"
                )
                # Try to extract actual failure reason from first case block or details
                reason = (
                    f"{total_failures} test(s) failed"
                    if total_failures > 0
                    else "Test failures detected"
                )

                if case_blocks_for_target:
                    # Extract first line of first failure block as reason
                    first_block = case_blocks_for_target[0]
                    lines = first_block.split("\n")
                    if len(lines) > 1:
                        # Skip the header line, get first line of actual error
                        for line in lines[1:]:
                            stripped = line.strip()
                            if stripped and not stripped.startswith(
                                ("at ", "...", "Caused by:")
                            ):
                                reason = stripped
                                break
                    # If we didn't find a good error line, check if first line after header is the exception
                    if reason == f"{total_failures} test(s) failed" and len(lines) > 1:
                        # The first line after header might be the exception line
                        if lines[1].strip():
                            reason = lines[1].strip()
                else:
                    # Try to extract reason from raw stdout if no case blocks found
                    # Look for exception/error lines in the raw output
                    logger.debug(
                        "No case blocks found, searching raw stdout for exception"
                    )
                    for line in stdout.splitlines():
                        stripped = line.strip()
                        # Look for Java exception patterns (exception class names and messages)
                        if (
                            stripped
                            and (
                                "Exception" in stripped
                                or "Error" in stripped
                                or "Failure" in stripped
                            )
                            and not stripped.startswith(
                                (
                                    "at ",
                                    "...",
                                    "Caused by:",
                                    "[INFO]",
                                    "[ERROR]",
                                    "Summary:",
                                    "Reports:",
                                )
                            )
                            and "Tests run:" not in stripped
                        ):
                            logger.debug(f"Found exception line for reason: {stripped}")
                            reason = stripped
                            break

                result.add_test(
                    test_name=target,
                    status=ResultStatus.FAILED,
                    reason=reason,
                    execution_time=execution_time,
                    details=test_details,
                )
            else:
                logger.debug("Test passed")
                result.add_test(
                    test_name=target,
                    status=ResultStatus.SUCCESS,
                    reason="Test passed",
                    execution_time=execution_time,
                    details=test_details,
                )

        logger.debug(
            f"Final result: success={result.success}, total={result.total_tests}, "
            f"passed={result.passed_tests}, failed={result.failed_tests}, skipped={result.skipped_tests}"
        )

        return result
