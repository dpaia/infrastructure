"""Project reset evaluator for EE-bench evaluation.

This evaluator resets the project to its original state (clean working directory)
by discarding all uncommitted changes using git reset --hard.
"""

import logging
from typing import Optional, Union, List, TYPE_CHECKING

from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig, EvalSpec
from ee_bench_core.core.eval import (
    EvaluationContext,
    Evaluator,
    EvaluatorDependency,
    EvaluatorResult,
    EvaluatorStatus,
)

if TYPE_CHECKING:
    from ee_bench_core.adapters.sandbox_base import Sandbox

logger = logging.getLogger(__name__)


class ProjectResetEvaluator(Evaluator):
    """Evaluator that resets the project to original state.

    This evaluator performs a hard reset of the git repository to discard all
    uncommitted changes (both staged and unstaged). This is typically used after
    test patch application to restore the project before applying predictions.

    Uses git reset --hard to ensure clean state.

    Sandbox is provided via the evaluate() method parameter.
    """

    def __init__(
        self,
        name: str,
        dependencies: Optional[Union[List[str], EvaluatorDependency]] = None,
        is_terminal: bool = False,
        description: Optional[str] = None,
    ):
        """Initialize project reset evaluator.

        Args:
            name: Evaluator name
            dependencies: Evaluator dependencies
            is_terminal: Whether this is a terminal evaluator
            description: Evaluator description
        """
        self._name = name
        self._dependencies = dependencies
        self._is_terminal = is_terminal
        self._description = description or "Reset project to original state"

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return self._description

    @property
    def dependencies(self) -> Optional[EvaluatorDependency]:
        return self._dependencies

    @property
    def is_terminal(self) -> bool:
        return self._is_terminal

    def evaluate(
        self,
        spec: EvalSpec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        run_id: str,
        shared_context: EvaluationContext,
        sandbox: "Sandbox",
        **kwargs,
    ) -> EvaluatorResult:
        """Reset project to original state.

        Args:
            spec: Code evaluation spec (may provide dependencies if not injected)
            env_config: Environment configuration
            config: Dataset configuration
            run_id: Evaluation run ID
            shared_context: Shared context
            sandbox: Sandbox instance for executing commands
            **kwargs: Additional parameters

        Returns:
            EvaluatorResult with reset operation results
        """
        try:
            # Get project path from env_config
            project_path = "/workspace/task_project"
            if hasattr(env_config, "project_path"):
                project_path = str(env_config.project_path)
            elif hasattr(env_config, "workspace_dir") and env_config.workspace_dir:
                # Fallback for configs without project_path property
                project_path = str(env_config.workspace_dir)

            logger.debug(f"Resetting project at {project_path} to original state")

            # Execute git reset --hard to discard all changes
            reset_command = "git reset --hard"
            result = sandbox.run_command(
                cmd=reset_command,
                cwd=project_path,
                timeout=30,
            )

            if result.returncode == 0:
                # Clean all untracked files (including ignored files) for completely clean state
                # -f: force, -d: directories, -x: also remove ignored files
                clean_command = "git clean -fdx"
                clean_result = sandbox.run_command(
                    cmd=clean_command,
                    cwd=project_path,
                    timeout=30,
                )

                if clean_result.returncode == 0:
                    logger.debug(
                        "Project reset successful (all untracked files removed)"
                    )
                    return EvaluatorResult(
                        evaluator_name=self.name,
                        status=EvaluatorStatus.SUCCESS,
                        message="Project reset to original state successfully (all untracked files removed)",
                        data={
                            "reset_output": result.stdout.strip(),
                            "clean_output": clean_result.stdout.strip(),
                        },
                    )
                else:
                    # Reset succeeded but clean failed - still considered success
                    logger.warning(f"git clean failed: {clean_result.stderr}")
                    return EvaluatorResult(
                        evaluator_name=self.name,
                        status=EvaluatorStatus.SUCCESS,
                        message="Project reset (reset succeeded, clean failed)",
                        data={
                            "reset_output": result.stdout.strip(),
                            "clean_warning": clean_result.stderr.strip(),
                        },
                    )
            else:
                logger.error(f"git reset failed: {result.stderr}")
                return EvaluatorResult(
                    evaluator_name=self.name,
                    status=EvaluatorStatus.FAILED,
                    message="Failed to reset project",
                    error=f"git reset --hard failed: {result.stderr.strip()}",
                )

        except Exception as e:
            logger.error(f"Error resetting project: {e}", exc_info=logger.isEnabledFor(logging.DEBUG))
            return EvaluatorResult(
                evaluator_name=self.name,
                status=EvaluatorStatus.ERROR,
                message="Exception while resetting project",
                error=str(e),
            )
