"""Adapters for shared integrations across specifications.

This package contains reusable adapters for common operations like Docker,
Git, patch management, and test running. These adapters can be used by
any specification implementation.
"""

from .docker import DockerAdapter
from .docker.docker_process_manager import DockerProcessManager
from .git import GitAdapter
from .gradle import GradleModuleDetector, GradleOutputParser, GradleTestRunner
from .junit_parser import parse_junit_report
from .maven import MavenModuleDetector, MavenOutputParser, MavenTestRunner
from .patch import PatchAdapter, PatchCollectorAdapter
from .process_manager import LocalProcessManager, ProcessManager, ProcessResult
from .testrunner_base import TestResult, TestRunner

__all__ = [
    # Docker
    "DockerAdapter",
    "DockerProcessManager",
    # Git
    "GitAdapter",
    # Patch
    "PatchAdapter",
    "PatchCollectorAdapter",
    # Process
    "ProcessManager",
    "ProcessResult",
    "LocalProcessManager",
    # Test runners
    "TestRunner",
    "TestResult",
    "MavenTestRunner",
    "GradleTestRunner",
    # Maven-specific
    "MavenModuleDetector",
    "MavenOutputParser",
    # Gradle-specific
    "GradleModuleDetector",
    "GradleOutputParser",
    # JUnit parser
    "parse_junit_report",
]
