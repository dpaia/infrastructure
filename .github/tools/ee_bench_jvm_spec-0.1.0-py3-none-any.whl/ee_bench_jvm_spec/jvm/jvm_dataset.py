"""JVM-specific EE-bench dataset manager implementation.

This module provides JVM-specific dataset management that returns
JvmCodeBenchmarkConfig instances instead of the base CodeBenchmarkConfig.
"""

import logging

from ee_bench_code_spec.dataset import CodeDatasetManager

from .jvm_config import JvmCodeBenchmarkConfig

logger = logging.getLogger(__name__)


class JvmCodeDatasetManager(CodeDatasetManager):
    """JVM-specific dataset manager for EE-bench specification.

    Extends CodeDatasetManager to return JvmCodeBenchmarkConfig instances
    which include JVM-specific fields like build_system, jvm_version, etc.
    """

    def _item_to_config(self, item: dict, language: str | None = None) -> JvmCodeBenchmarkConfig:
        """Convert a dataset item dictionary to JvmCodeBenchmarkConfig.

        This overrides the parent method to return JVM-specific config.

        Args:
            item: Raw dataset item dictionary
            language: Language to assign if not in item

        Returns:
            JvmCodeBenchmarkConfig instance
        """
        # Use JvmCodeBenchmarkConfig's from_dict which handles all JVM-specific fields
        config = JvmCodeBenchmarkConfig.from_dict(item)

        # Set language if not present
        if not hasattr(config, "language") or not config.language:
            config.language = language or "jvm"

        return config
