"""Base classes for test runner adapters.

This module provides the abstract base class and result dataclass
for test execution across different build tools and specifications.
"""

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from ee_bench_core.core.models import EvaluationResult, ResultStatus, EnvironmentConfig

logger = logging.getLogger(__name__)


class TestEvaluationResult(EvaluationResult):
    """Evaluation result for a single test execution.

    Inherits from EvaluationResult where instance_id is the test name
    and reason is why the test failed/passed/skipped.
    """

    def __init__(
        self,
        test_name: str,
        status: ResultStatus,
        reason: str = "",
        execution_time: float = 0.0,
        details: Optional[List[str]] = None,
    ):
        """Initialize test evaluation result.

        Args:
            test_name: Unique test identifier (e.g., "com.example.MyTest#testMethod")
            status: Test result status (SUCCESS, FAILED, or SKIPPED)
            reason: Explanation of result (failure message, skip reason, etc.)
            execution_time: Test execution time in seconds
            details: Additional detail lines (stacktraces, error messages, etc.)
        """
        self._instance_id = test_name
        self._result = status
        self._reason = reason
        self._execution_time = execution_time
        self._details = details or []

    @property
    def instance_id(self) -> str:
        """Get the test name."""
        return self._instance_id

    @property
    def result(self) -> ResultStatus:
        """Get the test result status."""
        return self._result

    @property
    def reason(self) -> str:
        """Get the reason for the test result."""
        return self._reason

    @property
    def execution_time(self) -> float:
        """Get test execution time in seconds."""
        return self._execution_time

    @property
    def details(self) -> List[str]:
        """Get additional detail lines."""
        return self._details

    def to_dict(self) -> Dict[str, any]:
        """Convert to dictionary format.

        Returns:
            Dictionary representation of test evaluation result
        """
        return {
            "test_name": self._instance_id,
            "status": self._result.value,
            "reason": self._reason,
            "execution_time": self._execution_time,
            "details": self._details,
        }


@dataclass
class TestResult:
    """Represents the result of a test execution batch.

    Uses TestEvaluationResult for individual test results and maintains
    counters for quick status checks.

    Fields:
        success: True if all tests passed, False if any test failed
        total_tests: Count of total tests executed
        passed_tests: Count of tests that passed
        failed_tests: Count of tests that failed (includes errors)
        skipped_tests: Count of tests that were skipped
        tests: Dictionary mapping test names to TestEvaluationResult objects
        execution_time: Total time in seconds for the execution
        raw_output: Concatenated raw stdout/stderr collected for debugging
    """

    success: bool = True
    total_tests: int = 0
    passed_tests: int = 0
    failed_tests: int = 0
    skipped_tests: int = 0
    tests: Dict[str, TestEvaluationResult] = field(default_factory=dict)
    execution_time: float = 0.0
    raw_output: str = ""

    def add_result(self, test_result: TestEvaluationResult) -> None:
        """Add a test result and update counters.

        Args:
            test_result: TestEvaluationResult to add
        """
        test_name = test_result.instance_id

        # Add to tests dictionary
        self.tests[test_name] = test_result

        # Update counters
        self.total_tests += 1

        if test_result.result == ResultStatus.SUCCESS:
            self.passed_tests += 1
        elif test_result.result == ResultStatus.FAILED:
            self.failed_tests += 1
            self.success = False  # Any failure sets success to False
        elif test_result.result == ResultStatus.SKIPPED:
            self.skipped_tests += 1

    def add_test(
        self,
        test_name: str,
        status: ResultStatus,
        reason: str = "",
        execution_time: float = 0.0,
        details: Optional[List[str]] = None,
    ) -> None:
        """Convenience method to add a test result directly.

        Args:
            test_name: Unique test identifier
            status: Test result status
            reason: Explanation of result
            execution_time: Test execution time in seconds
            details: Additional detail lines
        """
        test_result = TestEvaluationResult(
            test_name=test_name,
            status=status,
            reason=reason,
            execution_time=execution_time,
            details=details,
        )
        self.add_result(test_result)

    def failure_details(self) -> List[str]:
        """Extract formatted failure details for all failed tests.

        Returns:
            List of formatted failure messages including test names and details
        """
        failure_details = []
        for test_name, test_result in self.tests.items():
            if test_result.result == ResultStatus.FAILED:
                reason = test_result.reason or "<no reason available>"
                details_text = (
                    "\n".join(test_result.details) if test_result.details else ""
                )
                if details_text:
                    failure_details.append(
                        f"Test failed: {test_name}: {reason}\n{details_text}"
                    )
                else:
                    failure_details.append(f"Test failed: {test_name}: {reason}")
        return failure_details

    def to_dict(self) -> Dict[str, any]:
        """Convert to dictionary format for JSON serialization.

        Returns:
            Dictionary representation of test result
        """
        return {
            "success": self.success,
            "total_tests": self.total_tests,
            "passed_tests": self.passed_tests,
            "failed_tests": self.failed_tests,
            "skipped_tests": self.skipped_tests,
            "tests": {name: result.to_dict() for name, result in self.tests.items()},
            "execution_time": self.execution_time,
        }


class TestRunner(ABC):
    """Abstract base class for test execution adapters.

    Provides a common interface for running tests with different build tools
    (Maven, Gradle, etc.) and aggregating their results.
    """

    def run_tests(
        self,
        test_classes: List[str],
        project_dir: str = "/workspace/task_project",
        timeout: int = 300,
        test_args: Optional[str] = None,
        env_config: Optional[EnvironmentConfig] = None,
    ) -> TestResult:
        """Run one or more specific tests and aggregate their results.

        Behavior:
        - Accepts fully qualified class names and optional method selectors (Class#method)
        - Supports an optional module hint prefix (module::a.b.Class#method) for multi-module builds
        - Delegates actual execution and parsing to the concrete runner's _run_test
        - If provided, test_args are appended to the underlying build tool command line

        Args:
            test_classes: List of test filters (e.g., com.example.FooTest, moduleA::com.example.FooTest#bar)
            project_dir: Project root on disk where the build tool should run
            timeout: Per-test timeout in seconds when invoking the build tool
            test_args: Optional extra arguments passed to the build tool (space-delimited)
            env_config: Optional EnvironmentConfig for execution context

        Returns:
            TestResult with totals aggregated across all requested tests
        """
        logger.info(
            f"Running {len(test_classes)} specific tests with {self.__class__.__name__}"
        )

        working_dir = Path(project_dir)

        start_time = datetime.now()

        aggregated_result = TestResult()
        combined_output_parts: List[str] = []

        try:
            for raw_name in test_classes:
                # Normalize to extract clean name (module hint is handled inside _run_test)
                _, clean_name, _ = self._normalize_test_name(raw_name)
                logger.debug(f"Running test {clean_name}")
                single = self._run_test(
                    clean_name, working_dir, timeout, test_args, env_config
                )

                # If no tests were found, add the clean_name as a failed test
                if single.total_tests == 0:
                    single.add_test(
                        test_name=clean_name,
                        status=ResultStatus.FAILED
                        if not single.success
                        else ResultStatus.SUCCESS,
                        reason="No test results found"
                        if not single.success
                        else "Test passed",
                        details=[],
                    )

                logger.debug(f"Test {clean_name} finished. Result: {single.success}")

                # Aggregate tests from single result
                for test_name, test_eval in single.tests.items():
                    aggregated_result.add_result(test_eval)

                combined_output_parts.append(single.raw_output)

            end_time = datetime.now()
            execution_time = (end_time - start_time).total_seconds()

            aggregated_result.execution_time = execution_time
            aggregated_result.raw_output = "\n\n".join(combined_output_parts)

            return aggregated_result

        except Exception as e:
            logger.error(f"Test execution failed: {e}")
            error_result = TestResult()
            for class_name in test_classes:
                error_result.add_test(
                    test_name=class_name,
                    status=ResultStatus.FAILED,
                    reason=f"Test execution error: {e}",
                    details=[str(e)],
                )
            return error_result

    def _normalize_test_name(self, raw: str) -> Tuple[Optional[str], str, str]:
        """Parse a raw test spec into canonical parts.

        Accepts strings like:
        - module::a.b.Class
        - module::a.b.Class#method
        - a.b.Class
        - a.b.Class#method

        Args:
            raw: Raw test specification string

        Returns:
            Tuple of (module_hint, clean_name, class_for_search) where:
            - module_hint: The optional module prefix or None
            - clean_name: The full name without the module prefix (suitable for build tool filtering)
            - class_for_search: The fully qualified class name without method/params (for file lookup)
        """
        module_hint = None
        name = raw.strip()
        if "::" in name:
            module_hint, name = name.split("::", 1)
            module_hint = module_hint.strip() or None
        # strip method part: #method or (..)
        class_part = name.split("#", 1)[0]
        class_part = class_part.split("(", 1)[0]
        return module_hint, name, class_part

    @abstractmethod
    def _run_test(
        self,
        test_name: str,
        working_dir: Path,
        timeout: int,
        test_args: Optional[str] = None,
        env_config: Optional[EnvironmentConfig] = None,
    ) -> TestResult:
        """Run a single test using the underlying build tool and return a parsed TestResult.

        Args:
            test_name: Test name to execute (e.g., com.example.FooTest or com.example.FooTest#method)
            working_dir: Working directory where tests should run
            timeout: Timeout in seconds for test execution
            test_args: Optional additional arguments to pass to build tool

        Returns:
            TestResult for the single test execution
        """
        raise NotImplementedError
