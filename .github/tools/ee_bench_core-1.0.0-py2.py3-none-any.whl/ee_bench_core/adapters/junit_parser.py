"""JUnit XML report parser adapter.

This module provides functionality to parse JUnit XML test reports
and convert them into TestResult objects, supporting both local file
system and container-based reading.
"""

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Optional

from junitparser import JUnitXml

from ee_bench_core.core.models import ResultStatus
from .testrunner_base import TestResult

if TYPE_CHECKING:
    from ee_bench_core.adapters.sandbox_base import Sandbox

logger = logging.getLogger(__name__)


def _parse_xml_content(
    xml_content: str, class_fqn: Optional[str], result: TestResult
) -> None:
    """Parse XML content and add test results.

    Args:
        xml_content: XML string content to parse
        class_fqn: Optional fully qualified class name to filter results
        result: TestResult object to add parsed tests to
    """
    xml = JUnitXml.fromstring(xml_content)

    for suite in xml:
        for case in suite:
            # Filter by class if specified (skip filter for wildcard "*")
            if class_fqn and class_fqn != "*":
                # Match exact class name OR inner classes (ParentClass$InnerClass)
                # This allows filtering by parent class to include all its inner classes
                is_match = case.classname == class_fqn or (
                    case.classname.startswith(class_fqn + "$")
                )
                if not is_match:
                    continue

            test_name = f"{case.classname}#{case.name}"
            logger.debug(f"Test: {test_name}")

            # Add case execution time
            test_time = float(case.time) if case.time else 0.0
            result.execution_time += test_time
            logger.debug(f"Test execution time: {test_time} seconds")

            # Collect result details
            details = []
            for res in case.result:
                if res.message:
                    details.append(res.message)
                    logger.debug(f"Test result: {res.message}")

            if case.is_passed:
                result.add_test(
                    test_name=test_name,
                    status=ResultStatus.SUCCESS,
                    reason="Test passed",
                    execution_time=test_time,
                    details=details,
                )
                logger.debug(f"Test passed: {test_name}")
            elif case.is_skipped:
                result.add_test(
                    test_name=test_name,
                    status=ResultStatus.SKIPPED,
                    reason="Test skipped",
                    execution_time=test_time,
                    details=details,
                )
                logger.debug(f"Test skipped: {test_name}")
            else:
                # Error, Failure, or other result types count as failures
                reason = "Test failed"
                if details:
                    reason = details[0] if details[0] else reason
                result.add_test(
                    test_name=test_name,
                    status=ResultStatus.FAILED,
                    reason=reason,
                    execution_time=test_time,
                    details=details,
                )
                logger.debug(f"Test failed: {test_name}")


def parse_junit_report(
    reports_dir: Path,
    class_fqn: Optional[str] = None,
    sandbox: Optional["Sandbox"] = None,
) -> Optional[TestResult]:
    """Parse JUnit XML reports from local filesystem or container.

    Args:
        reports_dir: Directory containing JUnit XML reports
        class_fqn: Optional fully qualified class name to filter results
        sandbox: Optional Sandbox instance for reading from container

    Returns:
        TestResult with aggregated results from all XML files, or None if no valid results found
    """
    logger.debug(f"Reports dir: {reports_dir}")

    result = TestResult(execution_time=0.0, raw_output="")

    # If sandbox is provided, read from container
    if sandbox is not None:
        logger.debug(f"Reading XML reports from container: {reports_dir}")
        try:
            # List XML files in the container
            find_cmd = ["find", str(reports_dir), "-type", "f", "-name", "*.xml"]
            list_result = sandbox.run_command(find_cmd, cwd="/")

            if list_result.returncode != 0 or not list_result.stdout.strip():
                logger.warning(f"No XML files found in container directory: {reports_dir}")
                return None

            xml_files = [
                f.strip() for f in list_result.stdout.strip().split("\n") if f.strip()
            ]

            if not xml_files:
                logger.warning(f"No XML files found in container directory: {reports_dir}")
                return None

            logger.debug(f"Found {len(xml_files)} XML file(s) in container")

            # Read and parse each XML file from container
            for xml_file in xml_files:
                try:
                    logger.debug(f"Reading XML file from container: {xml_file}")

                    # Read file content from container
                    cat_result = sandbox.run_command(["cat", xml_file], cwd="/")

                    if cat_result.returncode != 0:
                        logger.warning(f"Failed to read file from container: {xml_file}")
                        continue

                    xml_content = cat_result.stdout

                    if not xml_content or not xml_content.strip():
                        logger.warning(f"Empty XML file in container: {xml_file}")
                        continue

                    # Parse XML content
                    logger.debug(f"Parsing XML content ({len(xml_content)} bytes)")
                    _parse_xml_content(xml_content, class_fqn, result)

                except Exception as e:
                    logger.error(f"Error parsing XML file {xml_file}: {e}")
                    from ee_bench_core.core.utils import trace_error

                    logger.debug(trace_error(e))
                    continue

            if result.total_tests == 0:
                logger.warning("No test cases found in any XML files")
                return None

            logger.debug(
                f"Parsed {result.total_tests} tests from {len(xml_files)} XML file(s) in container"
            )
            return result

        except Exception as e:
            logger.error(f"Error reading XML reports from container: {e}")
            from ee_bench_core.core.utils import trace_error

            logger.debug(trace_error(e))
            return None

    # Otherwise, read from local filesystem
    if not reports_dir.exists():
        logger.warning(f"Reports directory does not exist: {reports_dir}")
        return None

    # Find all XML files in the reports directory
    xml_files = list(reports_dir.glob("**/*.xml"))
    if not xml_files:
        logger.warning(f"No XML files found in reports directory: {reports_dir}")
        return None

    for xml_file in xml_files:
        try:
            logger.debug(f"Parsing XML file: {xml_file}")

            # Read file from local filesystem
            with open(xml_file, "r") as f:
                xml_content = f.read()

            # Parse XML content
            _parse_xml_content(xml_content, class_fqn, result)

        except Exception as e:
            logger.error(f"Error parsing XML file {xml_file}: {e}")
            from ee_bench_core.core.utils import trace_error

            logger.debug(trace_error(e))
            continue

    if result.total_tests == 0:
        logger.warning("No test cases found in any XML files")
        return None

    return result
