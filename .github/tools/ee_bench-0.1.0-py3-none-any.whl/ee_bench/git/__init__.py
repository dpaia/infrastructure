"""ee_bench.git - Local git operations for EE-bench imports."""

from ee_bench.git.configurer import LocalGitConfigurer, PatchApplier

__version__ = "0.1.0"

__all__ = ["LocalGitConfigurer", "PatchApplier"]
