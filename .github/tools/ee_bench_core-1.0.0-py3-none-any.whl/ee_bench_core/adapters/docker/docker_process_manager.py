"""Docker process execution manager for running commands in containers.

This module provides a unified interface for executing commands inside Docker
containers, including support for input, streaming output, and timeouts.
"""

import logging
import time
from pathlib import Path
from typing import TYPE_CHECKING, Optional, Union, List

from .docker import DockerAdapter
from ..process_manager_base import ProcessManager, ProcessResult

if TYPE_CHECKING:
    from core.abc_types import EnvironmentConfig

logger = logging.getLogger(__name__)


class DockerProcessManager(ProcessManager):
    """Manager for executing commands inside Docker containers.

    Provides similar interface to ProcessManager but executes commands
    inside Docker containers via docker exec.
    """

    def __init__(self, docker_adapter: DockerAdapter = DockerAdapter(), debug_output: bool = True):
        """Initialize Docker process manager.

        Args:
            docker_adapter: DockerAdapter instance for container operations
            debug_output: Whether to write process output to debug log in real-time
        """
        self.docker = docker_adapter
        self.debug_output = debug_output

    def run_command(
        self,
        cmd: Union[str, List[str]],
        cwd: Optional[Union[str, Path]] = None,
        timeout: Optional[int] = None,
        stdin_input: Optional[str] = None,
        env: Optional[dict] = None,
        shell: bool = False,
        log_prefix: str = "",
        env_config: Optional["EnvironmentConfig"] = None,
    ) -> ProcessResult:
        """Run a command inside a Docker container and return its result.

        Args:
            cmd: Command to execute (list of args or string)
            cwd: Working directory inside container
            timeout: Timeout in seconds (None for no timeout)
            stdin_input: Optional input to send to process stdin
            env: Optional environment variables dict
            shell: Ignored for Docker (always uses shell-style command)
            log_prefix: Prefix for debug log messages
            env_config: EnvironmentConfig for extracting container_id (required)

        Returns:
            ProcessResult with execution details

        Raises:
            ValueError: If env_config is None or doesn't have container_id
            Exception: If command execution fails critically
        """
        start_time = time.time()
        timed_out = False

        # Validate and extract container_id from env_config
        if env_config is None:
            raise ValueError("env_config is required for DockerProcessManager")

        if not hasattr(env_config, "container_id") or not env_config.container_id:
            raise ValueError("env_config must have a valid container_id")

        container_id = env_config.container_id
        env_vars = env

        # Convert Path to string for cwd
        if cwd is not None:
            cwd = str(cwd)

        # Format command
        if isinstance(cmd, list):
            cmd_str = " ".join(cmd)
        else:
            cmd_str = cmd

        # Log command execution
        logger.debug(
            f"{log_prefix}Executing command in container {container_id}: {cmd_str}"
        )
        if cwd:
            logger.debug(f"{log_prefix}Working directory: {cwd}")
        if timeout:
            logger.debug(f"{log_prefix}Timeout: {timeout}s")

        try:
            # Get container
            container = self.docker.client.containers.get(container_id)

            # If stdin is needed, use exec_create + exec_start for proper streaming
            if stdin_input:
                # Create exec instance
                exec_config = {
                    "stdin": True,
                    "stdout": True,
                    "stderr": True,
                    "tty": False,
                }
                if cwd:
                    exec_config["workdir"] = cwd
                if env_vars:
                    exec_config["environment"] = env_vars

                exec_id = self.docker.client.api.exec_create(
                    container_id, cmd_str, **exec_config
                )["Id"]

                # Start exec with socket for stdin
                sock = self.docker.client.api.exec_start(exec_id, socket=True)

                # Set socket timeout if specified
                if timeout:
                    sock_raw = sock._sock if hasattr(sock, "_sock") else sock
                    sock_raw.settimeout(timeout)

                # Send stdin input
                sock_stdin = sock._sock if hasattr(sock, "_sock") else sock
                sock_stdin.sendall(stdin_input.encode("utf-8"))
                # Shutdown write side to signal EOF, but keep read side open
                import socket as socket_module

                sock_stdin.shutdown(socket_module.SHUT_WR)

                # Use docker's frames_iter_no_tty to separate stdout/stderr while reading
                from docker.utils.socket import frames_iter_no_tty

                stdout_data = b""
                stderr_data = b""

                try:
                    # Parse multiplexed stream as it's read from socket
                    for stream, data in frames_iter_no_tty(sock):
                        if stream == 1:  # stdout
                            stdout_data += data
                        elif stream == 2:  # stderr
                            stderr_data += data
                except (socket_module.timeout, TimeoutError):
                    timed_out = True
                    logger.warning(
                        f"{log_prefix}Command exceeded timeout of {timeout}s"
                    )
                finally:
                    sock.close()

                # Get exit code
                exec_info = self.docker.client.api.exec_inspect(exec_id)
                exit_code = exec_info["ExitCode"]

                stdout = stdout_data.decode("utf-8") if stdout_data else ""
                stderr = stderr_data.decode("utf-8") if stderr_data else ""
            else:
                # No stdin needed - use simpler exec_run
                exec_kwargs = {
                    "demux": True,  # Separate stdout/stderr
                    "stdin": False,
                    "tty": False,
                }

                if cwd:
                    exec_kwargs["workdir"] = cwd
                if env_vars:
                    exec_kwargs["environment"] = env_vars

                # Execute command
                exec_result = container.exec_run(cmd_str, **exec_kwargs)

                # Extract results
                exit_code = exec_result.exit_code

                # exec_result.output is a tuple (stdout, stderr) when demux=True
                if isinstance(exec_result.output, tuple):
                    stdout_bytes, stderr_bytes = exec_result.output
                    stdout = stdout_bytes.decode("utf-8") if stdout_bytes else ""
                    stderr = stderr_bytes.decode("utf-8") if stderr_bytes else ""
                else:
                    # Fall back to single output
                    output = (
                        exec_result.output.decode("utf-8") if exec_result.output else ""
                    )
                    stdout = output
                    stderr = ""

            # Log output if debug enabled
            if self.debug_output:
                for line in stdout.splitlines():
                    logger.debug(f"{log_prefix}[stdout] {line}")
                for line in stderr.splitlines():
                    logger.debug(f"{log_prefix}[stderr] {line}")

        except Exception as e:
            duration = time.time() - start_time
            logger.error(f"{log_prefix}Command execution failed: {e}")
            raise

        duration = time.time() - start_time

        # Check if timed out (basic check - docker exec doesn't have built-in timeout)
        if timeout and duration >= timeout:
            timed_out = True
            logger.warning(f"{log_prefix}Command exceeded timeout of {timeout}s")

        # Log completion
        logger.debug(
            f"{log_prefix}Command completed in {duration:.2f}s "
            f"with exit code {exit_code}"
        )

        return ProcessResult(
            returncode=exit_code,
            stdout=stdout,
            stderr=stderr,
            duration=duration,
            timed_out=timed_out,
        )

    def run_command_with_input(
        self,
        cmd: Union[str, List[str]],
        stdin_input: str,
        cwd: Optional[Union[str, Path]] = None,
        timeout: Optional[int] = None,
        env: Optional[dict] = None,
        shell: bool = False,
        log_prefix: str = "",
        env_config: Optional["EnvironmentConfig"] = None,
    ) -> ProcessResult:
        """Run a command with input sent to stdin.

        This is a convenience method that calls run_command with stdin_input.

        Args:
            cmd: Command to execute
            stdin_input: Input to send to process stdin
            cwd: Working directory inside container
            timeout: Timeout in seconds
            env: Optional environment variables dict
            shell: Ignored for Docker
            log_prefix: Prefix for debug log messages
            env_config: EnvironmentConfig for extracting container_id (required)

        Returns:
            ProcessResult with execution details
        """
        # Disable debug output for input commands to avoid logging sensitive data
        original_debug = self.debug_output
        self.debug_output = False

        try:
            return self.run_command(
                cmd=cmd,
                cwd=cwd,
                timeout=timeout,
                stdin_input=stdin_input,
                env=env,
                shell=shell,
                log_prefix=log_prefix,
                env_config=env_config,
            )
        finally:
            self.debug_output = original_debug
