"""CLI helper utilities for command-line interface operations.

This module provides reusable helper functions for CLI-specific operations
like displaying environment configuration mode and formatting output.
"""

import logging
from typing import List, Optional, Dict, Any

import click

logger = logging.getLogger(__name__)


def display_environment_mode(
    spec_kwargs: dict, ids: Optional[List[str]] = None
) -> None:
    """Display environment configuration mode for CLI feedback.

    This is a CLI-specific display function that shows which mode is being used
    (pre-configured vs ad-hoc). Actual validation happens in load_or_build_environments().

    Args:
        spec_kwargs: Spec keyword arguments containing config parameters
        ids: Optional list of instance IDs (for display only)

    Example:
        >>> display_environment_mode({"environment_config_path": "env.json"}, ["task-001"])
        Pre-configured mode
        Environment config: env.json
        Instance IDs: task-001

        >>> display_environment_mode({"sandbox": "docker", "workspace_dir": "/workspace"})
        Ad-hoc mode
        Sandbox: docker
        Workspace: /workspace
    """
    environment_config_path = spec_kwargs.get("environment_config_path")

    if environment_config_path:
        # Pre-configured mode: loading from existing config file
        click.echo("Pre-configured mode")
        click.echo(f"Environment config: {environment_config_path}")
        if ids:
            click.echo(f"Instance IDs: {', '.join(ids)}")
    else:
        # Ad-hoc mode: building config from CLI parameters
        click.echo("Ad-hoc mode")
        sandbox = spec_kwargs.get("sandbox")
        workspace_dir = spec_kwargs.get("workspace_dir")

        if sandbox:
            click.echo(f"Sandbox: {sandbox}")
        if workspace_dir:
            click.echo(f"Workspace: {workspace_dir}")


def get_and_validate_spec(ctx: click.Context, command_name: str = ""):
    """Get and validate spec from Click context.

    Extracts spec_name from context, validates it exists, loads the spec,
    and sets the logging context.

    Args:
        ctx: Click context object
        command_name: Optional command name for better error messages

    Returns:
        Tuple of (spec_name, spec) where spec is the loaded specification

    Raises:
        click.UsageError: If spec is not provided or not found

    Example:
        >>> @click.command()
        >>> @click.pass_context
        >>> def my_command(ctx):
        >>>     spec_name, spec = get_and_validate_spec(ctx, "my-command")
        >>>     # Use spec...
    """
    from ee_bench_core.core.spec_registry import get_eval_spec, list_available_specs
    from ee_bench_core.core.utils import set_command_context

    spec_name = ctx.obj.get("spec")

    if not spec_name:
        cmd_example = f" {command_name}" if command_name else ""
        raise click.UsageError(
            "Specification not provided. Use --spec parameter or set EE_BENCH_SPEC environment variable.\n"
            f"Example: ee-bench --spec jvm{cmd_example} --dataset-name my-dataset.json\n"
            "Available specs: " + ", ".join(list_available_specs())
        )

    # Get the specification
    spec = get_eval_spec(spec_name)
    logger.info(f"Using specification: {spec_name} ({spec.description})")
    set_command_context(spec.name)

    return spec_name, spec


def normalize_instance_ids(instance_ids: tuple) -> List[str]:
    """Normalize instance IDs from multiple invocations or comma/space separated lists.

    Handles various input formats:
    - Multiple invocations: --instance-ids id1 --instance-ids id2
    - Comma-separated: --instance-ids id1,id2,id3
    - Space-separated: --instance-ids "id1 id2 id3"
    - Mixed: --instance-ids "id1,id2" --instance-ids id3

    Args:
        instance_ids: Tuple of instance IDs from Click's multiple=True option

    Returns:
        Normalized list of instance ID strings

    Example:
        >>> normalize_instance_ids(("id1,id2", "id3"))
        ['id1', 'id2', 'id3']
        >>> normalize_instance_ids(("id1 id2", "id3,id4"))
        ['id1', 'id2', 'id3', 'id4']
    """
    ids: List[str] = []
    for item in instance_ids:
        if isinstance(item, (list, tuple)):
            ids.extend([str(x) for x in item])
        elif isinstance(item, str):
            # Split by both comma and space
            for part in item.replace(",", " ").split():
                if part:
                    ids.append(part)
    return ids


def parse_and_merge_spec_kwargs(
    spec, command_name: str, spec_args: tuple, dynamic_kwargs: Dict[str, Any]
) -> Dict[str, Any]:
    """Parse spec-specific arguments and merge with dynamic kwargs.

    Parses unprocessed spec_args (SPEC_ARGS from Click), converts types based on
    spec parameter definitions, and merges with dynamically added kwargs from
    Click options.

    Args:
        spec: Specification object
        command_name: Name of the command (e.g., "prepare-environment")
        spec_args: Tuple of unprocessed spec arguments from Click
        dynamic_kwargs: Dict of dynamically added kwargs from Click options

    Returns:
        Merged dictionary of spec keyword arguments with proper types

    Example:
        >>> spec_kwargs = parse_and_merge_spec_kwargs(
        ...     spec, "prepare-environment",
        ...     ("--max-workers", "8"),
        ...     {"timeout": 3600}
        ... )
        >>> spec_kwargs
        {'max_workers': 8, 'timeout': 3600}
    """
    from ee_bench_core.core.utils.argparse_ext import (
        parse_spec_args,
        convert_kwargs_types,
    )

    # Parse spec-specific arguments from SPEC_ARGS
    spec_kwargs = parse_spec_args(spec_args)

    # Convert kwargs types based on spec parameter definitions
    typed_kwargs = convert_kwargs_types(dynamic_kwargs, spec, command_name)

    # Merge with kwargs from dynamically added options (higher priority)
    # Skip None values to let spec use its own defaults
    spec_kwargs.update({k: v for k, v in typed_kwargs.items() if v is not None})

    return spec_kwargs
