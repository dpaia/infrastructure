"""JSON format handler.

Handles encoding/decoding of JSON files with UTF-8 encoding.
"""

import json
import logging
from typing import Any, BinaryIO, Iterator

from .base import FormatHandler

logger = logging.getLogger(__name__)


class JsonHandler(FormatHandler):
    """Format handler for JSON files.

    Handles standard JSON encoding/decoding with UTF-8 encoding.
    Does not provide streaming support (entire file loaded into memory).
    """

    def __init__(self, indent: int = 2, ensure_ascii: bool = False):
        """Initialize JSON handler.

        Args:
            indent: Indentation level for pretty printing (default: 2)
            ensure_ascii: Escape non-ASCII characters (default: False)
        """
        self.indent = indent
        self.ensure_ascii = ensure_ascii

    @classmethod
    def formats(cls) -> list[str]:
        """Return supported format extensions.

        Returns:
            List containing "json"
        """
        return ["json"]

    def decode(self, content: bytes) -> Any:
        """Decode JSON bytes to Python object.

        Args:
            content: JSON bytes (UTF-8 encoded)

        Returns:
            Decoded Python object (dict, list, etc.)

        Raises:
            ValueError: If content is not valid JSON
        """
        try:
            text = content.decode("utf-8")
            return json.loads(text)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON content: {e}") from e
        except UnicodeDecodeError as e:
            raise ValueError(f"Invalid UTF-8 encoding: {e}") from e

    def encode(self, data: Any) -> bytes:
        """Encode Python object to JSON bytes.

        Args:
            data: Python object to encode

        Returns:
            JSON bytes (UTF-8 encoded)

        Raises:
            ValueError: If data cannot be serialized to JSON
        """
        try:
            text = json.dumps(
                data,
                indent=self.indent,
                ensure_ascii=self.ensure_ascii,
            )
            return text.encode("utf-8")
        except (TypeError, ValueError) as e:
            raise ValueError(f"Cannot serialize to JSON: {e}") from e

    def decode_stream(self, stream: BinaryIO) -> Iterator[Any]:
        """Decode JSON from stream.

        Note: JSON does not support true streaming - entire content
        is loaded into memory.

        Args:
            stream: Binary stream to read from

        Yields:
            Single decoded JSON object

        Raises:
            ValueError: If stream content is not valid JSON
        """
        content = stream.read()
        yield self.decode(content)

    def encode_stream(self, items: Iterator[Any], stream: BinaryIO) -> None:
        """Encode items to JSON stream.

        Note: JSON does not support true streaming - all items
        are collected into a list before encoding.

        Args:
            items: Iterator of items to encode (will be collected into list)
            stream: Binary stream to write to

        Raises:
            ValueError: If items cannot be serialized to JSON
        """
        # Collect all items into list
        data = list(items)
        content = self.encode(data)
        stream.write(content)
