"""Gradle configurer for adding Gradle to JVM base images.

This configurer adds Gradle build tool to JVM base images, creating
Gradle-enabled images that can be used for Gradle-based projects.
"""

import logging

from ee_bench_core.core import DependencyPosition
from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig

from ee_bench_jvm_spec.jvm.base_docker_build_tool_configurer import (
    BaseDockerBuildToolConfigurer,
)
from ee_bench_jvm_spec.jvm.jvm_config import BuildSystem

logger = logging.getLogger(__name__)

# Gradle version mappings based on JDK version
GRADLE_VERSION_MAP = {
    "8": "7.6.4",  # Last version supporting Java 8
    "11": "8.5",
    "17": "8.5",
    "21": "8.5",
    "24": "9.1.0",
    "25": "9.1.0" # Latest for newest JDK
}

DEFAULT_GRADLE_VERSION = "8.5"


class DockerGradleConfigurer(BaseDockerBuildToolConfigurer):
    """Configurer that adds Gradle to JVM base image.

    This configurer enhances a JVM base image by installing Gradle
    build tool. It automatically selects an appropriate Gradle version based
    on the JDK version.

    The resulting image can be used for Gradle-based Java projects.

    Metadata:
        name: gradle
        priority: 50 (build tool - runs after base)
        dependencies: ["jvm_base_image"]
        specs: ["jvm"]
    """

    # Metadata for plugin discovery
    __configurer_name__ = "gradle"
    __configurer_description__ = "Adds Gradle to JVM base image"
    __configurer_version__ = "1.0.0"
    __configurer_specs__ = ["jvm"]

    def __init__(self, namespace: str = "ee-bench", **kwargs):
        """Initialize Gradle configurer.

        Args:
            namespace: Docker image namespace (default: "ee-bench")
            **kwargs: Additional parameters (ignored, for compatibility)
        """
        super().__init__(tool_name="gradle", namespace=namespace, **kwargs)

    @property
    def build_system(self):
        """Return the BuildSystem enum for Gradle."""
        return BuildSystem.GRADLE

    @property
    def tool_version_param_name(self) -> str:
        """Return the parameter name for Gradle version override."""
        return "gradle_version"

    def get_version_map(self) -> dict[str, str]:
        """Return version mapping dictionary for Gradle.

        Returns:
            Dict mapping JDK version to Gradle version
        """
        return GRADLE_VERSION_MAP

    def get_default_version(self) -> str:
        """Return default Gradle version.

        Returns:
            Default Gradle version string
        """
        return DEFAULT_GRADLE_VERSION

    def generate_dockerfile(
        self,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        **kwargs,
    ) -> str:
        """Generate Dockerfile to add Gradle.

        Args:
            env_config: Environment configuration
            config: Dataset configuration
            **kwargs: Additional parameters (base_image, gradle_version required)

        Returns:
            Dockerfile content as string
        """
        base_image = kwargs.get("base_image", "ubuntu:22.04")
        gradle_version = kwargs.get("gradle_version", DEFAULT_GRADLE_VERSION)

        return f"""FROM {base_image}

# Install Gradle {gradle_version}
RUN wget https://services.gradle.org/distributions/gradle-{gradle_version}-bin.zip \\
    && unzip gradle-{gradle_version}-bin.zip -d /opt \\
    && ln -s /opt/gradle-{gradle_version} /opt/gradle \\
    && rm gradle-{gradle_version}-bin.zip

ENV PATH="/opt/gradle/bin:${{PATH}}"
ENV GRADLE_HOME="/opt/gradle"
"""
