"""Base class for local build tool configurers (Maven/Gradle).

This module provides an abstract base class that extracts common logic
for verifying build tools (Maven, Gradle, etc.) on the local system.
"""

import logging
import shutil
import subprocess
from abc import ABC, abstractmethod
from pathlib import Path

from ee_bench_core.adapters.local import LocalEnvironmentConfig
from ee_bench_core.core import DependencyPosition
from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig
from ee_bench_core.core.errors import EnvironmentError
from ee_bench_core.core.eval import EnvironmentConfigurer

logger = logging.getLogger(__name__)


class BaseLocalBuildToolConfigurer(EnvironmentConfigurer, ABC):
    """Abstract base class for local build tool configurers.

    This class extracts common logic for verifying build tools (Maven, Gradle, etc.)
    on the local system. Subclasses only need to implement tool-specific methods:
    - build_system property (returns BuildSystem enum)
    - tool_name property (returns tool name string)
    - get_download_url() (returns download URL)
    - parse_version_from_output() (parses version from command output)
    - check_for_wrapper() (optional: checks for wrapper like mvnw/gradlew)

    Common functionality handled by base class:
    - Environment type checking (LocalEnvironmentConfig)
    - Build system verification
    - System tool installation check
    - Version detection
    - HOME directory detection
    - Environment variable setup
    """

    def __init__(self, **kwargs):
        """Initialize build tool configurer.

        Args:
            **kwargs: Additional parameters (ignored, for compatibility)
        """
        pass

    @property
    @abstractmethod
    def build_system(self):
        """Return the BuildSystem enum for this tool.

        Returns:
            BuildSystem enum (e.g., BuildSystem.MAVEN or BuildSystem.GRADLE)
        """
        pass

    @property
    @abstractmethod
    def tool_name(self) -> str:
        """Return the tool name in lowercase.

        Returns:
            Tool name (e.g., "maven" or "gradle")
        """
        pass

    @property
    def tool_command(self) -> str:
        """Return the command name for this tool.

        Returns:
            Command name (defaults to tool_name, e.g., "mvn" for Maven)
        """
        return self.tool_name

    @property
    def tool_home_env_var(self) -> str:
        """Return the HOME environment variable name.

        Returns:
            HOME variable name (e.g., "MAVEN_HOME" or "GRADLE_HOME")
        """
        return f"{self.tool_name.upper()}_HOME"

    @property
    def tool_version_env_var(self) -> str:
        """Return the VERSION environment variable name.

        Returns:
            VERSION variable name (e.g., "MAVEN_VERSION" or "GRADLE_VERSION")
        """
        return f"{self.tool_name.upper()}_VERSION"

    @abstractmethod
    def get_download_url(self) -> str:
        """Return the download URL for this tool.

        Returns:
            Download URL string
        """
        pass

    @abstractmethod
    def parse_version_from_output(self, version_output: str) -> str | None:
        """Parse version from tool's version command output.

        Args:
            version_output: Output from running tool --version or -version

        Returns:
            Version string or None if not found
        """
        pass

    def check_for_wrapper(
        self, env_config: LocalEnvironmentConfig, config: DatasetConfig
    ) -> tuple[str, str] | None:
        """Check for wrapper (mvnw/gradlew) in project.

        Override this method in subclasses that support wrappers.

        Args:
            env_config: Environment configuration
            config: Dataset configuration

        Returns:
            Tuple of (wrapper_path, version) if found, None otherwise
        """
        return None

    def find_tool_home(self, tool_path: str, version_output: str) -> str | None:
        """Find TOOL_HOME from executable path and version output.

        Args:
            tool_path: Path to tool executable
            version_output: Output from tool -version

        Returns:
            TOOL_HOME path or None if not found
        """
        tool_path_obj = Path(tool_path).resolve()

        # Common patterns:
        # /usr/local/tool/bin/tool -> /usr/local/tool
        # /opt/tool/bin/tool -> /opt/tool

        if tool_path_obj.parent.name == "bin":
            potential_home = tool_path_obj.parent.parent

            # Check if this looks like TOOL_HOME (has bin, lib directories)
            if (potential_home / "lib").exists() and (potential_home / "bin").exists():
                return str(potential_home)

        return None

    @property
    def name(self) -> str:
        """Return configurer name."""
        return f"local_{self.tool_name}"

    @property
    def description(self) -> str:
        """Return configurer description."""
        return f"Verifies local {self.tool_name.capitalize()} installation and sets {self.tool_home_env_var}"

    @property
    def specs(self) -> list[str] | None:
        """Return supported spec names."""
        return ["jvm"]

    @property
    def dependencies(self) -> list[str] | DependencyPosition | None:
        """Return dependency configuration."""
        return DependencyPosition(
            after=["local_jvm", "local_task_setup"],
            before=["task_image"],
            priority=50,
        )

    def should_configure(
        self,
        spec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        **kwargs,
    ) -> tuple[bool, str | None]:
        """Check if this configurer should run.

        Only runs for local environments with matching build system.

        Args:
            spec: Evaluation specification
            env_config: Environment configuration
            config: Dataset configuration
            **kwargs: Additional parameters

        Returns:
            Tuple of (should_configure, reason)
        """
        # Only configure local environments
        if not isinstance(env_config, LocalEnvironmentConfig):
            return False, f"Not a local environment (type: {type(env_config).__name__})"

        # Check build system
        from ee_bench_jvm_spec.jvm import JvmCodeEvalSpec

        build_system = JvmCodeEvalSpec.get_build_system(config, **kwargs)
        if build_system != self.build_system:
            return (
                False,
                f"Build system is {build_system.name}, not {self.build_system.name}",
            )

        return True, None

    def configure(
        self,
        spec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        **kwargs,
    ) -> EnvironmentConfig:
        """Verify tool installation and configure env_vars.

        Checks for wrapper first (if supported). If not found, checks for
        system installation.

        Args:
            spec: Evaluation specification
            env_config: Environment configuration (LocalEnvironmentConfig)
            config: Dataset configuration
            **kwargs: Additional parameters

        Returns:
            Updated EnvironmentConfig with tool HOME and VERSION set

        Raises:
            EnvironmentError: If tool is not installed
        """
        if not isinstance(env_config, LocalEnvironmentConfig):
            return env_config

        logger.info(f"Verifying local {self.tool_name.capitalize()} installation")

        # Check for wrapper first (if supported by subclass)
        wrapper_result = self.check_for_wrapper(env_config, config)
        if wrapper_result:
            wrapper_path, version = wrapper_result
            logger.info(f"Using {self.tool_name} wrapper: {wrapper_path}")
            env_config.env_vars[f"{self.tool_name.upper()}_WRAPPER"] = wrapper_path
            env_config.env_vars[self.tool_version_env_var] = version
            logger.info(
                f"Local {self.tool_name.capitalize()} configuration complete: wrapper {version}"
            )
            return env_config

        # No wrapper - check for system installation
        logger.info(
            f"No {self.tool_name} wrapper found, checking for system {self.tool_name} installation"
        )

        tool_path = shutil.which(self.tool_command)
        if not tool_path:
            raise EnvironmentError(
                f"{self.tool_name.capitalize()} not found in PATH and no wrapper in project.\n"
                f"Please install {self.tool_name.capitalize()} or ensure the project includes a wrapper.\n"
                f"Download from: {self.get_download_url()}"
            )

        # Get version
        try:
            result = subprocess.run(
                [self.tool_command, "-version"],
                capture_output=True,
                text=True,
                check=True,
            )
            version_output = result.stdout
            logger.debug(f"{self.tool_name.capitalize()} version output: {version_output}")
        except subprocess.CalledProcessError as e:
            raise EnvironmentError(f"Failed to get {self.tool_name.capitalize()} version: {e}")

        # Parse version
        version = self.parse_version_from_output(version_output)
        if not version:
            logger.warning(
                f"Could not parse {self.tool_name.capitalize()} version from: {version_output}"
            )
            version = "unknown"

        logger.info(f"Found {self.tool_name.capitalize()} version: {version} at {tool_path}")

        # Find HOME directory if not already set
        tool_home = env_config.env_vars.get(self.tool_home_env_var)
        if not tool_home:
            tool_home = self.find_tool_home(tool_path, version_output)
            if tool_home:
                logger.info(f"Detected {self.tool_home_env_var}: {tool_home}")
            else:
                logger.warning(f"Could not automatically detect {self.tool_home_env_var}")

        # Update env_vars
        if tool_home:
            env_config.env_vars[self.tool_home_env_var] = tool_home
        env_config.env_vars[self.tool_version_env_var] = version

        logger.info(
            f"Local {self.tool_name.capitalize()} configuration complete: {self.tool_name.capitalize()} {version}"
        )

        return env_config
