"""Docker sandbox implementation.

This module provides a Sandbox implementation for Docker containers,
wrapping DockerProcessManager with env_config as instance state.
"""

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Callable, List, Optional, Union

from .docker import DockerAdapter
from .docker_process_manager import DockerProcessManager
from ..sandbox_base import Sandbox, ProcessResult

if TYPE_CHECKING:
    from ee_bench_core.core.abc_types import EnvironmentConfig

logger = logging.getLogger(__name__)


class DockerSandbox(Sandbox):
    """Sandbox implementation for Docker containers.

    Encapsulates a Docker execution environment with its configuration.
    The environment configuration is stored as instance state.
    """

    def __init__(
        self,
        env_config: "EnvironmentConfig",
        docker_adapter: Optional[DockerAdapter] = None,
        debug_output: bool = True,
    ):
        """Initialize Docker sandbox with environment configuration.

        Args:
            env_config: Docker environment configuration with container_id, image_name, etc.
            docker_adapter: Optional DockerAdapter instance (creates new if None)
            debug_output: Whether to write process output to debug log in real-time
        """
        super().__init__(env_config)

        # Phase 3.2: Store Docker container state in sandbox instance
        # Initialize from env_config for backward compatibility
        self.container_id: Optional[str] = getattr(env_config, "container_id", None)
        self.ephemeral_container_id: Optional[str] = None

        # Create DockerProcessManager for delegation
        if docker_adapter is None:
            docker_adapter = DockerAdapter()

        self._process_manager = DockerProcessManager(
            docker_adapter=docker_adapter, debug_output=debug_output
        )
        self.docker = docker_adapter

    def start(self, **kwargs) -> None:
        """Start the Docker container.

        Creates and starts a container from the image specified in env_config.
        Phase 3.3: Implements lifecycle logic directly instead of delegating to ProcessManager.

        Args:
            **kwargs: Additional parameters for container creation

        Raises:
            RuntimeError: If container start fails
            ValueError: If env_config is missing required fields
        """
        # Import here to avoid circular dependency
        from ..sandbox_base import SandboxStatus

        logger.info(f"Starting Docker sandbox for instance '{self.get_instance_id()}'")

        self._set_status(SandboxStatus.STARTING)

        try:
            # Validate configuration
            if not hasattr(self.env_config, "image_name") or not self.env_config.image_name:
                instance_id = self.get_instance_id()
                raise ValueError(
                    f"env_config for instance '{instance_id}' must have image_name to start Docker environment"
                )

            # Get workspace_dir if available
            workspace_dir = getattr(self.env_config, "workspace_dir", None)

            # Get docker run options if available (parsed by base_spec)
            docker_run_opts = getattr(self.env_config, "docker_run_opts", {})

            # Parse and store docker_opts in env_config if provided
            docker_opts_str = kwargs.get("docker_opts", "")
            if docker_opts_str:
                from ee_bench_core.core.utils.argparse_ext import parse_docker_opts

                parsed_opts = parse_docker_opts(docker_opts_str)
                # Store parsed docker options in env_config for sandbox to use
                docker_run_opts = parsed_opts
                logger.debug(f"Parsed docker opts: {parsed_opts}")

            logger.info(f"Starting Docker environment from image: {self.env_config.image_name}")
            if docker_run_opts:
                logger.debug(f"Applying docker run options: {docker_run_opts}")

            # Create and start container directly using DockerAdapter
            self.container_id = self.docker.run_container(
                image=self.env_config.image_name,
                working_dir=str(workspace_dir) if workspace_dir else None,
                detach=True,
                **docker_run_opts,
            )

            # Update env_config with container_id (maintain backward compatibility)
            self.env_config.container_id = self.container_id

            logger.info(f"Started Docker container: {self.container_id}")
            self._set_status(SandboxStatus.RUNNING)

        except Exception as e:
            instance_id = self.get_instance_id()
            logger.error(f"Failed to start Docker sandbox for instance '{instance_id}': {e}")
            self._set_status(SandboxStatus.ERROR)
            raise RuntimeError(
                f"Failed to start Docker environment for instance '{instance_id}': {e}"
            )

    def stop(self, **kwargs) -> None:
        """Stop and remove the Docker container.

        Phase 3.3: Implements lifecycle logic directly instead of delegating to ProcessManager.

        Args:
            **kwargs: Additional parameters (ignored)

        Raises:
            RuntimeError: If container stop fails
        """
        # Import here to avoid circular dependency
        from ..sandbox_base import SandboxStatus

        logger.info(f"Stopping Docker sandbox for instance '{self.get_instance_id()}'")

        self._set_status(SandboxStatus.STOPPING)

        try:
            # Check if there's a container to stop
            if not self.container_id:
                instance_id = self.get_instance_id()
                logger.warning(
                    f"Cannot stop Docker environment for instance '{instance_id}': no container_id"
                )
                self._set_status(SandboxStatus.STOPPED)
                return

            logger.info(f"Stopping Docker container: {self.container_id}")

            # Stop the container directly using DockerAdapter
            self.docker.stop_container(self.container_id)
            logger.info(f"Stopped container: {self.container_id}")

            # Remove the container
            self.docker.remove_container(self.container_id)
            logger.info(f"Removed container: {self.container_id}")

            # Clear container_id from both sandbox and env_config
            self.container_id = None
            self.env_config.container_id = None

            logger.info("Docker sandbox stopped")
            self._set_status(SandboxStatus.STOPPED)

        except Exception as e:
            logger.warning(f"Failed to stop Docker sandbox: {e}")
            self._set_status(SandboxStatus.ERROR)
            # Don't raise - stop should be best-effort

    def is_running(self) -> bool:
        """Check if the Docker container is running.

        Returns:
            True if container exists and is running, False otherwise
        """

        if not self.container_id:
            return False

        try:
            import docker.errors

            container = self.docker.client.containers.get(self.container_id)
            return container.status == "running"
        except docker.errors.NotFound:
            return False
        except Exception as e:
            logger.warning(f"Failed to check container status: {e}")
            return False

    def run_command(
        self,
        cmd: Union[str, List[str]],
        cwd: Optional[Union[str, Path]] = None,
        timeout: Optional[int] = None,
        stdin_input: Optional[str] = None,
        env: Optional[dict] = None,
        shell: bool = False,
        log_prefix: str = "",
        stream_output: bool = False,
        output_callback: Optional[Callable[[str], None]] = None,
        **kwargs,
    ) -> ProcessResult:
        """Run a command inside the Docker container.

        Phase 3.4: Passes container_id directly instead of via env_config.

        Args:
            cmd: Command to execute
            cwd: Working directory inside container
            timeout: Timeout in seconds
            stdin_input: Optional input to send to stdin
            env: Optional environment variables
            shell: Whether to execute through shell (ignored for Docker)
            log_prefix: Prefix for log messages
            stream_output: Stream output in real-time
            output_callback: Callback for each output line
            **kwargs: Additional parameters (e.g., start=True to auto-start container)

        Returns:
            ProcessResult with execution details

        Raises:
            RuntimeError: If command execution fails or container not started
        """
        # Validate that container is started
        if not self.container_id:
            raise RuntimeError(
                f"Cannot run command in Docker sandbox for instance '{self.get_instance_id()}': "
                f"container not started. Call start() first."
            )

        # Phase 3.4: Pass container_id directly via kwargs instead of env_config
        # Filter out parameters that are already explicitly passed to avoid conflicts
        from ee_bench_core.core.utils.dict_utils import exclude_keys

        filtered_kwargs = exclude_keys(
            kwargs,
            "cmd", "cwd", "timeout", "stdin_input", "env", "shell",
            "log_prefix", "container_id", "stream_output", "output_callback",
            "env_config",  # Don't pass env_config since we're passing container_id directly
        )

        return self._process_manager.run_command(
            cmd=cmd,
            cwd=cwd,
            timeout=timeout,
            stdin_input=stdin_input,
            env=env,
            shell=shell,
            log_prefix=log_prefix,
            container_id=self.container_id,  # Pass container_id directly
            stream_output=stream_output,
            output_callback=output_callback,
            **filtered_kwargs,
        )

    def open_interactive_shell(
        self,
        working_dir: Optional[Union[str, Path]] = None,
        **kwargs,
    ) -> ProcessResult:
        """Open an interactive shell inside the Docker container.

        Phase 3.4: Passes container_id directly instead of via env_config.

        Args:
            working_dir: Optional working directory inside container
            **kwargs: Additional parameters (e.g., start=True to auto-start container)

        Returns:
            ProcessResult with shell exit code

        Raises:
            RuntimeError: If shell cannot be opened
        """
        # Validate that container is started
        if not self.container_id:
            raise RuntimeError(
                f"Cannot open shell in Docker sandbox for instance '{self.get_instance_id()}': "
                f"container not started. Call start() first."
            )

        # Phase 3.4: Pass container_id directly via kwargs instead of env_config
        return self._process_manager.open_interactive_shell(
            working_dir=working_dir, container_id=self.container_id, **kwargs
        )

    def cleanup(self, **kwargs) -> None:
        """Clean up the Docker sandbox completely.

        Stops and removes the container, and optionally removes the image.
        Phase 3.3: Implements cleanup logic directly instead of delegating to ProcessManager.

        Args:
            **kwargs: Additional parameters:
                     - keep_images: If True, don't remove Docker images (default: False)

        Raises:
            RuntimeError: If cleanup fails
        """
        # Import here to avoid circular dependency
        from ..sandbox_base import SandboxStatus

        instance_id = self.get_instance_id()
        keep_images = kwargs.get("keep_images", False)

        logger.info(f"Cleaning up Docker sandbox for instance '{instance_id}'")

        self._set_status(SandboxStatus.CLEANING)

        try:
            # Stop and remove container if exists
            if self.container_id:
                try:
                    logger.debug(f"Stopping container: {self.container_id}")
                    self.docker.stop_container(self.container_id, timeout=10)
                    logger.debug(f"Stopped container: {self.container_id}")
                except Exception as e:
                    logger.debug(
                        f"Could not stop container {self.container_id} (may already be stopped): {e}"
                    )

                try:
                    logger.info(f"Removing container: {self.container_id}")
                    self.docker.remove_container(self.container_id, force=True)
                    logger.info(f"Removed container: {self.container_id}")
                except Exception as e:
                    logger.warning(f"Failed to remove container {self.container_id}: {e}")
                    raise RuntimeError(
                        f"Failed to cleanup Docker container {self.container_id}: {e}"
                    )

                self.container_id = None
            else:
                logger.debug(
                    f"No container_id found for instance '{instance_id}', skipping container cleanup"
                )

            # Optionally remove image
            image_name = getattr(self.env_config, "image_name", None)
            if image_name and not keep_images:
                try:
                    logger.info(f"Removing Docker image: {image_name}")
                    self.docker.remove_image(image_name, force=True)
                    logger.info(f"Removed Docker image: {image_name}")
                except Exception as e:
                    logger.debug(
                        f"Could not remove image {image_name} (may be in use or already removed): {e}"
                    )

            logger.info(f"Docker sandbox cleaned up for instance '{instance_id}'")
            self._set_status(SandboxStatus.CLEANED)

        except Exception as e:
            logger.error(f"Failed to cleanup Docker sandbox for instance '{instance_id}': {e}")
            self._set_status(SandboxStatus.ERROR)
            raise

    @staticmethod
    def cleanup_ephemeral_container(
        container_id: str, docker_adapter: Optional[DockerAdapter] = None
    ) -> None:
        """Clean up an ephemeral Docker container by ID.

        This is a utility method for cleaning up containers that were created
        outside of a Sandbox context (e.g., ephemeral containers for ad-hoc evaluation).

        Args:
            container_id: ID of the container to clean up
            docker_adapter: Optional DockerAdapter instance (creates new if None)

        Raises:
            RuntimeError: If cleanup fails
        """
        logger.info(f"Cleaning up ephemeral container: {container_id}")

        if docker_adapter is None:
            docker_adapter = DockerAdapter()

        try:
            docker_adapter.stop_container(container_id)
            docker_adapter.remove_container(container_id)
            logger.info(f"Removed ephemeral container: {container_id}")
        except Exception as e:
            logger.warning(f"Failed to cleanup ephemeral container {container_id}: {e}")
            raise RuntimeError(
                f"Failed to cleanup ephemeral container {container_id}: {e}"
            )
