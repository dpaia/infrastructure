"""Predictions collector plugin registry for dynamic collector discovery and registration.

This module provides a registry system for predictions collectors that allows:
- Registering collectors by name (programmatically or via decorator)
- Discovering collectors from entry points (plugins)
- Retrieving collector factories by name
- Listing all available collectors with metadata
"""

import logging
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

from .predictions_collector import PredictionsCollector
from .eval.base_plugin_registry import (
    BasePluginRegistry,
    PluginMetadata,
    create_global_registry_accessors,
)
from .config import get_config

logger = logging.getLogger(__name__)


@dataclass
class CollectorMetadata(PluginMetadata[PredictionsCollector]):
    """Metadata about a registered predictions collector.

    Attributes:
        name: Unique identifier for the collector
        factory: Factory function or class that creates the collector
        description: Human-readable description
        version: Version string (e.g., "1.0.0")
        author: Author or organization name
        tags: List of tags for categorization (e.g., ["git", "agent", "json"])
        specs: List of spec names this collector applies to (empty = all specs)
        entry_point: Entry point name if loaded from plugin (None if programmatic)
        trigger_modes: List of trigger modes (e.g., ["gold", "agent", "diff"])
    """

    trigger_modes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict:
        """Convert metadata to dictionary for serialization."""
        base_dict = super().to_dict()
        base_dict["trigger_modes"] = self.trigger_modes
        return base_dict


class PredictionsCollectorRegistry(BasePluginRegistry[PredictionsCollector]):
    """Registry for predictions collector plugins with support for multiple collectors per name.

    The registry allows:
    1. Programmatic registration via register() or @register_collector decorator
    2. Automatic discovery from entry points (ee_bench.collectors)
    3. Retrieval of collector factories by name (with priority and applicability checks)
    4. Listing all available collectors with metadata
    5. Multiple collectors can be registered with the same name

    When multiple collectors share a name, get() will:
    - Sort them by priority (highest first)
    - Check is_applicable() for each (if spec/env_config provided)
    - Return the first applicable collector

    Example:
        >>> registry = PredictionsCollectorRegistry()
        >>>
        >>> # Register programmatically
        >>> registry.register(
        ...     name="agent",
        ...     factory=AgentPredictionsCollector,
        ...     description="Agent-based predictions"
        ... )
        >>>
        >>> # Register another with same name but different priority
        >>> registry.register(
        ...     name="agent",
        ...     factory=AgentCodeCollector,
        ...     description="Agent code predictions"
        ... )
        >>>
        >>> # Get collector (returns highest priority applicable one)
        >>> factory = registry.get("agent", spec=spec, env_config=env_config)
        >>> collector = factory()
    """

    def __init__(self, auto_discover: bool = False):
        """Initialize registry with multi-collector support."""
        # Override parent's _plugins to store lists of collectors
        # Dict[str, List[CollectorMetadata]]
        self._multi_plugins: Dict[str, List[CollectorMetadata]] = {}
        # Call parent init but we'll use our own storage
        super().__init__(auto_discover=auto_discover)

    def _get_plugin_type_name(self) -> str:
        """Get the name of this plugin type for logging and error messages."""
        return "predictions collector"

    def _is_plugin_enabled(self, name: str) -> bool:
        """Check if collector should be enabled based on configuration."""
        # For now, collectors are not in disabled lists
        # Can extend config to support disabling collectors if needed
        return True

    def _get_metadata_attributes(self) -> Dict[str, str]:
        """Get attribute names for extracting collector metadata from factories."""
        return {
            "name": "__collector_name__",
            "description": "__collector_description__",
            "version": "__collector_version__",
            "author": "__collector_author__",
            "tags": "__collector_tags__",
            "specs": "__collector_specs__",
            "trigger_modes": "__collector_trigger_modes__",
        }

    def _create_metadata(
        self,
        name: str,
        factory: Callable[..., PredictionsCollector],
        description: str,
        version: str,
        author: str,
        tags: List[str],
        specs: List[str],
        entry_point: Optional[str] = None,
        **kwargs,
    ) -> CollectorMetadata:
        """Create collector-specific metadata instance."""
        trigger_modes = kwargs.get("trigger_modes", [])
        return CollectorMetadata(
            name=name,
            factory=factory,
            description=description,
            version=version,
            author=author,
            tags=tags,
            trigger_modes=trigger_modes,
            specs=specs,
            entry_point=entry_point,
        )

    def _extract_extra_metadata(
        self, factory: Callable, attr_map: Dict[str, str]
    ) -> Dict:
        """Extract collector-specific metadata fields."""
        return {
            "trigger_modes": getattr(
                factory,
                attr_map.get("trigger_modes", "__collector_trigger_modes__"),
                [],
            )
        }

    def register_collector(
        self,
        name: str,
        description: str = "",
        version: str = "1.0.0",
        author: str = "",
        tags: Optional[List[str]] = None,
        trigger_modes: Optional[List[str]] = None,
        specs: Optional[List[str]] = None,
        replace: bool = False,
    ):
        """Decorator for registering collector classes.

        Args:
            name: Unique identifier for the collector
            description: Human-readable description
            version: Version string
            author: Author or organization name
            tags: List of tags for categorization
            trigger_modes: List of trigger modes (e.g., ["gold", "agent"])
            specs: List of spec names this collector applies to (empty = all specs)
            replace: If True, replace existing registration

        Returns:
            Decorator function that registers the class

        Example:
            >>> registry = PredictionsCollectorRegistry()
            >>>
            >>> @registry.register_collector(
            ...     name="custom_collector",
            ...     description="Custom collector",
            ...     tags=["custom"],
            ...     trigger_modes=["custom"],
            ...     specs=["jvm"]
            ... )
            ... class CustomCollector(PredictionsCollector):
            ...     def collect(self, ...):
            ...         pass
        """
        return self.register_plugin(
            name=name,
            description=description,
            version=version,
            author=author,
            tags=tags,
            specs=specs,
            replace=replace,
            trigger_modes=trigger_modes,
        )

    def register(
        self,
        name: str,
        factory: Callable[..., PredictionsCollector],
        description: str = "",
        version: str = "1.0.0",
        author: str = "",
        tags: Optional[List[str]] = None,
        specs: Optional[List[str]] = None,
        replace: bool = False,
        **kwargs,
    ) -> None:
        """Register a predictions collector.

        Unlike the base class, this allows multiple collectors with the same name.
        When replace=True, removes all existing collectors with that name first.

        Args:
            name: Collector identifier (multiple collectors can share this name)
            factory: Factory function or class
            description: Description
            version: Version string
            author: Author name
            tags: Tags for categorization
            specs: Applicable spec names
            replace: If True, replace all existing collectors with this name
            **kwargs: Additional metadata fields (e.g., trigger_modes)
        """
        # Check if disabled
        if not self._is_plugin_enabled(name):
            logger.info(
                f"Predictions collector '{name}' is disabled, skipping registration"
            )
            return

        # Create metadata
        metadata = self._create_metadata(
            name=name,
            factory=factory,
            description=description,
            version=version,
            author=author,
            tags=tags or [],
            specs=specs or [],
            entry_point=None,
            **kwargs,
        )

        # If replace=True, remove all existing collectors with this name
        if replace and name in self._multi_plugins:
            logger.info(f"Replacing all collectors with name '{name}'")
            self._multi_plugins[name] = []

        # Add to multi-collector storage
        if name not in self._multi_plugins:
            self._multi_plugins[name] = []

        self._multi_plugins[name].append(metadata)
        logger.debug(
            f"Registered collector '{name}' (total with this name: {len(self._multi_plugins[name])})"
        )

        # Also register in parent's _plugins dict for compatibility (use first one)
        if name not in self._plugins or replace:
            self._plugins[name] = metadata

    def get(
        self, name: str, spec=None, env_config=None, **kwargs
    ) -> Callable[..., PredictionsCollector]:
        """Get collector factory by name with priority and applicability checks.

        When multiple collectors share a name:
        1. Sort by priority (highest first)
        2. If spec/env_config provided, check is_applicable() for each
        3. Return first applicable collector
        4. If no spec/env_config, return highest priority collector

        Args:
            name: Collector name
            spec: Optional spec for applicability check
            env_config: Optional env config for applicability check
            **kwargs: Additional parameters for is_applicable check

        Returns:
            Collector factory class/function

        Raises:
            KeyError: If no collector found with given name
            ValueError: If no applicable collector found when spec/env_config provided

        Examples:
            # Get with applicability check
            factory = registry.get("agent", spec=jvm_spec, env_config=env_config, agent="claude")

            # Get highest priority (no applicability check)
            factory = registry.get("agent")
        """
        if name not in self._multi_plugins:
            raise KeyError(f"Predictions collector '{name}' not found in registry")

        collectors = self._multi_plugins[name]

        # Sort by priority (highest first), then by description for stability
        sorted_collectors = sorted(
            collectors,
            key=lambda m: (-getattr(m.factory, "priority", 0), m.description),
        )

        # If spec/env_config provided, check applicability
        if spec is not None or env_config is not None:
            for metadata in sorted_collectors:
                try:
                    if metadata.factory.is_applicable(spec, env_config, **kwargs):
                        logger.debug(
                            f"Selected collector '{name}': {metadata.description} "
                            f"(priority={getattr(metadata.factory, 'priority', 0)})"
                        )
                        return metadata.factory
                except Exception as e:
                    logger.warning(
                        f"Error checking applicability of '{name}' "
                        f"({metadata.description}): {e}"
                    )
                    continue

            # No applicable collector found
            raise ValueError(
                f"No applicable collector found for '{name}' with given parameters. "
                f"Tried {len(sorted_collectors)} collector(s)."
            )

        # No applicability check - return highest priority
        selected = sorted_collectors[0]
        logger.debug(
            f"Selected collector '{name}' (highest priority): {selected.description}"
        )
        return selected.factory

    def list(self) -> List[str]:
        """List all unique collector names.

        Returns:
            List of collector names (deduplicated)
        """
        return list(self._multi_plugins.keys())

    def list_all_variants(self, name: Optional[str] = None) -> List[CollectorMetadata]:
        """List all collector variants.

        Args:
            name: Optional name filter. If provided, returns only collectors with that name.

        Returns:
            List of all collector metadata objects (including multiple per name)
        """
        if name:
            return self._multi_plugins.get(name, [])

        result = []
        for collectors in self._multi_plugins.values():
            result.extend(collectors)
        return result

    def discover_plugins(self, group: str = "ee_bench.collectors") -> int:
        """Discover and register collectors from entry points.

        This method scans for entry points in the specified group and loads
        collector factories from them. Entry points should be defined in
        pyproject.toml or setup.py:

        [project.entry-points."ee_bench.collectors"]
        my_collector = "my_package.collectors:MyCollector"

        Args:
            group: Entry point group name (default: "ee_bench.collectors")

        Returns:
            Number of collectors discovered and registered
        """
        # Override parent to use our register() method that populates _multi_plugins
        import logging
        from importlib.metadata import entry_points

        logger = logging.getLogger(__name__)
        count = 0
        plugin_type = self._get_plugin_type_name()

        try:
            eps = entry_points(group=group)
        except TypeError:
            eps = entry_points().get(group, [])

        attr_map = self._get_metadata_attributes()

        for ep in eps:
            try:
                factory = ep.load()
                name = getattr(factory, attr_map.get("name", "__collector_name__"), ep.name)

                # Extract metadata
                description = getattr(factory, attr_map.get("description", "__collector_description__"), "")
                version = getattr(factory, attr_map.get("version", "__collector_version__"), "1.0.0")
                author = getattr(factory, attr_map.get("author", "__collector_author__"), "")
                tags = getattr(factory, attr_map.get("tags", "__collector_tags__"), [])
                specs = getattr(factory, attr_map.get("specs", "__collector_specs__"), [])
                trigger_modes = getattr(factory, attr_map.get("trigger_modes", "__collector_trigger_modes__"), [])

                # Use our register() method to properly populate both _plugins and _multi_plugins
                self.register(
                    name=name,
                    factory=factory,
                    description=description,
                    version=version,
                    author=author,
                    tags=tags,
                    specs=specs,
                    trigger_modes=trigger_modes,
                )
                count += 1

                spec_info = f" (specs: {', '.join(specs)})" if specs else " (all specs)"
                logger.info(
                    f"Discovered {plugin_type} '{name}' from entry point '{ep.name}'{spec_info}"
                )

            except Exception as e:
                logger.error(
                    f"Failed to load {plugin_type} from entry point '{ep.name}': {e}",
                    exc_info=True,
                )

        logger.info(f"Discovered {count} {plugin_type}s from entry points")
        return count


# Global registry accessor functions created using the factory pattern
# This eliminates code duplication across multiple registry types
(
    get_global_registry,
    _register_plugin_generic,
    list_collectors,
) = create_global_registry_accessors(PredictionsCollectorRegistry)


def register_collector(
    name: str,
    description: str = "",
    version: str = "1.0.0",
    author: str = "",
    tags: Optional[List[str]] = None,
    trigger_modes: Optional[List[str]] = None,
    specs: Optional[List[str]] = None,
    replace: bool = False,
):
    """Decorator for registering collectors in the global registry.

    This is a convenience function that uses the global registry.

    Args:
        name: Unique identifier for the collector
        description: Human-readable description
        version: Version string
        author: Author or organization name
        tags: List of tags for categorization
        trigger_modes: List of trigger modes for this collector
        specs: List of spec names this collector applies to (empty = all specs)
        replace: If True, replace existing registration

    Returns:
        Decorator function

    Example:
        >>> @register_collector(
        ...     name="my_collector",
        ...     description="My custom collector",
        ...     tags=["custom"],
        ...     trigger_modes=["custom"],
        ...     specs=["jvm"]
        ... )
        ... class MyCollector(PredictionsCollector):
        ...     pass
    """
    registry = get_global_registry()
    return registry.register_collector(
        name=name,
        description=description,
        version=version,
        author=author,
        tags=tags,
        trigger_modes=trigger_modes,
        specs=specs,
        replace=replace,
    )
