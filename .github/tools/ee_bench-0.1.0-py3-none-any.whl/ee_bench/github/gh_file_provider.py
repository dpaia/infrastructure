"""GhFileProvider — generic GitHub file fetcher with configurable file list."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from jinja2 import Environment, StrictUndefined

from ee_bench.generator import FileSpec, Provider
from ee_bench.generator.errors import ProviderError

logger = logging.getLogger(__name__)


class GhFileProvider(Provider):
    """Provider that fetches files from a GitHub repository.

    Configurable ``files`` list: each entry has a ``path`` (template)
    and ``field`` (output field name).  Supports both GitHub API
    fetching and local filesystem reads.
    """

    def __init__(self, **kwargs: Any) -> None:
        self._files_config: list[dict[str, str]] = []
        self._field_to_path: dict[str, str] = {}
        self._repo: Any = None
        self._local_root: Path | None = None
        self._jinja_env = Environment(undefined=StrictUndefined)
        self._content_cache: dict[tuple[str, str], str] = {}
        if kwargs:
            self.prepare(**kwargs)

    def prepare(self, **options: Any) -> None:
        """Prepare provider with GitHub repo and file configuration.

        Options:
            repo: Source GitHub repo (e.g., ``scaleapi/SWE-bench_Pro-os``).
            github_token: GitHub PAT for API access.
            local_path: Local filesystem path to repo clone (skips GitHub API).
            files: List of dicts with ``path`` and ``field`` keys.
        """
        self._files_config = options.get("files", [])
        local_path = options.get("local_path", "")

        if local_path:
            self._local_root = Path(local_path)
            if not self._local_root.is_dir():
                raise ProviderError(
                    f"GhFileProvider local_path '{local_path}' is not a directory"
                )
            logger.info(
                "GhFileProvider: configured %d files from local path %s",
                len(self._files_config),
                local_path,
            )
        else:
            from github import Github
            from urllib3.util.retry import Retry

            repo_name = options.get("repo", "")
            github_token = options.get("github_token", "")

            if not repo_name:
                raise ProviderError("GhFileProvider requires 'repo' or 'local_path' option")

            # Disable retries on rate limit (403) to fail fast instead of blocking
            retry = Retry(total=3, status_forcelist=[500, 502, 503, 504])
            gh = Github(github_token, retry=retry) if github_token else Github(retry=retry)
            self._repo = gh.get_repo(repo_name)

            logger.info(
                "GhFileProvider: configured %d files from %s",
                len(self._files_config),
                repo_name,
            )

        # Build field → path template mapping
        self._field_to_path = {}
        for entry in self._files_config:
            self._field_to_path[entry["field"]] = entry["path"]

        self._content_cache.clear()

    def checkout(self, local_path: str | Path) -> None:
        """Set local filesystem root for file reads.

        If *local_path* is empty / falsy the call is a no-op so that
        callers can pass an optional env-var without extra guards.
        """
        if not local_path:
            return
        self._local_root = Path(local_path)
        if not self._local_root.is_dir():
            raise ProviderError(
                f"GhFileProvider local_path '{local_path}' is not a directory"
            )

    def provide(self, item=None, *, files=None, **kwargs) -> dict[str, str]:
        """Fetch files and return field->content mapping.

        Args:
            item: Item dict with fields for path template rendering.
            files: List of FileSpec objects or dicts with path/field keys.
                   Overrides prepare-time files config if provided.
            **kwargs: Ignored.

        Returns:
            Dict mapping field names to file contents.
        """
        item = item or {}
        result: dict[str, str] = {}

        # Determine which files to fetch
        file_specs: list[dict[str, str]] = []
        if files:
            for f in files:
                if isinstance(f, FileSpec):
                    file_specs.append({"path": f.path, "field": f.field})
                else:
                    file_specs.append(f)
        else:
            file_specs = self._files_config

        for spec in file_specs:
            field = spec["field"]
            path_template = spec["path"]

            instance_id = item.get("instance_id", "")
            cache_key = (instance_id, field)
            if cache_key in self._content_cache:
                result[field] = self._content_cache[cache_key]
                continue

            # Resolve path template
            resolved_path = self._resolve_path(path_template, item)
            content = self._fetch_file(resolved_path)
            self._content_cache[cache_key] = content
            result[field] = content

        return result

    def _resolve_path(self, path_template: str, item: dict[str, Any]) -> str:
        """Resolve a path template using item fields."""
        if "{{" in path_template:
            try:
                tmpl = self._jinja_env.from_string(path_template)
                return tmpl.render(**item)
            except Exception as e:
                logger.warning("Failed to render path template '%s': %s", path_template, e)
                return ""
        # Try Python f-string style interpolation
        try:
            return path_template.format(**item)
        except (KeyError, IndexError):
            return path_template

    def _fetch_file(self, path: str) -> str:
        """Fetch a single file's content from GitHub or local filesystem."""
        if self._local_root is not None:
            return self._fetch_local(path)
        return self._fetch_github(path)

    def _fetch_local(self, path: str) -> str:
        """Read file content from local filesystem."""
        file_path = self._local_root / path
        try:
            return file_path.read_text(encoding="utf-8")
        except FileNotFoundError:
            logger.warning("Local file not found: '%s'", file_path)
            return ""
        except Exception as e:
            logger.warning("Failed to read local file '%s': %s", file_path, e)
            return ""

    def _fetch_github(self, path: str) -> str:
        """Fetch file content from GitHub API."""
        try:
            file_content = self._repo.get_contents(path)
            if isinstance(file_content, list):
                logger.warning("Path '%s' is a directory, not a file", path)
                return ""
            return file_content.decoded_content.decode("utf-8")
        except Exception as e:
            logger.warning("Failed to fetch '%s': %s", path, e)
            return ""
