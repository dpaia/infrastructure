"""HuggingFace dataset provider implementation."""

from __future__ import annotations

import hashlib
import json
import re
from typing import Any, Iterator

from ee_bench.generator import Filter, Provider
from ee_bench.generator.errors import ProviderError

# Supported filter operators and their match functions.
# Each takes (field_value, filter_arg) and returns bool.
_FILTER_OPS: dict[str, Any] = {
    "eq": lambda v, arg: str(v) == str(arg),
    "not_eq": lambda v, arg: str(v) != str(arg),
    "in": lambda v, arg: str(v) in [str(a) for a in arg],
    "not_in": lambda v, arg: str(v) not in [str(a) for a in arg],
    "contains": lambda v, arg: str(arg) in str(v),
    "not_contains": lambda v, arg: str(arg) not in str(v),
    "regex": lambda v, arg: bool(re.search(str(arg), str(v))),
    "startswith": lambda v, arg: str(v).startswith(str(arg)),
    "endswith": lambda v, arg: str(v).endswith(str(arg)),
}


def _compile_filters(raw: dict[str, Any]) -> list[tuple[str, str, Any]]:
    """Compile a filters dict into a list of (field, operator, argument) tuples.

    Supports two syntaxes per field:
      - Shorthand:  ``field: value``  → ``eq`` match
      - Advanced:   ``field: {op: arg, ...}``  → one tuple per operator

    Returns:
        List of (field_name, operator, argument) tuples.

    Raises:
        ProviderError: If an unknown operator is used.
    """
    compiled: list[tuple[str, str, Any]] = []
    for field, spec in raw.items():
        if isinstance(spec, dict):
            for op, arg in spec.items():
                if op not in _FILTER_OPS:
                    raise ProviderError(
                        f"Unknown filter operator '{op}' for field '{field}'. "
                        f"Supported: {sorted(_FILTER_OPS)}"
                    )
                compiled.append((field, op, arg))
        else:
            # Shorthand: scalar value → eq
            compiled.append((field, "eq", spec))
    return compiled


def _compile_filter_objects(filters: list[Filter]) -> list[tuple[str, str, Any]]:
    """Compile a list of Filter dataclass objects into compiled filter tuples."""
    compiled: list[tuple[str, str, Any]] = []
    for f in filters:
        if f.eq is not None:
            compiled.append((f.field, "eq", f.eq))
        if f.contains is not None:
            compiled.append((f.field, "contains", f.contains))
        if f.in_ is not None:
            compiled.append((f.field, "in", f.in_))
    return compiled


def _row_matches(row: dict[str, Any], compiled: list[tuple[str, str, Any]]) -> bool:
    """Check whether a dataset row satisfies all compiled filter conditions."""
    for field, op, arg in compiled:
        value = row.get(field, "")
        if not _FILTER_OPS[op](value, arg):
            return False
    return True


class HuggingFaceDatasetProvider(Provider):
    """Provider that reads data from HuggingFace datasets.

    Dynamically discovers dataset columns and exposes them as provider fields.
    Works with any dataset on HuggingFace Hub (e.g., ScaleAI/SWE-bench_Pro).
    """

    def __init__(self, **kwargs: Any) -> None:
        self._dataset = None
        self._options: dict[str, Any] = {}
        self._column_names: list[str] = []
        self._compiled_filters: list[tuple[str, str, Any]] = []
        if kwargs:
            self.prepare(**kwargs)

    def prepare(self, **options: Any) -> None:
        """Prepare the provider by loading the dataset.

        Args:
            **options: Provider options including:
                - dataset_name: HuggingFace dataset ID (e.g., "ScaleAI/SWE-bench_Pro")
                - dataset_path: Local file path (alternative to dataset_name)
                - split: Dataset split (default: "test")
                - hf_token: HuggingFace API token for gated datasets
                - filters: Generic filter dict (see below)
                - filter_repos: (legacy) List of repos to include
                - exclude_repos: (legacy) List of repos to exclude
                - filter_language: (legacy) Filter by repo_language field
        """
        self._options = options

        dataset_name = options.get("dataset_name")
        dataset_path = options.get("dataset_path")
        split = options.get("split", "test")
        hf_token = options.get("hf_token")

        if not dataset_name and not dataset_path:
            raise ProviderError(
                "Either 'dataset_name' or 'dataset_path' must be provided"
            )

        try:
            from datasets import load_dataset
        except ImportError:
            raise ProviderError(
                "The 'datasets' package is required. Install with: pip install datasets>=2.20"
            )

        # Treat empty string token as None (from ${HF_TOKEN:-} when env var is unset)
        if hf_token is not None and not hf_token.strip():
            hf_token = None

        try:
            if dataset_path:
                ds = load_dataset("json", data_files=dataset_path, split=split)
            else:
                load_kwargs: dict[str, Any] = {"split": split}
                if hf_token:
                    load_kwargs["token"] = hf_token
                ds = load_dataset(dataset_name, **load_kwargs)
        except Exception as e:
            raise ProviderError(f"Failed to load dataset: {e}")

        self._dataset = ds
        self._column_names = list(ds.column_names)

        # Compile filters from prepare options
        self._compiled_filters = self._build_filters(options)

    @staticmethod
    def _build_filters(options: dict[str, Any]) -> list[tuple[str, str, Any]]:
        """Build compiled filter list from options, merging generic and legacy."""
        filters_raw: dict[str, Any] = dict(options.get("filters") or {})

        # Convert legacy options into generic filter entries
        filter_language = options.get("filter_language")
        if filter_language:
            filters_raw.setdefault("repo_language", filter_language)

        filter_repos = options.get("filter_repos")
        if filter_repos:
            existing = filters_raw.get("repo")
            if isinstance(existing, dict):
                existing.setdefault("in", filter_repos)
            else:
                filters_raw.setdefault("repo", {"in": filter_repos})

        exclude_repos = options.get("exclude_repos")
        if exclude_repos:
            existing = filters_raw.get("repo")
            if isinstance(existing, dict):
                existing.setdefault("not_in", exclude_repos)
            else:
                filters_raw.setdefault("repo", {"not_in": exclude_repos})

        if not filters_raw:
            return []

        return _compile_filters(filters_raw)

    def provide(
        self, item=None, *, filters=None, limit=None, **kwargs
    ) -> Iterator[dict[str, Any]]:
        """Yield dataset rows as dicts, optionally filtered and limited.

        Args:
            item: Ignored (this is a primary provider).
            filters: Optional list of Filter objects or a raw filter dict.
            limit: Maximum number of items to yield.
            **kwargs: Ignored.

        Yields:
            Dataset rows as dictionaries with all column values plus 'checksum'.
        """
        if self._dataset is None:
            raise ProviderError("Provider not prepared. Call prepare() first.")

        # Merge prepare-time filters with per-call filters
        compiled = list(self._compiled_filters)
        if filters:
            if isinstance(filters, list):
                compiled.extend(_compile_filter_objects(filters))
            elif isinstance(filters, dict):
                compiled.extend(_compile_filters(filters))

        count = 0
        for i in range(len(self._dataset)):
            if limit is not None and count >= limit:
                return

            row = self._dataset[i]

            if compiled and not _row_matches(row, compiled):
                continue

            result = dict(row)
            result["checksum"] = self._compute_checksum(result)
            yield result
            count += 1

    @staticmethod
    def _compute_checksum(row: dict[str, Any]) -> str:
        """Compute SHA-256 checksum of a serialized row."""
        serialized = json.dumps(row, sort_keys=True, ensure_ascii=False)
        return hashlib.sha256(serialized.encode("utf-8")).hexdigest()
