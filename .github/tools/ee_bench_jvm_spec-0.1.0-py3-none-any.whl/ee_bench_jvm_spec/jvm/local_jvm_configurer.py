"""Local JVM configurer for verifying JVM installation on the host system."""

import logging
import shutil
import subprocess
from pathlib import Path

from ee_bench_code_spec.local_env_config import CodeLocalEnvironmentConfig
from ee_bench_core.core import DependencyPosition
from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig
from ee_bench_core.core.errors import EnvironmentError
from ee_bench_core.core.eval import EnvironmentConfigurer

logger = logging.getLogger(__name__)


class LocalJvmConfigurer(EnvironmentConfigurer):
    """Configurer that verifies JVM installation on local system.

    This configurer checks that Java/JDK is installed on the host system
    and sets JAVA_HOME in env_vars if not already set.

    For local execution, the user must have JDK installed on their system.
    This configurer verifies the installation and sets up environment variables.

    Metadata:
        name: local_jvm
        priority: 10 (runs after JvmLocalEnvironmentInitializer)
        dependencies: after jvm_local_environment_initializer
        specs: ["jvm"]
    """

    __configurer_name__ = "local_jvm"
    __configurer_description__ = "Verifies local JVM installation"
    __configurer_version__ = "1.0.0"
    __configurer_specs__ = ["jvm"]

    def __init__(self, required_version: str | None = None, **kwargs):
        """Initialize local JVM configurer.

        Args:
            required_version: Optional required JVM version (e.g., "17", "21")
            **kwargs: Additional parameters
        """
        self.required_version = required_version

    @property
    def name(self) -> str:
        """Return configurer name."""
        return "local_jvm"

    @property
    def description(self) -> str:
        """Return configurer description."""
        return "Verifies local JVM installation and sets JAVA_HOME"

    @property
    def specs(self) -> list[str] | None:
        """Return specs this configurer applies to."""
        return ["jvm"]

    @property
    def dependencies(self) -> list[str] | DependencyPosition | None:
        """Return dependency specification."""
        return DependencyPosition(after=["jvm_local_environment_initializer"], priority=10)

    def should_configure(
        self,
        spec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        **kwargs,
    ) -> tuple[bool, str | None]:
        """Check if this configurer should run.

        Only runs for local environments.

        Args:
            spec: Evaluation specification
            env_config: Environment configuration
            config: Dataset configuration
            **kwargs: Additional parameters

        Returns:
            Tuple of (should_configure, reason)
        """
        # Only configure local environments
        if not isinstance(env_config, CodeLocalEnvironmentConfig):
            return (
                False,
                f"Not a code local environment (type: {type(env_config).__name__})",
            )

        return True, None

    def configure(
        self,
        spec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        **kwargs,
    ) -> EnvironmentConfig:
        """Verify JVM installation and configure JVM fields.

        Args:
            spec: Evaluation specification
            env_config: Environment configuration (CodeLocalEnvironmentConfig)
            config: Dataset configuration
            **kwargs: Additional parameters

        Returns:
            Updated EnvironmentConfig with JAVA_HOME and java_version set

        Raises:
            EnvironmentError: If JVM is not installed or version is incompatible
        """
        if not isinstance(env_config, CodeLocalEnvironmentConfig):
            return env_config

        logger.info("Verifying local JVM installation")

        # Check if java is available
        java_path = shutil.which("java")
        if not java_path:
            raise EnvironmentError(
                "Java not found in PATH. Please install JDK and ensure it's in your PATH."
            )

        # Get Java version
        try:
            result = subprocess.run(
                ["java", "-version"], capture_output=True, text=True, check=True
            )
            version_output = result.stderr  # java -version outputs to stderr
            logger.debug(f"Java version output: {version_output}")
        except subprocess.CalledProcessError as e:
            raise EnvironmentError(f"Failed to get Java version: {e}")

        # Parse version (looking for patterns like "17.0.1", "21.0.2", etc.)
        import re

        version_match = re.search(r'version "(\d+)\.', version_output)
        if not version_match:
            # Try newer format: version "21" or "21.0.1"
            version_match = re.search(r'version "(\d+)', version_output)

        if not version_match:
            logger.warning(f"Could not parse Java version from: {version_output}")
            java_version = "unknown"
        else:
            java_version = version_match.group(1)

        logger.info(f"Found Java version: {java_version} at {java_path}")

        # Find JAVA_HOME if not already set
        java_home = env_config.env_vars.get("JAVA_HOME")
        if not java_home:
            # Try to determine JAVA_HOME from java executable path
            java_home = self._find_java_home(java_path)
            if java_home:
                logger.info(f"Detected JAVA_HOME: {java_home}")
            else:
                logger.warning("Could not automatically detect JAVA_HOME")

        # Update env_vars (for compatibility/runtime use)
        if java_home:
            env_config.env_vars["JAVA_HOME"] = java_home
        env_config.env_vars["JAVA_VERSION"] = java_version

        # Also store in config attributes if it's JvmCodeLocalEnvironmentConfig
        # (this will be used for serialization/tracking)
        from .jvm_local_env_config import JvmCodeLocalEnvironmentConfig

        if isinstance(env_config, JvmCodeLocalEnvironmentConfig):
            if java_home:
                env_config.java_home = Path(java_home)
            env_config.java_version = java_version

        # Verify version if required
        if self.required_version:
            if java_version != self.required_version and java_version != "unknown":
                raise EnvironmentError(
                    f"Java version {java_version} does not match required version {self.required_version}"
                )

        logger.info(f"Local JVM configuration complete: Java {java_version}")

        return env_config

    def _find_java_home(self, java_path: str) -> str | None:
        """Attempt to find JAVA_HOME from java executable path.

        Args:
            java_path: Path to java executable

        Returns:
            JAVA_HOME path or None if not found
        """
        # Try using java executable path
        java_path_obj = Path(java_path).resolve()

        # Common patterns:
        # /usr/lib/jvm/java-17-openjdk/bin/java -> /usr/lib/jvm/java-17-openjdk
        # /usr/local/Cellar/openjdk@17/17.0.1/bin/java -> /usr/local/Cellar/openjdk@17/17.0.1
        # /Library/Java/JavaVirtualMachines/jdk-17.jdk/Contents/Home/bin/java -> .../Contents/Home

        # Go up from bin/java to parent directory
        if java_path_obj.parent.name == "bin":
            potential_home = java_path_obj.parent.parent

            # Check if this looks like JAVA_HOME (has bin, lib directories)
            if (potential_home / "lib").exists():
                return str(potential_home)

            # macOS special case: might be in Contents/Home
            if potential_home.name == "Home" and (potential_home.parent / "MacOS").exists():
                return str(potential_home)

        # Try to use java_home command on macOS
        try:
            result = subprocess.run(
                ["/usr/libexec/java_home"],
                capture_output=True,
                text=True,
                check=True,
                timeout=5,
            )
            return result.stdout.strip()
        except (
            subprocess.CalledProcessError,
            FileNotFoundError,
            subprocess.TimeoutExpired,
        ):
            pass

        return None
