"""Backward-compatible helper utilities using SandboxManager.

This module provides backward-compatible functions that delegate to
SandboxManager. New code should use SandboxManager directly.

Note: These functions use a global SandboxManager instance with auto-generated
instance IDs. For better control over sandbox lifecycle, use SandboxManager directly.
"""

import logging
import uuid
from typing import Callable, Optional, TypeVar

from .sandbox_manager import SandboxManager
from ee_bench_core.core.models import EnvironmentConfig

logger = logging.getLogger(__name__)

T = TypeVar("T")

# Global singleton manager for backward compatibility
_global_manager = SandboxManager()


def with_sandbox(
    env_config: EnvironmentConfig,
    func: Callable[[object], T],
    cleanup: bool = False,
    **kwargs,
) -> T:
    """Execute a function with managed sandbox lifecycle.

    This helper manages the complete sandbox lifecycle:
    1. Create sandbox from env_config
    2. Start sandbox
    3. Execute provided function with sandbox
    4. Stop sandbox (in finally block)
    5. Cleanup sandbox if requested (in finally block)

    Note: Uses global SandboxManager with auto-generated instance ID.
    For better control, use SandboxManager directly.

    Args:
        env_config: Environment configuration to create sandbox from
        func: Function to execute with sandbox (receives sandbox as first argument)
        cleanup: Whether to cleanup sandbox after execution (default: False)
        **kwargs: Additional arguments passed to func

    Returns:
        Result from func

    Raises:
        Exception: Any exception raised by func is propagated after cleanup

    Example:
        >>> def run_tests(sandbox, config):
        ...     result = sandbox.run_command("pytest")
        ...     return result
        >>>
        >>> result = with_sandbox(
        ...     env_config=env_config,
        ...     func=run_tests,
        ...     cleanup=True,
        ...     config=dataset_config
        ... )
    """
    # Generate unique instance ID for this sandbox
    instance_id = f"{env_config.instance_id}_{uuid.uuid4().hex[:8]}"

    return _global_manager.with_sandbox(
        instance_id=instance_id,
        env_config=env_config,
        func=func,
        cleanup=cleanup,
        **kwargs,
    )


def with_sandbox_safe(
    env_config: EnvironmentConfig,
    func: Callable[[object], T],
    cleanup: bool = False,
    default: Optional[T] = None,
    **kwargs,
) -> Optional[T]:
    """Execute a function with managed sandbox lifecycle, catching all exceptions.

    Same as with_sandbox(), but catches all exceptions and returns a default value
    instead of propagating them. Useful for optional operations where failure should
    not abort the entire workflow.

    Args:
        env_config: Environment configuration to create sandbox from
        func: Function to execute with sandbox (receives sandbox as first argument)
        cleanup: Whether to cleanup sandbox after execution (default: False)
        default: Default value to return if execution fails (default: None)
        **kwargs: Additional arguments passed to func

    Returns:
        Result from func, or default if execution failed

    Example:
        >>> result = with_sandbox_safe(
        ...     env_config=env_config,
        ...     func=optional_operation,
        ...     cleanup=True,
        ...     default=None,
        ...     config=dataset_config
        ... )
        >>> if result is None:
        ...     logger.warning("Optional operation failed")
    """
    try:
        return with_sandbox(env_config, func, cleanup=cleanup, **kwargs)
    except Exception as e:
        logger.warning(
            f"Sandbox operation failed for instance '{env_config.instance_id}': {e}"
        )
        return default


def cleanup_sandboxes(
    environments: dict[str, EnvironmentConfig], **kwargs
) -> tuple[int, int]:
    """Clean up multiple sandboxes from environment configurations.

    This utility function creates sandboxes from environment configurations
    and performs cleanup on each one. Useful for bulk cleanup operations.

    Note: Creates a temporary SandboxManager for cleanup operations.

    Args:
        environments: Dictionary mapping instance_id to EnvironmentConfig
        **kwargs: Additional parameters passed to sandbox.cleanup():
                 - keep_images: If True, don't remove Docker images (default: False)
                 - force: Force removal even if resources are in use

    Returns:
        Tuple of (cleanup_count, error_count)

    Example:
        >>> environments = {
        ...     "task-1": env_config_1,
        ...     "task-2": env_config_2,
        ... }
        >>> success, failed = cleanup_sandboxes(environments, keep_images=False)
        >>> logger.info(f"Cleaned up {success} sandboxes, {failed} failures")
    """
    if not environments:
        logger.debug("No environments to cleanup")
        return 0, 0

    # Create temporary manager for bulk cleanup
    manager = SandboxManager()

    logger.info(f"Cleaning up {len(environments)} environment(s)")
    cleanup_count = 0
    error_count = 0

    for instance_id, env_config in environments.items():
        try:
            # Create sandbox
            manager.create_sandbox(instance_id, env_config)
            # Cleanup immediately (no need to start)
            manager.cleanup_sandbox(instance_id, **kwargs)
            manager.remove_sandbox(instance_id)
            cleanup_count += 1
            logger.debug(f"Cleaned up sandbox for instance '{instance_id}'")

        except Exception as e:
            logger.error(f"Failed to cleanup environment for {instance_id}: {e}")
            error_count += 1

    logger.info(f"Cleanup completed: {cleanup_count} cleaned up, {error_count} errors")
    return cleanup_count, error_count


def get_global_manager() -> SandboxManager:
    """Get the global SandboxManager instance.

    Returns:
        Global SandboxManager instance

    Example:
        >>> manager = get_global_manager()
        >>> states = manager.get_all_states()
        >>> print(f"Active sandboxes: {len(manager)}")
    """
    return _global_manager
