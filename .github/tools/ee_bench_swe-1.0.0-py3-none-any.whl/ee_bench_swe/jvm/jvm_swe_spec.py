"""JVM-specific SWE-bench evaluation specification.

This module provides the JVM (Java/Maven/Gradle) implementation of the
SWE-bench specification with automatic build system detection and
appropriate test runner selection.
"""

import logging
from typing import Any, Dict, List, Optional

from ee_bench_core.core.abc_types import (
    DatasetManager,
    EnvironmentManager,
    EvaluationRunner,
    ReportManager
)
from ee_bench_core.core.spec_registry import register_spec
from ee_bench_core.core.models import DatasetConfig, EnvironmentConfig
from ee_bench_core.di.application_container import ApplicationContainer
from ee_bench_swe.swe_spec import SweEvalSpec
from .jvm_swe_config import JvmSweBenchmarkConfig, BuildSystem
from .jvm_swe_dataset import JvmSweDatasetManager
from .jvm_di_container import JvmSweContainer

logger = logging.getLogger(__name__)


@register_spec
class JvmSweEvalSpec(SweEvalSpec):
    """JVM-specific SWE-bench evaluation specification.

    Provides JVM-specific implementation for SWE-bench format evaluations
    including Maven/Gradle build system detection, appropriate test runner
    selection, and JVM-specific environment management.
    """

    def __init__(self, report_manager: Optional[ReportManager] = None):
        """Initialize JVM SWE-bench specification.

        Args:
            report_manager: Optional report manager for tracking evaluation results
        """
        super().__init__(report_manager)

        # Initialize DI containers (using BaseEvalSpec infrastructure)
        self.initialize_containers()

    @property
    def name(self) -> str:
        """Get the canonical name of this specification.

        Returns:
            "swe-jvm"
        """
        return "swe-jvm"

    @property
    def description(self) -> str:
        """Get a human-readable description.

        Returns:
            Description of JVM SWE-bench specification
        """
        return "Software Engineering Benchmark for JVM (Java/Maven/Gradle)"

    # DI Container Methods (override BaseEvalSpec)

    def initialize_containers(self) -> None:
        """Initialize DI containers for JVM SWE-bench specification.

        Creates ApplicationContainer and JvmSweContainer, linking them together.
        """
        self.app_container = ApplicationContainer.create_with_defaults()
        self.container = JvmSweContainer()
        self.container.app.override(self.app_container)

    def get_dataset_manager(self, **kwargs) -> DatasetManager:
        """Create a JVM-specific dataset manager instance.

        Returns JvmSweDatasetManager which returns JvmSweBenchmarkConfig
        instances with JVM-specific fields.

        Args:
            **kwargs: Spec-specific initialization parameters

        Returns:
            JvmSweDatasetManager instance
        """
        return JvmSweDatasetManager(**kwargs)

    def configure_for_evaluation(
        self,
        config: DatasetConfig,
        env_config: EnvironmentConfig,
        **kwargs
    ) -> None:
        """Configure DI container for specific evaluation instance.

        This method should be called before get_evaluation_runner() to set
        runtime configuration based on the task config and environment.

        Args:
            config: Dataset configuration for the task
            env_config: Environment configuration
            **kwargs: Additional parameters including:
                - predictions_path: Path to predictions file or "gold"
                - working_dir: Working directory for dataset manager
                - max_workers: Maximum parallel workers
        """
        # Determine execution mode (local vs docker)
        # Check for either image_name or container_id to determine if using docker
        from ee_bench_swe.swe_env_config import SweEnvironmentConfig
        has_image = isinstance(env_config, SweEnvironmentConfig) and hasattr(env_config, 'image_name') and env_config.image_name
        has_container = hasattr(env_config, 'container_id') and env_config.container_id
        execution_mode = "docker" if (has_image or has_container) else "local"

        # Determine build system
        build_system = self.get_build_system(config)
        build_system_str = build_system.value  # Convert enum to string

        # Determine predictions mode
        predictions_path = kwargs.get('predictions_path')
        predictions_mode = "gold" if not predictions_path or (isinstance(predictions_path, str) and predictions_path.lower() == "gold") else "json"

        # Configure container
        self.container.config.from_dict({
            "execution_mode": execution_mode,
            "build_system": build_system_str,
            "predictions_mode": predictions_mode,
            "predictions_path": predictions_path,
            "working_dir": kwargs.get('working_dir', '.'),
            "max_workers": kwargs.get('max_workers', 1)
        })

        self._configured = True
        logger.debug(
            f"Configured JvmSweContainer: execution_mode={execution_mode}, "
            f"build_system={build_system_str}, predictions_mode={predictions_mode}"
        )

    def get_build_system(self, config: DatasetConfig) -> BuildSystem:
        """Detect build system from configuration.

        Args:
            config: Dataset configuration (should be JvmSweBenchmarkConfig)

        Returns:
            BuildSystem enum (MAVEN or GRADLE)

        Raises:
            ValueError: If config is not a JvmSweBenchmarkConfig or build system cannot be determined
        """
        if not isinstance(config, JvmSweBenchmarkConfig):
            raise ValueError(
                f"config must be a JvmSweBenchmarkConfig, got {type(config).__name__}"
            )

        # Use build_system field if available
        if config.build_system:
            return BuildSystem.from_string(config.build_system.lower())

        # Fall back to is_maven field
        if config.is_maven:
            return BuildSystem.MAVEN
        else:
            return BuildSystem.GRADLE

    def get_environment_manager(
        self,
        config: DatasetConfig,
        **kwargs
    ) -> EnvironmentManager:
        """Create a JVM-specific environment manager instance.

        This method automatically selects the correct environment manager
        (Maven or Gradle) based on the configuration's build_system field.

        Args:
            config: Dataset configuration for the task (should be JvmSweBenchmarkConfig)
            **kwargs: Spec-specific initialization parameters

        Returns:
            MavenEnvironmentManager or GradleEnvironmentManager instance

        Raises:
            ValueError: If config is not a JvmSweBenchmarkConfig
        """
        from .jvm_swe_maven_env import MavenEnvironmentManager
        from .jvm_swe_gradle_env import GradleEnvironmentManager

        # Detect build system
        build_system = self.get_build_system(config)

        # Get Docker adapter and namespace from kwargs
        docker_adapter = kwargs.get('docker_adapter')
        if not docker_adapter:
            # Fallback: create default docker adapter
            from ee_bench_core.adapters.docker import DockerAdapter
            docker_adapter = DockerAdapter()
        namespace = kwargs.get('namespace', self.name)

        # Select environment manager based on build system
        if build_system == BuildSystem.MAVEN:
            logger.debug(f"Using Maven environment manager for {config.instance_id}")
            return MavenEnvironmentManager(docker_adapter, namespace)
        else:
            logger.debug(f"Using Gradle environment manager for {config.instance_id}")
            return GradleEnvironmentManager(docker_adapter, namespace)

    def prepare_environment(
        self,
        dataset_name: str,
        instance_ids: List[str],
        **kwargs
    ):
        """Prepare environments for multiple task instances.

        Overrides base implementation to support filtering when instance_ids is empty.

        Args:
            dataset_name: Name of the dataset
            instance_ids: List of instance IDs to prepare (if empty, uses filters)
            **kwargs: Additional parameters including:
                - filters: Optional dict of filters to apply when instance_ids is empty
                           (e.g., {"language": "java", "repo": "spring-petclinic", "tags": ["bug"]})
                - max_workers: Number of parallel workers
                - Other spec-specific parameters

        Returns:
            EnvironmentPreparationResult
        """
        # If no instance_ids provided, use filters to get list from dataset
        if not instance_ids:
            filters_param = kwargs.get('filters')

            # Parse filters if provided as JSON string
            if filters_param and isinstance(filters_param, str):
                import json
                try:
                    filters = json.loads(filters_param)
                except json.JSONDecodeError as e:
                    raise ValueError(f"Invalid filters JSON: {e}")
            elif isinstance(filters_param, dict):
                filters = filters_param
            else:
                filters = None

            # Get dataset manager and list instances with filters
            working_dir = kwargs.get('working_dir', '.')
            dataset_manager = self.get_dataset_manager(working_dir=working_dir)

            # List all instances matching filters
            configs = dataset_manager.list_dataset_instances(
                dataset_name=dataset_name,
                filters=filters
            )

            # Extract instance IDs
            instance_ids = [config.instance_id for config in configs]

            if filters:
                logger.info(f"Applied filters {filters}, found {len(instance_ids)} matching instances")
            else:
                logger.info(f"No filters provided, found {len(instance_ids)} total instances in dataset")

        # Call parent implementation with resolved instance_ids
        return super().prepare_environment(
            dataset_name=dataset_name,
            instance_ids=instance_ids,
            **kwargs
        )

    def get_cli_parameters(self, command: str) -> List[Dict[str, Any]]:
        """Get spec-specific CLI parameters for a command.

        Args:
            command: Command name

        Returns:
            List of parameter definitions for Click options
        """
        # Get base parameters (includes max_workers)
        base_params = self.get_base_cli_parameters(command)

        # Common SWE-bench parameters
        common_swe_params = [
            {
                "names": ["--split"],
                "type": str,
                "default": None,
                "help": "Dataset split to use (e.g., 'lite', 'verified')"
            }
        ]

        # JVM-specific parameters
        jvm_params = [
            {
                "names": ["--jvm-version"],
                "type": str,
                "default": "24",
                "help": "JVM version to use (default: 24)"
            }
        ]

        # Command-specific parameters
        if command == "prepare-environment":
            return base_params + common_swe_params + jvm_params + [
                {
                    "names": ["--base-only"],
                    "is_flag": True,
                    "default": False,
                    "help": "Build only base images, not task-specific images"
                },
                {
                    "names": ["--force-rebuild"],
                    "is_flag": True,
                    "default": False,
                    "help": "Force rebuild of instance images even if they exist"
                },
                {
                    "names": ["--namespace"],
                    "type": str,
                    "default": None,
                    "help": "Docker images namespace (default: ee-bench)"
                },
                {
                    "names": ["--cleanup-expired"],
                    "is_flag": True,
                    "default": False,
                    "help": "Cleanup expired/dangling images after build"
                },
                {
                    "names": ["--build-system"],
                    "type": str,
                    "default": None,
                    "help": "Force specific build system (maven or gradle)"
                },
                {
                    "names": ["--filters"],
                    "type": str,
                    "default": None,
                    "help": "Filters to apply when instance-ids not provided (JSON format: {\"language\": \"java\", \"repo\": \"spring-petclinic\", \"tags\":[\"bug\"]})"
                }
            ]
        elif command == "run-evaluation":
            return base_params + common_swe_params + jvm_params + [
                {
                    "names": ["--docker-opts"],
                    "type": str,
                    "default": None,
                    "help": "Additional Docker run options (JSON or CLI format: '{\"memory\": \"2g\"}' or '--memory 2g --cpus 2')"
                },
                {
                    "names": ["--clean"],
                    "is_flag": True,
                    "default": False,
                    "help": "Cleanup images created during evaluation after completion"
                },
                {
                    "names": ["--predictions-path"],
                    "type": str,
                    "default": None,
                    "help": "Path to predictions file - if 'gold', uses gold predictions"
                },
                {
                    "names": ["--build-system"],
                    "type": str,
                    "default": None,
                    "help": "Force specific build system (maven or gradle)"
                }
            ]
        else:
            return base_params + common_swe_params + jvm_params
