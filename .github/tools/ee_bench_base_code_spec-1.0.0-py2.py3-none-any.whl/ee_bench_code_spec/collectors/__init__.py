"""Predictions collectors for extracting predictions from environments."""

from .gold_collector import GoldPredictionsCollector

__all__ = [
    "GoldPredictionsCollector",
]
