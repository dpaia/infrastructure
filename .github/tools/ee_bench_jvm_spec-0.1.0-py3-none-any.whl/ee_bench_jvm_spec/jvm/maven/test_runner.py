"""Maven test runner adapter.

This module provides a test runner for Maven-based Java projects.
"""

import logging
import shlex
from pathlib import Path

from ..build_tool_detector import detect_maven_command
from ee_bench_core.core.models import EnvironmentConfig

from ..jvm_test_runner_base import BaseJvmTestRunner
from .module_detector import MavenModuleDetector
from .output_parser import MavenOutputParser

logger = logging.getLogger(__name__)


class MavenTestRunner(BaseJvmTestRunner):
    """Test runner implementation for Maven-based projects.

    This class extends BaseJvmTestRunner with Maven-specific implementations
    for module detection, command building, and report parsing.
    """

    tool_name = "maven"

    def _create_module_detector(self):
        """Create Maven module detector.

        Returns:
            MavenModuleDetector instance
        """
        return MavenModuleDetector()

    def _create_output_parser(self):
        """Create Maven output parser.

        Returns:
            MavenOutputParser instance
        """
        return MavenOutputParser()

    def _detect_build_command(
        self, sandbox, working_dir: Path, env_config: EnvironmentConfig | None
    ) -> list[str]:
        """Detect Maven command (mvn or wrapper).

        Args:
            working_dir: Project root directory
            env_config: Environment configuration

        Returns:
            List containing Maven command (e.g., ['mvn'] or ['./mvnw'])
        """
        return detect_maven_command(sandbox, working_dir)

    def _build_test_command(
        self,
        base_cmd: list[str],
        module: str | None,
        test_name: str,
        test_args: str | None,
    ) -> list[str]:
        """Build Maven test command.

        Args:
            base_cmd: Base Maven command
            module: Module path or None
            test_name: Clean test name
            test_args: Optional additional arguments

        Returns:
            Complete Maven command list
        """
        cmd = list(base_cmd)
        cmd.append("test")

        # Add module specification if present
        if test_name != "*" and module and module != ".":
            cmd.extend(["-pl", module, "-am"])

        # Add test specification and Maven options
        if test_name != "*":
            cmd.append(f"-Dtest={test_name}")
        cmd.append("-DfailIfNoTests=false")
        cmd.append("-Dsurefire.useFile=true")
        cmd.extend(["-B", "--no-transfer-progress"])

        # Add any additional test arguments
        if test_args:
            cmd.extend(shlex.split(test_args))

        return cmd

    def _get_report_directories(self, working_dir: Path, module: str | None) -> list[Path]:
        """Get Maven report directories (surefire and failsafe).

        Args:
            working_dir: Project root directory
            module: Module path or None

        Returns:
            List of paths to surefire-reports and failsafe-reports
        """
        base = working_dir
        if module and module != ".":
            base /= module

        return [
            base / "target" / "surefire-reports",
            base / "target" / "failsafe-reports",
        ]
