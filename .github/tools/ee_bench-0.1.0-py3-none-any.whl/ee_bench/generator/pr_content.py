"""PR content formatting for GitHub import workflows."""

import re

from ee_bench.generator.text import sanitize_mentions

# Common issue tag prefixes to strip from titles
_TAG_PREFIX_RE = re.compile(
    r"^\[(?:Bug|Feature(?:\s+request)?|Enhancement|Regression|Question|Discussion|RFC|WIP)"
    r"(?:\s*[:/.]\s*[^\]]*?)?\]\s*:?\s*",
    re.IGNORECASE,
)

# Markdown heading prefixes
_HEADING_RE = re.compile(r"^#{1,6}\s+")


def _details_block(key: str, summary: str, content: str) -> str:
    """Wrap content in a metadata-tagged ``<details>`` block."""
    return (
        f'<details type="metadata" key="{key}">'
        f"<summary>{summary}</summary>\n\n{content}\n\n</details>"
    )


class PRContentFormatter:
    """Generates and sanitizes PR titles and bodies from dataset items."""

    def format_title(self, problem_statement: str, max_length: int = 100) -> str:
        """Extract title from problem_statement using first non-empty line.

        Algorithm:
        1. Take first non-empty line
        2. Strip markdown heading prefixes
        3. Strip common issue tag prefixes like [Bug]:, [Feature request]:
        4. Truncate at last word boundary before max_length
        5. Apply sanitize_mentions()
        """
        if not problem_statement:
            return ""

        # First non-empty line
        title = ""
        for line in problem_statement.splitlines():
            stripped = line.strip()
            if stripped:
                title = stripped
                break

        if not title:
            return ""

        # Strip markdown heading prefixes
        title = _HEADING_RE.sub("", title)

        # Strip common issue tag prefixes
        title = _TAG_PREFIX_RE.sub("", title).strip()

        # Truncate at word boundary, keeping the last complete word
        if len(title) > max_length:
            truncated = title[: max_length - 3]  # reserve room for "..."
            last_space = truncated.rfind(" ")
            if last_space > (max_length - 3) // 2:
                title = truncated[:last_space] + "..."
            else:
                title = truncated + "..."

        return sanitize_mentions(title)

    def format_body(
        self,
        problem_statement: str,
        details: list[tuple[str, str, str]] | None = None,
    ) -> str:
        """Build PR body from problem statement and collapsible detail sections.

        Args:
            problem_statement: Main problem description (always shown).
            details: List of ``(key, caption, value)`` tuples.  Each non-empty
                value is appended as a ``<details type="metadata" key="key">``
                block with ``caption`` as the visible summary.
        """
        parts = [sanitize_mentions(problem_statement)]

        for key, caption, value in details or []:
            if value:
                parts.append(_details_block(key, caption, sanitize_mentions(value)))

        return "\n\n".join(parts) + "\n"
