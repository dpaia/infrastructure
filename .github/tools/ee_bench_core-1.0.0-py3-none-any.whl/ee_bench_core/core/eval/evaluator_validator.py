"""Validator for evaluator dependencies and execution order.

This module provides validation and topological sorting for evaluator pipelines,
ensuring that dependencies form a valid DAG and computing the correct execution order.
"""

import logging
from collections import defaultdict, deque
from typing import Dict, List, Set

from .evaluator import DependencyPosition, Evaluator, EvaluatorDependency

logger = logging.getLogger(__name__)


class EvaluatorValidator:
    """Validates evaluator dependencies and computes execution order.

    This class separates dependency validation and ordering logic from
    the evaluation runner, providing:
    - Dependency validation (unknown references, cycles)
    - Position constraint validation
    - Topological sorting with level grouping for parallelization
    """

    def __init__(self, evaluators: List[Evaluator]):
        """Initialize validator with list of evaluators.

        Args:
            evaluators: List of evaluators to validate and order
        """
        self.evaluators = evaluators
        self.evaluator_map = {e.name: e for e in evaluators}

    def validate(self) -> None:
        """Validate evaluator dependencies.

        Raises:
            ValueError: If dependencies are invalid (unknown references, cycles, etc.)
        """
        self._validate_dependencies()

    def get_execution_order(self) -> List[List[Evaluator]]:
        """Compute execution order respecting dependencies and positions.

        Returns:
            List of batches, where each batch is a list of evaluators that
            can be executed in parallel. Batches are ordered such that all
            dependencies are satisfied.

        Raises:
            ValueError: If dependencies cannot be resolved
        """
        return self._get_execution_order()

    def _normalize_dependencies(self, evaluator: Evaluator) -> EvaluatorDependency:
        """Normalize dependency specification to EvaluatorDependency.

        Args:
            evaluator: Evaluator to normalize dependencies for

        Returns:
            EvaluatorDependency instance
        """
        deps = evaluator.dependencies

        if deps is None:
            return EvaluatorDependency()

        if isinstance(deps, EvaluatorDependency):
            return deps

        if isinstance(deps, list):
            # Legacy format: list of names means "after" dependencies
            return EvaluatorDependency(after=deps)

        raise ValueError(
            f"Invalid dependencies type for {evaluator.name}: {type(deps)}"
        )

    def _validate_dependencies(self) -> None:
        """Validate evaluator dependencies form valid DAG.

        Checks:
        1. All referenced evaluators exist
        2. Position constraints are valid
        3. No circular dependencies

        Raises:
            ValueError: If validation fails
        """
        # Check that all referenced evaluators exist
        for evaluator in self.evaluators:
            deps = self._normalize_dependencies(evaluator)

            for dep_name in deps.after:
                if dep_name not in self.evaluator_map:
                    raise ValueError(
                        f"Evaluator '{evaluator.name}' depends on unknown "
                        f"evaluator '{dep_name}'"
                    )

            for dep_name in deps.before:
                if dep_name not in self.evaluator_map:
                    raise ValueError(
                        f"Evaluator '{evaluator.name}' must run before unknown "
                        f"evaluator '{dep_name}'"
                    )

        # Validate position constraints
        position_counts = defaultdict(int)
        for evaluator in self.evaluators:
            deps = self._normalize_dependencies(evaluator)
            if deps.position:
                position_counts[deps.position] += 1

        # Check for cycles
        self._check_for_cycles()

        logger.debug(
            f"Validated {len(self.evaluators)} evaluators: "
            f"{position_counts[DependencyPosition.FIRST]} first, "
            f"{position_counts[DependencyPosition.MIDDLE]} middle, "
            f"{position_counts[DependencyPosition.LAST]} last"
        )

    def _check_for_cycles(self) -> None:
        """Check for circular dependencies in evaluator graph using DFS.

        Raises:
            ValueError: If a cycle is detected
        """
        # Build adjacency list (after relationships)
        graph: Dict[str, Set[str]] = defaultdict(set)

        for evaluator in self.evaluators:
            deps = self._normalize_dependencies(evaluator)

            # "after" creates edge from dependency to evaluator
            for dep_name in deps.after:
                graph[dep_name].add(evaluator.name)

            # "before" creates edge from evaluator to dependency
            for dep_name in deps.before:
                graph[evaluator.name].add(dep_name)

        # DFS for cycle detection
        WHITE = 0  # Not visited
        GRAY = 1  # Visiting (in current path)
        BLACK = 2  # Visited (completed)

        color = {name: WHITE for name in self.evaluator_map}
        path: List[str] = []

        def dfs(node: str) -> bool:
            """DFS visit. Returns True if cycle found."""
            if color[node] == GRAY:
                # Found cycle
                cycle_start = path.index(node)
                cycle = path[cycle_start:] + [node]
                raise ValueError(f"Circular dependency detected: {' -> '.join(cycle)}")

            if color[node] == BLACK:
                return False

            color[node] = GRAY
            path.append(node)

            for neighbor in graph.get(node, []):
                dfs(neighbor)

            path.pop()
            color[node] = BLACK
            return False

        for name in self.evaluator_map:
            if color[name] == WHITE:
                dfs(name)

    def _get_execution_order(self) -> List[List[Evaluator]]:
        """Compute execution order respecting dependencies and positions.

        Strategy:
        1. Separate evaluators into FIRST, MIDDLE, LAST groups
        2. Topologically sort each group independently
        3. Concatenate: FIRST batches + MIDDLE batches + LAST batches

        Returns:
            List of batches (list of evaluators that can run in parallel)
        """
        # Separate evaluators by position
        first_evals: List[Evaluator] = []
        middle_evals: List[Evaluator] = []
        last_evals: List[Evaluator] = []

        for evaluator in self.evaluators:
            deps = self._normalize_dependencies(evaluator)

            if deps.position == DependencyPosition.FIRST:
                first_evals.append(evaluator)
            elif deps.position == DependencyPosition.LAST:
                last_evals.append(evaluator)
            else:
                middle_evals.append(evaluator)

        # Topologically sort each group
        first_batches = self._topological_sort(first_evals) if first_evals else []
        middle_batches = self._topological_sort(middle_evals) if middle_evals else []
        last_batches = self._topological_sort(last_evals) if last_evals else []

        # Concatenate batches
        all_batches = first_batches + middle_batches + last_batches

        logger.info(
            f"Computed execution order: {len(all_batches)} batches "
            f"({len(first_batches)} first, {len(middle_batches)} middle, "
            f"{len(last_batches)} last)"
        )

        return all_batches

    def _topological_sort(self, evaluators: List[Evaluator]) -> List[List[Evaluator]]:
        """Perform topological sort with level grouping using Kahn's algorithm.

        This handles both "after" and "before" constraints and groups evaluators
        into levels (batches) that can be executed in parallel.

        Args:
            evaluators: List of evaluators to sort

        Returns:
            List of batches, where each batch can be executed in parallel
        """
        if not evaluators:
            return []

        # Build evaluator map for this subset
        eval_map = {e.name: e for e in evaluators}

        # Build adjacency list and in-degree count
        graph: Dict[str, Set[str]] = defaultdict(set)
        in_degree: Dict[str, int] = {e.name: 0 for e in evaluators}

        for evaluator in evaluators:
            deps = self._normalize_dependencies(evaluator)

            # "after" creates edges from dependencies to this evaluator
            for dep_name in deps.after:
                if dep_name in eval_map:
                    graph[dep_name].add(evaluator.name)
                    in_degree[evaluator.name] += 1

            # "before" creates edges from this evaluator to dependencies
            for dep_name in deps.before:
                if dep_name in eval_map:
                    graph[evaluator.name].add(dep_name)
                    in_degree[dep_name] += 1

        # Kahn's algorithm with level grouping
        batches: List[List[Evaluator]] = []
        queue = deque([name for name, degree in in_degree.items() if degree == 0])

        while queue:
            # Process all nodes at current level (batch)
            batch_size = len(queue)
            batch: List[Evaluator] = []

            for _ in range(batch_size):
                name = queue.popleft()
                batch.append(eval_map[name])

                # Reduce in-degree for neighbors
                for neighbor in graph[name]:
                    in_degree[neighbor] -= 1
                    if in_degree[neighbor] == 0:
                        queue.append(neighbor)

            batches.append(batch)

        # Check if all evaluators were processed (no cycles)
        processed_count = sum(len(batch) for batch in batches)
        if processed_count != len(evaluators):
            raise ValueError(
                f"Cannot compute execution order: cycle detected or "
                f"invalid dependencies ({processed_count}/{len(evaluators)} processed)"
            )

        return batches
