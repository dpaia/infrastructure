"""EE-Bench JVM Specification Plugin.

This plugin provides JVM-specific implementation (Java/Maven/Gradle) for EE-bench
format evaluations.
"""

from .jvm import (
    BaseDependenciesConfigurer,
    # Base classes
    BaseDockerBuildToolConfigurer,
    BaseJvmTestRunner,
    BaseLocalBuildToolConfigurer,
    DockerGradleConfigurer,
    DockerMavenConfigurer,
    GradleDependenciesConfigurer,
    GradleTestRunner,
    # Docker configurers
    JvmBaseImageConfigurer,
    JvmCodeBenchmarkConfig,
    # Spec
    JvmCodeEvalSpec,
    JvmCodeLocalEnvironmentConfig,
    # Local configurers
    JvmLocalEnvironmentInitializer,
    JvmPredictionFormatterEvaluator,
    # Evaluators
    JvmTestPatchFormatterEvaluator,
    LocalGradleConfigurer,
    LocalJvmConfigurer,
    LocalMavenConfigurer,
    LocalTaskSetupConfigurer,
    MavenDependenciesConfigurer,
    # Test runners
    MavenTestRunner,
)

__all__ = [
    # Spec
    "JvmCodeEvalSpec",
    "JvmCodeBenchmarkConfig",
    "JvmCodeLocalEnvironmentConfig",
    # Base classes
    "BaseDockerBuildToolConfigurer",
    "BaseLocalBuildToolConfigurer",
    "BaseDependenciesConfigurer",
    "BaseJvmTestRunner",
    # Docker configurers
    "JvmBaseImageConfigurer",
    "DockerMavenConfigurer",
    "DockerGradleConfigurer",
    "MavenDependenciesConfigurer",
    "GradleDependenciesConfigurer",
    # Local configurers
    "JvmLocalEnvironmentInitializer",
    "LocalJvmConfigurer",
    "LocalMavenConfigurer",
    "LocalGradleConfigurer",
    "LocalTaskSetupConfigurer",
    # Test runners
    "MavenTestRunner",
    "GradleTestRunner",
    # Evaluators
    "JvmTestPatchFormatterEvaluator",
    "JvmPredictionFormatterEvaluator",
]

__version__ = "0.1.0"
