"""Core evaluator interfaces and types for the evaluation framework.

This module provides the abstract Evaluator interface and related types for
building composable evaluation pipelines with dependency management.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union

if TYPE_CHECKING:
    from core.abc_types import DatasetConfig, EnvironmentConfig, EvalSpec
    from core.base_spec import BaseEvalSpec


class EvaluatorStatus(Enum):
    """Status of an evaluator execution."""

    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"
    ERROR = "error"


class DependencyPosition(Enum):
    """Position constraints for evaluator execution order."""

    FIRST = "first"
    MIDDLE = "middle"
    LAST = "last"


@dataclass
class EvaluatorDependency:
    """Specification of evaluator dependencies and execution constraints.

    Attributes:
        after: List of evaluator names that must run before this evaluator
        before: List of evaluator names that must run after this evaluator
        position: Optional position constraint (first/middle/last)
    """

    after: List[str] = field(default_factory=list)
    before: List[str] = field(default_factory=list)
    position: Optional[DependencyPosition] = None

    def __post_init__(self):
        """Validate dependency specification."""
        if self.position == DependencyPosition.FIRST and self.after:
            raise ValueError("FIRST position cannot have 'after' dependencies")
        if self.position == DependencyPosition.LAST and self.before:
            raise ValueError("LAST position cannot have 'before' dependencies")


@dataclass
class EvaluatorResult:
    """Result of an evaluator execution.

    Attributes:
        evaluator_name: Name of the evaluator that produced this result
        status: Execution status
        message: Human-readable message describing the result
        data: Optional dictionary with additional result data
        error: Optional error message if status is ERROR or FAILED
    """

    evaluator_name: str
    status: EvaluatorStatus
    message: str
    data: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None

    @property
    def success(self) -> bool:
        """Check if evaluation succeeded."""
        return self.status == EvaluatorStatus.SUCCESS

    @property
    def failed(self) -> bool:
        """Check if evaluation failed."""
        return self.status == EvaluatorStatus.FAILED

    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary."""
        return {
            "evaluator_name": self.evaluator_name,
            "status": self.status.value,
            "message": self.message,
            "data": self.data,
            "error": self.error,
        }


@dataclass
class EvaluationContext:
    """Shared context passed between evaluators in a pipeline.

    This context allows evaluators to share results and data with each other.
    Note that config and env_config are passed as explicit parameters to
    evaluate() and can_skip(), not stored in this context.

    Attributes:
        results: Dict mapping evaluator names to their results
        shared_data: Dict for implementation-specific shared data
            Common entries:
            - 'container_id': Docker container ID
            - 'workspace_dir': Workspace directory path
            - Custom data needed by evaluators
    """

    results: Dict[str, EvaluatorResult] = field(default_factory=dict)
    shared_data: Dict[str, Any] = field(default_factory=dict)

    def get_result(self, evaluator_name: str) -> Optional[EvaluatorResult]:
        """Get result from a specific evaluator.

        Args:
            evaluator_name: Name of the evaluator

        Returns:
            EvaluatorResult if found, None otherwise
        """
        return self.results.get(evaluator_name)

    def has_succeeded(self, evaluator_name: str) -> bool:
        """Check if an evaluator completed successfully.

        Args:
            evaluator_name: Name of the evaluator

        Returns:
            True if evaluator succeeded, False otherwise
        """
        result = self.results.get(evaluator_name)
        return result is not None and result.status == EvaluatorStatus.SUCCESS

    def has_failed(self, evaluator_name: str) -> bool:
        """Check if an evaluator failed.

        Args:
            evaluator_name: Name of the evaluator

        Returns:
            True if evaluator failed, False otherwise
        """
        result = self.results.get(evaluator_name)
        return result is not None and result.status == EvaluatorStatus.FAILED

    def set_result(self, result: EvaluatorResult) -> None:
        """Store result from an evaluator.

        Args:
            result: The evaluator result to store
        """
        self.results[result.evaluator_name] = result


class Evaluator(ABC):
    """Abstract base class for evaluation steps.

    Each evaluator represents a discrete step in an evaluation pipeline.
    Evaluators can declare dependencies on other evaluators and can be
    composed into complex evaluation workflows.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique identifier for this evaluator.

        Returns:
            Evaluator name (must be unique within a pipeline)
        """
        pass

    @property
    def description(self) -> str:
        """Human-readable description of what this evaluator does.

        Returns:
            Description string
        """
        return f"Evaluator: {self.name}"

    @property
    def dependencies(self) -> Optional[Union[List[str], EvaluatorDependency]]:
        """Dependency specification for this evaluator.

        Returns:
            - None: No dependencies
            - List[str]: List of evaluator names that must run before this one
            - EvaluatorDependency: Full dependency specification with after/before/position
        """
        return None

    @property
    def is_terminal(self) -> bool:
        """Whether evaluation should stop if this evaluator fails.

        Terminal evaluators stop the entire pipeline on failure.
        Non-terminal evaluators allow the pipeline to continue.

        Returns:
            True if terminal, False otherwise
        """
        return False

    @property
    def is_async(self) -> bool:
        """Whether this evaluator runs asynchronously.

        Async evaluators:
        - Return an evaluation ID from evaluate() instead of EvaluatorResult
        - Submit results externally (e.g., via API callback)
        - Can be executed in parallel with other async evaluators

        Sync evaluators:
        - Return EvaluatorResult directly from evaluate()
        - Block until evaluation completes

        Returns:
            True if async, False if synchronous
        """
        return False

    @property
    def timeout(self) -> Optional[int]:
        """Custom timeout in seconds for this evaluator.

        If None, the runner's default_timeout will be used.
        This allows individual evaluators to have different timeouts
        based on their expected execution time.

        Examples:
            - Quick validation: 60 seconds
            - Full test suite: 1800 seconds (30 minutes)
            - Long-running integration tests: 3600 seconds (1 hour)

        Returns:
            Timeout in seconds, or None to use default
        """
        return None

    @property
    def retry_count(self) -> int:
        """Number of times to retry this evaluator on transient failures.

        Default is 1 (no retries). Set to higher values for evaluators
        that may fail due to transient issues (network errors, resource
        contention, etc.).

        Examples:
            - 1: No retries (default)
            - 3: Retry up to 2 additional times on failure
            - 5: Retry up to 4 additional times (for flaky operations)

        Returns:
            Number of attempts (minimum 1)
        """
        return 1

    @abstractmethod
    def evaluate(
        self,
        spec: EvalSpec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        run_id: str,
        shared_context: EvaluationContext,
        **kwargs,
    ) -> Union[EvaluatorResult, str]:
        """Execute the evaluation step.

        Args:
            spec: Evaluation specification providing dependencies and configuration
            env_config: Environment configuration for this evaluation
            config: Dataset configuration for the task being evaluated
            run_id: Unique identifier for this evaluation run
            shared_context: Shared context with results from previous evaluators
            **kwargs: Additional evaluator-specific parameters
                - container_id: Docker container ID (also in shared_context.shared_data)
                - workspace_dir: Workspace directory (also in shared_context.shared_data)

        Returns:
            For synchronous evaluators (is_async=False):
                EvaluatorResult with status and details

            For asynchronous evaluators (is_async=True):
                str: Evaluation ID for tracking result submission

        Raises:
            Exception: If evaluation encounters an error
            :param spec:
        """
        pass

    def can_skip(
        self,
        spec: "BaseEvalSpec",
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        run_id: str,
        shared_context: EvaluationContext,
    ) -> tuple[bool, Optional[str]]:
        """Check if this evaluator can be skipped based on context.

        This method is called before evaluate() to allow evaluators to
        skip execution based on the current evaluation state.

        Args:
            spec: Evaluation specification providing dependencies and configuration
            env_config: Environment configuration
            config: Dataset configuration
            run_id: Evaluation run ID
            shared_context: Shared context with results from previous evaluators

        Returns:
            Tuple of (should_skip, reason):
            - should_skip: True if evaluator should be skipped
            - reason: Optional explanation for why it was skipped

        Examples:
            # Skip if dependency failed
            if shared_context.has_failed("baseline_evaluation"):
                return True, "Baseline evaluation failed"

            # Skip if config condition not met
            if not config.fail_to_pass:
                return True, "No fail-to-pass tests defined"

            # Don't skip
            return False, None
            :param spec:
        """
        return False, None
