"""Result schema normalization and evaluation for EE-bench v2.0 criteria format.

Provides:
- ``normalize_result`` — detects v1.0 or v2.0 result format and normalizes to v2.0
- ``normalize_expected`` — synthesizes criteria from legacy FAIL_TO_PASS/PASS_TO_PASS
- ``evaluate_criteria`` — evaluates each criterion and returns per-criterion + overall pass/fail
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Result normalization (run.sh output)
# ---------------------------------------------------------------------------


def normalize_result(result: dict[str, Any]) -> dict[str, Any]:
    """Normalize a run.sh result to v2.0 criteria format.

    If ``schema_version`` is ``"2.0"`` and ``criteria`` is present, the result is
    returned as-is.  Otherwise (v1.0 or absent version), the legacy flat fields
    (``patch_applied``, ``compile_success``, ``summary``, ``passed_tests``,
    ``failed_tests``) are synthesized into a ``criteria`` array.
    """
    if result.get("schema_version") == "2.0" and "criteria" in result:
        return result

    # Synthesize v2.0 criteria from v1.0 flat fields
    criteria: list[dict[str, Any]] = []

    # patch_applied
    patch_applied = result.get("patch_applied")
    if patch_applied is not None:
        criteria.append({
            "criterion": "patch_applied",
            "status": "pass" if patch_applied else "fail",
        })

    # compilation
    compile_success = result.get("compile_success")
    if compile_success is not None:
        criteria.append({
            "criterion": "compilation",
            "status": "pass" if compile_success else "fail",
        })

    # tests
    summary = result.get("summary")
    passed_tests = result.get("passed_tests")
    failed_tests = result.get("failed_tests")
    if summary is not None or passed_tests is not None or failed_tests is not None:
        passed_tests = passed_tests or []
        failed_tests = failed_tests or []
        if summary is None:
            summary = {
                "total": len(passed_tests) + len(failed_tests),
                "passed": len(passed_tests),
                "failed": len(failed_tests),
                "errors": 0,
                "skipped": 0,
            }
        has_failures = bool(failed_tests) or summary.get("failed", 0) > 0
        criteria.append({
            "criterion": "tests",
            "status": "fail" if has_failures else "pass",
            "summary": summary,
            "passed_tests": passed_tests,
            "failed_tests": failed_tests,
        })

    normalized = dict(result)
    normalized["schema_version"] = "2.0"
    normalized["criteria"] = criteria
    return normalized


# ---------------------------------------------------------------------------
# Expected normalization (metadata.json evaluation section)
# ---------------------------------------------------------------------------


def normalize_expected(expected: dict[str, Any]) -> dict[str, Any]:
    """Normalize expected evaluation data to v2.0 criteria format.

    If ``evaluation.criteria`` is present, the expected data is returned as-is.
    Otherwise, synthesizes criteria from legacy ``FAIL_TO_PASS`` / ``PASS_TO_PASS``
    fields (which may be at top level or under ``evaluation``).
    """
    evaluation = expected.get("evaluation", {})
    if isinstance(evaluation, dict) and "criteria" in evaluation:
        return expected

    # Synthesize from legacy fields
    fail_to_pass = (
        expected.get("FAIL_TO_PASS")
        or expected.get("fail_to_pass")
        or evaluation.get("FAIL_TO_PASS")
        or evaluation.get("fail_to_pass")
        or []
    )
    pass_to_pass = (
        expected.get("PASS_TO_PASS")
        or expected.get("pass_to_pass")
        or evaluation.get("PASS_TO_PASS")
        or evaluation.get("pass_to_pass")
        or []
    )

    criteria: list[dict[str, Any]] = [
        {"criterion": "patch_applied", "evaluation_mode": "required"},
        {"criterion": "compilation", "evaluation_mode": "required"},
        {
            "criterion": "tests",
            "evaluation_mode": "required",
            "config": {
                "fail_to_pass": fail_to_pass,
                "pass_to_pass": pass_to_pass,
            },
        },
    ]

    normalized = dict(expected)
    if "evaluation" not in normalized:
        normalized["evaluation"] = {}
    normalized["evaluation"] = dict(normalized["evaluation"])
    normalized["evaluation"]["criteria"] = criteria
    return normalized


# ---------------------------------------------------------------------------
# Criterion evaluation
# ---------------------------------------------------------------------------


def evaluate_criteria(
    result: dict[str, Any],
    expected: dict[str, Any],
) -> dict[str, Any]:
    """Evaluate result criteria against expected criteria.

    Both ``result`` and ``expected`` should already be normalized to v2.0 format
    (call ``normalize_result`` and ``normalize_expected`` first).

    Returns a dict with:
    - ``overall``: ``"pass"`` or ``"fail"``
    - ``criteria``: list of per-criterion evaluation results
    """
    result_criteria = {c["criterion"]: c for c in result.get("criteria", [])}
    expected_criteria = expected.get("evaluation", {}).get("criteria", [])

    evaluations: list[dict[str, Any]] = []
    all_required_pass = True

    for exp in expected_criteria:
        criterion_name = exp["criterion"]
        mode = exp.get("evaluation_mode", "required")
        config = exp.get("config", {})

        result_criterion = result_criteria.get(criterion_name)

        if result_criterion is None:
            eval_result: dict[str, Any] = {
                "criterion": criterion_name,
                "evaluation_mode": mode,
                "status": "missing",
                "passed": False,
                "message": f"Criterion '{criterion_name}' not found in result",
            }
            evaluations.append(eval_result)
            if mode == "required":
                all_required_pass = False
            continue

        # Evaluate based on criterion type
        passed, message, details = _evaluate_single(
            criterion_name, result_criterion, config
        )

        eval_result = {
            "criterion": criterion_name,
            "evaluation_mode": mode,
            "status": result_criterion.get("status", "error"),
            "passed": passed,
            "message": message,
        }
        if details:
            eval_result["details"] = details
        evaluations.append(eval_result)

        if mode == "required" and not passed:
            all_required_pass = False

    return {
        "overall": "pass" if all_required_pass else "fail",
        "criteria": evaluations,
    }


def _evaluate_single(
    criterion_name: str,
    result_criterion: dict[str, Any],
    config: dict[str, Any],
) -> tuple[bool, str, dict[str, Any] | None]:
    """Evaluate a single criterion against its config.

    Returns ``(passed, message, details)``.
    """
    status = result_criterion.get("status", "error")

    if criterion_name == "tests":
        return _evaluate_tests(result_criterion, config)
    if criterion_name == "compilation":
        return _evaluate_compilation(result_criterion, config)
    if criterion_name == "patch_applied":
        return _evaluate_patch_applied(result_criterion, config)
    if criterion_name == "coverage":
        return _evaluate_coverage(result_criterion, config)
    if criterion_name == "rubric":
        return _evaluate_rubric(result_criterion, config)

    # Generic / unknown criterion: just check status
    passed = status == "pass"
    return passed, f"status={status}", None


def _evaluate_tests(
    result_criterion: dict[str, Any],
    config: dict[str, Any],
) -> tuple[bool, str, dict[str, Any] | None]:
    """Evaluate the 'tests' criterion."""
    fail_to_pass = config.get("fail_to_pass", [])
    pass_to_pass = config.get("pass_to_pass", [])

    passed_names = {t["name"] for t in result_criterion.get("passed_tests", [])}
    failed_names = {t["name"] for t in result_criterion.get("failed_tests", [])}

    # Check FAIL_TO_PASS: these tests must now be in passed_tests
    f2p_passed = [t for t in fail_to_pass if t in passed_names]
    f2p_failed = [t for t in fail_to_pass if t not in passed_names]

    # Check PASS_TO_PASS: these tests must still be in passed_tests
    p2p_passed = [t for t in pass_to_pass if t in passed_names]
    p2p_failed = [t for t in pass_to_pass if t not in passed_names]

    all_pass = not f2p_failed and not p2p_failed

    details = {
        "fail_to_pass": {
            "total": len(fail_to_pass),
            "passed": len(f2p_passed),
            "failed": len(f2p_failed),
            "failed_tests": f2p_failed,
        },
        "pass_to_pass": {
            "total": len(pass_to_pass),
            "passed": len(p2p_passed),
            "failed": len(p2p_failed),
            "failed_tests": p2p_failed,
        },
    }

    if all_pass:
        msg = (
            f"FAIL_TO_PASS: {len(f2p_passed)}/{len(fail_to_pass)}, "
            f"PASS_TO_PASS: {len(p2p_passed)}/{len(pass_to_pass)}"
        )
    else:
        msg = (
            f"FAIL_TO_PASS: {len(f2p_passed)}/{len(fail_to_pass)} "
            f"({len(f2p_failed)} still failing), "
            f"PASS_TO_PASS: {len(p2p_passed)}/{len(pass_to_pass)} "
            f"({len(p2p_failed)} regressed)"
        )

    return all_pass, msg, details


def _evaluate_compilation(
    result_criterion: dict[str, Any],
    config: dict[str, Any],
) -> tuple[bool, str, dict[str, Any] | None]:
    """Evaluate the 'compilation' criterion."""
    must_succeed = config.get("must_succeed", True)
    status = result_criterion.get("status", "error")

    if not must_succeed:
        return True, "compilation not required", None

    passed = status == "pass"
    msg = f"compilation {'succeeded' if passed else 'failed'}"
    return passed, msg, None


def _evaluate_patch_applied(
    result_criterion: dict[str, Any],
    config: dict[str, Any],
) -> tuple[bool, str, dict[str, Any] | None]:
    """Evaluate the 'patch_applied' criterion."""
    must_succeed = config.get("must_succeed", True)
    status = result_criterion.get("status", "error")

    if not must_succeed:
        return True, "patch application not required", None

    passed = status == "pass"
    msg = f"patch {'applied' if passed else 'failed to apply'}"
    return passed, msg, None


def _evaluate_coverage(
    result_criterion: dict[str, Any],
    config: dict[str, Any],
) -> tuple[bool, str, dict[str, Any] | None]:
    """Evaluate the 'coverage' criterion."""
    metrics = result_criterion.get("metrics", {})
    issues: list[str] = []

    min_line = config.get("min_line_coverage_pct")
    if min_line is not None:
        actual = metrics.get("line_coverage_pct", 0)
        if actual < min_line:
            issues.append(f"line coverage {actual}% < {min_line}%")

    min_branch = config.get("min_branch_coverage_pct")
    if min_branch is not None:
        actual = metrics.get("branch_coverage_pct", 0)
        if actual < min_branch:
            issues.append(f"branch coverage {actual}% < {min_branch}%")

    passed = not issues
    msg = "; ".join(issues) if issues else "coverage thresholds met"
    return passed, msg, {"metrics": metrics}


def _evaluate_rubric(
    result_criterion: dict[str, Any],
    config: dict[str, Any],
) -> tuple[bool, str, dict[str, Any] | None]:
    """Evaluate the 'rubric' criterion."""
    scores = result_criterion.get("scores", {})
    total_score = result_criterion.get("total_score")
    issues: list[str] = []

    min_total = config.get("min_total_score")
    if min_total is not None and total_score is not None:
        if total_score < min_total:
            issues.append(f"total score {total_score} < {min_total}")

    min_dim_scores = config.get("min_dimension_scores", {})
    for dim, min_score in min_dim_scores.items():
        actual = scores.get(dim, 0)
        if actual < min_score:
            issues.append(f"{dim} score {actual} < {min_score}")

    passed = not issues
    msg = "; ".join(issues) if issues else "rubric thresholds met"
    return passed, msg, {"scores": scores, "total_score": total_score}
