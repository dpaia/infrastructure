"""Base interface for process managers.

This module defines the abstract ProcessManager interface that can be implemented
for different execution environments (local, Docker, etc.).
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, List, Optional, Union

if TYPE_CHECKING:
    from core.abc_types import EnvironmentConfig


@dataclass
class ProcessResult:
    """Result of a process execution.

    Attributes:
        returncode: Process exit code
        stdout: Standard output as string
        stderr: Standard error as string
        duration: Execution time in seconds
        timed_out: Whether the process timed out
    """

    returncode: int
    stdout: str
    stderr: str
    duration: float
    timed_out: bool = False


class ProcessManager(ABC):
    """Abstract base class for process managers.

    Defines the interface for executing commands in different environments.
    """

    @abstractmethod
    def run_command(
        self,
        cmd: Union[str, List[str]],
        cwd: Optional[Union[str, Path]] = None,
        timeout: Optional[int] = None,
        stdin_input: Optional[str] = None,
        env: Optional[dict] = None,
        shell: bool = False,
        log_prefix: str = "",
        env_config: Optional["EnvironmentConfig"] = None,
    ) -> ProcessResult:
        """Run a command and return its result.

        Args:
            cmd: Command to execute (list of args or string if shell=True)
            cwd: Working directory for the command
            timeout: Timeout in seconds (None for no timeout)
            stdin_input: Optional input to send to process stdin
            env: Optional environment variables dict (None uses parent env)
            shell: Whether to execute through shell
            log_prefix: Prefix for debug log messages
            env_config: Optional EnvironmentConfig for extracting execution context (e.g., container_id)

        Returns:
            ProcessResult with execution details
        """
        pass

    @abstractmethod
    def run_command_with_input(
        self,
        cmd: Union[str, List[str]],
        stdin_input: str,
        cwd: Optional[Union[str, Path]] = None,
        timeout: Optional[int] = None,
        env: Optional[Union[dict, "EnvironmentConfig"]] = None,
        shell: bool = False,
        log_prefix: str = "",
    ) -> ProcessResult:
        """Run a command with input sent to stdin.

        Args:
            cmd: Command to execute
            stdin_input: Input to send to process stdin
            cwd: Working directory for the command
            timeout: Timeout in seconds
            env: Optional environment variables dict or EnvironmentConfig
            shell: Whether to execute through shell
            log_prefix: Prefix for debug log messages

        Returns:
            ProcessResult with execution details
        """
        pass
