"""Script runner — load and execute a .py pipeline script."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from types import ModuleType
from typing import Any


def run_script(
    path: str | Path,
    variables: dict[str, str] | None = None,
    dry_run: bool = False,
) -> Any:
    """Load and execute a Python pipeline script.

    Execution order:

    1. If *variables* are provided, inject them into the scripting runtime
       (accessible via ``ee_bench.generator.script_args()``).
    2. Set the dry-run flag (accessible via ``ee_bench.generator.is_dry_run()``).
    3. Load the module from *path*.
    4. If the module defines a ``main()`` callable, call it.
    5. Otherwise, module-level code has already executed — nothing extra.

    Args:
        path: Path to the ``.py`` file.
        variables: Optional ``KEY=VALUE`` pairs exposed to the script via
            ``script_args()``.
        dry_run: If True, ``is_dry_run()`` returns True inside the script.

    Returns:
        Whatever ``main()`` returns, or ``None``.
    """
    from ee_bench.generator.scripting import _set_dry_run, _set_script_args

    path = Path(path).resolve()
    if not path.exists():
        raise FileNotFoundError(f"Script not found: {path}")

    # Set scripting runtime state
    _set_script_args(variables or {})
    _set_dry_run(dry_run)

    module = _load_module(path)

    if hasattr(module, "main") and callable(module.main):
        return module.main()

    return None


def _load_module(path: Path) -> ModuleType:
    """Import a .py file as a module."""
    module_name = path.stem

    # Add script's directory to sys.path so relative imports work
    script_dir = str(path.parent)
    if script_dir not in sys.path:
        sys.path.insert(0, script_dir)

    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load module from {path}")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module
