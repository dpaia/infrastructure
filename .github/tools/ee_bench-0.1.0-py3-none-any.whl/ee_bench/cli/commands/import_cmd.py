"""Import command group - import datasets into GitHub organization."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import click

from ee_bench.cli.cli import Context, pass_context


@click.group("import")
def import_group() -> None:
    """Import datasets into GitHub organization as PRs.

    Commands for importing HuggingFace datasets into GitHub, creating forks,
    branches, PRs, labels, and project assignments.

    Use 'ee-dataset run-script' with a Python script for the import pipeline.
    """


@import_group.command()
@pass_context
def run(ctx: Context) -> None:
    """Run the import pipeline (deprecated — use run-script instead).

    Example:
        ee-dataset run-script scripts/import_swe_bench_pro.py
    """
    raise click.ClickException(
        "The 'import run' command has been removed. "
        "Use 'ee-dataset run-script <script.py>' instead."
    )


@import_group.command("dry-run")
@pass_context
def dry_run(ctx: Context) -> None:
    """Preview import (deprecated — use run-script --dry-run instead).

    Example:
        ee-dataset run-script scripts/import_swe_bench_pro.py --dry-run
    """
    raise click.ClickException(
        "The 'import dry-run' command has been removed. "
        "Use 'ee-dataset run-script <script.py> --dry-run' instead."
    )


@import_group.command()
@click.option(
    "--state-file",
    "-s",
    type=click.Path(exists=True, path_type=Path),
    help="Path to state file. Defaults to value in config.",
)
@pass_context
def status(ctx: Context, state_file: Path | None) -> None:
    """Show import progress summary.

    Displays counts of created, updated, skipped, and errored items.

    Example:
        ee-dataset import status --state-file .state/swe-bench-pro.json
    """
    from ee_bench.importer.sync_state import get_state_summary, load_state

    # Resolve state file path
    if not state_file:
        config = ctx.config or {}
        gen_opts = _get_generator_options(config)
        sf = gen_opts.get("state_file")
        if sf:
            state_file = Path(sf)
        else:
            raise click.ClickException(
                "State file not specified. Use --state-file or set in config."
            )

    state = load_state(state_file)
    summary = get_state_summary(state)

    click.echo(f"Dataset: {state.dataset or '(unknown)'}")
    click.echo(f"Last sync: {state.last_sync or '(never)'}")
    click.echo(f"Total items: {len(state.items)}")
    click.echo("")

    for status_name, count in sorted(summary.items()):
        click.echo(f"  {status_name}: {count}")


@import_group.command()
@click.option(
    "--instance-id",
    "-i",
    required=True,
    help="Instance ID to remove from state.",
)
@click.option(
    "--state-file",
    "-s",
    type=click.Path(path_type=Path),
    help="Path to state file. Defaults to value in config.",
)
@pass_context
def reset(ctx: Context, instance_id: str, state_file: Path | None) -> None:
    """Remove an item from the import state.

    This allows re-importing a specific item on the next run.

    Example:
        ee-dataset import reset --instance-id django__django-16255 \\
            --state-file .state/swe-bench-pro.json
    """
    from ee_bench.importer.sync_state import load_state, remove_item_state, save_state

    if not state_file:
        config = ctx.config or {}
        gen_opts = _get_generator_options(config)
        sf = gen_opts.get("state_file")
        if sf:
            state_file = Path(sf)
        else:
            raise click.ClickException(
                "State file not specified. Use --state-file or set in config."
            )

    state = load_state(state_file)
    removed = remove_item_state(state, instance_id)

    if removed:
        save_state(state, state_file)
        click.echo(f"Removed '{instance_id}' from state. It will be re-imported on next run.")
    else:
        click.echo(f"Instance '{instance_id}' not found in state.")


def _get_generator_options(config: dict[str, Any]) -> dict[str, Any]:
    """Extract generator options from config."""
    generator_config = config.get("generator")
    if isinstance(generator_config, dict):
        return generator_config.get("options", {})
    return config.get("generator_options", {})
