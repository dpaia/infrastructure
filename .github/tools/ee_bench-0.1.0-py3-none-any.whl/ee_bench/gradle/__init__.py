"""ee_bench.gradle - Gradle build-system provider for ee_bench.generator."""

from ee_bench.gradle.provider import GradleProvider

__version__ = "0.1.0"

__all__ = ["GradleProvider"]
