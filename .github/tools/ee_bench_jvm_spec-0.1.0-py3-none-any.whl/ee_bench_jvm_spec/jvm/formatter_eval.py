"""JVM code formatter evaluator plugins.

This module provides evaluator plugins for applying code formatters after patches are applied.
Two evaluators are provided:
1. JvmTestPatchFormatterEvaluator - Runs after test_patch_application
2. JvmPredictionFormatterEvaluator - Runs after prediction_application

Both support Maven and Gradle build systems and automatically detect which to use.
"""

import logging
from abc import ABC
from pathlib import Path
from typing import TYPE_CHECKING

from ee_bench_core.core import PositionConstraint
from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig, EvalSpec
from ee_bench_core.core.eval import (
    EvaluationContext,
    Evaluator,
    EvaluatorDependency,
    EvaluatorResult,
    EvaluatorStatus,
)

from ee_bench_jvm_spec.jvm.jvm_code_spec import JvmCodeEvalSpec
from ee_bench_jvm_spec.jvm.jvm_config import BuildSystem

if TYPE_CHECKING:
    from ee_bench_core.adapters.sandbox_base import Sandbox

logger = logging.getLogger(__name__)


class BaseJvmFormatterEvaluator(Evaluator, ABC):
    """Base evaluator for applying JVM code formatters.

    This evaluator applies code formatters (Maven/Gradle) after patches are applied.
    Errors are ignored as formatters are optional and non-blocking.
    """

    # Metadata for plugin discovery (to be overridden by subclasses)
    __evaluator_name__ = "jvm_formatter"
    __evaluator_description__ = "Apply JVM code formatters"
    __evaluator_version__ = "1.0.0"
    __evaluator_author__ = "EE-Benchmark Team"
    __evaluator_tags__ = ["formatting", "jvm", "maven", "gradle"]
    __evaluator_specs__ = ["jvm"]  # Only for JVM specs

    def __init__(
        self,
        name: str,
        dependencies: EvaluatorDependency | None = None,
        is_terminal: bool = False,
        timeout: int | None = 300,
        retry_count: int = 1,
    ):
        """Initialize formatter evaluator.

        Args:
            name: Unique name for this evaluator
            dependencies: Dependency specification
            is_terminal: Whether failure should stop the pipeline (default: False)
            timeout: Optional custom timeout in seconds (default: 300)
            retry_count: Number of retry attempts (default: 1)
        """
        self._name = name
        self._dependencies = dependencies
        self._is_terminal = is_terminal
        self._timeout = timeout
        self._retry_count = retry_count

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return "Apply JVM code formatters (Maven/Gradle)"

    @property
    def dependencies(self) -> EvaluatorDependency | None:
        return self._dependencies

    @property
    def is_terminal(self) -> bool:
        return self._is_terminal

    @property
    def timeout(self) -> int | None:
        return self._timeout

    @property
    def retry_count(self) -> int:
        return self._retry_count

    def evaluate(
        self,
        spec: EvalSpec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        run_id: str,
        shared_context: EvaluationContext,
        sandbox: "Sandbox",
        **kwargs,
    ) -> EvaluatorResult:
        """Apply code formatters.

        Args:
            spec: Evaluation spec
            env_config: Environment configuration
            config: Dataset configuration
            run_id: Evaluation run ID
            shared_context: Shared context
            sandbox: Sandbox instance for executing commands
            **kwargs: Additional parameters

        Returns:
            EvaluatorResult with formatting outcome
        """
        try:
            # Get project path from env_config
            project_path = "/workspace/task_project"
            if hasattr(env_config, "project_path"):
                project_path = str(env_config.project_path)
            elif hasattr(env_config, "workspace_dir") and env_config.workspace_dir:
                project_path = str(env_config.workspace_dir)

            working_dir = Path(project_path)

            build_system = JvmCodeEvalSpec.get_build_system(config, **kwargs)
            logger.debug(f"Using {build_system.name} formatter")

            commands = self._get_formatter_commands(working_dir, build_system)

            applied_formatters = []
            failed_formatters = []

            for cmd in commands:
                formatter_name = " ".join(cmd)
                try:
                    logger.debug(f"Trying to apply formatter: {formatter_name}")
                    result = sandbox.run_command(
                        cmd=cmd,
                        cwd=working_dir,
                        timeout=self._timeout,
                    )

                    if result.returncode == 0:
                        applied_formatters.append(formatter_name)
                        logger.info(f"Successfully applied formatter: {formatter_name}")
                    else:
                        failed_formatters.append(formatter_name)
                        logger.debug(
                            f"Formatter {formatter_name} failed with exit code {result.returncode}"
                        )
                except Exception as e:
                    failed_formatters.append(formatter_name)
                    logger.debug(f"Formatter {formatter_name} not available or failed: {e}")

            # Always return success since formatters are optional
            message_parts = []
            if applied_formatters:
                message_parts.append(f"Applied: {', '.join(applied_formatters)}")
            if failed_formatters:
                message_parts.append(f"Skipped: {', '.join(failed_formatters)}")

            message = "; ".join(message_parts) if message_parts else "No formatters applied"

            return EvaluatorResult(
                evaluator_name=self.name,
                status=EvaluatorStatus.SUCCESS,
                message=message,
                data={
                    "applied_formatters": applied_formatters,
                    "failed_formatters": failed_formatters,
                    "total_formatters": len(commands),
                    "build_system": build_system.name.lower(),
                },
            )

        except Exception as e:
            logger.error(f"Error applying formatters: {e}", exc_info=True)
            # Still return success since formatters are optional
            return EvaluatorResult(
                evaluator_name=self.name,
                status=EvaluatorStatus.SUCCESS,
                message="Formatter evaluation failed but continuing",
                error=str(e),
            )

    def _get_formatter_commands(
        self, working_dir: Path, build_system: BuildSystem
    ) -> list[list[str]]:
        """Get formatter commands based on build system.

        Args:
            working_dir: Working directory for the project
            build_system: Build system (Maven or Gradle)

        Returns:
            List of formatter commands
        """
        if build_system == BuildSystem.MAVEN:
            return self._get_maven_commands(working_dir)
        if build_system == BuildSystem.GRADLE:
            return self._get_gradle_commands(working_dir)
        return []

    def _get_maven_commands(self, working_dir: Path) -> list[list[str]]:
        """Get Maven formatter commands.

        Args:
            working_dir: Working directory for the project

        Returns:
            List of Maven formatter commands
        """

        maven_cmd = ["mvn"]

        return [
            maven_cmd + ["spring-javaformat:apply"],
            maven_cmd + ["spotless:apply"],
        ]

    def _get_gradle_commands(self, working_dir: Path) -> list[list[str]]:
        """Get Gradle formatter commands.

        Args:
            working_dir: Working directory for the project

        Returns:
            List of Gradle formatter commands
        """
        # Choose Gradle wrapper if present
        gradlew_path = working_dir / "gradlew"
        if gradlew_path.exists() and gradlew_path.is_file():
            gradle_cmd = ["./gradlew"]
        else:
            gradle_cmd = ["gradle"]

        return [
            gradle_cmd + ["spotlessApply"],
        ]

class JvmTestPatchFormatterEvaluator(BaseJvmFormatterEvaluator):
    """Formatter evaluator that runs after test_patch_application.

    This plugin applies code formatters after the test patch has been applied,
    before running fail_to_pass_validation.
    """

    # Plugin metadata
    __evaluator_name__ = "jvm_test_patch_formatter"
    __evaluator_description__ = "Apply JVM formatters after test patch"
    __evaluator_version__ = "1.0.0"
    __evaluator_author__ = "EE-Benchmark Team"
    __evaluator_tags__ = ["formatting", "jvm", "maven", "gradle", "test-patch"]
    __evaluator_specs__ = ["jvm"]

    def __init__(
        self,
        name: str = "jvm_test_patch_formatter",
        timeout: int | None = 300,
        retry_count: int = 1,
    ):
        """Initialize test patch formatter evaluator.

        Args:
            name: Evaluator name (default: "jvm_test_patch_formatter")
            timeout: Custom timeout in seconds (default: 300)
            retry_count: Number of retry attempts (default: 1)
        """
        super().__init__(
            name=name,
            dependencies=EvaluatorDependency(
                after=["test_patch_application"], before=["fail_to_pass_validation"]
            ),
            is_terminal=False,  # Non-terminal - don't stop pipeline on formatter errors
            timeout=timeout,
            retry_count=retry_count,
        )

    @property
    def description(self) -> str:
        return "Apply JVM code formatters after test patch (Maven/Gradle)"


class JvmPredictionFormatterEvaluator(BaseJvmFormatterEvaluator):
    """Formatter evaluator that runs after prediction_application.

    This plugin applies code formatters after the prediction patch has been applied,
    before running all_tests_validation.
    """

    # Plugin metadata
    __evaluator_name__ = "jvm_prediction_formatter"
    __evaluator_description__ = "Apply JVM formatters after prediction patch"
    __evaluator_version__ = "1.0.0"
    __evaluator_author__ = "EE-Benchmark Team"
    __evaluator_tags__ = ["formatting", "jvm", "maven", "gradle", "prediction"]
    __evaluator_specs__ = ["jvm"]

    def __init__(
        self,
        name: str = "jvm_prediction_formatter",
        timeout: int | None = 300,
        retry_count: int = 1,
    ):
        """Initialize prediction formatter evaluator.

        Args:
            name: Evaluator name (default: "jvm_prediction_formatter")
            timeout: Custom timeout in seconds (default: 300)
            retry_count: Number of retry attempts (default: 1)
        """
        super().__init__(
            name=name,
            dependencies=EvaluatorDependency(
                after=["prediction_application"], before=["all_tests_validation"]
            ),
            is_terminal=False,  # Non-terminal - don't stop pipeline on formatter errors
            timeout=timeout,
            retry_count=retry_count,
        )

    @property
    def description(self) -> str:
        return "Apply JVM code formatters after prediction patch (Maven/Gradle)"
