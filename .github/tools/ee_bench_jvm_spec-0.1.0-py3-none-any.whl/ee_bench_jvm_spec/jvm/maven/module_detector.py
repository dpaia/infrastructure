"""Maven module detection for multi-module projects."""

from ..module_detector_base import ModuleDetector


class MavenModuleDetector(ModuleDetector):
    """Module detector with Maven-specific scoring.

    Strongly prefers Maven build files (pom.xml) and weakly prefers
    Gradle files (build.gradle, build.gradle.kts) as fallback.
    """

    def __init__(self):
        """Initialize with Maven build file preferences."""
        super().__init__(
            primary_build_files=["pom.xml"],
            secondary_build_files=["build.gradle", "build.gradle.kts"],
        )
