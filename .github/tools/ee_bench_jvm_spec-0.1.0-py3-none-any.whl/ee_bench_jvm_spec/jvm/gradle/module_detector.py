"""Gradle module detection for multi-module projects."""

from ..module_detector_base import ModuleDetector


class GradleModuleDetector(ModuleDetector):
    """Module detector with Gradle-specific scoring.

    Strongly prefers Gradle build files (build.gradle, build.gradle.kts)
    and weakly prefers Maven files (pom.xml) as fallback.
    """

    def __init__(self):
        """Initialize with Gradle build file preferences."""
        super().__init__(
            primary_build_files=["build.gradle", "build.gradle.kts"],
            secondary_build_files=["pom.xml"],
        )
