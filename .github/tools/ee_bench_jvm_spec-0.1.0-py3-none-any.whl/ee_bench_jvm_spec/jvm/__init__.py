"""JVM-specific EE-bench specification implementation.

This package provides JVM (Java/Maven/Gradle) specific implementations
for EE-bench format evaluations.
"""

from ee_bench_jvm_spec.jvm.base_dependencies_configurer import BaseDependenciesConfigurer

from .base_docker_build_tool_configurer import BaseDockerBuildToolConfigurer
from .base_local_build_tool_configurer import BaseLocalBuildToolConfigurer
from .formatter_eval import (
    JvmPredictionFormatterEvaluator,
    JvmTestPatchFormatterEvaluator,
)
from .gradle import (
    DockerGradleConfigurer,
    GradleDependenciesConfigurer,
    GradleTestRunner,
    LocalGradleConfigurer,
)
from .jvm_base_image_configurer import JvmBaseImageConfigurer
from .jvm_code_spec import JvmCodeEvalSpec
from .jvm_config import JvmCodeBenchmarkConfig
from .jvm_local_env_config import JvmCodeLocalEnvironmentConfig
from .jvm_local_env_initializer import JvmLocalEnvironmentInitializer
from .jvm_test_runner_base import BaseJvmTestRunner
from .local_jvm_configurer import LocalJvmConfigurer
from .local_task_setup_configurer import LocalTaskSetupConfigurer
from .maven import (
    DockerMavenConfigurer,
    LocalMavenConfigurer,
    MavenDependenciesConfigurer,
    MavenTestRunner,
)

__all__ = [
    "JvmCodeBenchmarkConfig",
    "JvmCodeLocalEnvironmentConfig",
    "JvmCodeEvalSpec",
    # Base classes
    "BaseDockerBuildToolConfigurer",
    "BaseLocalBuildToolConfigurer",
    "BaseDependenciesConfigurer",
    "BaseJvmTestRunner",
    # Docker configurers
    "JvmBaseImageConfigurer",
    "DockerMavenConfigurer",
    "DockerGradleConfigurer",
    "MavenDependenciesConfigurer",
    "GradleDependenciesConfigurer",
    # Local configurers
    "JvmLocalEnvironmentInitializer",
    "LocalJvmConfigurer",
    "LocalMavenConfigurer",
    "LocalGradleConfigurer",
    "LocalTaskSetupConfigurer",
    # Test runners
    "MavenTestRunner",
    "GradleTestRunner",
    # Evaluators
    "JvmTestPatchFormatterEvaluator",
    "JvmPredictionFormatterEvaluator",
]
