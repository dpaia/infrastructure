"""JVM SWE-bench specification dependency injection container.

This module defines the JvmSweContainer which extends SweContainer with
JVM-specific dependencies (Maven/Gradle test runners, dataset manager).
"""

from dependency_injector import providers

from ee_bench_core.adapters.gradle.test_runner import GradleTestRunner
from ee_bench_core.adapters.maven.test_runner import MavenTestRunner
from ee_bench_core.di.base_container import BaseContainer
from ee_bench_swe.swe_container import SweContainer, _create_evaluators_pipeline
from ee_bench_swe.jvm.jvm_swe_dataset import JvmSweDatasetManager


class JvmSweContainer(SweContainer):
    """JVM SWE-bench specification dependencies container.

    Extends SweContainer with JVM-specific dependencies:
    - TestRunner (Maven or Gradle based on build_system)
    - Dataset Manager (JvmSweDatasetManager)

    Inherits from SweContainer:
    - ProcessManager (local or docker)
    - PatchAdapter (with ProcessManager)
    - PredictionsProvider (gold or json)
    - Evaluators pipeline (automatically wired when we override test_runner)

    Configuration keys:
        - working_dir: Working directory for dataset manager
        - execution_mode: "local" or "docker" for ProcessManager selection
        - build_system: "maven" or "gradle" for TestRunner selection
        - predictions_mode: "gold" or "json" for PredictionsProvider selection
        - predictions_path: Path to predictions file (for json mode)
        - max_workers: Maximum parallel workers
    """

    # Dataset Manager (singleton per spec)
    dataset_manager = providers.Singleton(
        JvmSweDatasetManager,
        working_dir=BaseContainer.config.working_dir
    )

    # TestRunner Factory (Maven or Gradle based on build_system)
    # Returns MavenTestRunner or GradleTestRunner with injected ProcessManager
    test_runner = providers.Selector(
        BaseContainer.config.build_system,
        maven=providers.Factory(
            MavenTestRunner,
            process_manager=BaseContainer.process_manager
        ),
        gradle=providers.Factory(
            GradleTestRunner,
            process_manager=BaseContainer.process_manager
        ),
    )

    # Evaluators Factory - Standard SWE-bench evaluation pipeline
    # Uses helper function from SweContainer with our test_runner
    evaluators = providers.Factory(
        lambda tr, pa, pp: _create_evaluators_pipeline(tr, pa, pp),
        tr=test_runner,  # Our Maven/Gradle test runner
        pa=BaseContainer.patch_adapter,
        pp=SweContainer.predictions_provider
    )

    @classmethod
    def create_for_evaluation(
        cls,
        app_container,
        execution_mode: str,
        build_system: str,
        predictions_mode: str = "gold",
        predictions_path: str = None,
        working_dir: str = ".",
        max_workers: int = 1,
    ) -> "JvmSweContainer":
        """Create container configured for a specific evaluation.

        This is a convenience method for creating and configuring a container
        in one step.

        Args:
            app_container: ApplicationContainer instance
            execution_mode: "local" or "docker"
            build_system: "maven" or "gradle"
            predictions_mode: "gold" or "json"
            predictions_path: Path to predictions file (for json mode)
            working_dir: Working directory for dataset manager
            max_workers: Maximum parallel workers

        Returns:
            Configured JvmSweContainer instance
        """
        container = cls()
        container.app.override(app_container)
        container.config.from_dict(
            {
                "execution_mode": execution_mode,
                "build_system": build_system,
                "predictions_mode": predictions_mode,
                "predictions_path": predictions_path,
                "working_dir": working_dir,
                "max_workers": max_workers,
            }
        )
        return container
