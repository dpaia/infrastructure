"""Base EE-bench specification dependency injection container.

This module defines the base CodeContainer that provides common dependencies
for all EE-bench format evaluations.
"""

from typing import List

from ee_bench_code_spec.evaluator_factory import create_minimal_pipeline, create_minimal_pipeline_test_already_applied
from ee_bench_core.di.base_container import BaseContainer


def _create_evaluators_pipeline(test_runner, patch_adapter, evaluators_pipeline="gold") -> List:
    """Create EE-bench evaluator pipeline with injected dependencies.

    This is a wrapper for the DI factory function to work with dependency-injector.

    Args:
        test_runner: Injected TestRunner
        patch_adapter: Injected PatchAdapter
        predictions_name: Name of predictions collector ("gold", "agent", "agent-test", etc.)

    Returns:
        List of evaluators with all dependencies injected

    Note:
        PredictionsCollector is obtained from spec.get_predictions_collector_provider()
        at runtime, not provided to this function.

        The pipeline is selected based on evaluators_pipeline
    """
    from ee_bench_code_spec.evaluator_factory import create_standard_pipeline

    match evaluators_pipeline:
        case "standard":
            return create_standard_pipeline(
                test_runner=test_runner,
                patch_adapter=patch_adapter
            )
        case "minimal_with_test_patch":
            return create_minimal_pipeline(
                test_runner=test_runner,
                patch_adapter=patch_adapter
            )
        case "minimal":
            return create_minimal_pipeline_test_already_applied(
                test_runner=test_runner,
                patch_adapter=patch_adapter
            )
        case _:
            return create_minimal_pipeline(
                test_runner=test_runner,
                patch_adapter=patch_adapter,
                base_test_score=100
            )


class CodeContainer(BaseContainer):
    """Base container for EE-bench specifications.

    Extends BaseContainer with EE-bench specific dependencies:
    - TestRunner (ABSTRACT - must be provided by language-specific container)
    - Evaluators pipeline (uses TestRunner, PatchAdapter, PredictionsCollector)

    Inherits from BaseContainer:
    - ProcessManager (local or docker)
    - PatchAdapter (with ProcessManager)

    Language-specific containers (JvmCodeContainer, PythonCodeContainer, etc.)
    MUST extend this and provide concrete TestRunner implementation.

    Configuration keys (in addition to BaseContainer):
        - predictions_mode: "gold", "json", or "agent" (for evaluation runtime)
        - predictions_path: Path to predictions file or "gold"/"agent"
        - build_system: Build system for test runner selection (language-specific)

    Note: PredictionsCollector is NOT managed by DI container.
          Use spec.get_predictions_collector_provider().get_collector(**kwargs) instead.
    """

    pass
