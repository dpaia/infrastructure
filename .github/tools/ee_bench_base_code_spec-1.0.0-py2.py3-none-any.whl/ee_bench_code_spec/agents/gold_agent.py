"""Gold Agent for EE-bench.

This module provides a simple "gold" agent that returns the gold/reference patch
from the EE-bench dataset configuration. This is useful for testing the agent-based
predictions collection system and for establishing baseline results.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING, Optional

from ee_bench_agents.agent_runner import AgentRunner
from ee_bench_agents.agent_types import (
    Agent,
    AgentMetadata,
    AgentOpts,
    AgentResult,
)
from ee_bench_core.core.models import ResultStatus

if TYPE_CHECKING:
    from ee_bench_core.core.models import DatasetConfig, EnvironmentConfig

logger = logging.getLogger(__name__)


@dataclass
class GoldAgentResult(AgentResult):
    """Result from Gold agent execution.

    This is a standard AgentResult that contains the gold patch from the dataset.
    """

    pass


class GoldAgentRunner(AgentRunner):
    """Runner for Gold agent that applies the gold patch to the project.

    This runner extracts the gold patch from the dataset configuration and
    applies it to the project files. The git diff will then show the changes.
    """

    def run(
        self,
        agent: Agent,
        prompt: str,
        opts: AgentOpts,
        env_config: EnvironmentConfig,
        sandbox: Sandbox,
        cfg: Optional[DatasetConfig] = None,
        timeout: Optional[int] = None,
        **kwargs,
    ) -> GoldAgentResult:
        """Extract gold patch and apply it to the project.

        Args:
            agent: Agent instance (Gold agent)
            prompt: Prompt text (ignored for gold agent)
            opts: Agent options (ignored)
            env_config: Environment configuration (required for applying patch)
            cfg: Dataset configuration containing the gold patch
            timeout: Execution timeout
            **kwargs: Additional arguments (must include 'start' flag to create container)

        Returns:
            GoldAgentResult with the gold patch as stdout

        Raises:
            ValueError: If cfg is None or doesn't have 'patch' attribute
            RuntimeError: If patch application fails
        """
        start_time = datetime.utcnow()

        logger.info("Running Gold agent (applying gold patch)")

        # Validate that we have the dataset config
        if cfg is None:
            raise ValueError("Dataset configuration (cfg) is required for Gold agent")

        # Validate environment config
        if env_config is None:
            raise ValueError("Environment configuration is required to apply patch")

        # Extract gold patch from config
        if not hasattr(cfg, "patch"):
            raise ValueError(
                f"Dataset config for {getattr(cfg, 'instance_id', 'unknown')} "
                f"does not have 'patch' attribute. Cannot extract gold patch."
            )

        patch = getattr(cfg, "patch", None)
        if patch is None:
            raise ValueError(
                f"Gold patch is None for instance {getattr(cfg, 'instance_id', 'unknown')}. "
                f"Cannot use gold agent."
            )

        logger.info(f"Extracted gold patch ({len(patch)} characters)")

        # Apply the patch
        try:
            import tempfile
            from pathlib import Path

            # Get project path from environment config
            workspace = getattr(env_config, "workspace_dir", "/workspace")
            project_dir = getattr(env_config, "project_dir", "task_project")
            project_path = f"{workspace}/{project_dir}"

            logger.info(f"Applying patch to {project_path}")

            # Write patch to a temporary file
            with tempfile.NamedTemporaryFile(
                mode="w", suffix=".patch", delete=False
            ) as f:
                f.write(patch)
                temp_patch_file = f.name

            # For Docker environments, copy the patch file into the container
            patch_path_in_env = "/tmp/gold.patch"
            if hasattr(env_config, "container_id") and env_config.container_id:
                import subprocess

                subprocess.run(
                    [
                        "docker",
                        "cp",
                        temp_patch_file,
                        f"{env_config.container_id}:{patch_path_in_env}",
                    ],
                    check=True,
                    capture_output=True,
                    text=True,
                )
            else:
                # For local environments, use the temp file path directly
                patch_path_in_env = temp_patch_file

            # Apply the patch
            result = sandbox.run_command(
                cmd=f"git -C {project_path} apply {patch_path_in_env}",
                cwd=project_path,
                timeout=timeout or 300,
            )

            # Clean up temp file
            try:
                Path(temp_patch_file).unlink()
            except Exception:
                pass

            if result.returncode != 0:
                logger.warning(
                    "git apply failed for %s (exit=%s): %s",
                    project_path,
                    result.returncode,
                    result.stderr.strip(),
                )
                raise RuntimeError(
                    f"git apply failed with exit code {result.returncode}: {result.stderr}"
                )

            logger.info("Successfully applied gold patch")

        except Exception as e:
            logger.exception("Failed to apply gold patch for %s", project_path)
            end_time = datetime.utcnow()
            duration = (end_time - start_time).total_seconds()
            return GoldAgentResult(
                description="Agent 'gold' run completed",
                status=ResultStatus.FAILED,
                result=None,
                start_time=start_time,
                end_time=end_time,
                duration=duration,
                stdout="",
                stderr=str(e),
                exit_code=1,
            )

        end_time = datetime.utcnow()
        duration = (end_time - start_time).total_seconds()

        logger.info(f"Gold agent completed in {duration:.2f}s")

        # Return result with the patch content as stdout
        return GoldAgentResult(
            description="Agent 'gold' run completed",
            status=ResultStatus.SUCCESS,
            result=None,
            start_time=start_time,
            end_time=end_time,
            duration=duration,
            stdout=patch,  # The gold patch content
            stderr="",
            exit_code=0,
        )


@dataclass
class _GoldAgent(Agent):
    """Internal Agent implementation for Gold patch agent."""

    _metadata: AgentMetadata

    def metadata(self) -> AgentMetadata:
        """Return agent metadata."""
        return self._metadata

    def runner(self) -> GoldAgentRunner:
        """Return gold agent runner."""
        return GoldAgentRunner()


def GoldAgent():
    """Factory for Gold Agent that applies gold/reference patches.

    This agent extracts the gold patch from the dataset configuration and applies
    it to the project in the workspace/container. It uses a custom runner instead
    of an entry_command, making it suitable for testing the agent-based evaluation
    system without requiring external AI services.

    Use cases:
    - Testing the agent-based predictions collection system
    - Establishing baseline/oracle results (100% correct patches)
    - Verifying that the evaluation pipeline works correctly
    - Testing patch application without running expensive AI models

    Returns:
        Agent: Configured Gold agent instance

    Example:
        >>> agent = GoldAgent()
        >>> agent.metadata().name
        'gold'
        >>> # The agent will apply patches via its custom runner
    """
    return _GoldAgent(
        AgentMetadata(
            name="gold",
            description=(
                "Oracle agent that returns the gold/reference patch from the EE-bench dataset. "
                "Used for testing and establishing baseline results. "
                "Does not require any external dependencies or API keys."
            ),
            role="oracle",
            system_prompt=(
                "You are an oracle that provides the correct solution by extracting "
                "the gold/reference patch from the dataset configuration."
            ),
            version="0.1.0",
        )
    )
