"""Prediction evaluator for EE-bench evaluation."""

from typing import Optional, TYPE_CHECKING, Union, List

from ee_bench_core.adapters.eval import PatchApplierEvaluator
from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig, EvalSpec
from ee_bench_core.core.eval import (
    EvaluationContext,
    Evaluator,
    EvaluatorDependency,
    EvaluatorResult,
    EvaluatorStatus,
)

if TYPE_CHECKING:
    from ee_bench_core.adapters.sandbox_base import Sandbox


class PredictionEvaluator(Evaluator):
    """Evaluator that applies the prediction patch from external source.

    This applies the AI/agent generated patch to the codebase.
    Wraps PatchApplierEvaluator with prediction-specific logic.

    Supports dependency injection for patch_adapter.
    PredictionsCollector is obtained from spec.get_predictions_collector_provider()
    at runtime based on CLI parameters (--agent, --predictions-path, etc.).
    """

    def __init__(
        self,
        name: str,
        patch_adapter=None,
        dependencies: Optional[Union[List[str], EvaluatorDependency]] = None,
        is_terminal: bool = False,
        description: Optional[str] = None,
    ):
        """Initialize prediction evaluator.

        Args:
            name: Evaluator name
            patch_adapter: Optional injected PatchAdapter instance (DI pattern)
            dependencies: Evaluator dependencies
            is_terminal: Whether this is a terminal evaluator
            description: Evaluator description

        Note:
            predictions_collector is obtained from spec.get_predictions_collector_provider()
            at runtime, not injected via constructor.
        """
        self._name = name
        self._patch_adapter = patch_adapter
        self._dependencies = dependencies
        self._is_terminal = is_terminal
        self._description = description

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return self._description

    @property
    def dependencies(self) -> Optional[EvaluatorDependency]:
        return self._dependencies

    @property
    def is_terminal(self) -> bool:
        return self._is_terminal

    def evaluate(
        self,
        spec: EvalSpec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        run_id: str,
        shared_context: EvaluationContext,
        sandbox: "Sandbox",
        **kwargs,
    ) -> EvaluatorResult:
        """Apply prediction patch.

        Args:
            spec: Code evaluation spec (may provide dependencies if not injected)
            env_config: Environment configuration
            config: Dataset configuration
            run_id: Evaluation run ID
            shared_context: Shared context
            sandbox: Sandbox instance for executing commands
            **kwargs: Additional parameters

        Returns:
            EvaluatorResult with patch application results and PredictionResult in data field
        """
        # Get predictions_collector from spec's provider (based on CLI params)
        try:
            provider = spec.get_predictions_collector_provider(**kwargs)
            predictions_collector = provider.get_collector(**kwargs)
        except Exception as e:
            return EvaluatorResult(
                evaluator_name=self.name,
                status=EvaluatorStatus.ERROR,
                message=f"Failed to get predictions collector from spec: {e}",
                error=str(e),
            )

        # Get prediction result from collector (to include in evaluator result)
        from ee_bench_core.core.models import ResultStatus

        prediction_result = predictions_collector.collect(
            instance_id=config.instance_id,
            sandbox=sandbox,
            config=config,
            **kwargs,
        )

        # Create patch getter function that uses predictions_collector
        def get_prediction_patch(cfg: DatasetConfig, ctx: EvaluationContext) -> str:
            """Get prediction patch from predictions collector."""
            if prediction_result.status != ResultStatus.SUCCESS:
                error_msg = prediction_result.error or "unknown error"
                raise ValueError(
                    f"predictions_collector failed for {cfg.instance_id}: {error_msg}"
                )
            if not prediction_result.content:
                raise ValueError(
                    f"predictions_collector returned empty content for instance_id: {cfg.instance_id}"
                )
            return prediction_result.content

        # Create PatchApplierEvaluator with prediction patch getter and injected patch_adapter
        patch_applier = PatchApplierEvaluator(
            name=self.name,
            patch_getter=get_prediction_patch,
            is_terminal=self.is_terminal,
            patch_adapter=self._patch_adapter,  # Pass through injected dependency
        )

        # Delegate to PatchApplierEvaluator
        result = patch_applier.evaluate(
            spec, env_config, config, run_id, shared_context, sandbox, **kwargs
        )

        # Add PredictionResult to data field
        if result.data is None:
            result.data = {}
        prediction_dict: dict[str, _] = prediction_result.to_dict()
        prediction_dict.pop("content")
        result.data["prediction_result"] = prediction_dict

        return result
