"""JVM EE-bench specification dependency injection container.

This module defines the JvmCodeContainer which extends CodeContainer with
JVM-specific dependencies (Maven/Gradle test runners, dataset manager).
"""

from dependency_injector import providers
from ee_bench_code_spec.container import CodeContainer, _create_evaluators_pipeline
from ee_bench_core.di.base_container import BaseContainer

from ee_bench_jvm_spec.jvm.gradle.test_runner import GradleTestRunner
from ee_bench_jvm_spec.jvm.jvm_dataset import JvmCodeDatasetManager
from ee_bench_jvm_spec.jvm.maven.test_runner import MavenTestRunner


class JvmCodeContainer(CodeContainer):
    """JVM EE-bench specification dependencies container.

    Extends CodeContainer with JVM-specific dependencies:
    - TestRunner (Maven or Gradle based on build_system)
    - Dataset Manager (JvmCodeDatasetManager)

    Inherits from CodeContainer:
    - ProcessManager (local or docker)
    - PatchAdapter (with ProcessManager)
    - Evaluators pipeline (automatically wired when we override test_runner)

    Configuration keys:
        - execution_mode: "local" or "docker" for ProcessManager selection
        - build_system: "maven" or "gradle" for TestRunner selection
        - predictions_mode: "gold", "json", or "agent" (for evaluation runtime)
        - predictions_path: Path to predictions file or "gold"/"agent"
        - max_workers: Maximum parallel workers

    Note:
        PredictionsCollector is obtained from spec.get_predictions_collector_provider()
        at evaluation runtime, not managed by DI container.
    """

    # Dataset Manager (singleton per spec)
    dataset_manager = providers.Singleton(JvmCodeDatasetManager)

    # TestRunner Factory (Maven or Gradle based on build_system)
    # Returns MavenTestRunner or GradleTestRunner (no parameters needed)
    test_runner = providers.Selector(
        BaseContainer.config.build_system,
        maven=providers.Factory(MavenTestRunner),
        gradle=providers.Factory(GradleTestRunner),
    )

    # Evaluators Factory - Standard EE-bench evaluation pipeline
    # Uses helper function from CodeContainer with our test_runner
    # Passes predictions name from container config to select appropriate pipeline
    evaluators = providers.Factory(
        lambda tr, pa, pn: _create_evaluators_pipeline(tr, pa, pn),
        tr=test_runner,  # Our Maven/Gradle test runner
        pa=BaseContainer.patch_adapter,
        pn=BaseContainer.config.evaluators_pipeline,  # Predictions collector name
    )

    @classmethod
    def create_for_evaluation(
        cls,
        app_container,
        execution_mode: str,
        build_system: str,
        predictions_mode: str = "gold",
        predictions_path: str = None,
        max_workers: int = 1,
    ) -> "JvmCodeContainer":
        """Create container configured for a specific evaluation.

        This is a convenience method for creating and configuring a container
        in one step.

        Args:
            app_container: ApplicationContainer instance
            execution_mode: "local" or "docker"
            build_system: "maven" or "gradle"
            predictions_mode: "gold" or "json"
            predictions_path: Path to predictions file (for json mode)
            max_workers: Maximum parallel workers

        Returns:
            Configured JvmCodeContainer instance
        """
        container = cls()
        container.app.override(app_container)
        container.config.from_dict(
            {
                "execution_mode": execution_mode,
                "build_system": build_system,
                "predictions_mode": predictions_mode,
                "predictions_path": predictions_path,
                "max_workers": max_workers,
            }
        )
        return container
