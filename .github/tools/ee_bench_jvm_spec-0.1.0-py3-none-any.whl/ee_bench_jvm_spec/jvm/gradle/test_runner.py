"""Gradle test runner adapter.

This module provides a test runner for Gradle-based Java projects.
"""

import logging
import shlex
from pathlib import Path

from ..build_tool_detector import detect_gradle_command
from ee_bench_core.core.models import EnvironmentConfig

from ..jvm_test_runner_base import BaseJvmTestRunner
from .module_detector import GradleModuleDetector
from .output_parser import GradleOutputParser

logger = logging.getLogger(__name__)


class GradleTestRunner(BaseJvmTestRunner):
    """Test runner implementation for Gradle-based projects.

    This class extends BaseJvmTestRunner with Gradle-specific implementations
    for module detection, command building, and report parsing.
    """

    tool_name = "gradle"

    def _create_module_detector(self):
        """Create Gradle module detector.

        Returns:
            GradleModuleDetector instance
        """
        return GradleModuleDetector()

    def _create_output_parser(self):
        """Create Gradle output parser.

        Returns:
            GradleOutputParser instance
        """
        return GradleOutputParser()

    def _detect_build_command(
        self, sandbox, working_dir: Path, env_config: EnvironmentConfig | None
    ) -> list[str]:
        """Detect Gradle command (gradle or wrapper).

        Args:
            working_dir: Project root directory
            env_config: Environment configuration

        Returns:
            List containing Gradle command (e.g., ['gradle'] or ['./gradlew'])
        """
        return detect_gradle_command(sandbox, working_dir)

    def _build_test_command(
        self,
        base_cmd: list[str],
        module: str | None,
        test_name: str,
        test_args: str | None,
    ) -> list[str]:
        """Build Gradle test command.

        Args:
            base_cmd: Base Gradle command
            module: Module path or None
            test_name: Clean test name
            test_args: Optional additional arguments

        Returns:
            Complete Gradle command list
        """
        # Derive task name for module if provided
        task = "test"
        if test_name != "*"and module and module != ".":
            task = self._task_with_module(module, "test")

        cmd = list(base_cmd)
        cmd.append(task)
        cmd.append("--no-daemon")
        cmd.append("--info")
        cmd.append("--build-cache")
        cmd.append("-Dtest.report.junitXml.required=true")

        # Add any additional test arguments
        if test_args:
            cmd.extend(shlex.split(test_args))

        # Add test specification
        if test_name != "*":
            cmd.extend(["--tests", test_name])

        return cmd

    def _get_report_directories(self, working_dir: Path, module: str | None) -> list[Path]:
        """Get Gradle report directories (build/test-results).

        Args:
            working_dir: Project root directory
            module: Module path or None

        Returns:
            List of paths to test-results directories
        """
        base = working_dir
        if module and module != ".":
            base /= module

        return [base / "build" / "test-results" / "test"]

    @staticmethod
    def _task_with_module(module: str | None, task: str) -> str:
        """Construct a Gradle task path for a module, e.g., :app:sub:test.

        Args:
            module: Module path using '/' separators or '.' for root
            task: Task name, such as 'test'

        Returns:
            A Gradle-qualified task string
        """
        return ":" + ":".join(module.split("/")) + ":" + task
