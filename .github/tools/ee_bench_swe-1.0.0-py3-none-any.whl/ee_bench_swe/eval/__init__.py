"""SWE-Bench specific evaluator implementations.

This package contains evaluators specific to the SWE-Bench evaluation protocol.
"""

from .prediction import PredictionEvaluator

__all__ = [
    "PredictionEvaluator",
]
