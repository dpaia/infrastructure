"""Base interface for sandboxes.

This module defines the abstract Sandbox interface that encapsulates
execution environments with their configuration.
"""

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, List, Optional, Union

if TYPE_CHECKING:
    from ee_bench_core.core.abc_types import EnvironmentConfig

logger = logging.getLogger(__name__)


class SandboxStatus(Enum):
    """Sandbox lifecycle status states.

    Tracks the current state of a sandbox through its lifecycle from creation
    to cleanup. This allows monitoring and managing sandbox state transitions.
    """

    CREATED = "created"  # Sandbox created but not started
    STARTING = "starting"  # Start operation in progress
    RUNNING = "running"  # Sandbox is running and ready
    STOPPING = "stopping"  # Stop operation in progress
    STOPPED = "stopped"  # Sandbox stopped but not cleaned
    CLEANING = "cleaning"  # Cleanup operation in progress
    CLEANED = "cleaned"  # Sandbox fully cleaned up
    ERROR = "error"  # Error state - operation failed


@dataclass
class ProcessResult:
    """Result of a process execution.

    Attributes:
        returncode: Process exit code
        stdout: Standard output as string
        stderr: Standard error as string
        duration: Execution time in seconds
        timed_out: Whether the process timed out
    """

    returncode: int
    stdout: str
    stderr: str
    duration: float
    timed_out: bool = False


class Sandbox(ABC):
    """Abstract base class for sandboxes.

    A Sandbox encapsulates an execution environment along with its configuration.
    The environment configuration is part of the sandbox instance state.

    Attributes:
        env_config: Environment configuration for this sandbox
        status: Current lifecycle status of the sandbox
    """

    def __init__(self, env_config: "EnvironmentConfig"):
        """Initialize sandbox with environment configuration.

        Args:
            env_config: Environment configuration containing workspace, container info, etc.
        """
        self.env_config = env_config
        self._status = SandboxStatus.CREATED

    @property
    def status(self) -> SandboxStatus:
        """Get the current status of the sandbox.

        Returns:
            Current SandboxStatus
        """
        return self._status

    def _set_status(self, new_status: SandboxStatus) -> None:
        """Set the sandbox status (protected method for internal use).

        Logs the status transition for debugging and monitoring.

        Args:
            new_status: New status to set
        """
        old_status = self._status
        self._status = new_status
        logger.debug(
            f"Sandbox '{self.get_instance_id()}' status: {old_status.value} -> {new_status.value}"
        )

    @abstractmethod
    def start(self, **kwargs) -> None:
        """Start the sandbox environment.

        For Docker: creates and starts the container
        For Local: no-op

        Args:
            **kwargs: Implementation-specific parameters

        Raises:
            RuntimeError: If sandbox start fails
        """
        pass

    @abstractmethod
    def stop(self, **kwargs) -> None:
        """Stop the sandbox environment.

        For Docker: stops and removes the container
        For Local: no-op

        Args:
            **kwargs: Implementation-specific parameters

        Raises:
            RuntimeError: If sandbox stop fails
        """
        pass

    @abstractmethod
    def is_running(self) -> bool:
        """Check if the sandbox is running.

        Returns:
            True if sandbox is running, False otherwise
        """
        pass

    @abstractmethod
    def run_command(
        self,
        cmd: Union[str, List[str]],
        cwd: Optional[Union[str, Path]] = None,
        timeout: Optional[int] = None,
        stdin_input: Optional[str] = None,
        env: Optional[dict] = None,
        shell: bool = False,
        log_prefix: str = "",
        **kwargs,
    ) -> ProcessResult:
        """Run a command in the sandbox and return its result.

        Args:
            cmd: Command to execute (list of args or string if shell=True)
            cwd: Working directory for the command
            timeout: Timeout in seconds (None for no timeout)
            stdin_input: Optional input to send to process stdin
            env: Optional environment variables dict
            shell: Whether to execute through shell
            log_prefix: Prefix for debug log messages
            **kwargs: Implementation-specific parameters

        Returns:
            ProcessResult with execution details

        Raises:
            RuntimeError: If command execution fails critically
        """
        pass

    @abstractmethod
    def open_interactive_shell(
        self,
        working_dir: Optional[Union[str, Path]] = None,
        **kwargs,
    ) -> ProcessResult:
        """Open an interactive shell in the sandbox.

        Args:
            working_dir: Optional working directory for the shell
            **kwargs: Implementation-specific parameters

        Returns:
            ProcessResult with shell exit code and minimal output

        Raises:
            RuntimeError: If shell cannot be opened
        """
        pass

    @abstractmethod
    def cleanup(self, **kwargs) -> None:
        """Clean up the sandbox environment completely.

        For Docker: stops and removes container, optionally removes images
        For Local: removes workspace directory

        Args:
            **kwargs: Implementation-specific parameters:
                     - keep_images: If True, don't remove Docker images (default: False)

        Raises:
            RuntimeError: If cleanup fails
        """
        pass

    @abstractmethod
    def copy_file_to_sandbox(
        self, content: str, dest_path: str, mode: int = 0o644
    ) -> bool:
        """Copy file content to a path inside the sandbox.

        Args:
            content: File content as string
            dest_path: Destination path inside the sandbox (absolute path)
            mode: File permissions in octal (default: 0o644 = rw-r--r--)

        Returns:
            True if successful, False otherwise

        Raises:
            RuntimeError: If copy operation fails critically
        """
        pass

    def get_workspace_dir(self) -> Optional[Path]:
        """Get workspace directory for this sandbox.

        Returns:
            Workspace directory path or None if not set
        """
        workspace_dir = getattr(self.env_config, "workspace_dir", None)
        if workspace_dir:
            return Path(workspace_dir)
        return None

    def get_project_dir(self) -> str:
        """Get project directory relative to workspace.

        Returns:
            Project directory path (default: task_project)
        """
        return getattr(self.env_config, "project_dir", "task_project")

    def get_instance_id(self) -> str:
        """Get instance ID for this sandbox.

        Returns:
            Instance ID (default: unknown)
        """
        return getattr(self.env_config, "instance_id", "unknown")
