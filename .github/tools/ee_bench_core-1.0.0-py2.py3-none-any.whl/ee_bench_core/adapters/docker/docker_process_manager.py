"""Docker process execution manager for running commands in containers.

This module provides a unified interface for executing commands inside Docker
containers, including support for input, streaming output, and timeouts.
"""

import logging
import time
from pathlib import Path
from typing import TYPE_CHECKING, Callable, Optional, Union, List

from .docker import DockerAdapter
from ..process_manager_base import ProcessManager, ProcessResult

if TYPE_CHECKING:
    from ee_bench_core.core.abc_types import EnvironmentConfig

logger = logging.getLogger(__name__)


class DockerProcessManager(ProcessManager):
    """Manager for executing commands inside Docker containers.

    Provides similar interface to ProcessManager but executes commands
    inside Docker containers via docker exec.

    Supports automatic container start via auto_start parameter in run_command.
    """

    def __init__(
        self, docker_adapter: DockerAdapter = DockerAdapter(), debug_output: bool = True
    ):
        """Initialize Docker process manager.

        Args:
            docker_adapter: DockerAdapter instance for container operations
            debug_output: Whether to write process output to debug log in real-time
        """
        self.docker = docker_adapter
        self.debug_output = debug_output

    def _ensure_container_running(
        self, container_id: str, auto_start: bool = False
    ) -> bool:
        """Ensure container is running, start it if needed and auto_start is True.

        Args:
            container_id: Container ID to check/start
            auto_start: If True, automatically start stopped containers

        Returns:
            True if container was started by this call, False if already running

        Raises:
            RuntimeError: If container doesn't exist or failed to start
        """
        import docker.errors

        try:
            container = self.docker.client.containers.get(container_id)
            status = container.status

            if status == "running":
                logger.debug(f"Container {container_id} is already running")
                return False

            if auto_start:
                logger.debug(
                    f"Starting stopped container: {container_id} (status: {status})"
                )
                container.start()
                logger.debug(f"Successfully started container: {container_id}")
                return True
            else:
                raise RuntimeError(
                    f"Container {container_id} is not running (status: {status}). "
                    f"Use --start to automatically start stopped containers."
                )

        except docker.errors.NotFound:
            raise RuntimeError(f"Container {container_id} not found")
        except RuntimeError:
            raise
        except Exception as e:
            raise RuntimeError(
                f"Failed to ensure container {container_id} is running: {e}"
            )

    def run_command(
        self,
        cmd: Union[str, List[str]],
        cwd: Optional[Union[str, Path]] = None,
        timeout: Optional[int] = None,
        stdin_input: Optional[str] = None,
        env: Optional[dict] = None,
        shell: bool = False,
        log_prefix: str = "",
        env_config: Optional["EnvironmentConfig"] = None,
        stream_output: bool = False,
        output_callback: Optional[Callable[[str], None]] = None,
        **kwargs,
    ) -> ProcessResult:
        """Run a command inside a Docker container and return its result.

        Phase 3.4: Now accepts container_id via kwargs (preferred) or env_config (backward compat).

        Args:
            cmd: Command to execute (list of args or string)
            cwd: Working directory inside container
            timeout: Timeout in seconds (None for no timeout)
            stdin_input: Optional input to send to process stdin
            env: Optional environment variables dict
            shell: Ignored for Docker (always uses shell-style command)
            log_prefix: Prefix for debug log messages
            env_config: [Deprecated] EnvironmentConfig for extracting container_id
            stream_output: Stream output in real-time
            output_callback: Callback function for each output line
            **kwargs: Additional parameters including:
                - container_id: (str) Container ID to execute in (preferred over env_config)
                - start: (bool) Auto-start stopped containers

        Returns:
            ProcessResult with execution details

        Raises:
            ValueError: If neither container_id nor env_config is provided
            Exception: If command execution fails critically
        """
        start_time = time.time()
        timed_out = False
        debug_output = kwargs.get("debug_output", self.debug_output)

        # Phase 3.4: Support both container_id kwarg (new) and env_config (backward compat)
        container_id = kwargs.get("container_id")

        # Extract auto_start from kwargs (from --start CLI parameter)
        auto_start = kwargs.get("start", False)

        # If container_id not provided via kwargs, try env_config (backward compatibility)
        if not container_id:
            if env_config is None:
                raise ValueError(
                    "Either container_id kwarg or env_config parameter is required for DockerProcessManager"
                )

            # Handle case where container_id is None in env_config
            container_id = getattr(env_config, "container_id", None)

        if not container_id:
            # Try to create a new container if auto_start and env_config with image_name available
            if (
                auto_start
                and env_config
                and hasattr(env_config, "image_name")
                and env_config.image_name
            ):
                logger.debug(
                    f"No container_id provided, creating new container from image: {env_config.image_name}"
                )

                # Get workspace_dir if available
                workspace_dir = getattr(env_config, "workspace_dir", None)

                # Create and start container
                container_id = self.docker.run_container(
                    image=env_config.image_name,
                    working_dir=str(workspace_dir) if workspace_dir else None,
                    detach=True,
                )

                # Update env_config with the new container_id
                env_config.container_id = container_id
                logger.debug(f"Created and started new container: {container_id}")
            else:
                if not auto_start:
                    raise ValueError(
                        "container_id must be provided, or use --start with env_config containing image_name to create a new container"
                    )
                else:
                    raise ValueError(
                        "Cannot create container: env_config with image_name is required when container_id is not provided"
                    )

        env_vars = env

        # Ensure container is running (will start if auto_start is True)
        self._ensure_container_running(container_id, auto_start=auto_start)

        # Convert Path to string for cwd
        if cwd is not None:
            cwd = str(cwd)

        # Format command for logging (convert list to string for display)
        # Keep cmd in its original form (list or string) for execution
        if isinstance(cmd, list):
            cmd_str_for_log = " ".join(cmd)
            cmd_for_exec = cmd  # Use list directly for docker exec
        else:
            cmd_str_for_log = cmd
            cmd_for_exec = cmd  # Use string as-is

        # Log command execution with type information
        logger.debug(
            f"{log_prefix}Executing command in container {container_id}: {cmd_str_for_log}"
        )
        logger.debug(
            f"{log_prefix}Command type: {type(cmd_for_exec).__name__}, "
            f"value: {repr(cmd_for_exec)}"
        )
        if env_vars:
            logger.debug(f"{log_prefix}Environment variables: {env_vars.keys()}")
        if cwd:
            logger.debug(f"{log_prefix}Working directory: {cwd}")
        if timeout:
            logger.debug(f"{log_prefix}Timeout: {timeout}s")

        try:
            # Get container
            container = self.docker.client.containers.get(container_id)

            # If stdin is needed, use exec_create + exec_start for proper streaming
            if stdin_input:
                # Create exec instance
                exec_config = {
                    "stdin": True,
                    "stdout": True,
                    "stderr": True,
                    "tty": False,
                }
                if cwd:
                    exec_config["workdir"] = cwd
                if env_vars:
                    exec_config["environment"] = env_vars

                exec_id = self.docker.client.api.exec_create(
                    container_id, cmd_for_exec, **exec_config
                )["Id"]

                # Start exec with socket for stdin
                sock = self.docker.client.api.exec_start(exec_id, socket=True)

                # Set socket timeout if specified
                if timeout:
                    sock_raw = sock._sock if hasattr(sock, "_sock") else sock
                    sock_raw.settimeout(timeout)

                # Send stdin input
                sock_stdin = sock._sock if hasattr(sock, "_sock") else sock
                sock_stdin.sendall(stdin_input.encode("utf-8"))
                # Shutdown write side to signal EOF, but keep read side open
                import socket as socket_module

                sock_stdin.shutdown(socket_module.SHUT_WR)

                # Use docker's frames_iter_no_tty to separate stdout/stderr while reading
                from docker.utils.socket import frames_iter_no_tty

                stdout_data = b""
                stderr_data = b""

                # Buffers for incomplete lines during debug logging
                stdout_log_buffer = ""
                stderr_log_buffer = ""

                try:
                    # Parse multiplexed stream as it's read from socket
                    for stream, data in frames_iter_no_tty(sock):
                        if stream == 1:  # stdout
                            stdout_data += data
                            # Write to debug log in real-time if enabled
                            if debug_output:
                                text = data.decode("utf-8")
                                stdout_log_buffer += text
                                # Extract complete lines for logging
                                while '\n' in stdout_log_buffer:
                                    line, stdout_log_buffer = stdout_log_buffer.split('\n', 1)
                                    logger.debug(f"{log_prefix}[stdout] {line}")
                        elif stream == 2:  # stderr
                            stderr_data += data
                            # Write to debug log in real-time if enabled
                            if debug_output:
                                text = data.decode("utf-8")
                                stderr_log_buffer += text
                                # Extract complete lines for logging
                                while '\n' in stderr_log_buffer:
                                    line, stderr_log_buffer = stderr_log_buffer.split('\n', 1)
                                    logger.debug(f"{log_prefix}[stderr] {line}")
                except (socket_module.timeout, TimeoutError):
                    timed_out = True
                    logger.warning(
                        f"{log_prefix}Command exceeded timeout of {timeout}s"
                    )
                finally:
                    # Log any remaining buffered content
                    if debug_output:
                        if stdout_log_buffer:
                            logger.debug(f"{log_prefix}[stdout] {stdout_log_buffer}")
                        if stderr_log_buffer:
                            logger.debug(f"{log_prefix}[stderr] {stderr_log_buffer}")
                    # Don't explicitly close socket - let it be garbage collected
                    # The underlying HTTPResponse is already closed by frames_iter_no_tty
                    pass

                # Get exit code
                exec_info = self.docker.client.api.exec_inspect(exec_id)
                exit_code = exec_info["ExitCode"]

                stdout = stdout_data.decode("utf-8") if stdout_data else ""
                stderr = stderr_data.decode("utf-8") if stderr_data else ""
            else:
                # No stdin needed - use simpler exec_run or streaming
                # Use streaming when explicitly requested OR when debug_output is enabled OR when timeout is specified
                if stream_output or debug_output or timeout:
                    # Use streaming approach with socket
                    exec_config = {
                        "stdin": False,
                        "stdout": True,
                        "stderr": True,
                        "tty": False,
                    }
                    if cwd:
                        exec_config["workdir"] = cwd
                    if env_vars:
                        exec_config["environment"] = env_vars

                    exec_id = self.docker.client.api.exec_create(
                        container_id, cmd_for_exec, **exec_config
                    )["Id"]

                    # Start exec with socket for streaming
                    sock = self.docker.client.api.exec_start(
                        exec_id, socket=True, stream=True
                    )

                    # Set socket timeout if specified
                    if timeout:
                        sock_raw = sock._sock if hasattr(sock, "_sock") else sock
                        sock_raw.settimeout(timeout)

                    # Use docker's frames_iter_no_tty to separate stdout/stderr while reading
                    from docker.utils.socket import frames_iter_no_tty
                    import socket as socket_module

                    stdout_buffer = ""  # Buffer for incomplete lines
                    stderr_buffer = ""
                    stdout_lines = []
                    stderr_lines = []

                    try:
                        # Parse multiplexed stream as it's read from socket
                        for stream, data in frames_iter_no_tty(sock):
                            if stream == 1:  # stdout
                                # Decode and add to buffer
                                text = data.decode("utf-8")
                                stdout_buffer += text

                                # Extract complete lines (ending with \n)
                                while '\n' in stdout_buffer:
                                    line, stdout_buffer = stdout_buffer.split('\n', 1)
                                    stdout_lines.append(line)
                                    # Write to debug log in real-time if enabled
                                    if debug_output:
                                        logger.debug(f"{log_prefix}[stdout] {line}")
                                    # Call output callback if provided
                                    if output_callback:
                                        output_callback(line)
                            elif stream == 2:  # stderr
                                # Decode and add to buffer
                                text = data.decode("utf-8")
                                stderr_buffer += text

                                # Extract complete lines (ending with \n)
                                while '\n' in stderr_buffer:
                                    line, stderr_buffer = stderr_buffer.split('\n', 1)
                                    stderr_lines.append(line)
                                    # Write to debug log in real-time if enabled
                                    if debug_output:
                                        logger.debug(f"{log_prefix}[stderr] {line}")
                    except (socket_module.timeout, TimeoutError):
                        timed_out = True
                        logger.warning(
                            f"{log_prefix}Command exceeded timeout of {timeout}s"
                        )
                    finally:
                        # Don't explicitly close socket - let it be garbage collected
                        # The underlying HTTPResponse is already closed by frames_iter_no_tty
                        pass

                    # Add any remaining buffered content as final line
                    if stdout_buffer:
                        stdout_lines.append(stdout_buffer)
                    if stderr_buffer:
                        stderr_lines.append(stderr_buffer)

                    # Get exit code
                    exec_info = self.docker.client.api.exec_inspect(exec_id)
                    exit_code = exec_info["ExitCode"]

                    stdout = "\n".join(stdout_lines)
                    stderr = "\n".join(stderr_lines)
                else:
                    # Normal buffered execution
                    # This path now supports timeout using threading
                    exec_kwargs = {
                        "demux": True,  # Separate stdout/stderr
                        "stdin": False,
                        "tty": False,
                    }

                    if cwd:
                        exec_kwargs["workdir"] = cwd
                    if env_vars:
                        exec_kwargs["environment"] = env_vars

                    if timeout:
                        # Use threading to enforce timeout on blocking exec_run
                        import threading
                        from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeoutError

                        logger.debug(f"{log_prefix}Using buffered execution with timeout {timeout}s")

                        # Execute in thread pool with timeout
                        with ThreadPoolExecutor(max_workers=1) as executor:
                            future = executor.submit(container.exec_run, cmd_for_exec, **exec_kwargs)
                            try:
                                exec_result = future.result(timeout=timeout)
                            except FuturesTimeoutError:
                                timed_out = True
                                logger.warning(f"{log_prefix}Command exceeded timeout of {timeout}s")
                                # Try to get partial results (may not be available)
                                stdout = ""
                                stderr = ""
                                exit_code = -1
                                # Skip normal result extraction
                                exec_result = None
                    else:
                        # No timeout - use normal exec_run
                        exec_result = container.exec_run(cmd_for_exec, **exec_kwargs)

                    # Extract results if exec completed
                    if exec_result is not None:
                        exit_code = exec_result.exit_code

                        # exec_result.output is a tuple (stdout, stderr) when demux=True
                        if isinstance(exec_result.output, tuple):
                            stdout_bytes, stderr_bytes = exec_result.output
                            stdout = stdout_bytes.decode("utf-8") if stdout_bytes else ""
                            stderr = stderr_bytes.decode("utf-8") if stderr_bytes else ""
                        else:
                            # Fall back to single output
                            output = (
                                exec_result.output.decode("utf-8")
                                if exec_result.output
                                else ""
                            )
                            stdout = output
                            stderr = ""

                        # Log output if debug enabled (only for non-streaming buffered execution)
                        if debug_output:
                            for line in stdout.splitlines():
                                logger.debug(f"{log_prefix}[stdout] {line}")
                            for line in stderr.splitlines():
                                logger.debug(f"{log_prefix}[stderr] {line}")

        except Exception:
            duration = time.time() - start_time
            logger.exception("%sDocker exec failed", log_prefix)
            raise

        duration = time.time() - start_time

        # Check if timed out (basic check - docker exec doesn't have built-in timeout)
        if timeout and duration >= timeout:
            timed_out = True
            logger.warning(f"{log_prefix}Command exceeded timeout of {timeout}s")

        # Log completion
        logger.debug(
            f"{log_prefix}Command completed in {duration:.2f}s "
            f"with exit code {exit_code}"
        )

        return ProcessResult(
            returncode=exit_code,
            stdout=stdout,
            stderr=stderr,
            duration=duration,
            timed_out=timed_out,
        )

    def open_interactive_shell(
        self,
        working_dir: Optional[Union[str, Path]] = None,
        env_config: Optional["EnvironmentConfig"] = None,
        **kwargs,
    ) -> ProcessResult:
        """Open an interactive shell inside a Docker container.

        Phase 3.4: Now accepts container_id via kwargs (preferred) or env_config (backward compat).

        Args:
            working_dir: Optional working directory inside container
            env_config: [Deprecated] EnvironmentConfig for extracting container_id
            **kwargs: Additional parameters:
                - container_id: (str) Container ID to execute in (preferred over env_config)
                - start: (bool) Auto-start stopped containers

        Returns:
            ProcessResult with shell exit code and minimal output

        Raises:
            ValueError: If neither container_id nor env_config is provided
            RuntimeError: If container doesn't exist or failed to start
        """
        import os
        import time

        start_time = time.time()

        # Phase 3.4: Support both container_id kwarg (new) and env_config (backward compat)
        container_id = kwargs.get("container_id")

        # Extract auto_start from kwargs
        auto_start = kwargs.get("start", False)

        # If container_id not provided via kwargs, try env_config (backward compatibility)
        if not container_id:
            if env_config is None:
                raise ValueError(
                    "Either container_id kwarg or env_config parameter is required for DockerProcessManager"
                )

            # Handle case where container_id is None in env_config
            container_id = getattr(env_config, "container_id", None)

        if not container_id:
            # Try to create a new container if auto_start and env_config with image_name available
            if (
                auto_start
                and env_config
                and hasattr(env_config, "image_name")
                and env_config.image_name
            ):
                logger.debug(
                    f"No container_id provided, creating new container from image: {env_config.image_name}"
                )

                # Get workspace_dir - prefer working_dir parameter over env_config
                workspace_dir_for_container = working_dir or getattr(
                    env_config, "workspace_dir", None
                )

                # Create and start container
                container_id = self.docker.run_container(
                    image=env_config.image_name,
                    working_dir=str(workspace_dir_for_container)
                    if workspace_dir_for_container
                    else None,
                    detach=True,
                )

                # Update env_config with the new container_id
                env_config.container_id = container_id
                logger.debug(f"Created and started new container: {container_id}")
            else:
                instance_id = getattr(env_config, "instance_id", "unknown") if env_config else "unknown"
                image_name = getattr(env_config, "image_name", None) if env_config else None

                if not auto_start:
                    error_msg = (
                        f"Docker environment for instance '{instance_id}' is missing container_id.\n"
                        f"Environment config details:\n"
                        f"  - instance_id: {instance_id}\n"
                        f"  - image_name: {image_name or 'not set'}\n"
                        f"  - workspace_dir: {working_dir or 'not set'}\n"
                        f"  - container_id: not set\n\n"
                        f"Possible solutions:\n"
                        f"  1. Use --start to automatically create a container from the image\n"
                        f"  2. Provide --container-id parameter: --container-id <container_id>\n"
                        f"  3. Use ad-hoc mode: --sandbox docker --container-id <id> --workspace-dir <path>"
                    )
                    raise ValueError(error_msg)
                else:
                    raise ValueError(
                        f"Cannot create container for instance '{instance_id}': "
                        f"env_config with image_name is required when container_id is not provided"
                    )

        # Ensure container is running
        self._ensure_container_running(container_id, auto_start=auto_start)

        # Convert Path to string if needed
        if working_dir is not None:
            working_dir = str(working_dir)

        logger.debug(
            f"Opening interactive shell in container {container_id}"
            + (f" at {working_dir}" if working_dir else "")
        )

        try:
            # Build docker exec command with interactive TTY
            cmd = ["docker", "exec", "-it"]

            # Add working directory if specified
            if working_dir:
                cmd.extend(["-w", working_dir])

            # Add container ID and shell
            cmd.extend([container_id, "/bin/bash"])

            # Execute docker command with os.system for full TTY support
            cmd_str = " ".join(cmd)
            exit_code = os.system(cmd_str)

            # os.system returns exit code shifted left by 8 bits on Unix
            if os.name != "nt":
                exit_code >>= 8

            duration = time.time() - start_time
            logger.debug(f"Interactive shell exited with code: {exit_code}")

            return ProcessResult(
                returncode=exit_code,
                stdout="",  # Interactive shell doesn't capture output
                stderr="",
                duration=duration,
                timed_out=False,
            )

        except Exception as e:
            duration = time.time() - start_time
            logger.exception(
                "Failed to open interactive shell in container %s", container_id[:12]
            )
            return ProcessResult(
                returncode=1,
                stdout="",
                stderr=str(e),
                duration=duration,
                timed_out=False,
            )
