"""EE-bench agents.

This module contains EE-bench specific agents.
"""

from .gold_agent import GoldAgent, GoldAgentRunner

__all__ = ["GoldAgent", "GoldAgentRunner"]
