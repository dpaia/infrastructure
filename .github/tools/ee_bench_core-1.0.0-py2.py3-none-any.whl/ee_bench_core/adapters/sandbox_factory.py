"""Factory for creating Sandbox instances based on EnvironmentConfig sandbox type.

This module provides a factory pattern for creating the appropriate Sandbox
implementation (Local or Docker) based on the environment configuration.
"""

import logging
from typing import TYPE_CHECKING

from .sandbox_base import Sandbox

if TYPE_CHECKING:
    from ee_bench_core.core.models import EnvironmentConfig

logger = logging.getLogger(__name__)


class SandboxFactory:
    """Factory for creating Sandbox instances.

    This factory examines the EnvironmentConfig sandbox_type and creates the appropriate
    Sandbox implementation with the env_config embedded as instance state.
    """

    @staticmethod
    def create_sandbox(env_config: "EnvironmentConfig", **kwargs) -> Sandbox:
        """Create appropriate Sandbox based on EnvironmentConfig sandbox_type.

        The returned Sandbox instance contains the env_config as instance state,
        so you don't need to pass it to individual methods.

        Args:
            env_config: Environment configuration with sandbox_type property
            **kwargs: Additional parameters for Sandbox initialization:
                - debug_output: Whether to write process output to debug log (default: True)
                - docker_adapter: DockerAdapter instance for Docker execution (optional)

        Returns:
            Sandbox instance (LocalSandbox or DockerSandbox) with env_config embedded

        Raises:
            ValueError: If sandbox_type is not 'local' or 'docker'
            AttributeError: If env_config doesn't have sandbox_type property

        Examples:
            >>> from ee_bench_core.adapters import SandboxFactory
            >>> from ee_bench_core.adapters.docker import DockerEnvironmentConfig
            >>>
            >>> # For Docker environments
            >>> env_config = DockerEnvironmentConfig(
            ...     instance_id="test-1",
            ...     image_name="my-image:latest",
            ...     container_id="abc123"
            ... )
            >>> sandbox = SandboxFactory.create_sandbox(env_config)
            >>> # Returns DockerSandbox with env_config embedded
            >>> result = sandbox.run_command("ls")  # No need to pass env_config!
            >>>
            >>> # For local environments
            >>> env_config = LocalEnvironmentConfig(
            ...     instance_id="test-1",
            ...     workspace_dir=Path("/tmp/test")
            ... )
            >>> sandbox = SandboxFactory.create_sandbox(env_config)
            >>> # Returns LocalSandbox with env_config embedded
            >>> result = sandbox.run_command("ls")  # No need to pass env_config!
        """
        # Get sandbox_type from env_config
        if not hasattr(env_config, "sandbox_type"):
            raise AttributeError(
                f"EnvironmentConfig {env_config.__class__.__name__} "
                f"must have a 'sandbox_type' property"
            )

        sandbox_type = env_config.sandbox_type

        logger.debug(f"Creating Sandbox for sandbox_type: {sandbox_type}")

        # Extract common parameters
        debug_output = kwargs.get("debug_output", True)

        # Create appropriate Sandbox based on sandbox_type
        if sandbox_type == "local":
            # Import locally to avoid circular import
            from .local.local_sandbox import LocalSandbox

            logger.debug("Creating LocalSandbox")
            return LocalSandbox(env_config=env_config, debug_output=debug_output)

        elif sandbox_type == "docker":
            # Import locally to avoid circular import
            from .docker import DockerAdapter
            from .docker.docker_sandbox import DockerSandbox

            logger.debug("Creating DockerSandbox")
            docker_adapter = kwargs.get("docker_adapter")
            if docker_adapter is None:
                docker_adapter = DockerAdapter()
            return DockerSandbox(
                env_config=env_config,
                docker_adapter=docker_adapter,
                debug_output=debug_output,
            )

        else:
            raise ValueError(
                f"Unsupported sandbox_type: '{sandbox_type}'. "
                f"Expected 'local' or 'docker'"
            )
