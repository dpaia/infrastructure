"""Default Dockerfile and run.sh templates per build system.

Used when no .ee-bench/codegen/ files are found in the repository.
Templates use {{ instance.* }} Jinja2 syntax.
"""

from __future__ import annotations

_MAVEN_DOCKERFILE = """\
FROM maven:3.9-eclipse-temurin-21 AS build-env
ARG REPO_URL={{ instance.repo_url }}
ARG BASE_COMMIT={{ instance.base_commit }}
LABEL ee_bench_instance_id="{{ instance.instance_id }}"
LABEL ee_bench_base_commit="{{ instance.base_commit }}"
WORKDIR /repo
RUN git clone ${REPO_URL} /repo && \\
    git checkout ${BASE_COMMIT}
RUN mvn dependency:go-offline -B -q || true
"""

_GRADLE_DOCKERFILE = """\
FROM gradle:8.7-jdk21 AS build-env
ARG REPO_URL={{ instance.repo_url }}
ARG BASE_COMMIT={{ instance.base_commit }}
LABEL ee_bench_instance_id="{{ instance.instance_id }}"
LABEL ee_bench_base_commit="{{ instance.base_commit }}"
WORKDIR /repo
RUN git clone ${REPO_URL} /repo && \\
    git checkout ${BASE_COMMIT}
RUN gradle dependencies --no-daemon -q || true
"""

_GRADLE_KOTLIN_DOCKERFILE = _GRADLE_DOCKERFILE

_MAVEN_RUN_SH = """\
#!/usr/bin/env bash
set -euo pipefail

PATCH_FILE="${EE_BENCH_SUBMISSION_PATCH:-}"
TEST_PATCH_FILE="${EE_BENCH_EVAL_PATCH:-}"
PROJECT_ROOT="${EE_BENCH_PROJECT_ROOT:-/repo}"

cd "${PROJECT_ROOT}"

# Reset to base commit (only if EE_BENCH_RESET is set)
if [ -n "${EE_BENCH_RESET:-}" ]; then
    git reset --hard HEAD
    git clean -fd
fi

# Apply test patch if provided
if [ -n "${TEST_PATCH_FILE}" ] && [ -f "${TEST_PATCH_FILE}" ]; then
    git apply --ignore-whitespace "${TEST_PATCH_FILE}" || true
fi

# Apply submission patch
if [ -n "${PATCH_FILE}" ] && [ -f "${PATCH_FILE}" ]; then
    git apply --ignore-whitespace "${PATCH_FILE}"
fi

# Run tests and capture result
mvn test -B -Dsurefire.failIfNoSpecifiedTests=false 2>&1
EXIT_CODE=$?

if [ $EXIT_CODE -eq 0 ]; then
    echo '{"status": "pass"}'
else
    echo '{"status": "fail"}'
fi
"""

_GRADLE_RUN_SH = """\
#!/usr/bin/env bash
set -euo pipefail

PATCH_FILE="${EE_BENCH_SUBMISSION_PATCH:-}"
TEST_PATCH_FILE="${EE_BENCH_EVAL_PATCH:-}"
PROJECT_ROOT="${EE_BENCH_PROJECT_ROOT:-/repo}"

cd "${PROJECT_ROOT}"

# Reset to base commit (only if EE_BENCH_RESET is set)
if [ -n "${EE_BENCH_RESET:-}" ]; then
    git reset --hard HEAD
    git clean -fd
fi

# Apply test patch if provided
if [ -n "${TEST_PATCH_FILE}" ] && [ -f "${TEST_PATCH_FILE}" ]; then
    git apply --ignore-whitespace "${TEST_PATCH_FILE}" || true
fi

# Apply submission patch
if [ -n "${PATCH_FILE}" ] && [ -f "${PATCH_FILE}" ]; then
    git apply --ignore-whitespace "${PATCH_FILE}"
fi

# Run tests and capture result
./gradlew test --no-daemon 2>&1
EXIT_CODE=$?

if [ $EXIT_CODE -eq 0 ]; then
    echo '{"status": "pass"}'
else
    echo '{"status": "fail"}'
fi
"""


def get_default_dockerfile(build_system: str, repo_url: str = "", base_commit: str = "") -> str:
    """Return default Dockerfile template for the given build system.

    The template uses Jinja2 ``{{ instance.* }}`` syntax.

    Args:
        build_system: One of ``"maven"``, ``"gradle"``, ``"gradle-kotlin"``.
        repo_url: Repository clone URL (informational, embedded in template).
        base_commit: Base commit SHA (informational, embedded in template).

    Returns:
        Dockerfile template string with ``{{ instance.* }}`` placeholders.
    """
    if build_system == "maven":
        return _MAVEN_DOCKERFILE
    elif build_system in ("gradle", "gradle-kotlin"):
        return _GRADLE_DOCKERFILE
    else:
        return _MAVEN_DOCKERFILE  # fallback


def get_default_run_sh(build_system: str) -> str:
    """Return default run.sh template for the given build system.

    Args:
        build_system: One of ``"maven"``, ``"gradle"``, ``"gradle-kotlin"``.

    Returns:
        Shell script string.
    """
    if build_system == "maven":
        return _MAVEN_RUN_SH
    elif build_system in ("gradle", "gradle-kotlin"):
        return _GRADLE_RUN_SH
    else:
        return _MAVEN_RUN_SH  # fallback
