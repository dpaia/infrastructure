"""Prediction evaluator for SWE-Bench evaluation."""

from typing import Optional, TYPE_CHECKING, Union, List

from ee_bench_core.adapters.eval import PatchApplierEvaluator
from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig, EvalSpec
from ee_bench_core.core.eval import (
    EvaluationContext,
    Evaluator,
    EvaluatorDependency,
    EvaluatorResult,
    EvaluatorStatus
)

if TYPE_CHECKING:
    from ee_bench_swe.swe_spec import SweEvalSpec


class PredictionEvaluator(Evaluator):
    """Evaluator that applies the prediction patch from external source.

    This applies the AI/agent generated patch to the codebase.
    Wraps PatchApplierEvaluator with prediction-specific logic.

    Supports dependency injection: patch_adapter and predictions_provider
    can be provided via constructor.
    """

    def __init__(self,
                 name: str,
                 patch_adapter=None,
                 predictions_provider=None,
                 dependencies: Optional[Union[List[str], EvaluatorDependency]] = None,
                 is_terminal: bool = False,
                 description: Optional[str] = None
                 ):
        """Initialize prediction evaluator.

        Args:
            name: Evaluator name
            patch_adapter: Optional injected PatchAdapter instance (DI pattern)
            predictions_provider: Optional injected PredictionsProvider (DI pattern)
            dependencies: Evaluator dependencies
            is_terminal: Whether this is a terminal evaluator
            description: Evaluator description
        """
        self._name = name
        self._patch_adapter = patch_adapter
        self._predictions_provider = predictions_provider
        self._dependencies = dependencies
        self._is_terminal = is_terminal
        self._description = description

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return self._description

    @property
    def dependencies(self) -> Optional[EvaluatorDependency]:
        return self._dependencies

    @property
    def is_terminal(self) -> bool:
        return self._is_terminal

    def evaluate(self, spec: EvalSpec, env_config: EnvironmentConfig, config: DatasetConfig, run_id: str,
                 shared_context: EvaluationContext, **kwargs) -> EvaluatorResult:
        """Apply prediction patch.

        Args:
            spec: SWE evaluation spec (may provide dependencies if not injected)
            env_config: Environment configuration
            config: Dataset configuration
            run_id: Evaluation run ID
            shared_context: Shared context
            **kwargs: Additional parameters

        Returns:
            EvaluatorResult with patch application results
        """
        # predictions_provider MUST be injected via constructor (DI pattern)
        if not self._predictions_provider:
            return EvaluatorResult(
                evaluator_name=self.name,
                status=EvaluatorStatus.ERROR,
                message="predictions_provider must be injected via constructor",
                error=(
                    "PredictionEvaluator requires predictions_provider to be provided at initialization. "
                    "Use DI container to create evaluators with injected dependencies. "
                    "See JvmSweContainer.evaluators() for example."
                )
            )

        predictions_provider = self._predictions_provider

        # Create patch getter function that uses predictions_provider
        def get_prediction_patch(cfg: DatasetConfig, ctx: EvaluationContext) -> str:
            """Get prediction patch from predictions provider."""
            prediction = predictions_provider.get_prediction(cfg)
            if not prediction:
                raise ValueError(f"predictions_provider returned None for instance_id: {cfg.instance_id}")
            return prediction

        # Create PatchApplierEvaluator with prediction patch getter and injected patch_adapter
        patch_applier = PatchApplierEvaluator(
            name=self.name,
            patch_getter=get_prediction_patch,
            is_terminal=self.is_terminal,
            patch_adapter=self._patch_adapter  # Pass through injected dependency
        )

        # Delegate to PatchApplierEvaluator
        return patch_applier.evaluate(spec, env_config, config, run_id, shared_context, **kwargs)
