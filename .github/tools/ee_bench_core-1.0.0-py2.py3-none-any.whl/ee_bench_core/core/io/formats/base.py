"""Base format handler interface.

Defines the abstract interface for file format handlers that encode/decode
data in different formats (JSON, JSONL, etc.).
"""

from abc import ABC, abstractmethod
from typing import Any, BinaryIO, Iterator


class FormatHandler(ABC):
    """Abstract base class for format handlers.

    Format handlers convert between raw bytes and structured data
    for different file formats.
    """

    @classmethod
    @abstractmethod
    def formats(cls) -> list[str]:
        """Return list of file format extensions this handler supports.

        Returns:
            List of format strings (e.g., ["json"])
        """
        pass

    @abstractmethod
    def decode(self, content: bytes) -> Any:
        """Decode bytes to structured data.

        Args:
            content: Raw bytes to decode

        Returns:
            Decoded data structure

        Raises:
            ValueError: If content cannot be decoded
        """
        pass

    @abstractmethod
    def encode(self, data: Any) -> bytes:
        """Encode structured data to bytes.

        Args:
            data: Data structure to encode

        Returns:
            Encoded bytes

        Raises:
            ValueError: If data cannot be encoded
        """
        pass

    def decode_stream(self, stream: BinaryIO) -> Iterator[Any]:
        """Decode data from stream (optional).

        Default implementation reads entire stream and decodes.
        Handlers can override for true streaming support.

        Args:
            stream: Binary stream to read from

        Yields:
            Decoded data items

        Raises:
            ValueError: If stream content cannot be decoded
        """
        content = stream.read()
        yield self.decode(content)

    def encode_stream(self, items: Iterator[Any], stream: BinaryIO) -> None:
        """Encode data items to stream (optional).

        Default implementation collects all items and encodes as batch.
        Handlers can override for true streaming support.

        Args:
            items: Iterator of data items to encode
            stream: Binary stream to write to

        Raises:
            ValueError: If items cannot be encoded
        """
        # Collect all items
        data = list(items)
        content = self.encode(data)
        stream.write(content)
