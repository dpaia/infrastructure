"""Environment configuration serialization manager.

This module provides centralized management for serializing and deserializing
environment configurations to/from JSON files.
"""

import logging
from typing import Any, Dict, TYPE_CHECKING

from .base_serializer import BaseSerializerManager
from .models import EnvironmentConfig

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


class EnvironmentSerializerManager(BaseSerializerManager[EnvironmentConfig]):
    """Manager for serializing and deserializing environment configurations.

    This class provides centralized functionality for:
    - Saving environment configs to JSON files (dict format, keyed by instance_id)
    - Loading environment configs from JSON files
    - Converting between EnvironmentConfig objects and dictionaries

    The manager works with dynamic config class loading to handle
    spec-specific config types (DockerEnvironmentConfig, LocalEnvironmentConfig, etc.).
    """

    def __init__(self):
        """Initialize environment serializer manager."""

    def to_dict(self, env_config: EnvironmentConfig) -> Dict[str, Any]:
        """Convert a single EnvironmentConfig to dictionary.

        Args:
            env_config: Environment configuration object

        Returns:
            Dictionary representation

        Raises:
            TypeError: If config cannot be serialized
        """
        try:
            return env_config.to_dict()
        except Exception as e:
            logger.error(f"Failed to serialize EnvironmentConfig: {e}")
            raise TypeError(f"Cannot serialize EnvironmentConfig: {e}") from e

    def from_dict(self, env_config_dict: Dict[str, Any]) -> EnvironmentConfig:
        """Convert a dictionary to EnvironmentConfig.

        Uses the `_config_class` field to dynamically import and instantiate
        the correct EnvironmentConfig subclass. Falls back to sandbox_type
        detection if `_config_class` is not present.

        Args:
            env_config_dict: Dictionary containing environment configuration data

        Returns:
            EnvironmentConfig instance of the appropriate subclass

        Raises:
            ValueError: If config type cannot be determined
            ImportError: If config class cannot be imported
        """
        # Try to use _config_class field for type information
        config_class_name = env_config_dict.get("_config_class")
        if config_class_name:
            try:
                # Split module path and class name
                module_path, class_name = config_class_name.rsplit(".", 1)

                # Dynamically import the module
                import importlib

                module = importlib.import_module(module_path)

                # Get the class from the module
                config_class = getattr(module, class_name)

                # Instantiate using from_dict
                logger.debug(
                    f"Deserializing environment config using _config_class: {config_class_name}"
                )
                return config_class.from_dict(env_config_dict)
            except (ImportError, AttributeError, ValueError) as e:
                logger.warning(
                    f"Failed to deserialize using _config_class '{config_class_name}': {e}. "
                    f"Falling back to sandbox_type detection."
                )

        # Fallback: Use sandbox_type
        sandbox_type = env_config_dict.get("sandbox_type", "docker")

        if sandbox_type == "docker":
            from ee_bench_core.adapters.docker import DockerEnvironmentConfig

            logger.debug("Deserializing as DockerEnvironmentConfig")
            return DockerEnvironmentConfig.from_dict(env_config_dict)
        elif sandbox_type == "local":
            from ee_bench_core.adapters.local import LocalEnvironmentConfig

            logger.debug("Deserializing as LocalEnvironmentConfig")
            return LocalEnvironmentConfig.from_dict(env_config_dict)
        else:
            raise ValueError(
                f"Unknown sandbox_type: {sandbox_type}. "
                f"Cannot deserialize environment config."
            )

    def get_collection_type(self) -> str:
        """Get the collection type for environment configs.

        Returns:
            "dict" - environment configs are stored as a JSON dictionary
                    keyed by instance_id
        """
        return "dict"

    def get_item_key(self, item: EnvironmentConfig) -> str:
        """Get the unique key for an environment config.

        Args:
            item: EnvironmentConfig to extract key from

        Returns:
            The instance_id of the environment config

        Raises:
            ValueError: If instance_id is not set
        """
        if not hasattr(item, "instance_id") or not item.instance_id:
            raise ValueError("EnvironmentConfig must have an instance_id")
        return item.instance_id
