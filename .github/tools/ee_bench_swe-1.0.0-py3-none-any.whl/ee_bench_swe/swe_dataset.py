"""SWE-bench dataset manager implementation.

This module provides dataset management for SWE-bench specification,
including loading, filtering, and managing benchmark task instances.
"""

import json
import logging
from pathlib import Path
from typing import Dict, List, Optional
from urllib.parse import urlparse

from ee_bench_core.core.abc_types import DatasetManager
from ee_bench_core.core.errors import DatasetError
from ee_bench_core.core.utils.io import download_file, copy_file

from .swe_config import SweBenchmarkConfig

logger = logging.getLogger(__name__)


class SweDatasetManager(DatasetManager):
    """Dataset manager for SWE-bench specification.

    Manages dataset files and instance retrieval for SWE-bench tasks.
    Supports loading from local files and downloading from URLs.
    """

    def __init__(self, working_dir: str = "."):
        """Initialize the dataset manager.

        Args:
            working_dir: Working directory for dataset files
        """
        self.working_dir = Path(working_dir)

        # Known dataset URLs for auto-download
        self.dataset_urls = {}

    def get_dataset_instance(
        self,
        instance_id: str,
        **kwargs
    ) -> SweBenchmarkConfig:
        """Retrieve a specific dataset instance by ID.

        First searches local dataset files. If not found, attempts to
        download known datasets and search them.

        Args:
            instance_id: Unique identifier for the task instance
            **kwargs: Additional parameters (language filter, dataset_name, etc.)

        Returns:
            SweBenchmarkConfig for the requested instance

        Raises:
            DatasetError: If instance not found or cannot be loaded
        """
        language_filter = kwargs.get("language")
        dataset_name = kwargs.get("dataset_name")

        # If dataset_name is a valid file path, search there first
        if dataset_name and Path(dataset_name).is_file():
            logger.debug(f"Searching for {instance_id} in specified dataset file: {dataset_name}")
            try:
                config = self._load_instance_from_file(instance_id, Path(dataset_name), language_filter)
                if config:
                    logger.info(f"Found task {instance_id} in {dataset_name}")
                    return config
            except Exception as e:
                logger.debug(f"Error loading from {dataset_name}: {e}")

        # First try to find in local files
        files_by_language = self._find_local_dataset_files()

        for language in sorted(files_by_language.keys()):
            # Skip if language filter specified and doesn't match
            if language_filter and language != language_filter:
                continue

            logger.debug(f"Looking for task {instance_id} in language {language or 'any'}")
            for dataset_file in files_by_language[language]:
                logger.debug(f"Searching in file {dataset_file}")
                try:
                    config = self._load_instance_from_file(instance_id, dataset_file, language)
                    if config:
                        logger.info(f"Found task {instance_id} in {dataset_file}")
                        return config
                except Exception as e:
                    logger.debug(f"Error loading from {dataset_file}: {e}")
                    continue

        # If not found locally, try downloading known datasets
        logger.info(f"Task {instance_id} not found locally, attempting to download datasets...")

        for filename, descriptor in self.dataset_urls.items():
            try:
                language = descriptor["language"]
                if language_filter and language != language_filter:
                    continue

                url = descriptor["url"]
                dataset_file = self._download_dataset_file(url, language, filename)
                config = self._load_instance_from_file(instance_id, dataset_file, language)
                if config:
                    logger.info(f"Found task {instance_id} in downloaded dataset: {dataset_file}")
                    return config
            except Exception as e:
                logger.debug(f"Task {instance_id} not found in {filename}: {e}")
                continue

        raise DatasetError(f"Task ID {instance_id} not found in any available dataset")

    def list_dataset_instances(
        self,
        dataset_name: Optional[str] = None,
        filters: Optional[Dict] = None,
        **kwargs
    ) -> List[SweBenchmarkConfig]:
        """List all available dataset instances.

        Args:
            dataset_name: Optional name of specific dataset to list
            filters: Optional filters to apply (e.g., {"language": "java", "repo": "spring-petclinic"})
            **kwargs: Additional parameters

        Returns:
            List of SweBenchmarkConfig instances matching criteria
        """
        filters = filters or {}
        configs = []

        if dataset_name:
            # Load specific dataset
            try:
                dataset_path = self._resolve_dataset_path(dataset_name)
                configs = self._load_all_from_file(dataset_path)
            except Exception as e:
                raise DatasetError(f"Failed to load dataset {dataset_name}: {e}")
        else:
            # Load all local datasets
            files_by_language = self._find_local_dataset_files()
            for language, dataset_files in files_by_language.items():
                for dataset_file in dataset_files:
                    try:
                        file_configs = self._load_all_from_file(dataset_file, language)
                        configs.extend(file_configs)
                    except Exception as e:
                        logger.warning(f"Failed to load {dataset_file}: {e}")
                        continue

        # Apply filters
        if filters:
            configs = self._apply_filters(configs, filters)

        return configs

    def install_dataset(
        self,
        dataset_url: str,
        dataset_name: Optional[str] = None,
        **kwargs
    ) -> Path:
        """Download and install a dataset from a URL.

        Args:
            dataset_url: URL to download the dataset from (or local file path)
            dataset_name: Optional name to save the dataset as
            **kwargs: Additional parameters (language, etc.)

        Returns:
            Path to the installed dataset file

        Raises:
            DatasetError: If download or installation fails
        """
        language = kwargs.get("language", "jvm")

        logger.info(f"Installing dataset from {dataset_url} with language={language}")

        # Check if it's a URL
        if dataset_url.startswith(('http://', 'https://')):
            return self._install_from_url(dataset_url, language, dataset_name)

        # Check if it's a local file path
        if Path(dataset_url).exists():
            return self._install_from_local_file(dataset_url, language, dataset_name)

        # Check if it's a known dataset name
        if dataset_url in self.dataset_urls:
            descriptor = self.dataset_urls[dataset_url]
            url = descriptor["url"]
            lang = descriptor.get("language", language)
            return self._download_dataset_file(url, lang, dataset_url)

        raise DatasetError(
            f"Dataset '{dataset_url}' not found. Must be a valid URL, file path, or known dataset name."
        )

    def _find_local_dataset_files(self) -> Dict[Optional[str], List[Path]]:
        """Find local dataset JSON files grouped by language.

        Returns:
            Mapping of language to list of dataset file paths
        """
        datasets_root = self.working_dir / "datasets"
        datasets_root.mkdir(parents=True, exist_ok=True)

        files_by_language: Dict[Optional[str], List[Path]] = {}

        # Check for task-specific config (inside containers)
        top_level_config = self.working_dir / "task-config.json"
        if top_level_config.exists() and top_level_config.is_file():
            return {None: [top_level_config]}

        # Scan datasets directory
        for lang_dir in sorted(datasets_root.iterdir()) if datasets_root.exists() else []:
            if not lang_dir.is_dir():
                continue

            language = lang_dir.name
            lang_files: List[Path] = []

            for file_path in lang_dir.glob("*.json"):
                if file_path.is_file():
                    lang_files.append(file_path)

            if lang_files:
                files_by_language[language] = sorted(set(lang_files))

        logger.debug(f"Found local dataset files: {files_by_language}")
        return files_by_language

    def _load_instance_from_file(
        self,
        instance_id: str,
        file_path: Path,
        language: Optional[str] = None
    ) -> Optional[SweBenchmarkConfig]:
        """Load a specific instance from a dataset file.

        Args:
            instance_id: Instance ID to find
            file_path: Path to dataset JSON file
            language: Language hint

        Returns:
            SweBenchmarkConfig if found, None otherwise
        """
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            if not isinstance(data, list):
                return None

            for item in data:
                if not isinstance(item, dict):
                    continue
                if item.get("instance_id") == instance_id:
                    return self._item_to_config(item, language or file_path.parent.name)

            return None
        except Exception as e:
            logger.debug(f"Error loading from {file_path}: {e}")
            return None

    def _load_all_from_file(
        self,
        file_path: Path,
        language: Optional[str] = None
    ) -> List[SweBenchmarkConfig]:
        """Load all instances from a dataset file.

        Args:
            file_path: Path to dataset JSON file
            language: Language hint

        Returns:
            List of SweBenchmarkConfig instances
        """
        configs = []

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            if not isinstance(data, list):
                raise DatasetError(f"Dataset file must contain a JSON array: {file_path}")

            lang = language or self._guess_language_from_path(file_path)

            seen_ids = set()
            for item in data:
                if not isinstance(item, dict):
                    continue

                instance_id = item.get("instance_id")
                if not instance_id or instance_id in seen_ids:
                    continue

                seen_ids.add(instance_id)
                config = self._item_to_config(item, lang)
                configs.append(config)

        except json.JSONDecodeError as e:
            raise DatasetError(f"Invalid JSON in {file_path}: {e}")
        except Exception as e:
            raise DatasetError(f"Failed to load {file_path}: {e}")

        return configs

    def _item_to_config(
        self,
        item: Dict,
        language: Optional[str] = None
    ) -> SweBenchmarkConfig:
        """Convert a dataset item dictionary to SweBenchmarkConfig.

        Args:
            item: Raw dataset item dictionary
            language: Language to assign if not in item

        Returns:
            SweBenchmarkConfig instance
        """
        # Parse test lists (may be JSON strings)
        fail_to_pass = item.get("FAIL_TO_PASS", item.get("fail_to_pass", []))
        if isinstance(fail_to_pass, str):
            try:
                fail_to_pass = json.loads(fail_to_pass)
            except:
                fail_to_pass = []

        pass_to_pass = item.get("PASS_TO_PASS", item.get("pass_to_pass", []))
        if isinstance(pass_to_pass, str):
            try:
                pass_to_pass = json.loads(pass_to_pass)
            except:
                pass_to_pass = []

        # Parse optional fields
        issue_numbers = item.get("issue_numbers")
        if isinstance(issue_numbers, str):
            try:
                issue_numbers = json.loads(issue_numbers)
            except:
                issue_numbers = None

        tags = item.get("tags")
        if isinstance(tags, str):
            try:
                tags = json.loads(tags)
            except:
                tags = None

        # Ensure language is set
        lang = item.get("language") or language or "jvm"

        return SweBenchmarkConfig(
            instance_id=item["instance_id"],
            repo=item.get("repo", ""),
            base_commit=item.get("base_commit", ""),
            problem_statement=item.get("problem_statement", ""),
            patch=item.get("patch"),
            test_patch=item.get("test_patch"),
            fail_to_pass=fail_to_pass,
            pass_to_pass=pass_to_pass,
            issue_numbers=issue_numbers,
            tags=tags,
            created_at=item.get("created_at"),
            version=item.get("version"),
            language=lang,
            _raw_instance=item
        )

    def _apply_filters(
        self,
        configs: List[SweBenchmarkConfig],
        filters: Dict
    ) -> List[SweBenchmarkConfig]:
        """Apply filters to a list of configs.

        Args:
            configs: List of configurations
            filters: Dictionary of filters

        Returns:
            Filtered list of configurations
        """
        filtered = configs

        for key, value in filters.items():
            if key == "language":
                filtered = [c for c in filtered if c.language == value]
            elif key == "repo":
                filtered = [c for c in filtered if value in c.repo]
            elif key == "tags":
                # Filter by tag
                if isinstance(value, list):
                    filtered = [c for c in filtered if c.tags and any(t in c.tags for t in value)]
                else:
                    filtered = [c for c in filtered if c.tags and value in c.tags]
            elif hasattr(filtered[0] if filtered else None, key):
                # Generic attribute filter
                filtered = [c for c in filtered if getattr(c, key, None) == value]

        return filtered

    def _download_dataset_file(
        self,
        url: str,
        language: str,
        filename: Optional[str] = None
    ) -> Path:
        """Download a dataset JSON file.

        Args:
            url: HTTPS URL pointing to the dataset JSON
            language: Language label for subfolder
            filename: Optional filename override

        Returns:
            Path to the downloaded file

        Raises:
            DatasetError: For network or HTTP errors
        """
        dest_dir = self.working_dir / "datasets" / language
        return download_file(url, dest_dir, filename, timeout=30, skip_if_exists=True)

    def _install_from_url(
        self,
        url: str,
        language: str,
        dataset_name: Optional[str] = None
    ) -> Path:
        """Install dataset from URL.

        Args:
            url: Dataset URL
            language: Language specification
            dataset_name: Optional name override

        Returns:
            Path to installed dataset
        """
        if not dataset_name:
            parsed_url = urlparse(url)
            dataset_name = Path(parsed_url.path).name
            if not dataset_name.endswith('.json'):
                dataset_name += '.json'

        return self._download_dataset_file(url, language, dataset_name)

    def _install_from_local_file(
        self,
        source_path: str,
        language: str,
        dataset_name: Optional[str] = None
    ) -> Path:
        """Install dataset from local file by copying.

        Args:
            source_path: Source file path
            language: Language specification
            dataset_name: Optional name override

        Returns:
            Path to installed dataset

        Raises:
            DatasetError: If source doesn't exist or isn't JSON
        """
        source = Path(source_path)
        if not source.suffix == '.json':
            raise DatasetError(f"Dataset file must be a JSON file: {source_path}")

        target_dir = self.working_dir / "datasets" / language
        return copy_file(source, target_dir, filename=dataset_name, overwrite=False)

    def _resolve_dataset_path(self, dataset_name: str) -> Path:
        """Resolve dataset name to file path.

        Args:
            dataset_name: Dataset name, stem, or path

        Returns:
            Resolved path to dataset file

        Raises:
            DatasetError: If dataset not found
        """
        # Try direct path
        candidate = Path(dataset_name)
        if candidate.exists() and candidate.is_file():
            return candidate

        # Search under datasets directory
        datasets_root = self.working_dir / "datasets"
        if datasets_root.exists():
            for p in datasets_root.rglob("*.json"):
                if p.name == dataset_name or p.stem == dataset_name:
                    return p

        # Try known datasets
        if dataset_name in self.dataset_urls:
            descriptor = self.dataset_urls[dataset_name]
            lang = descriptor.get("language", "jvm")
            url = descriptor.get("url")
            return self._download_dataset_file(url, lang, dataset_name)

        raise DatasetError(f"Dataset not found: {dataset_name}")

    def _guess_language_from_path(self, p: Path) -> Optional[str]:
        """Guess language from dataset file path.

        Args:
            p: Dataset file path

        Returns:
            Language string or None
        """
        try:
            parts = p.resolve().parts
        except:
            parts = p.parts

        if "datasets" in parts:
            i = parts.index("datasets")
            if i + 1 < len(parts):
                return parts[i + 1]

        # Fallback to parent dir name
        return p.parent.name if p.parent and p.parent.name else None
