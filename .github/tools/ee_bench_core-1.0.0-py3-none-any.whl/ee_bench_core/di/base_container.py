"""Base dependency injection container.

This module defines the base container that provides common dependencies
for all specifications.
"""

from dependency_injector import containers, providers

from ee_bench_core.adapters.process_manager import LocalProcessManager
from ee_bench_core.adapters.docker import DockerProcessManager
from ee_bench_core.adapters.patch import PatchAdapter


class BaseContainer(containers.DeclarativeContainer):
    """Base container for all specifications.

    This container provides the most common dependencies that almost all specs need:
    - ProcessManager (local or docker based on execution_mode)
    - PatchAdapter (with correct ProcessManager)
    - Evaluators (placeholder - to be provided by specification containers)

    Specification-specific containers should extend this and add their
    specific dependencies (TestRunner, PredictionsProvider, Evaluators, etc.).

    Configuration keys:
        - execution_mode: "local" or "docker" for ProcessManager selection
    """

    # Parent container for shared dependencies (ApplicationContainer)
    app = providers.DependenciesContainer()

    # Configuration provider
    config = providers.Configuration()

    # ProcessManager Factory (runtime decision based on execution_mode)
    # Returns LocalProcessManager or DockerProcessManager based on configuration
    process_manager = providers.Selector(
        config.execution_mode,
        local=providers.Factory(LocalProcessManager),
        docker=providers.Factory(
            DockerProcessManager, docker_adapter=app.docker_adapter
        ),
    )

    # PatchAdapter Factory
    # Returns PatchAdapter with injected ProcessManager
    patch_adapter = providers.Factory(PatchAdapter, process_manager=process_manager)

    # Evaluators - Placeholder (to be provided by subclasses)
    # Specification containers should override this with actual evaluator pipeline
    # This is declared here to establish the contract that all specs provide evaluators
