"""Unified file manager with protocol and format support.

Provides high-level API for file operations with:
- Multi-protocol support (file://, http://, https://, hf://)
- Format handling (JSON, JSONL)
- Optional caching
- Automatic protocol and format detection
"""

import logging
from pathlib import Path
from typing import Any, Optional, Iterator

from .cache_manager import CacheManager
from .formats import FormatHandler, JsonHandler, JsonlHandler
from .protocols.registry import ProtocolProviderRegistry

logger = logging.getLogger(__name__)


class FileManager:
    """Unified file operations with protocol and cache support.

    Orchestrates protocol providers, format handlers, and cache manager
    to provide a simple high-level API for file operations.

    Examples:
        # Load JSON from HTTP with caching
        fm = FileManager(use_cache=True)
        data = fm.load("https://example.com/dataset.json", format="json")

        # Load JSONL from HuggingFace
        data = fm.load("hf://username/dataset/data.jsonl", format="jsonl")

        # Save with auto-format detection
        fm.save("dataset.json", data)  # Detects JSON format from extension

        # Stream large JSONL file
        for item in fm.stream_load("large-dataset.jsonl"):
            process(item)
    """

    def __init__(
        self,
        use_cache: bool = False,
        cache_dir: Optional[Path] = None,
        protocol_registry: Optional[ProtocolProviderRegistry] = None,
    ):
        """Initialize file manager.

        Args:
            use_cache: Enable caching for remote files (default: False)
            cache_dir: Custom cache directory (default: ~/.ee-bench/cache)
            protocol_registry: Custom protocol registry (creates default if None)
        """
        self.use_cache = use_cache
        self.cache_manager = CacheManager(cache_dir=cache_dir)

        # Initialize protocol registry
        if protocol_registry is None:
            self.protocol_registry = ProtocolProviderRegistry(auto_discover=True)
        else:
            self.protocol_registry = protocol_registry

        # Initialize format handlers
        self._format_handlers: dict[str, FormatHandler] = {
            "json": JsonHandler(),
            "jsonl": JsonlHandler(),
        }

        logger.debug(
            f"FileManager initialized (cache={'enabled' if use_cache else 'disabled'})"
        )

    def load(
        self,
        path: str,
        format: Optional[str] = None,
        use_cache: Optional[bool] = None,
        **kwargs,
    ) -> Any:
        """Load and decode file from any supported protocol.

        Args:
            path: URI or file path (e.g., "https://example.com/data.json")
            format: Format to use ("json", "jsonl", or None for auto-detect)
            use_cache: Override instance cache setting (None uses instance setting)
            **kwargs: Additional options passed to protocol provider

        Returns:
            Decoded data (dict, list, etc. depending on format)

        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If format is unsupported or content invalid
            IOError: If loading fails

        Examples:
            # Auto-detect format from extension
            data = fm.load("dataset.json")

            # Explicit format
            data = fm.load("dataset.txt", format="json")

            # Remote file with caching
            data = fm.load("https://example.com/data.json", use_cache=True)

            # HuggingFace with token
            data = fm.load("hf://user/dataset/data.json", token="hf_...")
        """
        # Determine cache setting
        enable_cache = use_cache if use_cache is not None else self.use_cache

        # Detect format if not provided
        if format is None:
            format = self._detect_format(path)

        # Get format handler
        handler = self._get_format_handler(format)

        # Get protocol provider
        provider = self.protocol_registry.get_provider_for_uri(path)
        if provider is None:
            raise ValueError(
                f"No protocol provider found for URI: {path}. "
                f"Supported schemes: {self.protocol_registry.get_supported_schemes()}"
            )

        scheme = self._extract_scheme(path)
        logger.debug(f"Loading {path} using {provider.__class__.__name__} (format={format})")

        # Check cache first if enabled
        if enable_cache and scheme not in ("file", ""):
            cached_content = self.cache_manager.get_cached_content(path, scheme)
            if cached_content is not None:
                logger.info(f"Using cached content for {path}")
                return handler.decode(cached_content)

        # Load content via protocol provider
        cache_path = None
        if enable_cache and scheme not in ("file", ""):
            cache_path = self.cache_manager.get_cache_path(path, scheme)

        content = provider.load(path, cache_path=cache_path, **kwargs)

        # Decode content
        try:
            data = handler.decode(content)
            logger.info(f"Loaded {len(content)} bytes from {path} (format={format})")
            return data
        except ValueError as e:
            raise ValueError(f"Failed to decode {format.upper()} from {path}: {e}") from e

    def save(
        self,
        path: str,
        data: Any,
        format: Optional[str] = None,
        use_cache: Optional[bool] = None,
        **kwargs,
    ) -> str:
        """Encode and save data to any supported protocol.

        Args:
            path: URI or file path where to save
            data: Data to save
            format: Format to use ("json", "jsonl", or None for auto-detect)
            use_cache: Override instance cache setting (None uses instance setting)
            **kwargs: Additional options passed to protocol provider

        Returns:
            Final URI/path where content was saved

        Raises:
            ValueError: If format is unsupported or data invalid
            IOError: If saving fails

        Examples:
            # Auto-detect format from extension
            fm.save("dataset.json", data)

            # Explicit format
            fm.save("dataset.txt", data, format="jsonl")

            # HuggingFace upload with token
            fm.save("hf://user/dataset/data.json", data, token="hf_...")
        """
        # Determine cache setting
        enable_cache = use_cache if use_cache is not None else self.use_cache

        # Detect format if not provided
        if format is None:
            format = self._detect_format(path)

        # Get format handler
        handler = self._get_format_handler(format)

        # Encode data
        try:
            content = handler.encode(data)
        except ValueError as e:
            raise ValueError(f"Failed to encode {format.upper()}: {e}") from e

        # Get protocol provider
        provider = self.protocol_registry.get_provider_for_uri(path)
        if provider is None:
            raise ValueError(
                f"No protocol provider found for URI: {path}. "
                f"Supported schemes: {self.protocol_registry.get_supported_schemes()}"
            )

        scheme = self._extract_scheme(path)
        logger.debug(f"Saving to {path} using {provider.__class__.__name__} (format={format})")

        # Save via protocol provider
        result_uri = provider.save(path, content, **kwargs)

        # Update cache if enabled
        if enable_cache and scheme not in ("file", ""):
            self.cache_manager.save_to_cache(path, scheme, content)
            logger.debug(f"Cached content for {path}")

        logger.info(f"Saved {len(content)} bytes to {result_uri} (format={format})")
        return result_uri

    def exists(
        self,
        path: str,
        use_cache: Optional[bool] = None,
        **kwargs,
    ) -> bool:
        """Check if file exists.

        Args:
            path: URI or file path to check
            use_cache: Check cache first if enabled (None uses instance setting)
            **kwargs: Additional options passed to protocol provider

        Returns:
            True if file exists, False otherwise

        Examples:
            if fm.exists("dataset.json"):
                data = fm.load("dataset.json")
        """
        # Determine cache setting
        enable_cache = use_cache if use_cache is not None else self.use_cache

        scheme = self._extract_scheme(path)

        # Check cache first if enabled
        if enable_cache and scheme not in ("file", ""):
            if self.cache_manager.exists(path, scheme):
                logger.debug(f"Found {path} in cache")
                return True

        # Check via protocol provider
        provider = self.protocol_registry.get_provider_for_uri(path)
        if provider is None:
            return False

        return provider.exists(path, **kwargs)

    def delete(
        self,
        path: str,
        delete_cache: bool = True,
        **kwargs,
    ) -> bool:
        """Delete file.

        Args:
            path: URI or file path to delete
            delete_cache: Also delete from cache if present
            **kwargs: Additional options passed to protocol provider

        Returns:
            True if file was deleted, False otherwise

        Note:
            Only local file:// protocol supports deletion.
            For remote protocols, only cache can be deleted.

        Examples:
            # Delete local file
            fm.delete("dataset.json")

            # Delete only cache entry
            fm.delete("https://example.com/data.json", delete_cache=True)
        """
        scheme = self._extract_scheme(path)
        deleted = False

        # Delete from cache if requested
        if delete_cache and scheme not in ("file", ""):
            if self.cache_manager.delete(path, scheme):
                logger.debug(f"Deleted cache entry for {path}")
                deleted = True

        # Try to delete actual file (only works for local files)
        if scheme in ("file", ""):
            from .protocols.file_provider import FileProvider

            provider = FileProvider()
            try:
                file_path = provider._uri_to_path(path)
                if file_path.exists():
                    file_path.unlink()
                    logger.info(f"Deleted file: {file_path}")
                    deleted = True
            except Exception as e:
                logger.warning(f"Failed to delete {path}: {e}")

        return deleted

    def stream_load(
        self,
        path: str,
        format: Optional[str] = None,
        use_cache: Optional[bool] = None,
        **kwargs,
    ) -> Iterator[Any]:
        """Stream and decode file content (memory efficient for large files).

        Args:
            path: URI or file path
            format: Format to use ("json", "jsonl", or None for auto-detect)
            use_cache: Override instance cache setting (None uses instance setting)
            **kwargs: Additional options passed to protocol provider

        Yields:
            Decoded data items

        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If format is unsupported or content invalid
            IOError: If loading fails

        Note:
            JSON format does not support true streaming - entire file loaded to memory.
            JSONL format supports true streaming - one line at a time.

        Examples:
            # Stream large JSONL file
            for item in fm.stream_load("large-dataset.jsonl"):
                process(item)

            # Stream with explicit format
            for item in fm.stream_load("data.txt", format="jsonl"):
                process(item)
        """
        # Determine cache setting
        enable_cache = use_cache if use_cache is not None else self.use_cache

        # Detect format if not provided
        if format is None:
            format = self._detect_format(path)

        # Get format handler
        handler = self._get_format_handler(format)

        # Get protocol provider
        provider = self.protocol_registry.get_provider_for_uri(path)
        if provider is None:
            raise ValueError(
                f"No protocol provider found for URI: {path}. "
                f"Supported schemes: {self.protocol_registry.get_supported_schemes()}"
            )

        scheme = self._extract_scheme(path)
        logger.debug(f"Streaming {path} using {provider.__class__.__name__} (format={format})")

        # Get stream from protocol provider
        cache_path = None
        if enable_cache and scheme not in ("file", ""):
            cache_path = self.cache_manager.get_cache_path(path, scheme)

        stream = provider.stream_load(path, cache_path=cache_path, **kwargs)

        # Decode stream
        try:
            yield from handler.decode_stream(stream)
        except ValueError as e:
            raise ValueError(f"Failed to decode {format.upper()} from {path}: {e}") from e
        finally:
            # Close stream
            try:
                stream.close()
            except Exception:
                pass

    def clear_cache(self, scheme: Optional[str] = None) -> int:
        """Clear cached files.

        Args:
            scheme: Optional scheme to clear (clears all if None)

        Returns:
            Number of files deleted

        Examples:
            # Clear all cache
            fm.clear_cache()

            # Clear only HTTP cache
            fm.clear_cache(scheme="http")
        """
        return self.cache_manager.clear_cache(scheme=scheme)

    def get_cache_info(self) -> dict[str, Any]:
        """Get cache information.

        Returns:
            Dictionary with cache statistics

        Examples:
            info = fm.get_cache_info()
            print(f"Cache size: {info['total_size_mb']:.2f} MB")
        """
        total_size = self.cache_manager.get_cache_size()
        return {
            "enabled": self.use_cache,
            "directory": str(self.cache_manager.cache_dir),
            "total_size_bytes": total_size,
            "total_size_mb": total_size / (1024 * 1024),
            "supported_schemes": self.protocol_registry.get_supported_schemes(),
        }

    def _detect_format(self, path: str) -> str:
        """Detect format from file extension.

        Args:
            path: File path or URI

        Returns:
            Format string ("json" or "jsonl")

        Raises:
            ValueError: If format cannot be detected
        """
        # Extract filename from path
        from urllib.parse import urlparse, unquote

        parsed = urlparse(path)
        path_part = unquote(parsed.path) if parsed.path else path

        # Get extension
        ext = Path(path_part).suffix.lower().lstrip(".")

        if ext in ("json",):
            return "json"
        elif ext in ("jsonl",):
            return "jsonl"
        else:
            # Default to JSON
            logger.debug(f"Unknown extension '{ext}', defaulting to JSON format")
            return "json"

    def _get_format_handler(self, format: str) -> FormatHandler:
        """Get format handler by name.

        Args:
            format: Format name

        Returns:
            FormatHandler instance

        Raises:
            ValueError: If format is not supported
        """
        handler = self._format_handlers.get(format.lower())
        if handler is None:
            raise ValueError(
                f"Unsupported format: {format}. "
                f"Supported formats: {list(self._format_handlers.keys())}"
            )
        return handler

    def _extract_scheme(self, uri: str) -> str:
        """Extract scheme from URI.

        Args:
            uri: URI string

        Returns:
            Scheme string (lowercase) or empty string if no scheme
        """
        from urllib.parse import urlparse

        parsed = urlparse(uri)
        return parsed.scheme.lower() if parsed.scheme else ""
