"""Base SWE-bench specification dependency injection container.

This module defines the base SweContainer that provides common dependencies
for all SWE-bench format evaluations.
"""

from typing import List

from dependency_injector import providers

from ee_bench_core.di.base_container import BaseContainer
from ee_bench_swe.swe_predictions import GoldPredictionsProvider, JsonPredictionsProvider


def _create_evaluators_pipeline(test_runner, patch_adapter, predictions_provider) -> List:
    """Create SWE-bench evaluator pipeline with injected dependencies.

    This is a wrapper for the DI factory function to work with dependency-injector.

    Args:
        test_runner: Injected TestRunner
        patch_adapter: Injected PatchAdapter
        predictions_provider: Injected PredictionsProvider (Gold/Json)

    Returns:
        List of evaluators with all dependencies injected
    """
    from ee_bench_swe.swe_evaluator_factory import create_standard_swe_pipeline
    return create_standard_swe_pipeline(
        test_runner=test_runner,
        patch_adapter=patch_adapter,
        predictions_provider=predictions_provider
    )


class SweContainer(BaseContainer):
    """Base container for SWE-bench specifications.

    Extends BaseContainer with SWE-bench specific dependencies:
    - PredictionsProvider (gold or json based on predictions_mode)
    - TestRunner (ABSTRACT - must be provided by language-specific container)
    - Evaluators pipeline (uses TestRunner, PatchAdapter, PredictionsProvider)

    Inherits from BaseContainer:
    - ProcessManager (local or docker)
    - PatchAdapter (with ProcessManager)

    Language-specific containers (JvmSweContainer, PythonSweContainer, etc.)
    MUST extend this and provide concrete TestRunner implementation.

    Configuration keys (in addition to BaseContainer):
        - predictions_mode: "gold" or "json" for PredictionsProvider selection
        - predictions_path: Path to predictions file (for json mode)
        - build_system: Build system for test runner selection (language-specific)
    """

    # PredictionsProvider Factory (gold or json based on predictions_mode)
    # Returns GoldPredictionsProvider or JsonPredictionsProvider
    predictions_provider = providers.Selector(
        BaseContainer.config.predictions_mode,
        gold=providers.Factory(GoldPredictionsProvider),
        json=providers.Factory(
            JsonPredictionsProvider,
            prediction_path=BaseContainer.config.predictions_path
        ),
    )

    # TestRunner - To be provided by language-specific containers
    # Language-specific containers MUST override this
    # Not declared here to avoid capturing abstract reference

    # Evaluators Factory - To be provided by language-specific containers
    # Subclasses should define using pattern:
    #   evaluators = providers.Factory(
    #       lambda tr, pa, pp: _create_evaluators_pipeline(tr, pa, pp),
    #       tr=test_runner,  # Subclass's concrete test_runner
    #       pa=BaseContainer.patch_adapter,
    #       pp=predictions_provider
    #   )
    # Helper function _create_evaluators_pipeline() is provided in this module
