"""Local environment initializer configurer."""

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Optional, Union, List

from ee_bench_core.core.eval import EnvironmentConfigurer, DependencyPosition

if TYPE_CHECKING:
    from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig
    from ee_bench_core.core.base_spec import BaseEvalSpec

from .local_env_config import LocalEnvironmentConfig

logger = logging.getLogger(__name__)


class LocalEnvironmentInitializer(EnvironmentConfigurer):
    """Creates initial LocalEnvironmentConfig for local sandbox mode.

    This configurer runs FIRST (priority=-1000) and creates the base
    LocalEnvironmentConfig instance that subsequent configurers will enhance.

    It only runs when --sandbox local is specified.

    Subsequent configurers will populate env_vars with tool paths:
    - JAVA_HOME
    - MAVEN_HOME or GRADLE_HOME
    - Other tool-specific environment variables
    """

    __configurer_name__ = "local_environment_initializer"
    __configurer_description__ = "Creates initial LocalEnvironmentConfig"
    __configurer_version__ = "1.0.0"
    __configurer_specs__ = []  # Applies to all specs

    def __init__(self, workspace_base_dir: Optional[Path] = None, **kwargs):
        """Initialize local environment initializer.

        Args:
            workspace_base_dir: Base directory for workspaces (default: ./workspaces)
            **kwargs: Additional parameters
        """
        self.workspace_base_dir = workspace_base_dir or Path("./workspaces")

    @property
    def name(self) -> str:
        """Return configurer name."""
        return "local_environment_initializer"

    @property
    def description(self) -> str:
        """Return configurer description."""
        return "Creates initial LocalEnvironmentConfig for local sandbox"

    @property
    def specs(self) -> Optional[list[str]]:
        """Return specs this configurer applies to."""
        return []  # Apply to all specs

    @property
    def dependencies(self) -> Optional[Union[List[str], DependencyPosition]]:
        """Return dependency specification.

        Returns:
            DependencyPosition with highest priority (lowest number) to run first
        """
        # Run FIRST - highest priority (lowest number)
        return DependencyPosition(priority=-1000)

    def should_configure(
        self,
        spec: "BaseEvalSpec",
        env_config: "EnvironmentConfig",
        config: "DatasetConfig",
        **kwargs,
    ) -> tuple[bool, Optional[str]]:
        """Check if local environment should be initialized.

        Args:
            spec: Evaluation specification
            env_config: Environment configuration (will be None initially)
            config: Dataset configuration
            **kwargs: Additional parameters including 'sandbox'

        Returns:
            Tuple of (should_configure, reason)
        """
        # Check sandbox parameter
        sandbox = kwargs.get("sandbox", "docker")

        if sandbox != "local":
            return False, f"Sandbox is '{sandbox}', not 'local'"

        # Don't re-initialize if already created
        if isinstance(env_config, LocalEnvironmentConfig):
            return False, "LocalEnvironmentConfig already initialized"

        return True, None

    def configure(
        self,
        spec: "BaseEvalSpec",
        env_config: "EnvironmentConfig",
        config: "DatasetConfig",
        **kwargs,
    ) -> "EnvironmentConfig":
        """Create initial LocalEnvironmentConfig.

        Args:
            spec: Evaluation specification
            env_config: Existing environment config (may be None)
            config: Dataset configuration
            **kwargs: Additional parameters

        Returns:
            New LocalEnvironmentConfig instance
        """
        logger.info(f"Initializing local environment for {config.instance_id}")

        # Create workspace directory path
        workspace_dir = self.workspace_base_dir / config.instance_id
        workspace_dir.mkdir(parents=True, exist_ok=True)

        # Create initial local environment config
        # Subsequent configurers will populate env_vars with:
        # - JAVA_HOME
        # - MAVEN_HOME or GRADLE_HOME
        # - Other tool-specific environment variables
        local_config = LocalEnvironmentConfig(
            instance_id=config.instance_id,
            workspace_dir=workspace_dir,
            env_vars={},  # Will be populated by subsequent configurers
        )

        logger.debug(f"Created LocalEnvironmentConfig: {local_config.to_dict()}")
        logger.info(f"Local workspace created at: {workspace_dir}")

        return local_config
