"""ee_bench.dsl — Python DSL for building ee-bench scripts.

Example::

    from ee_bench.dsl import env, write_output, run_script
"""

from ee_bench.dsl.env import env
from ee_bench.dsl.output import write_output
from ee_bench.dsl.runner import run_script

__version__ = "0.1.0"

__all__ = [
    "env",
    "write_output",
    "run_script",
]
