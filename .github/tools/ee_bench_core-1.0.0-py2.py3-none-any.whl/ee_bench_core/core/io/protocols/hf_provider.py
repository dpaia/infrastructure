"""HuggingFace protocol provider for Hub datasets.

Handles hf:// URIs for downloading datasets from HuggingFace Hub.
"""

import logging
from pathlib import Path
from typing import BinaryIO, Optional

from .base import FileProtocolProvider

logger = logging.getLogger(__name__)


class HuggingFaceProvider(FileProtocolProvider):
    """Protocol provider for hf:// scheme (HuggingFace Hub).

    Handles URIs like:
    - hf://datasets/username/dataset-name/file.json
    - hf://username/dataset-name (downloads default file)
    - hf://username/dataset-name@branch/file.json (specific branch/revision)

    Requires huggingface_hub package to be installed.
    """

    # Plugin metadata
    __provider_name__ = "huggingface"
    __provider_description__ = "HuggingFace Hub hf:// protocol for datasets"
    __provider_version__ = "1.0.0"
    __provider_author__ = "EE-Bench"
    __provider_schemes__ = ["hf"]

    def __init__(self):
        """Initialize HuggingFace provider."""
        self._hf_available = self._check_huggingface_hub()

    @classmethod
    def schemes(cls) -> list[str]:
        """Return supported URI schemes."""
        return ["hf"]

    def load(
        self,
        uri: str,
        cache_path: Optional[Path] = None,
        **kwargs
    ) -> bytes:
        """Load content from HuggingFace Hub.

        Args:
            uri: HuggingFace URI (e.g., hf://username/dataset/file.json)
            cache_path: Optional path to save downloaded file (uses HF cache by default)
            **kwargs: Additional options:
                - token: HuggingFace API token
                - revision: Specific revision/branch (default: main)
                - repo_type: Repository type (default: "dataset")

        Returns:
            File content as bytes

        Raises:
            ImportError: If huggingface_hub not installed
            FileNotFoundError: If file doesn't exist on Hub
            IOError: If download fails
        """
        if not self._hf_available:
            raise ImportError(
                "huggingface_hub package required for hf:// protocol. "
                "Install with: pip install huggingface_hub"
            )

        from huggingface_hub import hf_hub_download
        from huggingface_hub.utils import HfHubHTTPError

        # Parse HF URI
        repo_id, filepath, revision = self._parse_hf_uri(uri)

        token = kwargs.get("token")
        revision = kwargs.get("revision", revision or "main")
        repo_type = kwargs.get("repo_type", "dataset")

        logger.info(f"Downloading from HuggingFace: {repo_id}/{filepath} (revision={revision})")

        try:
            # Download file (uses HF cache automatically)
            downloaded_path = hf_hub_download(
                repo_id=repo_id,
                filename=filepath,
                revision=revision,
                repo_type=repo_type,
                token=token,
            )

            # Read content
            with open(downloaded_path, "rb") as f:
                content = f.read()

            # Copy to custom cache if provided
            if cache_path and cache_path != Path(downloaded_path):
                logger.debug(f"Copying to custom cache: {cache_path}")
                cache_path.parent.mkdir(parents=True, exist_ok=True)
                with open(cache_path, "wb") as f:
                    f.write(content)

            logger.info(f"Downloaded {len(content)} bytes from HuggingFace")
            return content

        except HfHubHTTPError as e:
            if e.response and e.response.status_code == 404:
                raise FileNotFoundError(
                    f"File not found on HuggingFace Hub: {repo_id}/{filepath}"
                ) from e
            raise IOError(f"HTTP error from HuggingFace Hub: {e}") from e
        except Exception as e:
            raise IOError(
                f"Failed to download from HuggingFace Hub {repo_id}/{filepath}: {e}"
            ) from e

    def save(
        self,
        uri: str,
        content: bytes,
        **kwargs
    ) -> str:
        """Save content to HuggingFace Hub.

        Args:
            uri: HuggingFace URI
            content: Content to upload
            **kwargs: Additional options:
                - token: HuggingFace API token (required)
                - commit_message: Commit message (default: "Upload file")
                - repo_type: Repository type (default: "dataset")

        Returns:
            URI of uploaded file

        Raises:
            ImportError: If huggingface_hub not installed
            ValueError: If token not provided
            IOError: If upload fails
        """
        if not self._hf_available:
            raise ImportError(
                "huggingface_hub package required for hf:// protocol. "
                "Install with: pip install huggingface_hub"
            )

        token = kwargs.get("token")
        if not token:
            raise ValueError("HuggingFace token required for uploading. Provide token= kwarg.")

        from huggingface_hub import HfApi
        from io import BytesIO

        # Parse HF URI
        repo_id, filepath, revision = self._parse_hf_uri(uri)

        commit_message = kwargs.get("commit_message", "Upload file via EE-Bench")
        repo_type = kwargs.get("repo_type", "dataset")
        revision = kwargs.get("revision", revision or "main")

        logger.info(f"Uploading to HuggingFace: {repo_id}/{filepath}")

        try:
            api = HfApi(token=token)

            # Upload file
            api.upload_file(
                path_or_fileobj=BytesIO(content),
                path_in_repo=filepath,
                repo_id=repo_id,
                repo_type=repo_type,
                commit_message=commit_message,
                revision=revision,
            )

            logger.info(f"Uploaded to HuggingFace: {repo_id}/{filepath}")
            return uri

        except Exception as e:
            raise IOError(f"Failed to upload to HuggingFace Hub: {e}") from e

    def exists(self, uri: str, **kwargs) -> bool:
        """Check if file exists on HuggingFace Hub.

        Args:
            uri: HuggingFace URI
            **kwargs: Additional options:
                - token: HuggingFace API token
                - repo_type: Repository type (default: "dataset")

        Returns:
            True if file exists, False otherwise
        """
        if not self._hf_available:
            return False

        from huggingface_hub import HfApi
        from huggingface_hub.utils import HfHubHTTPError

        # Parse HF URI
        repo_id, filepath, revision = self._parse_hf_uri(uri)

        token = kwargs.get("token")
        repo_type = kwargs.get("repo_type", "dataset")
        revision = revision or "main"

        try:
            api = HfApi(token=token)
            # List files in repo to check if filepath exists
            files = api.list_repo_files(
                repo_id=repo_id,
                repo_type=repo_type,
                revision=revision,
            )
            return filepath in files
        except HfHubHTTPError:
            return False
        except Exception:
            return False

    def _check_huggingface_hub(self) -> bool:
        """Check if huggingface_hub is available.

        Returns:
            True if package is installed, False otherwise
        """
        try:
            import huggingface_hub
            return True
        except ImportError:
            logger.debug("huggingface_hub package not available")
            return False

    def _parse_hf_uri(self, uri: str) -> tuple[str, str, Optional[str]]:
        """Parse HuggingFace URI into components.

        Args:
            uri: HuggingFace URI (e.g., hf://username/dataset/file.json)

        Returns:
            Tuple of (repo_id, filepath, revision)

        Raises:
            ValueError: If URI format is invalid

        Examples:
            hf://username/dataset-name/file.json -> ("username/dataset-name", "file.json", None)
            hf://username/dataset-name@branch/file.json -> ("username/dataset-name", "file.json", "branch")
            hf://datasets/username/dataset/file.json -> ("username/dataset", "file.json", None)
        """
        from urllib.parse import urlparse

        parsed = urlparse(uri)

        if parsed.scheme != "hf":
            raise ValueError(f"Invalid HuggingFace URI scheme: {parsed.scheme}")

        # Remove leading slash
        path = parsed.path.lstrip("/")

        if not path:
            raise ValueError(f"Invalid HuggingFace URI (no path): {uri}")

        # Handle optional "datasets/" prefix
        if path.startswith("datasets/"):
            path = path[len("datasets/"):]

        # Split path into parts
        parts = path.split("/")

        if len(parts) < 2:
            raise ValueError(
                f"Invalid HuggingFace URI format. Expected hf://username/dataset/file.json, got: {uri}"
            )

        # Check for revision in repo name (e.g., dataset@branch)
        revision = None
        repo_name = parts[1]
        if "@" in repo_name:
            repo_name, revision = repo_name.split("@", 1)
            parts[1] = repo_name

        # Repo ID is username/dataset
        repo_id = f"{parts[0]}/{parts[1]}"

        # Filepath is everything after repo
        if len(parts) > 2:
            filepath = "/".join(parts[2:])
        else:
            # No filepath specified, assume default
            filepath = "dataset.json"

        logger.debug(f"Parsed HF URI: repo_id={repo_id}, filepath={filepath}, revision={revision}")
        return repo_id, filepath, revision
