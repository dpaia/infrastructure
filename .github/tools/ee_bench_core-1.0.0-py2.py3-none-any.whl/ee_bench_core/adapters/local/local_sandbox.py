"""Local sandbox implementation.

This module provides a Sandbox implementation for local execution,
wrapping LocalProcessManager with env_config as instance state.
"""

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Callable, List, Optional, Union

from ee_bench_core.adapters.process_manager import LocalProcessManager
from ee_bench_core.adapters.sandbox_base import Sandbox, ProcessResult

if TYPE_CHECKING:
    from ee_bench_core.core.abc_types import EnvironmentConfig

logger = logging.getLogger(__name__)


class LocalSandbox(Sandbox):
    """Sandbox implementation for local execution.

    Encapsulates a local execution environment with its configuration.
    The environment configuration is stored as instance state.
    """

    def __init__(
        self,
        env_config: "EnvironmentConfig",
        debug_output: bool = True,
    ):
        """Initialize local sandbox with environment configuration.

        Args:
            env_config: Local environment configuration with workspace_dir, etc.
            debug_output: Whether to write process output to debug log in real-time
        """
        super().__init__(env_config)

        # Create LocalProcessManager for delegation
        self._process_manager = LocalProcessManager(debug_output=debug_output)

    def start(self, **kwargs) -> None:
        """Start the local sandbox (no-op).

        For local execution, there's nothing to start.

        Args:
            **kwargs: Additional parameters (ignored)
        """
        # Import here to avoid circular dependency
        from ee_bench_core.adapters.sandbox_base import SandboxStatus

        logger.debug(
            f"LocalSandbox.start() - no-op for instance '{self.get_instance_id()}'"
        )
        # Local sandbox is immediately running after creation
        self._set_status(SandboxStatus.RUNNING)

    def stop(self, **kwargs) -> None:
        """Stop the local sandbox (no-op).

        For local execution, there's nothing to stop.

        Args:
            **kwargs: Additional parameters (ignored)
        """
        # Import here to avoid circular dependency
        from ee_bench_core.adapters.sandbox_base import SandboxStatus

        logger.debug(
            f"LocalSandbox.stop() - no-op for instance '{self.get_instance_id()}'"
        )
        # Transition to stopped state
        self._set_status(SandboxStatus.STOPPED)

    def is_running(self) -> bool:
        """Check if the local sandbox is running.

        For local execution, always returns True.

        Returns:
            Always True for local sandboxes
        """
        return True

    def run_command(
        self,
        cmd: Union[str, List[str]],
        cwd: Optional[Union[str, Path]] = None,
        timeout: Optional[int] = None,
        stdin_input: Optional[str] = None,
        env: Optional[dict] = None,
        shell: bool = False,
        log_prefix: str = "",
        stream_output: bool = False,
        output_callback: Optional[Callable[[str], None]] = None,
        **kwargs,
    ) -> ProcessResult:
        """Run a command locally.

        Phase 3.4: No longer passes env_config to ProcessManager (not needed for local execution).

        Args:
            cmd: Command to execute
            cwd: Working directory for the command
            timeout: Timeout in seconds
            stdin_input: Optional input to send to stdin
            env: Optional environment variables
            shell: Whether to execute through shell
            log_prefix: Prefix for log messages
            stream_output: Stream output in real-time
            output_callback: Callback for each output line
            **kwargs: Additional parameters (ignored)

        Returns:
            ProcessResult with execution details

        Raises:
            RuntimeError: If command execution fails
        """
        # Phase 3.4: Delegate to ProcessManager without env_config (not needed for local)
        # Filter out parameters that are already explicitly passed to avoid conflicts
        from ee_bench_core.core.utils.dict_utils import exclude_keys

        filtered_kwargs = exclude_keys(
            kwargs,
            "cmd", "cwd", "timeout", "stdin_input", "env", "shell",
            "log_prefix", "stream_output", "output_callback",
            "env_config",  # Don't pass env_config to avoid conflicts
        )

        return self._process_manager.run_command(
            cmd=cmd,
            cwd=cwd,
            timeout=timeout,
            stdin_input=stdin_input,
            env=env,
            shell=shell,
            log_prefix=log_prefix,
            stream_output=stream_output,
            output_callback=output_callback,
            **filtered_kwargs,
        )

    def open_interactive_shell(
        self,
        working_dir: Optional[Union[str, Path]] = None,
        **kwargs,
    ) -> ProcessResult:
        """Open an interactive shell locally.

        Phase 3.4: No longer passes env_config to ProcessManager (not needed for local execution).

        Args:
            working_dir: Optional working directory for the shell
            **kwargs: Additional parameters (ignored)

        Returns:
            ProcessResult with shell exit code

        Raises:
            RuntimeError: If shell cannot be opened
        """
        # Phase 3.4: Delegate to ProcessManager without env_config (not needed for local)
        return self._process_manager.open_interactive_shell(
            working_dir=working_dir, **kwargs
        )

    def cleanup(self, **kwargs) -> None:
        """Clean up the local sandbox.

        Removes the workspace directory if it exists.
        Phase 3.3: Implements cleanup logic directly instead of delegating to ProcessManager.

        Args:
            **kwargs: Additional parameters (ignored)

        Raises:
            RuntimeError: If cleanup fails
        """
        # Import here to avoid circular dependency
        from ee_bench_core.adapters.sandbox_base import SandboxStatus
        import shutil

        instance_id = self.get_instance_id()
        workspace_dir = getattr(self.env_config, "workspace_dir", None)

        logger.info(f"Cleaning up local sandbox for instance '{instance_id}'")

        self._set_status(SandboxStatus.CLEANING)

        try:
            # Remove workspace directory if it exists
            if workspace_dir and Path(workspace_dir).exists():
                try:
                    logger.info(f"Removing workspace directory: {workspace_dir}")
                    shutil.rmtree(workspace_dir)
                    logger.info(f"Removed workspace directory: {workspace_dir}")
                except Exception as e:
                    logger.warning(
                        f"Failed to remove workspace directory {workspace_dir}: {e}"
                    )
                    raise RuntimeError(
                        f"Failed to cleanup workspace directory {workspace_dir}: {e}"
                    )
            else:
                logger.debug(
                    f"Workspace directory not found or not set for instance '{instance_id}'"
                )

            logger.info(f"Local sandbox cleaned up for instance '{instance_id}'")
            self._set_status(SandboxStatus.CLEANED)

        except Exception as e:
            logger.error(f"Failed to cleanup local sandbox for instance '{instance_id}': {e}")
            self._set_status(SandboxStatus.ERROR)
            raise

    def copy_file_to_sandbox(
        self, content: str, dest_path: str, mode: int = 0o644
    ) -> bool:
        """Copy file content to a path in the local filesystem.

        Args:
            content: File content as string
            dest_path: Destination path (absolute or relative to workspace)
            mode: File permissions in octal (default: 0o644 = rw-r--r--)

        Returns:
            True if successful, False otherwise

        Raises:
            RuntimeError: If copy operation fails critically
        """
        import os

        try:
            # Convert to Path object
            dest = Path(dest_path)

            # Create parent directories if they don't exist
            dest.parent.mkdir(parents=True, exist_ok=True)

            # Write the content
            logger.debug(f"Copying file to local path: {dest} ({len(content)} bytes)")
            dest.write_text(content)

            # Set permissions
            os.chmod(dest, mode)

            logger.debug(f"Successfully copied file to {dest}")
            return True

        except Exception as e:
            logger.error(f"Error copying file to local sandbox: {e}")
            return False

    def copy_file_from_sandbox(
        self, source_path: str, dest_path: Optional[str] = None
    ) -> Optional[str]:
        """Copy file from local filesystem or return content.

        Args:
            source_path: Source path (absolute or relative to workspace)
            dest_path: Optional destination path on local filesystem.
                      If None, returns file content as string.

        Returns:
            If dest_path is None: file content as string, or None on error
            If dest_path is provided: dest_path on success, None on error

        Raises:
            RuntimeError: If copy operation fails critically
        """
        try:
            source = Path(source_path)

            if not source.exists():
                logger.error(f"Source file does not exist: {source}")
                return None

            if not source.is_file():
                logger.error(f"Source path is not a file: {source}")
                return None

            # Read content
            content = source.read_text()

            if dest_path:
                # Copy to destination
                dest = Path(dest_path)
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_text(content)
                logger.debug(
                    f"Copied file from {source} to {dest} ({len(content)} bytes)"
                )
                return dest_path
            else:
                # Return content
                logger.debug(f"Read file from {source} ({len(content)} bytes)")
                return content

        except Exception as e:
            logger.error(f"Error copying file from local sandbox: {e}")
            return None
