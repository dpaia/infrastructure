"""Docker adapter for container management and operations.

This module provides a unified interface for Docker operations including
image building, container management, and label-based caching.
"""

import atexit
import logging
import tempfile
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import docker
from docker.models.containers import Container
from docker.models.images import Image

logger = logging.getLogger(__name__)


class DockerAdapter:
    """Adapter for Docker operations with label-based caching support.

    Provides methods for building images, running containers, managing images,
    and implementing label-based caching strategies.

    This class uses a singleton pattern to ensure only one Docker client instance
    exists per process, preventing resource leaks and connection issues.
    """

    _instance = None
    _lock = None

    def __new__(cls, cache_duration_hours: int = 24):
        """Create or return singleton instance.

        Args:
            cache_duration_hours: Duration in hours for cache validity

        Returns:
            Singleton DockerAdapter instance
        """
        if cls._instance is None:
            # Import threading here to avoid circular imports
            import threading

            if cls._lock is None:
                cls._lock = threading.Lock()

            with cls._lock:
                # Double-check pattern
                if cls._instance is None:
                    instance = super().__new__(cls)
                    instance._initialized = False
                    cls._instance = instance
        return cls._instance

    def __init__(self, cache_duration_hours: int = 24):
        """Initialize Docker adapter.

        Args:
            cache_duration_hours: Duration in hours for cache validity

        Raises:
            RuntimeError: If Docker daemon connection fails
        """
        # Only initialize once
        if self._initialized:
            # Update cache duration even if already initialized
            self.cache_duration_hours = cache_duration_hours
            return

        self.cache_duration_hours = cache_duration_hours

        try:
            self.client = docker.from_env()
            # Test connection
            self.client.ping()
            logger.debug("Docker client initialized successfully")
            self._initialized = True

            # Register cleanup at exit
            atexit.register(self.__class__.close_singleton)
            # Register a late-stage cleanup to suppress HTTP warnings during final GC
            atexit.register(self.__class__._suppress_http_warnings_during_gc)
        except Exception as e:
            raise RuntimeError(f"Failed to connect to Docker daemon: {e}") from e

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - no-op for singleton, cleanup happens at process exit."""
        # Don't close the singleton client as it may be used elsewhere
        return False

    @classmethod
    def close_singleton(cls):
        """Close the singleton instance's Docker client.

        This should be called at application shutdown if needed.
        """
        if cls._instance is not None and hasattr(cls._instance, "client"):
            try:
                cls._instance.client.close()
                logger.debug("Docker singleton client closed")
            except Exception as e:
                logger.debug(f"Error closing Docker singleton client: {e}")
            finally:
                cls._instance = None

    @classmethod
    def _suppress_http_warnings_during_gc(cls):
        """Suppress HTTP connection warnings during final garbage collection.

        This is registered as an atexit handler AFTER close_singleton to suppress
        the Python 3.13 HTTP connection cleanup warnings that occur during final GC.
        These warnings are harmless but noisy.
        """
        import sys
        import os

        # Replace stderr with devnull to suppress GC warnings
        # This runs after close_singleton, so we're only suppressing final GC warnings
        try:
            sys.stderr.close()
        except Exception:
            pass
        sys.stderr = open(os.devnull, "w")

    def build_image(
        self,
        dockerfile_content: str,
        tag: str,
        buildargs: Optional[Dict[str, str]] = None,
        labels: Optional[Dict[str, str]] = None,
        **kwargs,
    ) -> Image:
        """Build Docker image from Dockerfile content.

        Args:
            dockerfile_content: Content of the Dockerfile
            tag: Tag for the built image
            buildargs: Build arguments to pass to Docker
            labels: Labels to attach to the image
            **kwargs: Additional arguments to pass to docker.build()

        Returns:
            Built Docker image

        Raises:
            docker.errors.BuildError: If image build fails
            docker.errors.APIError: If Docker API error occurs
        """
        # Create a dedicated temporary directory for the build context
        # This avoids permission issues when Docker walks parent directories on macOS
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            dockerfile_path = temp_path / "Dockerfile"

            # Write Dockerfile content
            dockerfile_path.write_text(dockerfile_content)

            logger.info(f"Building Docker image: {tag}")
            start_time = time.time()

            image, build_logs = self.client.images.build(
                path=str(temp_path),
                dockerfile="Dockerfile",
                tag=tag,
                buildargs=buildargs or {},
                labels=labels or {},
                rm=True,  # Remove intermediate containers
                **kwargs,
            )

            # Log build output
            for log in build_logs:
                if "stream" in log:
                    logger.debug(log["stream"].strip())

            build_duration = time.time() - start_time
            logger.info(f"Successfully built image: {tag} in {build_duration:.2f}s")
            return image

    def run_container(
        self,
        image: str,
        command: Optional[List[str]] = None,
        volumes: Optional[Dict[str, Dict[str, str]]] = None,
        environment: Optional[Dict[str, str]] = None,
        working_dir: Optional[str] = None,
        timeout: int = 300,
        remove: bool = True,
        detach: bool = False,
        name: Optional[str] = None,
        **kwargs,
    ) -> Tuple[int, str, str] | str:
        """Run container and return results, or create detached container.

        Args:
            image: Image name or ID to run
            command: Command to execute in container (defaults to ["tail", "-f", "/dev/null"] if detach=True)
            volumes: Volume mappings (host_path -> {'bind': container_path, 'mode': 'rw'})
            environment: Environment variables
            working_dir: Working directory inside container
            timeout: Timeout in seconds (ignored if detach=True)
            remove: Whether to remove container after execution (ignored if detach=True)
            detach: If True, create long-running container and return container ID without waiting
            name: Optional name for the container
            **kwargs: Additional arguments to pass to docker.run()

        Returns:
            If detach=False: Tuple of (exit_code, stdout, stderr)
            If detach=True: Container ID string

        Raises:
            docker.errors.ContainerError: If container exits with non-zero code
            docker.errors.ImageNotFound: If image not found
            docker.errors.APIError: If Docker API error occurs
            TimeoutError: If container execution exceeds timeout
        """
        logger.debug(f"Running container from image: {image} (detach={detach})")

        # For detached mode, use tail to keep container alive if no command specified
        if detach and command is None:
            command = ["tail", "-f", "/dev/null"]

        container: Optional[Container] = None
        try:
            container = self.client.containers.run(
                image=image,
                command=command,
                volumes=volumes,
                environment=environment,
                working_dir=working_dir,
                detach=True,
                remove=False,  # We'll remove manually after getting logs
                name=name,
                **kwargs,
            )

            # If detached mode, return container ID immediately
            if detach:
                logger.info(f"Created detached container: {container.id}")
                return container.id

            # Otherwise wait for container to finish
            result = container.wait(timeout=timeout)
            exit_code = result.get("StatusCode", -1)

            # Get logs
            stdout = container.logs(stdout=True, stderr=False).decode("utf-8")
            stderr = container.logs(stdout=False, stderr=True).decode("utf-8")

            logger.debug(f"Container exited with code: {exit_code}")
            return exit_code, stdout, stderr

        finally:
            # Only cleanup if not detached and remove=True
            if container and remove and not detach:
                try:
                    container.remove(force=True)
                except Exception as e:
                    logger.warning(f"Failed to remove container: {e}")

    def list_images_by_label(self, label_filter: Dict[str, str]) -> List[Image]:
        """List images matching label filters.

        Args:
            label_filter: Dictionary of label key-value pairs to filter by

        Returns:
            List of matching Docker images
        """
        filters = {"label": [f"{k}={v}" for k, v in label_filter.items()]}

        try:
            return self.client.images.list(filters=filters)
        except docker.errors.APIError:
            logger.exception("Failed to list images with filters=%s", filters)
            return []

    def remove_image(self, image_name: str, force: bool = False) -> None:
        """Remove Docker image.

        Args:
            image_name: Name or ID of image to remove
            force: Force removal even if image is in use

        Raises:
            docker.errors.ImageNotFound: If image not found
            docker.errors.APIError: If Docker API error occurs
        """
        try:
            self.client.images.remove(image_name, force=force)
            logger.info(f"Removed image: {image_name}")
        except docker.errors.ImageNotFound:
            logger.warning(f"Image not found: {image_name}")
            raise
        except docker.errors.APIError:
            logger.exception("Failed to remove image %s", image_name)
            raise

    def get_cached_images(self, image_type: str) -> List[Dict[str, str]]:
        """Get cached images by type using Docker labels.

        Args:
            image_type: Type of images to retrieve (e.g., 'base', 'task')

        Returns:
            List of dictionaries containing image information and labels
        """
        try:
            images = self.client.images.list(
                filters={"label": f"ee-bench.image-type={image_type}"}
            )

            cached_images = []
            for img in images:
                labels = img.labels or {}
                if "ee-bench.image-type" in labels:
                    cached_images.append(
                        {
                            "name": img.tags[0] if img.tags else img.id,
                            **labels,
                        }
                    )

            return cached_images
        except docker.errors.APIError:
            logger.exception("Failed to list cached images for type=%s", image_type)
            return []

    def list_cached_images(self) -> List[Dict[str, any]]:
        """List all cached base images with their details.

        Returns:
            List of dictionaries with image information including validity status
        """
        cached_images = self.get_cached_images("base")

        # Add validity information
        for img in cached_images:
            img["is_valid"] = self._is_cache_valid(img.get("ee-bench.created"))
            if img.get("ee-bench.created"):
                try:
                    created_time = datetime.fromisoformat(
                        img["ee-bench.created"].replace("Z", "+00:00")
                    )
                    current_time = datetime.now(created_time.tzinfo)
                    age = current_time - created_time
                    img["age_hours"] = int(age.total_seconds() / 3600)
                except Exception:
                    img["age_hours"] = None

        return cached_images

    def cleanup_expired_images(self) -> int:
        """Remove expired base images from cache.

        Returns:
            Number of images removed
        """
        cached_images = self.get_cached_images("base")
        removed_count = 0

        for img in cached_images:
            if not self._is_cache_valid(img.get("ee-bench.created")):
                try:
                    self.client.images.remove(img["name"], force=True)
                    logger.info(f"Removed expired base image: {img['name']}")
                    removed_count += 1
                except Exception as e:
                    logger.warning(f"Failed to remove expired image {img['name']}: {e}")

        return removed_count

    def image_exists(self, image_name: str) -> bool:
        """Check if an image exists.

        Args:
            image_name: Name or ID of image to check

        Returns:
            True if image exists, False otherwise
        """
        try:
            self.client.images.get(image_name)
            return True
        except docker.errors.ImageNotFound:
            return False
        except docker.errors.APIError:
            logger.exception("Error checking image existence for %s", image_name)
            return False

    def list_images(self, filters: Optional[Dict[str, str]] = None) -> List[Image]:
        """List Docker images with optional filters.

        Args:
            filters: Optional filters to apply (e.g., {"label": "key=value"})

        Returns:
            List of Image objects
        """
        try:
            return self.client.images.list(filters=filters or {})
        except docker.errors.APIError:
            logger.exception("Error listing images with filters=%s", filters)
            return []

    def list_containers(
        self, filters: Optional[Dict[str, str]] = None, all: bool = True
    ) -> List[Container]:
        """List Docker containers with optional filters.

        Args:
            filters: Optional filters to apply (e.g., {"ancestor": "image-name"})
            all: Include stopped containers (default: True)

        Returns:
            List of Container objects
        """
        try:
            return self.client.containers.list(filters=filters or {}, all=all)
        except docker.errors.APIError:
            logger.exception("Error listing containers with filters=%s", filters)
            return []

    def remove_container(self, container_id: str, force: bool = False) -> None:
        """Remove a container.

        Args:
            container_id: Container ID or name
            force: Force removal even if running

        Raises:
            docker.errors.NotFound: If container not found
            docker.errors.APIError: If removal fails
        """
        try:
            container = self.client.containers.get(container_id)
            container.remove(force=force)
            logger.info(f"Removed container: {container_id}")
        except docker.errors.NotFound:
            logger.warning(f"Container not found: {container_id}")
        except docker.errors.APIError:
            logger.exception("Failed to remove container %s", container_id)
            raise

    def stop_container(self, container_id: str, timeout: int = 10) -> None:
        """Stop a running container.

        Args:
            container_id: Container ID or name to stop
            timeout: Timeout in seconds to wait for container to stop (default: 10)

        Raises:
            docker.errors.NotFound: If container not found
            docker.errors.APIError: If Docker API error occurs
        """
        try:
            container = self.client.containers.get(container_id)
            container.stop(timeout=timeout)
            logger.info(f"Stopped container: {container_id}")
        except docker.errors.NotFound:
            logger.warning(f"Container not found: {container_id}")
        except docker.errors.APIError:
            logger.exception("Failed to stop container %s", container_id)
            raise

    def copy_to_container(
        self, container_id: str, content: str, dest_path: str, permissions: int = 0o755
    ) -> None:
        """Copy file content to a container using Docker's put_archive API.

        Args:
            container_id: Container ID or name
            content: File content to write
            dest_path: Destination path in container (e.g., '/tmp/script.sh')
            permissions: File permissions in octal (default: 0o755)

        Raises:
            docker.errors.NotFound: If container not found
            docker.errors.APIError: If copy operation fails
        """
        import io
        import tarfile

        try:
            container = self.client.containers.get(container_id)

            # Create tar archive in memory
            tar_stream = io.BytesIO()
            with tarfile.open(fileobj=tar_stream, mode="w") as tar:
                # Create TarInfo for the file
                file_name = Path(dest_path).name
                tarinfo = tarfile.TarInfo(name=file_name)
                tarinfo.size = len(content.encode("utf-8"))
                tarinfo.mode = permissions
                tarinfo.mtime = int(datetime.now().timestamp())

                # Add file to archive
                tar.addfile(tarinfo, io.BytesIO(content.encode("utf-8")))

            # Reset stream position to beginning
            tar_stream.seek(0)

            # Put archive into container at destination directory
            dest_dir = str(Path(dest_path).parent)
            container.put_archive(dest_dir, tar_stream.getvalue())

            logger.debug(
                f"Copied file to container {container_id[:12]}: {dest_path} "
                f"(size: {len(content)} bytes, permissions: {oct(permissions)})"
            )

        except docker.errors.NotFound:
            logger.error(
                "Container %s not found while copying to %s", container_id, dest_path
            )
            raise
        except docker.errors.APIError:
            logger.exception(
                "Failed to copy file to container %s -> %s", container_id, dest_path
            )
            raise

    def prune_images(self, filters: Optional[Dict[str, str]] = None) -> None:
        """Prune unused images with optional filters.

        Args:
            filters: Optional filters to apply (e.g., {"dangling": True})
        """
        try:
            result = self.client.images.prune(filters=filters or {})
            logger.info(f"Pruned {len(result.get('ImagesDeleted', []))} images")
        except docker.errors.APIError:
            logger.exception("Failed to prune images with filters=%s", filters)

    def _is_cache_valid(self, created_timestamp: Optional[str]) -> bool:
        """Check if cached image is still valid based on timestamp.

        Args:
            created_timestamp: ISO format timestamp string

        Returns:
            True if cache is valid, False otherwise
        """
        if not created_timestamp:
            return False

        try:
            created_time = datetime.fromisoformat(
                created_timestamp.replace("Z", "+00:00")
            )
            current_time = datetime.now(created_time.tzinfo)
            age = current_time - created_time

            is_valid = age < timedelta(hours=self.cache_duration_hours)
            if not is_valid:
                logger.debug(
                    f"Cache expired: age={age}, max_age={self.cache_duration_hours}h"
                )

            return is_valid

        except (ValueError, TypeError) as e:
            logger.warning(f"Failed to parse cache timestamp {created_timestamp}: {e}")
            return False
