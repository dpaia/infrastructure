"""ee_bench.github - GitHub providers for ee_bench.generator.

This package provides data providers that fetch issues and pull requests
from the GitHub API.
"""

from ee_bench.github.environment_provider import EEBenchEnvironmentProvider
from ee_bench.github.gh_file_provider import GhFileProvider
from ee_bench.github.issues_provider import GitHubIssuesProvider
from ee_bench.github.pull_requests_provider import GitHubPullRequestsProvider
from ee_bench.github.pr_importer import GitHubPRImporterGenerator
from ee_bench.github.patch_applier import apply_patches_via_api, PatchResult, apply_patch_to_content, parse_patch
from ee_bench.github.pr_body import build_pr_body, build_metadata_block, parse_metadata_block, update_metadata_in_body, render_pr_body_template, render_pr_title_template
from ee_bench.github.project_manager import ProjectManager

# New modules for enhanced functionality
from ee_bench.github.build_system import (
    BUILD_SYSTEM_GRADLE,
    BUILD_SYSTEM_GRADLE_KOTLIN,
    BUILD_SYSTEM_MAVEN,
    BUILD_SYSTEM_UNKNOWN,
    detect_build_system,
    is_gradle_project,
    is_maven_project,
)
from ee_bench.github.commit_fetcher import (
    CommitInfo,
    FetchedCommits,
    fetch_commits_for_issue,
    fetch_commits_from_timeline,
    filter_commits_by_branch,
    generate_combined_patch,
    get_base_commit,
    parse_commits_from_text,
    verify_commit_exists,
)
from ee_bench.github.test_field_parser import (
    ParsedTestFields,
    TextSource,
    extract_metadata,
    fetch_test_fields_for_issue,
    fetch_test_fields_from_commits,
    fetch_test_fields_from_issue,
    parse_test_fields,
    parse_test_fields_from_sources,
)

__version__ = "0.1.0"

__all__ = [
    # Providers
    "EEBenchEnvironmentProvider",
    "GhFileProvider",
    "GitHubIssuesProvider",
    "GitHubPullRequestsProvider",
    "GitHubPRImporterGenerator",
    # PR import utilities
    "apply_patches_via_api",
    "PatchResult",
    "apply_patch_to_content",
    "parse_patch",
    "build_pr_body",
    "build_metadata_block",
    "parse_metadata_block",
    "update_metadata_in_body",
    "render_pr_body_template",
    "render_pr_title_template",
    "ProjectManager",
    # Commit fetching
    "CommitInfo",
    "FetchedCommits",
    "fetch_commits_for_issue",
    "fetch_commits_from_timeline",
    "filter_commits_by_branch",
    "generate_combined_patch",
    "get_base_commit",
    "parse_commits_from_text",
    "verify_commit_exists",
    # Build system detection
    "BUILD_SYSTEM_GRADLE",
    "BUILD_SYSTEM_GRADLE_KOTLIN",
    "BUILD_SYSTEM_MAVEN",
    "BUILD_SYSTEM_UNKNOWN",
    "detect_build_system",
    "is_gradle_project",
    "is_maven_project",
    # Test field parsing
    "ParsedTestFields",
    "TextSource",
    "extract_metadata",
    "fetch_test_fields_for_issue",
    "fetch_test_fields_from_commits",
    "fetch_test_fields_from_issue",
    "parse_test_fields",
    "parse_test_fields_from_sources",
]
