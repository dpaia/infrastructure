"""Base module detection for multi-module Java projects.

This module provides the base class for detecting which module a test class
belongs to in multi-module projects.
"""

import json
import logging
from pathlib import Path
from typing import List, Optional

logger = logging.getLogger(__name__)


class ModuleDetector:
    """Base class for module detection in multi-module projects."""

    # Common test source roots to search
    TEST_ROOTS = [
        "src/test/java",
        "src/test/kotlin",
        "src/test/groovy",
        "src/integrationTest/java",
        "src/integrationTest/kotlin",
        "src/integrationTest/groovy",
        "src/it/java",
        "src/it/kotlin",
        "src/it/groovy",
    ]

    # File extensions to check
    FILE_EXTENSIONS = ["java", "kt", "groovy"]

    def detect_module(self, class_fqn: str, working_dir: Path) -> Optional[str]:
        """Detect module directory for a given class FQN.

        Args:
            class_fqn: Fully qualified class name (e.g., com.example.MyTest)
            working_dir: Project root directory

        Returns:
            Relative module path (e.g., "." for root, "module-name" for submodule),
            or None if not found
        """
        if not class_fqn:
            return None

        # First try to use modules.json if it exists
        modules_json_path = working_dir / "modules.json"
        if modules_json_path.exists():
            logger.debug("Found modules.json, attempting to detect module using it")
            module = self._detect_module_from_json(
                class_fqn, working_dir, modules_json_path
            )
            if module is not None:
                logger.debug(f"Module detected from modules.json: {module}")
                return module
            logger.debug(
                "Failed to detect module from modules.json, falling back to file scanning"
            )

        # Fallback to file system scanning
        return self._detect_module_fallback(class_fqn, working_dir)

    def _detect_module_from_json(
        self, class_fqn: str, working_dir: Path, modules_json_path: Path
    ) -> Optional[str]:
        """Detect module using modules.json file.

        Args:
            class_fqn: Fully qualified class name
            working_dir: Project root directory
            modules_json_path: Path to modules.json file

        Returns:
            Module path or None if not found
        """
        try:
            with open(modules_json_path, "r") as f:
                modules = json.load(f)

            class_name = class_fqn.split(".")[-1]
            package_name = ".".join(class_fqn.split(".")[:-1])
            pkg_path = package_name.replace(".", "/") if package_name else ""

            # Check each module from modules.json
            for module_name, module_info in modules.items():
                if module_name == "root":
                    module_path = working_dir
                    module_rel = "."
                else:
                    module_path = working_dir / module_name
                    module_rel = module_name

                # Look for test files in this module's test directories
                for test_root in self.TEST_ROOTS:
                    for ext in self.FILE_EXTENSIONS:
                        if pkg_path:
                            test_file_path = (
                                module_path
                                / test_root
                                / pkg_path
                                / f"{class_name}.{ext}"
                            )
                        else:
                            test_file_path = (
                                module_path / test_root / f"{class_name}.{ext}"
                            )

                        if test_file_path.exists():
                            logger.debug(
                                f"Found test file {test_file_path} in module {module_name}"
                            )
                            return module_rel

            return None

        except (json.JSONDecodeError, FileNotFoundError, KeyError) as e:
            logger.debug(f"Error reading modules.json: {e}")
            return None

    def _detect_module_fallback(
        self, class_fqn: str, working_dir: Path
    ) -> Optional[str]:
        """Fallback module detection using file system scanning.

        Args:
            class_fqn: Fully qualified class name
            working_dir: Project root directory

        Returns:
            Module path or None if not found
        """
        class_name = class_fqn.split(".")[-1]
        package_name = ".".join(class_fqn.split(".")[:-1])
        pkg_path = package_name.replace(".", "/") if package_name else ""

        candidates: List[Path] = []
        for root in self.TEST_ROOTS:
            for ext in self.FILE_EXTENSIONS:
                pattern = (
                    f"**/{root}/{pkg_path}/{class_name}.{ext}"
                    if pkg_path
                    else f"**/{root}/{class_name}.{ext}"
                )
                for p in working_dir.glob(pattern):
                    if p.is_file():
                        candidates.append(p)

        if not candidates:
            return None

        # Score candidates and pick the best one
        best_mod = None
        best_score = 10**9
        for p in candidates:
            parts = list(p.parts)
            try:
                idx = parts.index("src")
            except ValueError:
                continue
            mod_path = Path(*parts[:idx])
            if mod_path == working_dir:
                module_rel = "."
            else:
                module_rel = str(mod_path.relative_to(working_dir))

            score = self._score_module(mod_path, module_rel)

            if score < best_score or best_mod is None:
                best_score = score
                best_mod = module_rel

        return best_mod

    def _score_module(self, mod_path: Path, module_rel: str) -> int:
        """Score a module candidate (lower is better).

        Args:
            mod_path: Absolute path to module
            module_rel: Relative module path

        Returns:
            Score (lower is better)
        """
        raise NotImplementedError("Subclasses must implement _score_module")
