"""SectionProvider - extracts content from markdown ## sections in text."""

from __future__ import annotations

import re
from typing import Any

from ee_bench.generator import Provider
from ee_bench.generator.errors import ProviderError

_SECTION_HEADER_PATTERN = re.compile(r"^##\s+", re.MULTILINE)
_METADATA_START_PATTERN = re.compile(r"<!--\s*METADATA\b", re.IGNORECASE)

# Matches <details type="metadata" key="field_name"><summary>...</summary> ... </details>
_METADATA_DETAILS_PATTERN = re.compile(
    r'<details\s+type="metadata"\s+key="(?P<key>[^"]+)">'
    r"\s*<summary>[^<]*?</summary>"
    r"(?P<content>.*?)"
    r"</details>",
    re.DOTALL,
)

# Matches any <details> ... </details> (for backward compat with unkeyed blocks)
_DETAILS_BLOCK_PATTERN = re.compile(
    r"<details>\s*<summary>\s*(?P<summary>[^<]+?)\s*</summary>"
    r"(?P<content>.*?)"
    r"</details>",
    re.DOTALL,
)


def _parse_metadata_details(text: str) -> dict[str, tuple[str, re.Match]]:
    """Extract ``<details type="metadata" key="...">`` blocks.

    Returns dict mapping key -> (content, match).
    """
    return {
        m.group("key"): (m.group("content").strip(), m)
        for m in _METADATA_DETAILS_PATTERN.finditer(text)
    }


def _parse_unkeyed_details(text: str) -> dict[str, str]:
    """Extract unkeyed ``<details><summary>Title</summary>`` blocks.

    Returns dict mapping summary -> content.  Used as fallback for
    backward compatibility with old PR bodies that lack key attributes.
    """
    return {
        m.group("summary").strip(): m.group("content").strip()
        for m in _DETAILS_BLOCK_PATTERN.finditer(text)
    }


def _strip_metadata_details(text: str) -> str:
    """Remove all ``<details type="metadata" ...>`` blocks from text."""
    result = _METADATA_DETAILS_PATTERN.sub("", text)
    # Clean up excess blank lines left behind
    result = re.sub(r"\n{3,}", "\n\n", result)
    return result.strip()


def _parse_sections(text: str, sections: dict[str, str]) -> dict[str, str]:
    """Extract content from keyed ``<details>``, ``##`` sections, and unkeyed ``<details>``.

    Priority per field:
    1. ``<details type="metadata" key="field">`` — self-describing, preferred
    2. ``## Header`` — legacy format
    3. ``<details><summary>Header</summary>`` — legacy unkeyed format

    ``problem_statement`` is always returned: the full text minus
    extracted metadata ``<details>`` blocks and known ``##`` sections.
    """
    result: dict[str, str] = {}

    # 1. Parse keyed metadata <details> blocks
    keyed = _parse_metadata_details(text)

    # 2. Parse unkeyed <details> blocks (backward compat)
    unkeyed = _parse_unkeyed_details(text)

    for field_name, header in sections.items():
        # Try keyed <details> first
        if field_name in keyed:
            result[field_name] = keyed[field_name][0]
            continue

        # Try ## header
        header_idx = text.find(header)
        if header_idx >= 0:
            content_start = text.find("\n", header_idx)
            if content_start < 0:
                result[field_name] = ""
                continue
            content_start += 1

            remaining = text[content_start:]
            next_header = _SECTION_HEADER_PATTERN.search(remaining)
            metadata_match = _METADATA_START_PATTERN.search(remaining)

            end_idx = len(remaining)
            if next_header:
                end_idx = min(end_idx, next_header.start())
            if metadata_match:
                end_idx = min(end_idx, metadata_match.start())

            result[field_name] = remaining[:end_idx].strip()
            continue

        # Fall back to unkeyed <details><summary>Title</summary>
        summary_key = header.lstrip("#").strip()
        if summary_key in unkeyed:
            result[field_name] = unkeyed[summary_key]
            continue

        result[field_name] = ""

    # Also extract any keyed <details> not in the configured sections
    for key, (content, _match) in keyed.items():
        if key not in result:
            result[key] = content

    # Auto-extract problem_statement: full text minus metadata <details> blocks
    if "problem_statement" not in result or not result["problem_statement"]:
        result["problem_statement"] = _strip_metadata_details(text)

    return result


class SectionProvider(Provider):
    """Enrichment provider that extracts fields from PR body text.

    Supports three formats (checked in priority order):
    1. ``<details type="metadata" key="field">`` — self-describing, no config needed
    2. ``## Header`` sections — configured via ``sections`` dict
    3. ``<details><summary>Header</summary>`` — matched via ``sections`` dict

    ``problem_statement`` is always returned as the text remaining after
    metadata ``<details>`` blocks are removed, preserving any non-metadata
    ``<details>`` blocks (stack traces, repro steps, etc.).
    """

    def __init__(self, **kwargs: Any) -> None:
        self._sections: dict[str, str] = {}
        self._cache_key: str | None = None
        self._cache_result: dict[str, str] = {}
        if kwargs:
            self.prepare(**kwargs)

    def prepare(self, **options: Any) -> None:
        self._sections = dict(options.get("sections") or {})

    def provide(self, item=None, *, text="", **kwargs) -> dict[str, str]:
        """Extract section content from text.

        Args:
            item: Item dict (text can be extracted from item if not provided directly).
            text: Text containing sections to extract.
            **kwargs: Ignored.

        Returns:
            Dict of field_name -> content. Always includes ``problem_statement``.
            Keyed ``<details>`` blocks are extracted automatically even
            without prior configuration.
        """
        if not text and item:
            text = item.get("text", "") or item.get("description", "")

        if text != self._cache_key:
            self._cache_key = text
            self._cache_result = _parse_sections(text, self._sections)

        return dict(self._cache_result)
