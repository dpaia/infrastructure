"""CSharpEvalGenerator — transforms C# Dockerfiles + configs into EE-bench format."""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

from jinja2 import Environment, StrictUndefined

from ee_bench.generator.interfaces import Provider
from ee_bench.csharp.configs import get_config, get_repo_docker_config, get_varying_fields

logger = logging.getLogger(__name__)

_RESOURCES = Path(__file__).parent / "resources"

# Regex to match ENTRYPOINT and CMD directives
_ENTRYPOINT_CMD_PATTERN = re.compile(
    r'^(ENTRYPOINT|CMD)\s+.*$',
    re.MULTILINE,
)

RUN_SH_TEMPLATE = (_RESOURCES / "run.sh").read_text()
PARSER_PY = (_RESOURCES / "parser.py").read_text()
EMITTER_PY = (_RESOURCES / "emitter.py").read_text()


class CSharpEvalGenerator(Provider):
    """C# benchmark provider.

    Takes raw Dockerfile content and per-repo config, produces:
    - ``repo_shared``: Jinja2 templates for main branch (Dockerfile, run.sh, parser.py)
    - ``eval_files``: Pre-rendered install.sh for metadata.json
    """

    def provide(
        self,
        item=None,
        *,
        dockerfile_content: str = "",
        repo: str = "",
        base_commit: str = "",
        test_framework: str = "",
        env_setup_version: str = "1.0",
        run_tests_version: str = "1.0",
        target_org: str = "dpaia",
        **kwargs,
    ) -> dict[str, Any]:
        """Transform C# Dockerfile + config into EE-bench format.

        Args:
            item: Item dict (unused after explicit-param migration).
            dockerfile_content: Raw Dockerfile from CSHARP_HARNESS_PATH.
            repo: Upstream repo (e.g. "App-vNext/Polly").
            base_commit: Base commit hash.
            test_framework: Target framework (e.g. "net8.0", may be empty).
            env_setup_version: Install config version key.
            run_tests_version: Test config version key.
            target_org: GitHub org for forks.
            **kwargs: Ignored.

        Returns:
            Dict with 'repo_shared' and 'eval_files' keys.
        """
        # --- Resolve per-instance config ---
        config = get_config(repo, env_setup_version, run_tests_version)
        test_framework_flag = f"--framework {test_framework}" if test_framework else ""

        # --- Resolve repo-level Docker config ---
        docker_config = get_repo_docker_config(repo)
        varying = get_varying_fields(repo)

        # Fields that vary per-instance use {{ instance.* }} template variables
        # (resolved per-PR from metadata.json at evaluation time).
        # Fields that are constant across all instances get hardcoded.
        test_project_value = (
            "{{ instance.test_project }}" if "test_project" in varying
            else config["test_project"]
        )
        install_commands = docker_config["install_commands"].replace(
            "__TEST_PROJECT__", test_project_value,
        )
        install_block = self._format_install_block(install_commands)

        # --- Dockerfile with concrete install/build commands ---
        dockerfile_template = self._transform_dockerfile(
            dockerfile_content, install_block=install_block,
        )

        # --- run.sh with repo-level values ---
        # test_framework_flag always uses a template variable (varies per-instance).
        # test_project/test_logger use templates only when they vary across versions.
        test_logger_value = (
            "{{ instance.test_logger }}" if "test_logger" in varying
            else config["test_logger"]
        )
        rebuild_cmd = docker_config["rebuild_command"].replace(
            "__TEST_PROJECT__", test_project_value,
        )
        run_sh = RUN_SH_TEMPLATE
        run_sh = run_sh.replace("__REBUILD_CMD__", rebuild_cmd)
        run_sh = run_sh.replace("__TEST_PROJECT__", test_project_value)
        run_sh = run_sh.replace("__TEST_LOGGER__", test_logger_value)
        run_sh = run_sh.replace("__TEST_FRAMEWORK_FLAG__", "{{ instance.test_framework_flag }}")
        run_sh = run_sh.replace("__BUILD_FLAGS__", config.get("build_flags", ""))

        # --- Assemble repo_shared dict (templates for main branch) ---
        repo_shared: dict[str, str] = {
            "environment/Dockerfile": dockerfile_template,
            "eval/run.sh": run_sh,
            "eval/scripts/parser.py": PARSER_PY,
            "eval/scripts/emitter.py": EMITTER_PY,
        }

        return {
            "repo_shared": repo_shared,
            "eval_files": {},
            "test_project": config["test_project"],
            "test_logger": config["test_logger"],
            "build_flags": config.get("build_flags", ""),
            "varying_fields": varying,
        }

    @staticmethod
    def _render_template(template_str: str, **variables: str) -> str:
        """Render a Jinja2 template string with variables."""
        env = Environment(undefined=StrictUndefined)
        tmpl = env.from_string(template_str)
        return tmpl.render(**variables)

    @staticmethod
    def _format_install_block(commands: str) -> str:
        """Convert multi-line install commands to a single Dockerfile RUN instruction.

        Example::

            "cmd1\\ncmd2\\ncmd3"
            → "RUN cmd1 && \\\\\\n    cmd2 && \\\\\\n    cmd3"
        """
        lines = [line.strip() for line in commands.strip().split("\n") if line.strip()]
        if not lines:
            return ""
        if len(lines) == 1:
            return f"RUN {lines[0]}"
        return "RUN " + " && \\\n    ".join(lines)

    @staticmethod
    def _transform_dockerfile(raw: str, *, install_block: str = "") -> str:
        """Transform raw Dockerfile into a Jinja2 template for EE-bench.

        Appends git clone using ``{{ instance.owner }}/{{ instance.repo_name }}``,
        checks out ``{{ instance.base_commit }}``, sets WORKDIR,
        inserts concrete install/build commands,
        removes ENTRYPOINT/CMD, adds EE-bench labels.
        """
        if not raw:
            return ""

        dockerfile = _ENTRYPOINT_CMD_PATTERN.sub("", raw)

        while "\n\n\n" in dockerfile:
            dockerfile = dockerfile.replace("\n\n\n", "\n\n")

        dockerfile = dockerfile.rstrip() + "\n\n"
        dockerfile += 'RUN git clone https://github.com/{{ instance.owner }}/{{ instance.repo_name }}.git /app\n'
        dockerfile += 'WORKDIR /app\n'
        dockerfile += 'RUN git checkout {{ instance.base_commit }}\n\n'

        if install_block:
            dockerfile += install_block + '\n\n'

        dockerfile += 'LABEL ee-bench.type="codegen"\n'
        dockerfile += 'LABEL ee-bench.version="1.0"\n'
        dockerfile += 'RUN rm -rf /app/.ee-bench/ 2>/dev/null || true\n'

        return dockerfile

