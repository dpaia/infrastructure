"""Maven module detection for multi-module projects."""

from pathlib import Path

from ..module_detector_base import ModuleDetector


class MavenModuleDetector(ModuleDetector):
    """Module detector with Maven-specific scoring."""

    def _score_module(self, mod_path: Path, module_rel: str) -> int:
        """Score with strong preference for Maven modules.

        Args:
            mod_path: Absolute path to module
            module_rel: Relative module path

        Returns:
            Score (lower is better)
        """
        score = 0

        # Strong preference for Maven modules
        if (mod_path / "pom.xml").exists():
            score -= 5

        # Still consider Gradle hints but with lower weight
        if (mod_path / "build.gradle").exists() or (
            mod_path / "build.gradle.kts"
        ).exists():
            score -= 1

        # Prefer shallower modules
        depth = module_rel.count("/") if module_rel != "." else 0
        score += depth

        return score
