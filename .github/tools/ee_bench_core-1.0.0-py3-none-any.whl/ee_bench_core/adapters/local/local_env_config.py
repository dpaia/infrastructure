"""Local environment configuration for non-Docker execution."""

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict

from ee_bench_core.core import BaseEnvironmentConfig


@dataclass
class LocalEnvironmentConfig(BaseEnvironmentConfig):
    """Configuration for local (non-Docker) evaluation environments.

    This configuration stores minimal information about a local execution
    environment. Tool-specific details (JAVA_HOME, MAVEN_HOME, etc.) should
    be stored in env_vars by configurers.
    """

    @property
    def sandbox_type(self) -> str:
        """Return the sandbox type identifier.

        Returns:
            "local" to identify this as LocalEnvironmentConfig
        """
        return "local"

    def to_dict(self) -> Dict[str, Any]:
        """Convert environment config to dictionary format.

        Returns:
            Dictionary representation of the environment configuration
        """
        return {
            "sandbox_type": self.sandbox_type,
            "workspace_dir": str(self.workspace_dir),
            "project_dir": self.project_dir,
            "env_vars": self.env_vars,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "LocalEnvironmentConfig":
        """Create LocalEnvironmentConfig from dictionary.

        Args:
            data: Dictionary containing environment configuration

        Returns:
            LocalEnvironmentConfig instance
        """
        return cls(
            workspace_dir=Path(data["workspace_dir"]),
            project_dir=data.get("project_dir", "task_project"),
            env_vars=data.get("env_vars", {}),
        )
