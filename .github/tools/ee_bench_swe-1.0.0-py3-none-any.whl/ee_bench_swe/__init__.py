"""SWE-bench specification implementation.

This package implements the SWE-bench evaluation specification for
evaluating AI agents on software engineering tasks.
"""

from .swe_config import SweBenchmarkConfig
from .swe_dataset import SweDatasetManager

__all__ = [
    "SweBenchmarkConfig",
    "SweDatasetManager",
]
