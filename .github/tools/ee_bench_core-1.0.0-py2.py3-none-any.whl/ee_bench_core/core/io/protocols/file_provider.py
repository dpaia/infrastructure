"""File protocol provider for local filesystem access.

Handles file:// URIs and plain file paths.
"""

import logging
from pathlib import Path
from typing import BinaryIO, Optional
from urllib.parse import urlparse, unquote

from .base import FileProtocolProvider

logger = logging.getLogger(__name__)


class FileProvider(FileProtocolProvider):
    """Protocol provider for local file:// scheme.

    Handles:
    - file:///path/to/file (absolute)
    - file://./relative/path (relative)
    - /absolute/path (no scheme)
    - relative/path (no scheme)
    """

    # Plugin metadata
    __provider_name__ = "file"
    __provider_description__ = "Local filesystem file:// protocol"
    __provider_version__ = "1.0.0"
    __provider_author__ = "EE-Bench"
    __provider_schemes__ = ["file", ""]  # Empty string for paths without scheme

    @classmethod
    def schemes(cls) -> list[str]:
        """Return supported URI schemes."""
        return ["file", ""]  # Empty string handles plain paths

    def load(
        self,
        uri: str,
        cache_path: Optional[Path] = None,
        **kwargs
    ) -> bytes:
        """Load content from local file.

        Args:
            uri: File URI or plain path
            cache_path: Ignored for local files
            **kwargs: Additional options

        Returns:
            File content as bytes

        Raises:
            FileNotFoundError: If file doesn't exist
            IOError: If reading fails
        """
        file_path = self._uri_to_path(uri)

        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        if not file_path.is_file():
            raise IOError(f"Path is not a file: {file_path}")

        logger.debug(f"Loading file from: {file_path}")

        try:
            with open(file_path, "rb") as f:
                return f.read()
        except Exception as e:
            raise IOError(f"Failed to read file {file_path}: {e}") from e

    def save(
        self,
        uri: str,
        content: bytes,
        **kwargs
    ) -> str:
        """Save content to local file.

        Args:
            uri: File URI or plain path
            content: Content to save
            **kwargs: Additional options:
                - create_dirs: Create parent directories (default: True)
                - overwrite: Overwrite existing file (default: True)

        Returns:
            Absolute path to saved file

        Raises:
            IOError: If saving fails
            FileExistsError: If file exists and overwrite=False
        """
        file_path = self._uri_to_path(uri)
        create_dirs = kwargs.get("create_dirs", True)
        overwrite = kwargs.get("overwrite", True)

        # Check if file exists
        if file_path.exists() and not overwrite:
            raise FileExistsError(f"File already exists: {file_path}")

        # Create parent directories if needed
        if create_dirs and not file_path.parent.exists():
            logger.debug(f"Creating directories: {file_path.parent}")
            file_path.parent.mkdir(parents=True, exist_ok=True)

        logger.debug(f"Saving file to: {file_path}")

        try:
            with open(file_path, "wb") as f:
                f.write(content)
            return str(file_path.absolute())
        except Exception as e:
            raise IOError(f"Failed to write file {file_path}: {e}") from e

    def exists(self, uri: str, **kwargs) -> bool:
        """Check if file exists.

        Args:
            uri: File URI or plain path
            **kwargs: Additional options

        Returns:
            True if file exists, False otherwise
        """
        try:
            file_path = self._uri_to_path(uri)
            return file_path.exists() and file_path.is_file()
        except Exception:
            return False

    def stream_load(
        self,
        uri: str,
        cache_path: Optional[Path] = None,
        **kwargs
    ) -> BinaryIO:
        """Stream content from local file.

        Args:
            uri: File URI or plain path
            cache_path: Ignored for local files
            **kwargs: Additional options

        Returns:
            Binary stream (file object)

        Raises:
            FileNotFoundError: If file doesn't exist
            IOError: If opening fails
        """
        file_path = self._uri_to_path(uri)

        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        if not file_path.is_file():
            raise IOError(f"Path is not a file: {file_path}")

        logger.debug(f"Opening file stream: {file_path}")

        try:
            return open(file_path, "rb")
        except Exception as e:
            raise IOError(f"Failed to open file {file_path}: {e}") from e

    def _uri_to_path(self, uri: str) -> Path:
        """Convert URI to file path.

        Args:
            uri: File URI or plain path

        Returns:
            Path object
        """
        # Parse URI
        parsed = urlparse(uri)

        if parsed.scheme == "file":
            # file:// URI - extract path
            path_str = unquote(parsed.path)

            # Handle Windows absolute paths: file:///C:/path
            if parsed.netloc and len(parsed.netloc) == 1 and parsed.netloc.isalpha():
                # Windows drive letter in netloc
                path_str = f"{parsed.netloc}:{path_str}"
            elif parsed.netloc:
                # Network path: file://host/share
                path_str = f"//{parsed.netloc}{path_str}"

            return Path(path_str)
        elif parsed.scheme == "":
            # Plain path without scheme
            return Path(uri)
        else:
            # Unexpected scheme - treat as plain path
            logger.warning(f"Unexpected scheme '{parsed.scheme}' in FileProvider, treating as plain path")
            return Path(uri)
