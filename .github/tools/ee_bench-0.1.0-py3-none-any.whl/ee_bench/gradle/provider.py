"""GradleProvider — detects Gradle projects and enriches test names with module prefix."""

from __future__ import annotations

import re
from typing import Any

from ee_bench.generator.build_utils import (
    detect_gradle_build_system,
    extract_gradle_modules_from_tree,
    extract_module_map,
)
from ee_bench.generator.interfaces import Provider

_TEST_SRC_PATTERN = re.compile(
    r"^(?P<module>.+?)/src/test/(?:java|kotlin)/(?P<class_path>.+?)\.(?:java|kt)$"
)


def _enhance_module_map_from_tree(
    test_patch: str, tree_modules: dict[str, str],
) -> dict[str, str]:
    """Build a class_fqn -> module_prefix map using tree-based module info."""
    if not test_patch:
        return {}

    diff_header = re.compile(r"^diff --git a/(.+?) b/(.+?)$", re.MULTILINE)
    module_map: dict[str, str] = {}

    for match in diff_header.finditer(test_patch):
        path = match.group(2)
        m = _TEST_SRC_PATTERN.match(path)
        if not m:
            continue
        module_dir = m.group("module")
        class_fqn = m.group("class_path").replace("/", ".")
        if module_dir in tree_modules:
            notation = tree_modules[module_dir].lstrip(":")
            module_map[class_fqn] = notation
    return module_map


class GradleProvider(Provider):
    """Build-system provider for Gradle projects.

    Returns None for all fields when no Gradle files found -> chain falls back to Maven.
    """

    def provide(self, item=None, *, repo_tree=None, test_patch="", **kwargs) -> dict[str, Any] | None:
        """Detect Gradle build system and compute module map.

        Args:
            item: Item dict (unused after explicit-param migration).
            repo_tree: Repository file tree (list of paths).
            test_patch: Unified diff of test files.
            **kwargs: Ignored.

        Returns:
            Dict with build_system, is_maven, module_map or None if not Gradle.
        """
        if not repo_tree or not isinstance(repo_tree, list):
            return None

        gradle_system = detect_gradle_build_system(repo_tree)
        if gradle_system is None:
            return None
        module_map: dict[str, str] = {}
        if test_patch:
            module_map = extract_module_map(test_patch)
        if not module_map:
            tree_modules = extract_gradle_modules_from_tree(repo_tree)
            if tree_modules:
                module_map = _enhance_module_map_from_tree(test_patch, tree_modules)

        return {
            "build_system": gradle_system,
            "is_maven": False,
            "module_map": module_map,
        }
