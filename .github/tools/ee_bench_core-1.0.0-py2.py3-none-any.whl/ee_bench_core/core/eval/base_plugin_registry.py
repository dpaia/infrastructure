"""Base plugin registry for dynamic plugin discovery and registration.

This module provides a generic registry system that can be specialized for different
plugin types (evaluators, environment configurers, etc.).
"""

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Callable, Dict, Generic, List, Optional, Type, TypeVar
from importlib.metadata import entry_points

logger = logging.getLogger(__name__)

# Generic type for the plugin interface
TPlugin = TypeVar("TPlugin")


@dataclass
class PluginMetadata(Generic[TPlugin]):
    """Base metadata about a registered plugin.

    Attributes:
        name: Unique identifier for the plugin
        factory: Factory function or class that creates the plugin
        description: Human-readable description
        version: Version string (e.g., "1.0.0")
        author: Author or organization name
        tags: List of tags for categorization
        specs: List of spec names this plugin applies to (empty = all specs)
        entry_point: Entry point name if loaded from plugin (None if programmatic)
    """

    name: str
    factory: Callable[..., TPlugin]
    description: str = ""
    version: str = "1.0.0"
    author: str = ""
    tags: List[str] = field(default_factory=list)
    specs: List[str] = field(default_factory=list)
    entry_point: Optional[str] = None

    def to_dict(self) -> Dict:
        """Convert metadata to dictionary for serialization."""
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "author": self.author,
            "tags": self.tags,
            "specs": self.specs,
            "entry_point": self.entry_point,
        }


class BasePluginRegistry(ABC, Generic[TPlugin]):
    """Base registry for plugin discovery and management.

    This abstract base class provides common functionality for:
    1. Programmatic registration via register() or decorator
    2. Automatic discovery from entry points
    3. Retrieval of plugin factories by name
    4. Listing all available plugins with metadata

    Subclasses must implement:
    - _get_plugin_type_name(): Return plugin type name for logging/errors
    - _is_plugin_enabled(): Check if plugin should be registered
    - _get_metadata_attributes(): Return attribute names for plugin metadata
    """

    def __init__(self, auto_discover: bool = False):
        """Initialize registry.

        Args:
            auto_discover: If True, automatically discover plugins from entry points
        """
        self._plugins: Dict[str, PluginMetadata[TPlugin]] = {}

        if auto_discover:
            self.discover_plugins()

    @abstractmethod
    def _get_plugin_type_name(self) -> str:
        """Get the name of this plugin type for logging and error messages.

        Returns:
            Plugin type name (e.g., "evaluator", "environment configurer")
        """
        pass

    @abstractmethod
    def _is_plugin_enabled(self, name: str) -> bool:
        """Check if a plugin should be enabled based on configuration.

        Args:
            name: Plugin name

        Returns:
            True if plugin should be registered, False to skip
        """
        pass

    @abstractmethod
    def _get_metadata_attributes(self) -> Dict[str, str]:
        """Get attribute names for extracting plugin metadata from factories.

        Returns:
            Dictionary mapping metadata fields to attribute names, e.g.:
            {
                "name": "__evaluator_name__",
                "description": "__evaluator_description__",
                "version": "__evaluator_version__",
                ...
            }
        """
        pass

    @abstractmethod
    def _create_metadata(
        self,
        name: str,
        factory: Callable[..., TPlugin],
        description: str,
        version: str,
        author: str,
        tags: List[str],
        specs: List[str],
        entry_point: Optional[str] = None,
        **kwargs,
    ) -> PluginMetadata[TPlugin]:
        """Create plugin-specific metadata instance.

        Subclasses can override this to add extra fields to metadata.

        Args:
            name: Plugin name
            factory: Plugin factory
            description: Description
            version: Version string
            author: Author name
            tags: Tags for categorization
            specs: Applicable spec names
            entry_point: Entry point name if from plugin discovery
            **kwargs: Additional plugin-specific metadata fields

        Returns:
            PluginMetadata instance (or subclass)
        """
        pass

    def register(
        self,
        name: str,
        factory: Callable[..., TPlugin],
        description: str = "",
        version: str = "1.0.0",
        author: str = "",
        tags: Optional[List[str]] = None,
        specs: Optional[List[str]] = None,
        replace: bool = False,
        **kwargs,
    ) -> None:
        """Register a plugin factory.

        Args:
            name: Unique identifier for the plugin
            factory: Factory function or class that creates plugin instances
            description: Human-readable description
            version: Version string
            author: Author or organization name
            tags: List of tags for categorization
            specs: List of spec names this plugin applies to (empty = all specs)
            replace: If True, replace existing registration (default: False, raises error)
            **kwargs: Additional plugin-specific metadata fields

        Raises:
            ValueError: If name is already registered and replace=False
        """
        # Check if plugin is disabled in configuration
        if not self._is_plugin_enabled(name):
            plugin_type = self._get_plugin_type_name()
            logger.info(
                f"{plugin_type.capitalize()} '{name}' is disabled in configuration, "
                "skipping registration"
            )
            return

        if name in self._plugins and not replace:
            plugin_type = self._get_plugin_type_name()
            raise ValueError(
                f"{plugin_type.capitalize()} '{name}' is already registered. "
                f"Use replace=True to override."
            )

        metadata = self._create_metadata(
            name=name,
            factory=factory,
            description=description,
            version=version,
            author=author,
            tags=tags or [],
            specs=specs or [],
            entry_point=None,
            **kwargs,
        )

        self._plugins[name] = metadata
        plugin_type = self._get_plugin_type_name()
        logger.debug(f"Registered {plugin_type} '{name}' (version {version})")

    def register_plugin(
        self,
        name: str,
        description: str = "",
        version: str = "1.0.0",
        author: str = "",
        tags: Optional[List[str]] = None,
        specs: Optional[List[str]] = None,
        replace: bool = False,
        **kwargs,
    ):
        """Decorator for registering plugin classes.

        Args:
            name: Unique identifier for the plugin
            description: Human-readable description
            version: Version string
            author: Author or organization name
            tags: List of tags for categorization
            specs: List of spec names this plugin applies to (empty = all specs)
            replace: If True, replace existing registration
            **kwargs: Additional plugin-specific metadata fields

        Returns:
            Decorator function that registers the class
        """

        def decorator(cls: Type[TPlugin]) -> Type[TPlugin]:
            self.register(
                name=name,
                factory=cls,
                description=description,
                version=version,
                author=author,
                tags=tags,
                specs=specs,
                replace=replace,
                **kwargs,
            )
            return cls

        return decorator

    def get(self, name: str) -> Callable[..., TPlugin]:
        """Get plugin factory by name.

        Args:
            name: Plugin name

        Returns:
            Factory function or class

        Raises:
            KeyError: If plugin not found
        """
        if name not in self._plugins:
            available = ", ".join(self._plugins.keys())
            plugin_type = self._get_plugin_type_name()
            raise KeyError(
                f"{plugin_type.capitalize()} '{name}' not found. "
                f"Available {plugin_type}s: {available or 'none'}"
            )

        return self._plugins[name].factory

    def get_metadata(self, name: str) -> PluginMetadata[TPlugin]:
        """Get metadata for a plugin.

        Args:
            name: Plugin name

        Returns:
            PluginMetadata instance

        Raises:
            KeyError: If plugin not found
        """
        if name not in self._plugins:
            plugin_type = self._get_plugin_type_name()
            raise KeyError(f"{plugin_type.capitalize()} '{name}' not found")

        return self._plugins[name]

    def has(self, name: str) -> bool:
        """Check if plugin is registered.

        Args:
            name: Plugin name

        Returns:
            True if registered, False otherwise
        """
        return name in self._plugins

    def list(
        self, tags: Optional[List[str]] = None, spec: Optional[str] = None
    ) -> List[PluginMetadata[TPlugin]]:
        """List all registered plugins, optionally filtered by tags and/or spec.

        Args:
            tags: Optional list of tags to filter by (plugins must have at least one matching tag)
            spec: Optional spec name to filter by (plugins with empty specs list match all specs)

        Returns:
            List of PluginMetadata instances matching criteria
        """
        plugins = list(self._plugins.values())

        if tags:
            plugins = [
                meta for meta in plugins if any(tag in meta.tags for tag in tags)
            ]

        if spec:
            plugins = [meta for meta in plugins if not meta.specs or spec in meta.specs]

        return plugins

    def list_for_spec(self, spec_name: str) -> List[PluginMetadata[TPlugin]]:
        """List all plugins applicable to a specific spec.

        This is a convenience method that filters plugins by spec.
        A plugin is applicable if:
        - Its specs list is empty (universal plugin), OR
        - The spec_name is in its specs list

        Args:
            spec_name: Name of the specification (e.g., "jvm", "python")

        Returns:
            List of PluginMetadata instances applicable to the spec
        """
        return self.list(spec=spec_name)

    def unregister(self, name: str) -> None:
        """Unregister a plugin.

        Args:
            name: Plugin name

        Raises:
            KeyError: If plugin not found
        """
        if name not in self._plugins:
            plugin_type = self._get_plugin_type_name()
            raise KeyError(f"{plugin_type.capitalize()} '{name}' not found")

        del self._plugins[name]
        plugin_type = self._get_plugin_type_name()
        logger.debug(f"Unregistered {plugin_type} '{name}'")

    def clear(self) -> None:
        """Clear all registered plugins."""
        self._plugins.clear()
        plugin_type = self._get_plugin_type_name()
        logger.debug(f"Cleared all registered {plugin_type}s")

    def discover_plugins(self, group: str) -> int:
        """Discover and register plugins from entry points.

        This method scans for entry points in the specified group and loads
        plugin factories from them. Entry points should be defined in
        pyproject.toml or setup.py.

        Args:
            group: Entry point group name (e.g., "ee_bench.evaluators")

        Returns:
            Number of plugins discovered and registered
        """
        count = 0
        plugin_type = self._get_plugin_type_name()

        try:
            # Python 3.10+ API
            eps = entry_points(group=group)
        except TypeError:
            # Python 3.9 fallback
            eps = entry_points().get(group, [])

        attr_map = self._get_metadata_attributes()

        for ep in eps:
            try:
                # Load the entry point
                factory = ep.load()

                # Extract metadata from factory if available
                name = getattr(
                    factory, attr_map.get("name", "__plugin_name__"), ep.name
                )
                description = getattr(
                    factory, attr_map.get("description", "__plugin_description__"), ""
                )
                version = getattr(
                    factory, attr_map.get("version", "__plugin_version__"), "1.0.0"
                )
                author = getattr(
                    factory, attr_map.get("author", "__plugin_author__"), ""
                )
                tags = getattr(factory, attr_map.get("tags", "__plugin_tags__"), [])
                specs = getattr(factory, attr_map.get("specs", "__plugin_specs__"), [])

                # Extract any additional plugin-specific metadata
                extra_kwargs = self._extract_extra_metadata(factory, attr_map)

                # Register (don't replace existing)
                if not self.has(name):
                    metadata = self._create_metadata(
                        name=name,
                        factory=factory,
                        description=description,
                        version=version,
                        author=author,
                        tags=tags,
                        specs=specs,
                        entry_point=ep.name,
                        **extra_kwargs,
                    )
                    self._plugins[name] = metadata
                    count += 1
                    spec_info = (
                        f" (specs: {', '.join(specs)})" if specs else " (all specs)"
                    )
                    logger.debug(
                        f"Discovered {plugin_type} '{name}' from entry point '{ep.name}'{spec_info}"
                    )
                else:
                    logger.debug(
                        f"Skipping entry point '{ep.name}': {plugin_type} '{name}' already registered"
                    )

            except Exception as e:
                logger.error(
                    f"Failed to load {plugin_type} from entry point '{ep.name}': {e}",
                    exc_info=logger.isEnabledFor(logging.DEBUG),
                )

        logger.debug(f"Discovered {count} {plugin_type}s from entry points")
        return count

    def _extract_extra_metadata(
        self, factory: Callable, attr_map: Dict[str, str]
    ) -> Dict:
        """Extract additional plugin-specific metadata from factory.

        Subclasses can override this to extract extra metadata fields.

        Args:
            factory: Plugin factory
            attr_map: Attribute name mapping from _get_metadata_attributes()

        Returns:
            Dictionary of extra metadata fields
        """
        return {}


def create_global_registry_accessors(
    registry_class: Type[BasePluginRegistry[TPlugin]],
) -> tuple[Callable[[], BasePluginRegistry[TPlugin]], Callable, Callable]:
    """Create global registry accessor functions to eliminate duplication.

    This factory function creates three accessor functions for a global registry:
    - get_registry(): Returns the singleton registry instance
    - register_plugin(): Decorator for registering plugins
    - list_plugins(): Function for listing plugins

    This eliminates the need to duplicate the global registry pattern across
    multiple registry types.

    Args:
        registry_class: Registry class to instantiate (e.g., EvaluatorRegistry)

    Returns:
        Tuple of (get_registry, register_plugin, list_plugins) functions

    Example:
        >>> # In evaluator_registry.py
        >>> (
        ...     get_global_registry,
        ...     register_evaluator,
        ...     list_evaluators
        ... ) = create_global_registry_accessors(EvaluatorRegistry)
        >>>
        >>> # Use the generated functions
        >>> registry = get_global_registry()
        >>> @register_evaluator(name="my_eval", description="My evaluator")
        >>> class MyEvaluator(Evaluator):
        ...     pass
    """
    _global_registry: Optional[BasePluginRegistry[TPlugin]] = None

    def get_registry() -> BasePluginRegistry[TPlugin]:
        """Get the global registry instance.

        Returns:
            Global registry instance (created if needed)
        """
        nonlocal _global_registry
        if _global_registry is None:
            _global_registry = registry_class(auto_discover=False)
        return _global_registry

    def register_plugin(*args, **kwargs):
        """Decorator for registering plugins in the global registry.

        This is a convenience function that uses the global registry.
        All arguments are forwarded to the registry's register_plugin method.

        Returns:
            Decorator function
        """
        registry = get_registry()
        # Get the appropriate decorator method based on registry type
        # We need to determine the correct method name dynamically
        if hasattr(registry, "register_evaluator"):
            return registry.register_evaluator(*args, **kwargs)
        elif hasattr(registry, "register_configurer"):
            return registry.register_configurer(*args, **kwargs)
        else:
            # Fallback to generic register_plugin
            return registry.register_plugin(*args, **kwargs)

    def list_plugins(
        tags: Optional[List[str]] = None, spec: Optional[str] = None
    ) -> List[PluginMetadata[TPlugin]]:
        """List all registered plugins.

        Args:
            tags: Optional list of tags to filter by
            spec: Optional spec name to filter by

        Returns:
            List of PluginMetadata instances matching criteria
        """
        registry = get_registry()
        return registry.list(tags=tags, spec=spec)

    return get_registry, register_plugin, list_plugins
