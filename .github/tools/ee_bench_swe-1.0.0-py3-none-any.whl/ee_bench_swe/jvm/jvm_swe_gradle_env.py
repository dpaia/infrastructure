"""Gradle-specific SWE-bench environment manager."""

import logging

from ..swe_config import SweBenchmarkConfig
from ..swe_env import SweEnvironmentManager
from ..swe_env_config import SweEnvironmentConfig

logger = logging.getLogger(__name__)

# Gradle version mappings based on JDK version
GRADLE_VERSION_MAP = {
    "8": "7.6.4",    # Last version supporting Java 8
    "11": "8.5",
    "17": "8.5",
    "21": "8.5",
    "24": "8.11.1",  # Latest for newest JDK
}

DEFAULT_GRADLE_VERSION = "8.5"


class GradleEnvironmentManager(SweEnvironmentManager):
    """Environment manager for Gradle-based Java projects.

    Handles Gradle-specific project setup including dependency resolution
    and build configuration.
    """

    def get_language(self) -> str:
        """Get the programming language this manager handles.

        Returns:
            "java"
        """
        return "jvm"

    def get_default_version(self) -> str:
        """Get the default Java version.

        Returns:
            "24"
        """
        return "24"

    def setup_environment(self, config, force: bool = False, **kwargs):
        """Set up environment with JVM-specific version resolution.

        Handles jvm_version parameter and config.jvm_version attribute.

        Args:
            config: SweBenchmarkConfig for the task
            force: Whether to force rebuild if environment exists
            **kwargs: Additional parameters including jvm_version

        Returns:
            SweEnvironmentConfig describing the prepared environment
        """
        # Resolve JVM version from various sources
        # Priority: kwargs['version'] > config.jvm_version > kwargs['jvm_version'] > default
        # Note: config.jvm_version is prioritized over kwargs['jvm_version'] because the latter
        # is often a global default while config.jvm_version comes from the dataset instance
        if not kwargs.get("version"):
            jvm_version = None

            # First try config.jvm_version (from dataset instance)
            if hasattr(config, 'jvm_version') and config.jvm_version and config.jvm_version != self.get_default_version():
                jvm_version = config.jvm_version
            elif hasattr(config, 'get') and config.get('jvm_version') and config.get('jvm_version') != self.get_default_version():
                jvm_version = config.get('jvm_version')
            # Fall back to kwargs['jvm_version'] (global default)
            elif kwargs.get("jvm_version"):
                jvm_version = kwargs.get("jvm_version")

            if jvm_version:
                kwargs["version"] = jvm_version
                logger.info(f"Using JVM version {jvm_version} for {config.instance_id}")

        return super().setup_environment(config, force, **kwargs)

    def get_gradle_version(self, jdk_version: str, **kwargs) -> str:
        """Get Gradle version for given JDK version.

        Args:
            jdk_version: JDK version
            **kwargs: May contain gradle_version override

        Returns:
            Gradle version string
        """
        if "gradle_version" in kwargs:
            return kwargs["gradle_version"]
        return GRADLE_VERSION_MAP.get(jdk_version, DEFAULT_GRADLE_VERSION)

    def get_base_image_name(self, version: str, **kwargs) -> str:
        """Get the base image name including Gradle version.

        Format: "{namespace}-base:gradle{gradle-version}-jdk{version}"

        Args:
            version: JDK version
            **kwargs: May contain gradle_version override

        Returns:
            Base image name
        """
        gradle_version = self.get_gradle_version(version, **kwargs)
        return f"{self.namespace}-base:gradle{gradle_version}-jdk{version}"

    def generate_base_dockerfile(self, version: str, **kwargs) -> str:
        """Generate Dockerfile content for Gradle base image.

        Includes:
        - Eclipse Temurin JDK
        - Gradle (version based on JDK or kwargs)
        - Git and build tools
        - SSH setup for GitHub

        Args:
            version: Java version
            **kwargs: May contain gradle_version override

        Returns:
            Dockerfile content as string
        """
        gradle_version = self.get_gradle_version(version, **kwargs)

        return f"""FROM eclipse-temurin:{version}-jdk

# Install system dependencies
RUN apt-get update && apt-get install -y \\
    git \\
    wget \\
    curl \\
    unzip \\
    patch \\
    jq \\
    openssh-client \\
    ca-certificates \\
    build-essential \\
    && rm -rf /var/lib/apt/lists/*

# Install Gradle {gradle_version}
RUN wget https://services.gradle.org/distributions/gradle-{gradle_version}-bin.zip \\
    && unzip gradle-{gradle_version}-bin.zip -d /opt \\
    && ln -s /opt/gradle-{gradle_version} /opt/gradle \\
    && rm gradle-{gradle_version}-bin.zip

ENV PATH="/opt/gradle/bin:${{PATH}}"
ENV GRADLE_HOME="/opt/gradle"

# Set up SSH for git clone
RUN mkdir -p /root/.ssh && ssh-keyscan github.com >> /root/.ssh/known_hosts

WORKDIR /workspace
"""

    def generate_task_dockerfile(
        self,
        config: SweBenchmarkConfig,
        env_config: SweEnvironmentConfig
    ) -> str:
        """Generate Dockerfile content for Gradle task image.

        Args:
            config: Task configuration
            env_config: Environment configuration (e.g., base image)

        Returns:
            Dockerfile content as string
        """
        # repo field may or may not include .git suffix
        repo = config.repo if config.repo.endswith('.git') else f"{config.repo}.git"
        repo_url = f"https://github.com/{repo}"

        # Construct full project path
        project_path = f"{env_config.project_path}"

        return f"""FROM {env_config.base_image_name}

# Set task metadata as environment variables
ENV TASK_ID="{config.instance_id}"
ENV REPO="{config.repo}"
ENV BASE_COMMIT="{config.base_commit}"

# Copy task-specific configuration files
COPY task-config.json {env_config.workspace_dir}/
COPY task.txt {env_config.workspace_dir}/

# Clone repository and checkout base commit
RUN git clone {repo_url} {project_path} \\
    && cd {project_path} \\
    && git checkout {config.base_commit}

WORKDIR {project_path}

# Setup Gradle project: resolve dependencies and compile
RUN gradle dependencies --no-daemon || true
RUN gradle compileJava compileTestJava --no-daemon

# Default command
CMD ["/bin/bash"]
"""

    def setup_project(
        self,
        container_id: str,
        config: SweBenchmarkConfig
    ) -> None:
        """Setup Gradle project inside container.

        Note: In the new architecture, setup is done during image build.
        This method is kept for compatibility but does nothing.

        Args:
            container_id: Running container ID
            config: Task configuration
        """
        logger.info(f"Gradle project already set up during image build for {config.instance_id}")
