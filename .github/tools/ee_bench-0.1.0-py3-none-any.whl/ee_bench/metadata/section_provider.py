"""SectionProvider - extracts content from markdown ## sections in text."""

from __future__ import annotations

import re
from typing import Any

from ee_bench.generator import Provider
from ee_bench.generator.errors import ProviderError

_SECTION_HEADER_PATTERN = re.compile(r"^##\s+", re.MULTILINE)
_METADATA_START_PATTERN = re.compile(r"<!--\s*METADATA\b", re.IGNORECASE)


def _parse_sections(text: str, sections: dict[str, str]) -> dict[str, str]:
    """Extract content from markdown ``##`` sections."""
    result: dict[str, str] = {}

    for field_name, header in sections.items():
        header_idx = text.find(header)
        if header_idx < 0:
            result[field_name] = ""
            continue

        content_start = text.find("\n", header_idx)
        if content_start < 0:
            result[field_name] = ""
            continue
        content_start += 1

        remaining = text[content_start:]
        next_header = _SECTION_HEADER_PATTERN.search(remaining)
        metadata_match = _METADATA_START_PATTERN.search(remaining)

        end_idx = len(remaining)
        if next_header:
            end_idx = min(end_idx, next_header.start())
        if metadata_match:
            end_idx = min(end_idx, metadata_match.start())

        content = remaining[:end_idx].strip()
        result[field_name] = content

    return result


class SectionProvider(Provider):
    """Enrichment provider that extracts content from markdown ``##`` sections."""

    def __init__(self, **kwargs: Any) -> None:
        self._sections: dict[str, str] = {}
        self._cache_key: str | None = None
        self._cache_result: dict[str, str] = {}
        if kwargs:
            self.prepare(**kwargs)

    def prepare(self, **options: Any) -> None:
        sections = options.get("sections")
        if not sections:
            raise ProviderError(
                "SectionProvider requires 'sections' option — "
                "a dict mapping field_name -> section_header"
            )
        self._sections = dict(sections)

    def provide(self, item=None, *, text="", **kwargs) -> dict[str, str]:
        """Extract section content from text.

        Args:
            item: Item dict (text can be extracted from item if not provided directly).
            text: Text containing markdown ## sections.
            **kwargs: Ignored.

        Returns:
            Dict of section_name -> content.
        """
        if not text and item:
            text = item.get("text", "") or item.get("description", "")

        if text != self._cache_key:
            self._cache_key = text
            self._cache_result = _parse_sections(text, self._sections)

        return dict(self._cache_result)
