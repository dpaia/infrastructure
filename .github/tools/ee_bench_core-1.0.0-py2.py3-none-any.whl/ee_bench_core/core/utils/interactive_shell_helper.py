"""Helper utilities for opening interactive shells in environments.

This module provides reusable helper functions for opening interactive shells
in both local and Docker environments using environment configurations.
"""

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..models import EnvironmentConfig

logger = logging.getLogger(__name__)


def open_interactive_shell(env_config: "EnvironmentConfig", **kwargs) -> int:
    """Open an interactive shell in the environment specified by env_config.

    This function creates a temporary Sandbox from the environment configuration
    and uses it to open an interactive shell.

    Args:
        env_config: Environment configuration (LocalEnvironmentConfig or DockerEnvironmentConfig)
        **kwargs: Additional parameters:
            - start: If True, automatically start stopped Docker containers (default: False)

    Returns:
        Exit code from the shell session

    Raises:
        ValueError: If env_config is invalid or required parameters are missing
        RuntimeError: If Docker container doesn't exist or failed to start

    Examples:
        >>> from ee_bench_core.core.utils import open_interactive_shell
        >>> from ee_bench_core.adapters.local.local_env_config import LocalEnvironmentConfig
        >>> from pathlib import Path
        >>>
        >>> # Open local shell
        >>> env_config = LocalEnvironmentConfig(workspace_dir=Path("/tmp/test"))
        >>> exit_code = open_interactive_shell(env_config)
        >>>
        >>> # Open Docker shell
        >>> from ee_bench_core.adapters.docker.docker_env_config import DockerEnvironmentConfig
        >>> env_config = DockerEnvironmentConfig(
        ...     instance_id="test",
        ...     container_id="abc123",
        ...     workspace_dir=Path("/workspace")
        ... )
        >>> exit_code = open_interactive_shell(env_config, start=True)
    """
    # Import here to avoid circular dependency
    from ...adapters import SandboxFactory

    # Create sandbox from env_config
    sandbox = SandboxFactory.create_sandbox(env_config)

    # Get working directory
    working_dir = getattr(env_config, "workspace_dir", None)

    logger.info(
        "Opening interactive shell" + (f" at {working_dir}" if working_dir else "")
    )

    # Use sandbox's open_interactive_shell method
    result = sandbox.open_interactive_shell(working_dir=working_dir, **kwargs)

    # Return exit code for backward compatibility
    return result.returncode
