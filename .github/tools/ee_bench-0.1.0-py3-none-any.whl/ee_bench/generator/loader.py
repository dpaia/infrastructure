"""Plugin discovery and loading via static registry."""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING

from ee_bench.generator.errors import PluginNotFoundError

if TYPE_CHECKING:
    from ee_bench.generator.interfaces import Provider

PROVIDERS_REGISTRY: dict[str, str] = {
    # ee_bench.csharp
    "csharp_eval": "ee_bench.csharp:CSharpEvalGenerator",
    # ee_bench.dpaia
    "ee_bench_codegen_unified": "ee_bench.dpaia:EEBenchCodegenUnifiedGenerator",
    "ee_bench_codegen_flat": "ee_bench.dpaia:EEBenchCodegenFlatGenerator",
    # ee_bench.git
    "local_git": "ee_bench.git:LocalGitConfigurer",
    "patch_applier": "ee_bench.git:PatchApplier",
    # ee_bench.github
    "github_issues": "ee_bench.github:GitHubIssuesProvider",
    "github_pull_requests": "ee_bench.github:GitHubPullRequestsProvider",
    "gh_file": "ee_bench.github:GhFileProvider",
    "ee_bench_environment": "ee_bench.github:EEBenchEnvironmentProvider",
    "github_pr_importer": "ee_bench.github:GitHubPRImporterGenerator",
    # ee_bench.gradle
    "gradle": "ee_bench.gradle:GradleProvider",
    # ee_bench.huggingface
    "huggingface_dataset": "ee_bench.huggingface:HuggingFaceDatasetProvider",
    # ee_bench.maven
    "maven": "ee_bench.maven:MavenProvider",
    # ee_bench.metadata
    "metadata": "ee_bench.metadata:MetadataProvider",
    "markdown_sections": "ee_bench.metadata:SectionProvider",
    # ee_bench.module_test
    "module_test": "ee_bench.module_test:ModuleTestProvider",
    # ee_bench.patch_splitter
    "patch_splitter": "ee_bench.patch_splitter:PatchSplitterProvider",
    # ee_bench.run_scripts
    "run_scripts": "ee_bench.run_scripts:RunScriptsProvider",
    "github_attachment": "ee_bench.run_scripts:GitHubAttachmentGenerator",
    "attachment_export": "ee_bench.run_scripts:AttachmentExportGenerator",
    # ee_bench.swe_pro
    "swe_bench_pro_eval": "ee_bench.swe_pro:SweBenchProEvalGenerator",
}


def _resolve(target: str) -> type:
    """Resolve a 'module:ClassName' string to the actual class.

    Args:
        target: Dotted module path and class name separated by a colon.

    Returns:
        The class object.
    """
    module_path, class_name = target.rsplit(":", 1)
    module = importlib.import_module(module_path)
    return getattr(module, class_name)


def load_provider(name: str) -> Provider:
    """Load a provider plugin by name.

    Args:
        name: The provider name (registry key).

    Returns:
        Instantiated Provider object.

    Raises:
        PluginNotFoundError: If the provider is not found.
    """
    if name not in PROVIDERS_REGISTRY:
        raise PluginNotFoundError("provider", name)

    provider_class = _resolve(PROVIDERS_REGISTRY[name])
    return provider_class()


def list_providers() -> list[str]:
    """List all available provider plugin names.

    Returns:
        Sorted list of registered provider names.
    """
    return sorted(PROVIDERS_REGISTRY.keys())
