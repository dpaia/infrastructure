"""Git adapter for repository operations.

This module provides a unified interface for Git operations including
cloning repositories, checking out commits, and managing repository state.
"""

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Optional, Union

if TYPE_CHECKING:
    from .sandbox_base import Sandbox

logger = logging.getLogger(__name__)


class GitAdapter:
    """Adapter for Git operations.

    Provides methods for cloning repositories, checking out commits,
    resetting repository state, and querying repository information.
    """

    def clone_repository(
        self,
        sandbox: "Sandbox",
        repo_url: str,
        target_dir: Path,
        https_fallback: bool = True,
    ) -> None:
        """Clone a Git repository.

        Args:
            repo_url: URL of the repository to clone (SSH or HTTPS)
            target_dir: Directory to clone repository into
            https_fallback: If True, try HTTPS if SSH clone fails

        Raises:
            RuntimeError: If cloning fails
        """
        if target_dir.exists():
            logger.debug(f"Repository already exists: {target_dir}")
            return

        logger.debug(f"Cloning repository: {repo_url}")
        result = sandbox.run_command(["git", "clone", repo_url, str(target_dir)])

        if result.returncode != 0:
            if https_fallback:
                logger.warning("SSH clone failed, trying HTTPS...")
                https_url = self._convert_to_https(repo_url)
                result = sandbox.run_command(
                    ["git", "clone", https_url, str(target_dir)]
                )
                if result.returncode != 0:
                    raise RuntimeError(
                        f"Failed to clone repository with both SSH and HTTPS: {result.stderr}"
                    )
            else:
                raise RuntimeError(f"Failed to clone repository: {result.stderr}")

        logger.debug(f"Successfully cloned repository to: {target_dir}")

    def checkout_commit(self, sandbox: "Sandbox", repo_dir: Path, commit: str) -> None:
        """Checkout a specific commit in a repository.

        Args:
            repo_dir: Path to the repository
            commit: Commit hash to checkout

        Raises:
            RuntimeError: If checkout fails
        """
        if not repo_dir.exists():
            raise RuntimeError(f"Repository directory does not exist: {repo_dir}")

        logger.debug(f"Checking out commit: {commit}")
        result = sandbox.run_command(["git", "checkout", commit], cwd=repo_dir)

        if result.returncode != 0:
            raise RuntimeError(f"Failed to checkout commit {commit}: {result.stderr}")

    def reset_repository(self, sandbox: "Sandbox", repo_dir: Path) -> None:
        """Reset repository to a clean state.

        Performs git reset --hard HEAD and git clean -fd to remove
        all uncommitted changes and untracked files.

        Args:
            repo_dir: Path to the repository

        Raises:
            RuntimeError: If reset fails
        """
        if not repo_dir.exists():
            raise RuntimeError(f"Repository directory does not exist: {repo_dir}")

        logger.debug("Resetting repository to clean state...")

        result = sandbox.run_command(["git", "reset", "--hard", "HEAD"], cwd=repo_dir)
        if result.returncode != 0:
            raise RuntimeError(f"Failed to reset repository: {result.stderr}")

        result = sandbox.run_command(["git", "clean", "-fd"], cwd=repo_dir)
        if result.returncode != 0:
            raise RuntimeError(f"Failed to clean repository: {result.stderr}")

        logger.debug("Repository reset successful")

    def get_current_commit(self, sandbox: "Sandbox", repo_dir: Path) -> str:
        """Get the current commit hash of a repository.

        Args:
            repo_dir: Path to the repository

        Returns:
            Current commit hash (full SHA-1)

        Raises:
            RuntimeError: If unable to get commit hash
        """
        if not repo_dir.exists():
            raise RuntimeError(f"Repository directory does not exist: {repo_dir}")

        result = sandbox.run_command(["git", "rev-parse", "HEAD"], cwd=repo_dir)

        if result.returncode != 0:
            raise RuntimeError(f"Failed to get current commit: {result.stderr}")

        return result.stdout.strip()

    def has_changes(self, sandbox: "Sandbox", repo_dir: Path) -> bool:
        """Check if repository has uncommitted changes.

        Args:
            repo_dir: Path to the repository

        Returns:
            True if there are uncommitted changes, False otherwise

        Raises:
            RuntimeError: If unable to check status
        """
        if not repo_dir.exists():
            raise RuntimeError(f"Repository directory does not exist: {repo_dir}")

        result = sandbox.run_command(["git", "status", "--porcelain"], cwd=repo_dir)

        if result.returncode != 0:
            raise RuntimeError(f"Failed to check repository status: {result.stderr}")

        return bool(result.stdout.strip())

    def get_diff(
        self,
        sandbox: "Sandbox",
        repo_dir: Union[Path, str, None] = None,
        timeout: Optional[int] = None,
        base_commit: Optional[str] = None,
        use_file: bool = True,
        **kwargs,
    ) -> str:
        """Get git diff output from sandbox, excluding build artifacts.

        Stages all changes (including untracked files) while excluding build artifacts,
        then gets diff against base_commit or current HEAD.

        For large patches, uses file-based approach to avoid Docker exec buffer limits.

        Args:
            sandbox: Sandbox to execute commands in
            repo_dir: Path to the repository (optional, derived from sandbox.env_config)
            timeout: Optional timeout in seconds for git commands
            base_commit: Commit to compare against (e.g., "HEAD", "abc123").
                        If None, compares staged changes against current HEAD.
            use_file: If True (default), writes diff to file then reads (safer for large diffs).
                     If False, uses stdout directly (only for small diffs < 1MB).
            **kwargs: Additional parameters for sandbox.run_command

        Returns:
            Git diff output as string (empty if no changes or errors)

        Raises:
            ValueError: If repo_dir cannot be determined

        Examples:
            # Get all changes against HEAD (file-based, safe for large diffs)
            diff = adapter.get_diff(sandbox)

            # Get changes using stdout (only for small diffs)
            diff = adapter.get_diff(sandbox, use_file=False)

            # Get changes against specific commit
            diff = adapter.get_diff(sandbox, base_commit="abc123")
        """
        # Determine repo_dir from sandbox env_config if not provided
        if repo_dir is None:
            repo_dir = self._determine_project_path(sandbox.env_config)

        # DIAGNOSTIC 1: Check if directory exists
        check_result = sandbox.run_command(
            ["test", "-d", str(repo_dir)], timeout=5, **kwargs
        )
        if check_result.returncode != 0:
            logger.error(
                f"DIAGNOSIS: Repository directory {repo_dir} does not exist in sandbox. "
                f"Cannot collect diff."
            )
            return ""

        # DIAGNOSTIC 2: Check if it's a git repository
        git_check = sandbox.run_command(
            ["git", "-C", str(repo_dir), "rev-parse", "--git-dir"], timeout=5, **kwargs
        )
        if git_check.returncode != 0:
            logger.error(
                f"DIAGNOSIS: {repo_dir} is not a git repository. Cannot collect diff."
            )
            return ""

        # DIAGNOSTIC 3: Check for any changes before staging
        status_result = sandbox.run_command(
            ["git", "-C", str(repo_dir), "status", "--porcelain"], timeout=10, **kwargs
        )
        if status_result.returncode == 0:
            changes_list = [
                line for line in status_result.stdout.splitlines() if line.strip()
            ]
            changes_count = len(changes_list)
            logger.debug(
                f"DIAGNOSIS: Found {changes_count} changed/untracked files before staging"
            )
            if changes_count == 0:
                logger.info(
                    "DIAGNOSIS: No changes detected by git status. "
                    "All modifications may be in .gitignore or no changes were made."
                )

        # Stage all changes, excluding build artifacts
        exclusions = self._get_build_file_exclusions()
        add_cmd = ["git", "-C", str(repo_dir), "add", "-A", "--", "."]
        add_cmd.extend(exclusions)

        logger.debug(
            f"Staging changes (excluding {len(exclusions)} build wrapper patterns)"
        )
        add_result = sandbox.run_command(add_cmd, timeout=timeout, **kwargs)

        # Handle staging failures
        if add_result.returncode != 0:
            if "ignored by one of your .gitignore files" in add_result.stderr:
                logger.debug("Some files skipped by .gitignore (expected)")
            else:
                logger.warning(
                    f"Failed to stage files: {add_result.stderr}. "
                    f"Continuing with partial staging."
                )

        # DIAGNOSTIC 4: Check what was actually staged
        staged_result = sandbox.run_command(
            ["git", "-C", str(repo_dir), "diff", "--cached", "--name-only"],
            timeout=10,
            **kwargs,
        )
        if staged_result.returncode == 0:
            staged_files = [f for f in staged_result.stdout.splitlines() if f.strip()]
            logger.debug(f"DIAGNOSIS: {len(staged_files)} files staged for diff")
            if len(staged_files) == 0:
                logger.warning(
                    "DIAGNOSIS: No files staged. Diff will be empty. "
                    "Possible causes: all changes in .gitignore, or no actual modifications."
                )
            elif len(staged_files) <= 10:
                logger.debug(f"DIAGNOSIS: Staged files: {', '.join(staged_files)}")

        # Collect diff using file-based or stdout-based approach
        if use_file:
            return self._get_diff_via_file(
                sandbox, repo_dir, base_commit, timeout, **kwargs
            )
        else:
            return self._get_diff_via_stdout(
                sandbox, repo_dir, base_commit, timeout, **kwargs
            )

    def _get_diff_via_stdout(
        self,
        sandbox: "Sandbox",
        repo_dir: Union[Path, str],
        base_commit: Optional[str],
        timeout: Optional[int],
        **kwargs,
    ) -> str:
        """Get diff via stdout (for small diffs < 1MB).

        Args:
            sandbox: Sandbox to execute commands in
            repo_dir: Path to the repository
            base_commit: Optional base commit to compare against
            timeout: Optional timeout in seconds
            **kwargs: Additional parameters for sandbox.run_command

        Returns:
            Git diff output as string
        """
        diff_cmd = ["git", "-C", str(repo_dir), "diff", "--cached", "--no-color"]
        if base_commit:
            diff_cmd.insert(-1, base_commit)
            logger.debug(f"Getting diff against base commit: {base_commit}")

        result = sandbox.run_command(diff_cmd, timeout=timeout, **kwargs)
        diff_content = result.stdout or ""

        if diff_content:
            diff_size_mb = len(diff_content) / (1024 * 1024)
            logger.debug(f"Collected diff via stdout: {diff_size_mb:.2f} MB")
            if diff_size_mb > 1.0:
                logger.warning(
                    f"Diff is large ({diff_size_mb:.2f} MB). "
                    f"Consider using use_file=True for safer collection."
                )

        return diff_content

    def _get_diff_via_file(
        self,
        sandbox: "Sandbox",
        repo_dir: Union[Path, str],
        base_commit: Optional[str],
        timeout: Optional[int],
        **kwargs,
    ) -> str:
        """Get diff via temporary file (safe for large diffs).

        Runs git diff to get output, writes it to a temporary file in the sandbox,
        checks its size, then reads it back. This avoids Docker exec buffer limitations.

        Args:
            sandbox: Sandbox to execute commands in
            repo_dir: Path to the repository
            base_commit: Optional base commit to compare against
            timeout: Optional timeout in seconds
            **kwargs: Additional parameters for sandbox.run_command

        Returns:
            Git diff output as string
        """
        import uuid

        # Generate unique temp file name
        temp_file = f"/tmp/diff_{uuid.uuid4().hex[:8]}.patch"

        try:
            # Step 1: Get diff output via stdout
            diff_cmd = ["git", "-C", str(repo_dir), "diff", "--cached", "--no-color"]
            if base_commit:
                diff_cmd.insert(-1, base_commit)
                logger.debug(f"Getting diff against base commit: {base_commit}")

            result = sandbox.run_command(diff_cmd, timeout=timeout, **kwargs)

            if result.returncode not in (0, 1):
                logger.error(f"Failed to get diff: exit code {result.returncode}")
                return ""

            diff_content = result.stdout or ""

            if not diff_content:
                logger.debug("Diff is empty (no changes)")
                return ""

            # Step 2: Write diff to temp file in sandbox for size checking
            success = sandbox.copy_file_to_sandbox(diff_content, temp_file)
            if not success:
                logger.warning(
                    "Could not write diff to temp file for size checking. "
                    "Returning diff via stdout."
                )
                # SIZE CHECK: Check stdout size
                diff_size_mb = len(diff_content) / (1024 * 1024)
                logger.debug(f"Diff size: {diff_size_mb:.2f} MB")
                if diff_size_mb > 10:
                    logger.warning(
                        f"LARGE DIFF WARNING: Diff is {diff_size_mb:.1f} MB. "
                        f"This may indicate unexpected changes (build artifacts, "
                        f"generated files, etc.)"
                    )
                return diff_content

            # Step 3: Check file size
            size_result = sandbox.run_command(
                ["wc", "-c", temp_file], timeout=5, **kwargs
            )

            if size_result.returncode == 0:
                try:
                    size_bytes = int(size_result.stdout.split()[0])
                    size_mb = size_bytes / (1024 * 1024)
                    logger.debug(
                        f"Diff file size: {size_mb:.2f} MB ({size_bytes:,} bytes)"
                    )

                    # SIZE CHECK: Warn if diff is very large
                    if size_mb > 10:
                        logger.warning(
                            f"LARGE DIFF WARNING: Diff is {size_mb:.1f} MB. "
                            f"This may indicate unexpected changes (build artifacts, "
                            f"generated files, etc.)"
                        )

                except (ValueError, IndexError) as e:
                    logger.warning(f"Could not parse diff file size: {e}")

            logger.debug(
                f"Successfully collected diff via file: {len(diff_content):,} chars"
            )
            return diff_content

        finally:
            # Cleanup temp file
            cleanup_result = sandbox.run_command(
                ["rm", "-f", temp_file], timeout=5, **kwargs
            )
            if cleanup_result.returncode != 0:
                logger.debug(f"Could not remove temp file {temp_file}")

    def _parse_gitignore(
        self, sandbox: "Sandbox", repo_dir: Union[Path, str]
    ) -> list[str]:
        """Parse .gitignore file and convert patterns to git pathspec exclusions.

        Args:
            sandbox: Sandbox to execute commands in
            repo_dir: Path to the repository

        Returns:
            List of git pathspec exclusion patterns from .gitignore

        Note:
            - Skips comments (lines starting with #)
            - Skips empty lines
            - Skips negation patterns (lines starting with !)
            - Converts .gitignore patterns to :(exclude) pathspec format
        """
        gitignore_path = Path(repo_dir) / ".gitignore"

        # Try to read .gitignore file
        try:
            result = sandbox.run_command(["cat", str(gitignore_path)])
            if result.returncode != 0:
                logger.debug(f"No .gitignore found at {gitignore_path}")
                return []

            gitignore_content = result.stdout
        except Exception as e:
            logger.debug(f"Failed to read .gitignore: {e}")
            return []

        exclusions = []
        for line in gitignore_content.splitlines():
            line = line.strip()

            # Skip empty lines and comments
            if not line or line.startswith("#"):
                continue

            # Skip negation patterns (these would need special handling)
            if line.startswith("!"):
                continue

            # Remove trailing slashes for consistency
            pattern = line.rstrip("/")

            # Remove leading slash - in .gitignore it means "relative to repo root",
            # but in git pathspec it would mean "absolute path from filesystem root"
            if pattern.startswith("/"):
                pattern = pattern[1:]

            # Convert to git pathspec exclusion format
            exclusions.append(f":(exclude){pattern}")

        logger.debug(f"Loaded {len(exclusions)} exclusion patterns from .gitignore")
        return exclusions

    def _get_build_file_exclusions(self) -> list[str]:
        """Get list of pathspec exclusion patterns for build tool files and directories.

        Returns:
            List of git pathspec exclusion patterns (e.g., ":(exclude)gradlew")

        Note:
            Patterns exclude common build tool files that should not be part of
            code changes, even if they're not in .gitignore:
            - Gradle wrapper files: gradlew, gradlew.bat, gradle/wrapper/*
            - Maven wrapper files: mvnw, mvnw.cmd, .mvn/wrapper/*
            - Build directories: build/, target/, out/, .gradle/, .idea/, .vscode/

            This method does NOT include .gitignore patterns since git naturally
            respects .gitignore during add operations.
        """
        return [
            # Gradle build tool files
            ":(exclude)gradlew",
            ":(exclude)gradlew.bat",
            ":(exclude)gradle/wrapper/*",
            # Maven build tool files
            ":(exclude)mvnw",
            ":(exclude)mvnw.cmd",
            ":(exclude).mvn/wrapper/*",
            # Build output directories (common patterns that might not be in .gitignore)
            ":(exclude)build",
            ":(exclude)build/**",
            ":(exclude)*/build",
            ":(exclude)*/build/**",
            ":(exclude)target",
            ":(exclude)target/**",
            ":(exclude)*/target",
            ":(exclude)*/target/**",
            ":(exclude)out",
            ":(exclude)out/**",
            ":(exclude)*/out",
            ":(exclude)*/out/**",
            # IDE and build cache directories
            ":(exclude).gradle",
            ":(exclude).gradle/**",
            ":(exclude).idea",
            ":(exclude).idea/**",
            ":(exclude).vscode",
            ":(exclude).vscode/**",
        ]

    def _get_exclusion_patterns(
        self, sandbox: "Sandbox", repo_dir: Union[Path, str]
    ) -> list[str]:
        """Get list of pathspec exclusion patterns for build files, directories, and .gitignore.

        Args:
            sandbox: Sandbox to execute commands in
            repo_dir: Path to the repository

        Returns:
            List of git pathspec exclusion patterns (e.g., ":(exclude)gradlew")

        Note:
            Patterns exclude:
            - Gradle wrapper files: gradlew, gradlew.bat, gradle/wrapper/*
            - Maven wrapper files: mvnw, mvnw.cmd, .mvn/wrapper/*
            - Build directories: build/, target/, out/, .gradle/, .idea/
            - Patterns from .gitignore file in the repository
        """
        exclusions = self._get_build_file_exclusions()

        # Add patterns from .gitignore
        gitignore_patterns = self._parse_gitignore(sandbox, repo_dir)
        exclusions.extend(gitignore_patterns)

        return exclusions

    def _determine_project_path(self, env_config) -> str:
        """Determine project path from environment config.

        Args:
            env_config: Environment configuration

        Returns:
            Project path as string

        Raises:
            ValueError: If project_path cannot be determined
        """
        project_path = None
        if hasattr(env_config, "project_path") and env_config.project_path:
            try:
                project_path = str(env_config.project_path)
            except Exception:
                project_path = None

        if (
            not project_path
            and hasattr(env_config, "workspace_dir")
            and env_config.workspace_dir
        ):
            # Check if project_dir is specified
            if hasattr(env_config, "project_dir") and env_config.project_dir:
                project_path = str(
                    Path(env_config.workspace_dir) / env_config.project_dir
                )
            else:
                # Fallback to default project dir name
                project_path = str(Path(env_config.workspace_dir) / "task_project")

        if not project_path:
            raise ValueError("Cannot determine project_path from environment config")

        return project_path

    def _convert_to_https(self, repo_url: str) -> str:
        """Convert SSH repository URL to HTTPS.

        Args:
            repo_url: Repository URL (SSH or HTTPS)

        Returns:
            HTTPS repository URL
        """
        if repo_url.startswith("git@github.com:"):
            # Convert git@github.com:owner/repo.git to https://github.com/owner/repo.git
            path = repo_url[15:]  # Remove "git@github.com:"
            return f"https://github.com/{path}"
        else:
            return repo_url
