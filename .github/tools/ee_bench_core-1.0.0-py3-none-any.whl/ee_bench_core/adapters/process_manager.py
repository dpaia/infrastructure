"""Process execution manager for running external commands locally.

This module provides a unified interface for executing commands with
subprocess, including support for input, streaming output, and timeouts.
"""

import logging
import subprocess
import time
from pathlib import Path
from typing import TYPE_CHECKING, List, Optional, Union

from .process_manager_base import ProcessManager, ProcessResult

if TYPE_CHECKING:
    from core.abc_types import EnvironmentConfig

logger = logging.getLogger(__name__)


class LocalProcessManager(ProcessManager):
    """Manager for executing external commands with subprocess."""

    def __init__(self, debug_output: bool = True):
        """Initialize process manager.

        Args:
            debug_output: Whether to write process output to debug log in real-time
        """
        self.debug_output = debug_output

    def run_command(
        self,
        cmd: Union[str, List[str]],
        cwd: Optional[Union[str, Path]] = None,
        timeout: Optional[int] = None,
        stdin_input: Optional[str] = None,
        env: Optional[dict] = None,
        shell: bool = False,
        log_prefix: str = "",
        env_config: Optional["EnvironmentConfig"] = None,
    ) -> ProcessResult:
        """Run a command and return its result.

        Args:
            cmd: Command to execute (list of args or string if shell=True)
            cwd: Working directory for the command
            timeout: Timeout in seconds (None for no timeout)
            stdin_input: Optional input to send to process stdin
            env: Optional environment variables dict (None uses parent env)
            shell: Whether to execute through shell
            log_prefix: Prefix for debug log messages
            env_config: Optional EnvironmentConfig (ignored for local execution)

        Returns:
            ProcessResult with execution details

        Raises:
            subprocess.SubprocessError: If command execution fails critically
        """
        start_time = time.time()
        timed_out = False

        # Extract env vars from EnvironmentConfig if provided
        env_vars = None
        if env is not None and isinstance(env, dict):
            env_vars = env
        # If env is EnvironmentConfig, ignore it for local execution

        # Convert Path to string for cwd
        if cwd is not None:
            cwd = str(cwd)

        # Log command execution
        cmd_str = cmd if isinstance(cmd, str) else " ".join(cmd)
        logger.debug(f"{log_prefix}Executing command: {cmd_str}")
        if cwd:
            logger.debug(f"{log_prefix}Working directory: {cwd}")
        if timeout:
            logger.debug(f"{log_prefix}Timeout: {timeout}s")

        try:
            # Start process
            proc = subprocess.Popen(
                cmd,
                cwd=cwd,
                stdin=subprocess.PIPE if stdin_input else None,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=env_vars,
                shell=shell,
                text=True,
                bufsize=1,  # Line buffered
            )

            # Collect output - use communicate() which handles everything properly
            try:
                stdout, stderr = proc.communicate(input=stdin_input, timeout=timeout)
                returncode = proc.returncode

                # Log output if debug enabled
                if self.debug_output:
                    for line in stdout.splitlines():
                        logger.debug(f"{log_prefix}[stdout] {line}")
                    for line in stderr.splitlines():
                        logger.debug(f"{log_prefix}[stderr] {line}")

            except subprocess.TimeoutExpired:
                logger.warning(f"{log_prefix}Process timed out after {timeout}s")
                proc.kill()
                stdout, stderr = proc.communicate()
                returncode = proc.returncode
                timed_out = True

        except Exception as e:
            duration = time.time() - start_time
            logger.error(f"{log_prefix}Command execution failed: {e}")
            raise

        duration = time.time() - start_time

        # Log completion
        logger.debug(
            f"{log_prefix}Command completed in {duration:.2f}s "
            f"with exit code {returncode}"
        )

        return ProcessResult(
            returncode=returncode,
            stdout=stdout,
            stderr=stderr,
            duration=duration,
            timed_out=timed_out,
        )

    def run_command_with_input(
        self,
        cmd: Union[str, List[str]],
        stdin_input: str,
        cwd: Optional[Union[str, Path]] = None,
        timeout: Optional[int] = None,
        env: Optional[Union[dict, "EnvironmentConfig"]] = None,
        shell: bool = False,
        log_prefix: str = "",
    ) -> ProcessResult:
        """Run a command with input sent to stdin.

        This is a convenience method that calls run_command with stdin_input.

        Args:
            cmd: Command to execute
            stdin_input: Input to send to process stdin
            cwd: Working directory for the command
            timeout: Timeout in seconds
            env: Optional environment variables dict or EnvironmentConfig
            shell: Whether to execute through shell
            log_prefix: Prefix for debug log messages

        Returns:
            ProcessResult with execution details
        """
        # Disable debug output for input commands to avoid logging sensitive data
        original_debug = self.debug_output
        self.debug_output = False

        try:
            return self.run_command(
                cmd=cmd,
                cwd=cwd,
                timeout=timeout,
                stdin_input=stdin_input,
                env=env,
                shell=shell,
                log_prefix=log_prefix,
            )
        finally:
            self.debug_output = original_debug
