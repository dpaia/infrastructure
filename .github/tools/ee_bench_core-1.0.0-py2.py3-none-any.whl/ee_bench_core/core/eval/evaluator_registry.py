"""Evaluator plugin registry for dynamic evaluator discovery and registration.

This module provides a registry system for evaluators that allows:
- Registering evaluators by name (programmatically or via decorator)
- Discovering evaluators from entry points (plugins)
- Retrieving evaluator factories by name
- Listing all available evaluators with metadata
"""

import logging
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

from .evaluator import Evaluator
from .base_plugin_registry import (
    BasePluginRegistry,
    PluginMetadata,
    create_global_registry_accessors,
)
from ..config import get_config

logger = logging.getLogger(__name__)


@dataclass
class EvaluatorMetadata(PluginMetadata[Evaluator]):
    """Metadata about a registered evaluator.

    Attributes:
        name: Unique identifier for the evaluator
        factory: Factory function or class that creates the evaluator
        description: Human-readable description
        version: Version string (e.g., "1.0.0")
        author: Author or organization name
        tags: List of tags for categorization (e.g., ["patch", "test", "validation"])
        dependencies: List of evaluator names this depends on conceptually
        specs: List of spec names this evaluator applies to (empty = all specs)
        entry_point: Entry point name if loaded from plugin (None if programmatic)
    """

    dependencies: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict:
        """Convert metadata to dictionary for serialization."""
        base_dict = super().to_dict()
        base_dict["dependencies"] = self.dependencies
        return base_dict


class EvaluatorRegistry(BasePluginRegistry[Evaluator]):
    """Registry for evaluator plugins.

    The registry allows:
    1. Programmatic registration via register() or @register_evaluator decorator
    2. Automatic discovery from entry points (ee_bench.evaluators)
    3. Retrieval of evaluator factories by name
    4. Listing all available evaluators with metadata

    Example:
        >>> registry = EvaluatorRegistry()
        >>>
        >>> # Register programmatically
        >>> registry.register(
        ...     name="custom_validator",
        ...     factory=CustomValidatorEvaluator,
        ...     description="Validates custom constraints"
        ... )
        >>>
        >>> # Or use decorator
        >>> @registry.register_evaluator(
        ...     name="custom_checker",
        ...     description="Checks custom conditions"
        ... )
        ... class CustomCheckerEvaluator(Evaluator):
        ...     pass
        >>>
        >>> # Get evaluator factory
        >>> factory = registry.get("custom_validator")
        >>> evaluator = factory(name="validator", ...)
        >>>
        >>> # List all evaluators
        >>> for metadata in registry.list():
        ...     print(f"{metadata.name}: {metadata.description}")
    """

    def _get_plugin_type_name(self) -> str:
        """Get the name of this plugin type for logging and error messages."""
        return "evaluator"

    def _is_plugin_enabled(self, name: str) -> bool:
        """Check if evaluator should be enabled based on configuration."""
        config = get_config()
        return config.is_evaluator_enabled(name)

    def _get_metadata_attributes(self) -> Dict[str, str]:
        """Get attribute names for extracting evaluator metadata from factories."""
        return {
            "name": "__evaluator_name__",
            "description": "__evaluator_description__",
            "version": "__evaluator_version__",
            "author": "__evaluator_author__",
            "tags": "__evaluator_tags__",
            "specs": "__evaluator_specs__",
            "dependencies": "__evaluator_dependencies__",
        }

    def _create_metadata(
        self,
        name: str,
        factory: Callable[..., Evaluator],
        description: str,
        version: str,
        author: str,
        tags: List[str],
        specs: List[str],
        entry_point: Optional[str] = None,
        **kwargs,
    ) -> EvaluatorMetadata:
        """Create evaluator-specific metadata instance."""
        dependencies = kwargs.get("dependencies", [])
        return EvaluatorMetadata(
            name=name,
            factory=factory,
            description=description,
            version=version,
            author=author,
            tags=tags,
            dependencies=dependencies,
            specs=specs,
            entry_point=entry_point,
        )

    def _extract_extra_metadata(
        self, factory: Callable, attr_map: Dict[str, str]
    ) -> Dict:
        """Extract evaluator-specific metadata fields."""
        return {
            "dependencies": getattr(
                factory, attr_map.get("dependencies", "__evaluator_dependencies__"), []
            )
        }

    def register_evaluator(
        self,
        name: str,
        description: str = "",
        version: str = "1.0.0",
        author: str = "",
        tags: Optional[List[str]] = None,
        dependencies: Optional[List[str]] = None,
        specs: Optional[List[str]] = None,
        replace: bool = False,
    ):
        """Decorator for registering evaluator classes.

        Args:
            name: Unique identifier for the evaluator
            description: Human-readable description
            version: Version string
            author: Author or organization name
            tags: List of tags for categorization
            dependencies: List of evaluator names this conceptually depends on
            specs: List of spec names this evaluator applies to (empty = all specs)
            replace: If True, replace existing registration

        Returns:
            Decorator function that registers the class

        Example:
            >>> registry = EvaluatorRegistry()
            >>>
            >>> @registry.register_evaluator(
            ...     name="custom_eval",
            ...     description="Custom evaluator",
            ...     tags=["custom", "validation"],
            ...     specs=["jvm", "python"]
            ... )
            ... class CustomEvaluator(Evaluator):
            ...     def evaluate(self, ...):
            ...         pass
        """
        return self.register_plugin(
            name=name,
            description=description,
            version=version,
            author=author,
            tags=tags,
            specs=specs,
            replace=replace,
            dependencies=dependencies,
        )

    def discover_plugins(self, group: str = "ee_bench.evaluators") -> int:
        """Discover and register evaluators from entry points.

        This method scans for entry points in the specified group and loads
        evaluator factories from them. Entry points should be defined in
        pyproject.toml or setup.py:

        [project.entry-points."ee_bench.evaluators"]
        my_evaluator = "my_package.evaluators:MyEvaluator"

        Args:
            group: Entry point group name (default: "ee_bench.evaluators")

        Returns:
            Number of evaluators discovered and registered
        """
        return super().discover_plugins(group)


# Global registry accessor functions created using the factory pattern
# This eliminates code duplication across multiple registry types
(
    get_global_registry,
    _register_plugin_generic,
    list_evaluators,
) = create_global_registry_accessors(EvaluatorRegistry)


def register_evaluator(
    name: str,
    description: str = "",
    version: str = "1.0.0",
    author: str = "",
    tags: Optional[List[str]] = None,
    dependencies: Optional[List[str]] = None,
    specs: Optional[List[str]] = None,
    replace: bool = False,
):
    """Decorator for registering evaluators in the global registry.

    This is a convenience function that uses the global registry.

    Args:
        name: Unique identifier for the evaluator
        description: Human-readable description
        version: Version string
        author: Author or organization name
        tags: List of tags for categorization
        dependencies: List of evaluator names this conceptually depends on
        specs: List of spec names this evaluator applies to (empty = all specs)
        replace: If True, replace existing registration

    Returns:
        Decorator function

    Example:
        >>> @register_evaluator(
        ...     name="my_evaluator",
        ...     description="My custom evaluator",
        ...     tags=["custom"],
        ...     specs=["jvm"]
        ... )
        ... class MyEvaluator(Evaluator):
        ...     pass
    """
    registry = get_global_registry()
    return registry.register_evaluator(
        name=name,
        description=description,
        version=version,
        author=author,
        tags=tags,
        dependencies=dependencies,
        specs=specs,
        replace=replace,
    )
