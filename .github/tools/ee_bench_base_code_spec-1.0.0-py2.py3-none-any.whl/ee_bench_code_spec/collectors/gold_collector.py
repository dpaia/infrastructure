"""Gold standard predictions collector.

Collects predictions from dataset's patch field for testing purposes.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Optional

from ee_bench_core.adapters import Sandbox
from ee_bench_core.core.predictions_collector import PredictionsCollector
from ee_bench_core.core.models import PredictionResult, ResultStatus

if TYPE_CHECKING:
    from ee_bench_core.core.models import DatasetConfig

logger = logging.getLogger(__name__)


class GoldPredictionsCollector(PredictionsCollector):
    """Collects predictions from patch field in dataset configuration.

    This collector extracts the gold/reference prediction directly from the
    dataset configuration. It's primarily used for testing evaluation pipelines
    with known-good predictions.

    Usage:
        # Triggered automatically with --predictions=gold
        collector = GoldPredictionsCollector()
        entry = collector.collect(
            instance_id="task-1",
            env_config=env_config,
            config=dataset_config,
        )
    """

    # Plugin metadata
    __collector_name__ = "gold"
    __collector_description__ = "Collects gold/reference predictions from dataset"
    __collector_version__ = "1.0.0"
    __collector_author__ = "EE-Bench"
    __collector_tags__ = ["gold", "reference", "testing"]
    __collector_specs__ = []  # Works with all specs
    __collector_trigger_modes__ = ["gold"]

    # High priority for explicit gold collection
    priority = 15

    @classmethod
    def is_applicable(cls, spec, env_config, **kwargs) -> bool:
        """Check if gold collection is explicitly requested.

        Gold collection is typically triggered by explicit flag since
        it requires the dataset to have a patch field.

        Args:
            spec: Evaluation spec instance
            env_config: Environment configuration
            **kwargs: CLI parameters

        Returns:
            False (gold collector only used when explicitly requested via --predictions=gold)
        """
        # Gold collector should only be used when explicitly requested
        # via --predictions=gold, not for auto-selection
        return kwargs.get("predictions") == "gold"

    def collect(
        self,
        instance_id: str,
        sandbox: Sandbox,
        config: "DatasetConfig",
        timeout: Optional[int] = None,
        **kwargs,
    ) -> PredictionResult:
        """Collect prediction from dataset's patch field.

        Args:
            instance_id: Unique identifier for the task instance
            env_config: Environment configuration (not used for gold collection)
            config: Dataset configuration containing patch field
            timeout: Optional timeout (not used for gold collection)
            **kwargs: Additional parameters (not used for gold collection)

        Returns:
            PredictionResult with instance_id, content (patch), and source="gold"

        Raises:
            ValueError: If patch field is missing from config
            AttributeError: If config doesn't have patch attribute
        """
        try:
            # Extract patch from dataset config
            if not hasattr(config, "patch"):
                raise AttributeError(
                    f"Dataset config for {instance_id} does not have 'patch' attribute. "
                    f"Available attributes: {dir(config)}"
                )

            patch = getattr(config, "patch", None)
            if patch is None:
                raise ValueError(
                    f"patch is None for instance {instance_id}. "
                    f"Cannot use gold predictions collector."
                )

            # Check if patch is empty and provide helpful error message
            if not patch or patch.strip() == "":
                error_msg = (
                    f"Gold patch is empty for instance {instance_id}. "
                    f"This instance does not have a reference solution. "
                    f"Use a different predictions collector (e.g., agent) or select "
                    f"an instance with a gold patch."
                )
                logger.warning(error_msg)
                return PredictionResult(
                    instance_id=instance_id,
                    content="",
                    source="gold",
                    status=ResultStatus.SKIPPED,
                    error=error_msg,
                )

            logger.info(
                f"Collected gold prediction for {instance_id} ({len(patch)} chars)"
            )

            # Return PredictionResult with gold patch
            # Status will auto-set to SUCCESS if content is not empty (via __post_init__)
            return PredictionResult(
                instance_id=instance_id,
                content=patch,
                source="gold",
            )
        except (AttributeError, ValueError) as e:
            logger.error(f"Failed to collect gold prediction for {instance_id}: {e}")
            raise
        except Exception as e:
            logger.error(
                f"Unexpected error collecting gold prediction for {instance_id}: {e}"
            )
            raise RuntimeError(f"Gold collection failed: {e}") from e
