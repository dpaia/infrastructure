"""ee_bench.swe_pro - SWE-bench Pro eval generator for EE-bench."""

from ee_bench.swe_pro.generator import SweBenchProEvalGenerator

__version__ = "0.1.0"

__all__ = ["SweBenchProEvalGenerator"]
