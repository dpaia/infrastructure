"""Evaluator plugin registry for dynamic evaluator discovery and registration.

This module provides a registry system for evaluators that allows:
- Registering evaluators by name (programmatically or via decorator)
- Discovering evaluators from entry points (plugins)
- Retrieving evaluator factories by name
- Listing all available evaluators with metadata
"""

import logging
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Type
from importlib.metadata import entry_points

from .evaluator import Evaluator
from ..config import get_config

logger = logging.getLogger(__name__)


@dataclass
class EvaluatorMetadata:
    """Metadata about a registered evaluator.

    Attributes:
        name: Unique identifier for the evaluator
        factory: Factory function or class that creates the evaluator
        description: Human-readable description
        version: Version string (e.g., "1.0.0")
        author: Author or organization name
        tags: List of tags for categorization (e.g., ["patch", "test", "validation"])
        dependencies: List of evaluator names this depends on conceptually
        specs: List of spec names this evaluator applies to (empty = all specs)
        entry_point: Entry point name if loaded from plugin (None if programmatic)
    """

    name: str
    factory: Callable[..., Evaluator]
    description: str = ""
    version: str = "1.0.0"
    author: str = ""
    tags: List[str] = field(default_factory=list)
    dependencies: List[str] = field(default_factory=list)
    specs: List[str] = field(default_factory=list)
    entry_point: Optional[str] = None

    def to_dict(self) -> Dict:
        """Convert metadata to dictionary for serialization."""
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "author": self.author,
            "tags": self.tags,
            "dependencies": self.dependencies,
            "specs": self.specs,
            "entry_point": self.entry_point,
        }


class EvaluatorRegistry:
    """Registry for evaluator plugins.

    The registry allows:
    1. Programmatic registration via register() or @register_evaluator decorator
    2. Automatic discovery from entry points (ee_bench.evaluators)
    3. Retrieval of evaluator factories by name
    4. Listing all available evaluators with metadata

    Example:
        >>> registry = EvaluatorRegistry()
        >>>
        >>> # Register programmatically
        >>> registry.register(
        ...     name="custom_validator",
        ...     factory=CustomValidatorEvaluator,
        ...     description="Validates custom constraints"
        ... )
        >>>
        >>> # Or use decorator
        >>> @registry.register_evaluator(
        ...     name="custom_checker",
        ...     description="Checks custom conditions"
        ... )
        ... class CustomCheckerEvaluator(Evaluator):
        ...     pass
        >>>
        >>> # Get evaluator factory
        >>> factory = registry.get("custom_validator")
        >>> evaluator = factory(name="validator", ...)
        >>>
        >>> # List all evaluators
        >>> for metadata in registry.list():
        ...     print(f"{metadata.name}: {metadata.description}")
    """

    def __init__(self, auto_discover: bool = False):
        """Initialize registry.

        Args:
            auto_discover: If True, automatically discover evaluators from entry points
        """
        self._evaluators: Dict[str, EvaluatorMetadata] = {}

        if auto_discover:
            self.discover_plugins()

    def register(
        self,
        name: str,
        factory: Callable[..., Evaluator],
        description: str = "",
        version: str = "1.0.0",
        author: str = "",
        tags: Optional[List[str]] = None,
        dependencies: Optional[List[str]] = None,
        specs: Optional[List[str]] = None,
        replace: bool = False,
    ) -> None:
        """Register an evaluator factory.

        Args:
            name: Unique identifier for the evaluator
            factory: Factory function or class that creates Evaluator instances
            description: Human-readable description
            version: Version string
            author: Author or organization name
            tags: List of tags for categorization
            dependencies: List of evaluator names this conceptually depends on
            specs: List of spec names this evaluator applies to (empty = all specs)
            replace: If True, replace existing registration (default: False, raises error)

        Raises:
            ValueError: If name is already registered and replace=False
        """
        # Check if evaluator is disabled in configuration
        config = get_config()
        if not config.is_evaluator_enabled(name):
            logger.info(f"Evaluator '{name}' is disabled in configuration, skipping registration")
            return

        if name in self._evaluators and not replace:
            raise ValueError(
                f"Evaluator '{name}' is already registered. "
                f"Use replace=True to override."
            )

        metadata = EvaluatorMetadata(
            name=name,
            factory=factory,
            description=description,
            version=version,
            author=author,
            tags=tags or [],
            dependencies=dependencies or [],
            specs=specs or [],
        )

        self._evaluators[name] = metadata
        logger.debug(f"Registered evaluator '{name}' (version {version})")

    def register_evaluator(
        self,
        name: str,
        description: str = "",
        version: str = "1.0.0",
        author: str = "",
        tags: Optional[List[str]] = None,
        dependencies: Optional[List[str]] = None,
        specs: Optional[List[str]] = None,
        replace: bool = False,
    ):
        """Decorator for registering evaluator classes.

        Args:
            name: Unique identifier for the evaluator
            description: Human-readable description
            version: Version string
            author: Author or organization name
            tags: List of tags for categorization
            dependencies: List of evaluator names this conceptually depends on
            specs: List of spec names this evaluator applies to (empty = all specs)
            replace: If True, replace existing registration

        Returns:
            Decorator function that registers the class

        Example:
            >>> registry = EvaluatorRegistry()
            >>>
            >>> @registry.register_evaluator(
            ...     name="custom_eval",
            ...     description="Custom evaluator",
            ...     tags=["custom", "validation"],
            ...     specs=["swe-jvm", "swe-python"]
            ... )
            ... class CustomEvaluator(Evaluator):
            ...     def evaluate(self, ...):
            ...         pass
        """

        def decorator(cls: Type[Evaluator]) -> Type[Evaluator]:
            self.register(
                name=name,
                factory=cls,
                description=description,
                version=version,
                author=author,
                tags=tags,
                dependencies=dependencies,
                specs=specs,
                replace=replace,
            )
            return cls

        return decorator

    def get(self, name: str) -> Callable[..., Evaluator]:
        """Get evaluator factory by name.

        Args:
            name: Evaluator name

        Returns:
            Factory function or class

        Raises:
            KeyError: If evaluator not found
        """
        if name not in self._evaluators:
            available = ", ".join(self._evaluators.keys())
            raise KeyError(
                f"Evaluator '{name}' not found. "
                f"Available evaluators: {available or 'none'}"
            )

        return self._evaluators[name].factory

    def get_metadata(self, name: str) -> EvaluatorMetadata:
        """Get metadata for an evaluator.

        Args:
            name: Evaluator name

        Returns:
            EvaluatorMetadata instance

        Raises:
            KeyError: If evaluator not found
        """
        if name not in self._evaluators:
            raise KeyError(f"Evaluator '{name}' not found")

        return self._evaluators[name]

    def has(self, name: str) -> bool:
        """Check if evaluator is registered.

        Args:
            name: Evaluator name

        Returns:
            True if registered, False otherwise
        """
        return name in self._evaluators

    def list(
        self, tags: Optional[List[str]] = None, spec: Optional[str] = None
    ) -> List[EvaluatorMetadata]:
        """List all registered evaluators, optionally filtered by tags and/or spec.

        Args:
            tags: Optional list of tags to filter by (evaluators must have at least one matching tag)
            spec: Optional spec name to filter by (evaluators with empty specs list match all specs)

        Returns:
            List of EvaluatorMetadata instances matching criteria
        """
        evaluators = list(self._evaluators.values())

        if tags:
            evaluators = [
                meta for meta in evaluators if any(tag in meta.tags for tag in tags)
            ]

        if spec:
            evaluators = [
                meta for meta in evaluators if not meta.specs or spec in meta.specs
            ]

        return evaluators

    def list_for_spec(self, spec_name: str) -> List[EvaluatorMetadata]:
        """List all evaluators applicable to a specific spec.

        This is a convenience method that filters evaluators by spec.
        An evaluator is applicable if:
        - Its specs list is empty (universal evaluator), OR
        - The spec_name is in its specs list

        Args:
            spec_name: Name of the specification (e.g., "swe-jvm", "swe-python")

        Returns:
            List of EvaluatorMetadata instances applicable to the spec

        Example:
            >>> registry = EvaluatorRegistry()
            >>> registry.discover_plugins()
            >>>
            >>> # Get evaluators for JVM SWE spec
            >>> jvm_evaluators = registry.list_for_spec("swe-jvm")
            >>> for meta in jvm_evaluators:
            ...     print(f"{meta.name}: {meta.specs}")
        """
        return self.list(spec=spec_name)

    def unregister(self, name: str) -> None:
        """Unregister an evaluator.

        Args:
            name: Evaluator name

        Raises:
            KeyError: If evaluator not found
        """
        if name not in self._evaluators:
            raise KeyError(f"Evaluator '{name}' not found")

        del self._evaluators[name]
        logger.debug(f"Unregistered evaluator '{name}'")

    def clear(self) -> None:
        """Clear all registered evaluators."""
        self._evaluators.clear()
        logger.debug("Cleared all registered evaluators")

    def discover_plugins(self, group: str = "ee_bench.evaluators") -> int:
        """Discover and register evaluators from entry points.

        This method scans for entry points in the specified group and loads
        evaluator factories from them. Entry points should be defined in
        pyproject.toml or setup.py:

        [project.entry-points."ee_bench.evaluators"]
        my_evaluator = "my_package.evaluators:MyEvaluator"

        Args:
            group: Entry point group name (default: "ee_bench.evaluators")

        Returns:
            Number of evaluators discovered and registered
        """
        count = 0

        try:
            # Python 3.10+ API
            eps = entry_points(group=group)
        except TypeError:
            # Python 3.9 fallback
            eps = entry_points().get(group, [])

        for ep in eps:
            try:
                # Load the entry point
                factory = ep.load()

                # Extract metadata from factory if available
                name = getattr(factory, "__evaluator_name__", ep.name)
                description = getattr(factory, "__evaluator_description__", "")
                version = getattr(factory, "__evaluator_version__", "1.0.0")
                author = getattr(factory, "__evaluator_author__", "")
                tags = getattr(factory, "__evaluator_tags__", [])
                dependencies = getattr(factory, "__evaluator_dependencies__", [])
                specs = getattr(factory, "__evaluator_specs__", [])

                # Register (don't replace existing)
                if not self.has(name):
                    metadata = EvaluatorMetadata(
                        name=name,
                        factory=factory,
                        description=description,
                        version=version,
                        author=author,
                        tags=tags,
                        dependencies=dependencies,
                        specs=specs,
                        entry_point=ep.name,
                    )
                    self._evaluators[name] = metadata
                    count += 1
                    spec_info = (
                        f" (specs: {', '.join(specs)})" if specs else " (all specs)"
                    )
                    logger.info(
                        f"Discovered evaluator '{name}' from entry point '{ep.name}'{spec_info}"
                    )
                else:
                    logger.debug(
                        f"Skipping entry point '{ep.name}': evaluator '{name}' already registered"
                    )

            except Exception as e:
                logger.error(
                    f"Failed to load evaluator from entry point '{ep.name}': {e}",
                    exc_info=True,
                )

        logger.info(f"Discovered {count} evaluators from entry points")
        return count


# Global registry instance
_global_registry: Optional[EvaluatorRegistry] = None


def get_global_registry() -> EvaluatorRegistry:
    """Get the global evaluator registry instance.

    Returns:
        Global EvaluatorRegistry instance (created if needed)
    """
    global _global_registry
    if _global_registry is None:
        _global_registry = EvaluatorRegistry(auto_discover=False)
    return _global_registry


def register_evaluator(
    name: str,
    description: str = "",
    version: str = "1.0.0",
    author: str = "",
    tags: Optional[List[str]] = None,
    dependencies: Optional[List[str]] = None,
    specs: Optional[List[str]] = None,
    replace: bool = False,
):
    """Decorator for registering evaluators in the global registry.

    This is a convenience function that uses the global registry.

    Args:
        name: Unique identifier for the evaluator
        description: Human-readable description
        version: Version string
        author: Author or organization name
        tags: List of tags for categorization
        dependencies: List of evaluator names this conceptually depends on
        specs: List of spec names this evaluator applies to (empty = all specs)
        replace: If True, replace existing registration

    Returns:
        Decorator function

    Example:
        >>> @register_evaluator(
        ...     name="my_evaluator",
        ...     description="My custom evaluator",
        ...     tags=["custom"],
        ...     specs=["swe-jvm"]
        ... )
        ... class MyEvaluator(Evaluator):
        ...     pass
    """
    registry = get_global_registry()
    return registry.register_evaluator(
        name=name,
        description=description,
        version=version,
        author=author,
        tags=tags,
        dependencies=dependencies,
        specs=specs,
        replace=replace,
    )
