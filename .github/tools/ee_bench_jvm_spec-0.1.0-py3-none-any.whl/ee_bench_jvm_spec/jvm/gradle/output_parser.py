"""Gradle console output parser.

This module provides functionality to parse Gradle test execution console output
and extract test results when JUnit XML reports are not available.
"""

import logging
import re

from ee_bench_core.adapters import TestResult
from ee_bench_core.core.models import ResultStatus

logger = logging.getLogger(__name__)


class GradleOutputParser:
    """Parser for Gradle console output to extract test results."""

    # Regex patterns for Gradle output
    TEST_LINE_RE = re.compile(
        r"^(?P<class>[\w.$]+)\s*>\s*(?P<method>.+?)\s+(?P<status>PASSED|FAILED|SKIPPED|IGNORED|ABORTED)(?:\s*\((?P<duration>[^)]+)\))?\s*$"
    )
    TASK_LINE_RE = re.compile(
        r"^> Task\s+(?P<task>[:\w\-\.\#]+)(?:\s+(?P<outcome>FAILED|UP-TO-DATE|FROM-CACHE|NO-SOURCE|SKIPPED))?\s*$"
    )
    BUILD_STATUS_RE = re.compile(r"^BUILD\s+(?P<status>SUCCESSFUL|FAILED)\b")
    NO_TESTS_RE = re.compile(r"No tests found.*", re.IGNORECASE)
    COMPILATION_HINTS = [
        re.compile(r"\bCompilation failed\b", re.IGNORECASE),
        re.compile(r":compile(?:Java|Kotlin)\s+FAILED\b"),
        re.compile(r"\bkapt\b.*\bFAILED\b", re.IGNORECASE),
        re.compile(r"^\s*e:\s", re.IGNORECASE),  # Kotlin compiler
        re.compile(r"^\s*error:\s", re.IGNORECASE),  # javac at start
        re.compile(r":\s*error:\s", re.IGNORECASE),  # javac with file path prefix
    ]

    def parse(self, stdout: str, class_fqn: str, execution_time: float) -> TestResult:
        """Parse Gradle stdout output for a specific class.

        Args:
            stdout: Gradle console output
            class_fqn: Fully qualified class name being tested
            execution_time: Execution time in seconds

        Returns:
            TestResult with parsed information
        """
        lines = stdout.splitlines()

        # State for collecting failure details after a FAILED test line
        collecting_for: dict | None = None
        failure_buffer: list[str] = []

        def flush_failure_buffer_if_any():
            nonlocal collecting_for, failure_buffer
            if collecting_for is not None and failure_buffer:
                # Trim trailing blanks
                while failure_buffer and failure_buffer[-1].strip() == "":
                    failure_buffer.pop()
                if failure_buffer:
                    collecting_for["failure_block"] = "\n".join(failure_buffer)
            collecting_for = None
            failure_buffer = []

        cases: list[dict] = []
        no_tests_lines: list[str] = []
        compilation_lines: list[str] = []

        for raw_line in lines:
            line = raw_line.rstrip("\n")

            # Build status line terminates any ongoing failure block
            if self.BUILD_STATUS_RE.match(line):
                flush_failure_buffer_if_any()
                continue

            # Task line terminates ongoing failure block as well
            if self.TASK_LINE_RE.match(line):
                flush_failure_buffer_if_any()
                continue

            # Test lines
            tt = self.TEST_LINE_RE.match(line)
            if tt:
                flush_failure_buffer_if_any()
                tcase: dict[str, str] = {
                    "class": tt.group("class"),
                    "method": tt.group("method"),
                    "status": tt.group("status"),
                }
                if tt.group("duration"):
                    tcase["duration"] = tt.group("duration").strip()
                cases.append(tcase)

                # Start collecting following lines for FAILED tests
                if tcase["status"].upper() == "FAILED":
                    collecting_for = tcase
                    failure_buffer = []
                else:
                    collecting_for = None
                    failure_buffer = []
                continue

            # Accumulate lines into failure buffer if currently collecting
            if collecting_for is not None:
                failure_buffer.append(line)
                continue

            # "No tests found" lines
            if self.NO_TESTS_RE.search(line):
                no_tests_lines.append(line.strip())

            # Compilation hints
            for cre in self.COMPILATION_HINTS:
                if cre.search(line):
                    compilation_lines.append(line)
                    break

        # Finalize any pending failure block
        flush_failure_buffer_if_any()

        # Build TestResult using new structure
        result = TestResult(execution_time=execution_time, raw_output=stdout)

        for c in cases:
            test_id = f"{c.get('class', '')}#{c.get('method', '')}".strip("#")
            if not test_id:
                # Fallback to class_fqn if somehow parsing failed
                test_id = class_fqn

            status = (c.get("status") or "").upper()
            test_details: list[str] = []

            if c.get("duration"):
                test_details.append(f"Duration: {c['duration']}\n")
            if c.get("failure_block"):
                test_details.append(c["failure_block"])

            if status == "PASSED":
                result.add_test(
                    test_name=test_id,
                    status=ResultStatus.SUCCESS,
                    reason="Test passed",
                    details=test_details,
                )
            elif status == "FAILED":
                reason = "Test failed"
                if c.get("failure_block"):
                    # Use first line of failure block as reason
                    first_line = c["failure_block"].split("\n")[0]
                    if first_line.strip():
                        reason = first_line.strip()
                result.add_test(
                    test_name=test_id,
                    status=ResultStatus.FAILED,
                    reason=reason,
                    details=test_details or ["Test failed"],
                )
            elif status in {"SKIPPED", "IGNORED", "ABORTED"}:
                result.add_test(
                    test_name=test_id,
                    status=ResultStatus.SKIPPED,
                    reason=f"Test {status.lower()}",
                    details=test_details,
                )

        # Handle "No tests found" or pure compilation failure (no parsed cases)
        if not cases and (no_tests_lines or compilation_lines):
            # Attach to the requested class FQN
            msgs = []
            if no_tests_lines:
                msgs.extend(no_tests_lines)
            if compilation_lines:
                msgs.append("Compilation issues detected:")
                msgs.extend(compilation_lines)

            reason = "No tests found"
            if compilation_lines:
                # Use the first actual compilation error line as the reason
                # Find first line that doesn't start with common prefixes
                error_lines = [
                    line.strip()
                    for line in compilation_lines
                    if line.strip()
                    and not line.strip().startswith((">", "FAILURE:", "BUILD", "Task"))
                ]
                if error_lines:
                    reason = "\n".join(error_lines)
                else:
                    reason = "Compilation issues detected"

            result.add_test(
                test_name=class_fqn,
                status=ResultStatus.FAILED,
                reason=reason,
                details=msgs,
            )

        return result
