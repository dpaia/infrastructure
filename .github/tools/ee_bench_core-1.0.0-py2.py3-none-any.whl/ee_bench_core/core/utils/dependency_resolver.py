"""Generic dependency resolver for components with dependencies.

This module provides dependency resolution logic that can be used by both
Evaluators and EnvironmentConfigurers to compute execution order.
"""

import logging
from collections import defaultdict, deque
from typing import Dict, List, Optional, Protocol, Set, TypeVar, Union

from ..eval.evaluator import DependencyPosition, PositionConstraint

logger = logging.getLogger(__name__)


class DependentComponent(Protocol):
    """Protocol for components with dependencies.

    This protocol defines the interface required for dependency resolution.
    Both Evaluator and EnvironmentConfigurer implement this protocol.
    """

    @property
    def name(self) -> str:
        """Component name (must be unique)."""
        ...

    @property
    def dependencies(self) -> Optional[Union[List[str], DependencyPosition]]:
        """Dependency specification.

        Returns:
            - None: No explicit dependencies (treated as FIRST position)
            - List[str]: List of component names that must run before this one
            - DependencyPosition: Full dependency specification with position/priority
        """
        ...


T = TypeVar("T", bound=DependentComponent)


class DependencyResolver:
    """Resolves dependencies and computes execution order for components.

    Features:
    - Dependency validation (unknown references, cycles)
    - Position constraint support (FIRST/MIDDLE/LAST)
    - Priority-based ordering within same dependency level
    - Topological sorting with level grouping for parallelization

    This resolver works with any component that implements the DependentComponent
    protocol (has name and dependencies properties).
    """

    def __init__(self, components: List[T], skip_unresolved: bool = False):
        """Initialize resolver with list of components.

        Args:
            components: List of components to resolve dependencies for
            skip_unresolved: If True, skip unresolved dependencies instead of raising errors
        """
        self.components = components
        self.component_map: Dict[str, T] = {c.name: c for c in components}
        self.skip_unresolved = skip_unresolved

    def validate(self) -> None:
        """Validate component dependencies.

        Checks:
        1. All referenced components exist
        2. Position constraints are valid
        3. No circular dependencies

        Raises:
            ValueError: If dependencies are invalid
        """
        self._validate_references()
        self._check_for_cycles()

    def get_execution_order(self) -> List[List[T]]:
        """Compute execution order with position constraint support.

        Strategy:
        1. Separate components into FIRST, MIDDLE, LAST groups
        2. Topologically sort each group independently
        3. Concatenate: FIRST batches + MIDDLE batches + LAST batches

        Returns:
            List of batches
        """
        # Separate components by position
        first_components: List[T] = []
        middle_components: List[T] = []
        last_components: List[T] = []

        for component in self.components:
            deps = self._normalize_dependencies(component)

            if deps.position == PositionConstraint.FIRST:
                first_components.append(component)
            elif deps.position == PositionConstraint.LAST:
                last_components.append(component)
            else:
                middle_components.append(component)

        # Topologically sort each group
        first_batches = (
            self._topological_sort(first_components) if first_components else []
        )
        middle_batches = (
            self._topological_sort(middle_components) if middle_components else []
        )
        last_batches = (
            self._topological_sort(last_components) if last_components else []
        )

        # Concatenate batches
        all_batches = first_batches + middle_batches + last_batches

        logger.debug(
            f"Computed execution order: {len(all_batches)} batches "
            f"({len(first_batches)} first, {len(middle_batches)} middle, "
            f"{len(last_batches)} last)"
        )

        return all_batches

    def _normalize_dependencies(self, component: T) -> DependencyPosition:
        """Normalize dependency specification to DependencyPosition.

        When dependencies is None, treats component as FIRST position to ensure
        it runs early in the execution order (no explicit dependencies).

        Args:
            component: Component to normalize dependencies for

        Returns:
            DependencyPosition instance
        """
        deps = component.dependencies

        if deps is None:
            # Treat None as FIRST position - runs early with no explicit dependencies
            return DependencyPosition(position=PositionConstraint.FIRST)

        if isinstance(deps, DependencyPosition):
            return deps

        if isinstance(deps, list):
            # Legacy format: list of names means "after" dependencies
            return DependencyPosition(after=deps)

        raise ValueError(
            f"Invalid dependencies type for {component.name}: {type(deps)}"
        )

    def _validate_references(self) -> None:
        """Validate that all referenced components exist.

        If skip_unresolved is True, logs warnings instead of raising errors.

        Raises:
            ValueError: If unknown component is referenced and skip_unresolved is False
        """
        for component in self.components:
            deps = self._normalize_dependencies(component)

            for dep_name in deps.after:
                if dep_name not in self.component_map:
                    error_msg = (
                        f"Component '{component.name}' depends on unknown "
                        f"component '{dep_name}'"
                    )
                    if self.skip_unresolved:
                        logger.debug(f"Skipping unresolved dependency: {error_msg}")
                    else:
                        raise ValueError(error_msg)

            for dep_name in deps.before:
                if dep_name not in self.component_map:
                    error_msg = (
                        f"Component '{component.name}' must run before unknown "
                        f"component '{dep_name}'"
                    )
                    if self.skip_unresolved:
                        logger.debug(f"Skipping unresolved dependency: {error_msg}")
                    else:
                        raise ValueError(error_msg)

    def _check_for_cycles(self) -> None:
        """Check for circular dependencies using DFS.

        If skip_unresolved is True, ignores references to unknown components.

        Raises:
            ValueError: If a cycle is detected
        """
        # Build adjacency list (after relationships)
        graph: Dict[str, Set[str]] = defaultdict(set)

        for component in self.components:
            deps = self._normalize_dependencies(component)

            # "after" creates edge from dependency to component
            for dep_name in deps.after:
                # Skip unresolved dependencies if configured
                if dep_name in self.component_map:
                    graph[dep_name].add(component.name)

            # "before" creates edge from component to dependency
            for dep_name in deps.before:
                # Skip unresolved dependencies if configured
                if dep_name in self.component_map:
                    graph[component.name].add(dep_name)

        # DFS for cycle detection
        WHITE = 0  # Not visited
        GRAY = 1  # Visiting (in current path)
        BLACK = 2  # Visited (completed)

        color = {name: WHITE for name in self.component_map}
        path: List[str] = []

        def dfs(node: str) -> None:
            """DFS visit."""
            if color[node] == GRAY:
                # Found cycle
                cycle_start = path.index(node)
                cycle = path[cycle_start:] + [node]
                raise ValueError(f"Circular dependency detected: {' -> '.join(cycle)}")

            if color[node] == BLACK:
                return

            color[node] = GRAY
            path.append(node)

            for neighbor in graph.get(node, []):
                dfs(neighbor)

            path.pop()
            color[node] = BLACK

        for name in self.component_map:
            if color[name] == WHITE:
                dfs(name)

    def _topological_sort(self, components: List[T]) -> List[List[T]]:
        """Perform topological sort with level grouping using Kahn's algorithm.

        This handles both "after" and "before" constraints and groups components
        into levels (batches) that can be executed in parallel.

        Within each batch, components are sorted by priority (lower priority first).

        Args:
            components: List of components to sort

        Returns:
            List of batches, where each batch can be executed in parallel
        """
        if not components:
            return []

        # Build component map for this subset
        comp_map = {c.name: c for c in components}

        # Build adjacency list and in-degree count
        graph: Dict[str, Set[str]] = defaultdict(set)
        in_degree: Dict[str, int] = {c.name: 0 for c in components}

        for component in components:
            deps = self._normalize_dependencies(component)

            # "after" creates edges from dependencies to this component
            for dep_name in deps.after:
                if dep_name in comp_map:
                    graph[dep_name].add(component.name)
                    in_degree[component.name] += 1

            # "before" creates edges from this component to dependencies
            for dep_name in deps.before:
                if dep_name in comp_map:
                    graph[component.name].add(dep_name)
                    in_degree[dep_name] += 1

        # Kahn's algorithm with level grouping
        batches: List[List[T]] = []
        queue = deque([name for name, degree in in_degree.items() if degree == 0])

        while queue:
            # Process all nodes at current level (batch)
            batch_size = len(queue)
            batch_names: List[str] = []

            for _ in range(batch_size):
                name = queue.popleft()
                batch_names.append(name)

                # Reduce in-degree for neighbors
                for neighbor in graph[name]:
                    in_degree[neighbor] -= 1
                    if in_degree[neighbor] == 0:
                        queue.append(neighbor)

            # Sort batch by priority (lower priority first)
            batch_components = [comp_map[name] for name in batch_names]
            batch_components.sort(key=lambda c: self._get_priority(c))

            batches.append(batch_components)

        # Check if all components were processed (no cycles)
        processed_count = sum(len(batch) for batch in batches)
        if processed_count != len(components):
            raise ValueError(
                f"Cannot compute execution order: cycle detected or "
                f"invalid dependencies ({processed_count}/{len(components)} processed)"
            )

        return batches

    def _get_priority(self, component: T) -> int:
        """Get priority for a component.

        Priority can come from:
        1. DependencyPosition.priority field (if using full spec)
        2. Component.priority property (for backward compatibility)
        3. Default value of 100

        Args:
            component: Component to get priority for

        Returns:
            Priority value (lower = runs first)
        """
        deps = self._normalize_dependencies(component)

        # If priority specified in DependencyPosition, use that
        if deps.priority != 100:  # Non-default value
            return deps.priority

        # Otherwise try component's priority property (for backward compatibility)
        if hasattr(component, "priority"):
            return component.priority

        # Default
        return 100


def resolve_dependencies(
    components: List[T], validate: bool = True, skip_unresolved: bool = False
) -> List[List[T]]:
    """Convenience function to resolve dependencies and get execution order.

    Always uses position constraint support (FIRST/MIDDLE/LAST). The support_positions
    parameter is kept for backward compatibility but is now ignored.

    Args:
        components: List of components to resolve
        support_positions: Deprecated - always uses position support (kept for compatibility)
        validate: Whether to validate dependencies before resolving
        skip_unresolved: If True, skip unresolved dependencies with warnings instead of errors

    Returns:
        List of batches in execution order

    Raises:
        ValueError: If validation fails or dependencies cannot be resolved
                   (unless skip_unresolved=True for unresolved dependencies)

    Example:
        >>> from ee_bench_core.core.utils.dependency_resolver import resolve_dependencies
        >>> evaluators = [eval1, eval2, eval3]
        >>> batches = resolve_dependencies(evaluators)
        >>> for batch in batches:
        ...     # Execute batch in parallel
        ...     for evaluator in batch:
        ...         evaluator.evaluate(...)

        >>> # Skip unresolved dependencies with warnings
        >>> batches = resolve_dependencies(evaluators, skip_unresolved=True)
    """
    resolver = DependencyResolver(components, skip_unresolved=skip_unresolved)

    if validate:
        resolver.validate()

    # Always use position support
    return resolver.get_execution_order()
