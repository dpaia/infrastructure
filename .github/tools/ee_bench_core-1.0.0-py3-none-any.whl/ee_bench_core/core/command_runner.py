"""Base implementation of CommandRunner for executing commands in environments."""

import logging
import os
import tempfile
import time
import uuid
from pathlib import Path
from typing import Optional, Union, List

from typing import TYPE_CHECKING

from ee_bench_core.core.abc_types import CommandRunner
from ee_bench_core.core.models import CommandExecutionResult, EnvironmentConfig

if TYPE_CHECKING:
    from ee_bench_core.adapters import Sandbox

logger = logging.getLogger(__name__)


class BaseCommandRunner(CommandRunner):
    """Base implementation of CommandRunner using Sandbox.

    Handles command execution in both Docker and local environments by using
    the Sandbox abstraction which encapsulates the appropriate process manager
    based on the sandbox type.
    """

    def __init__(self):
        """Initialize BaseCommandRunner."""

    def _upload_script_local(self, script_file: str) -> str:
        """Get script path for local execution.

        Args:
            script_file: Path to script file on local filesystem

        Returns:
            Absolute path to script file

        Raises:
            Exception: If script file does not exist
        """
        script_path = Path(script_file).absolute()
        if not script_path.exists():
            raise Exception(f"Script file not found: {script_file}")
        return str(script_path)

    def _upload_script_docker(
        self, script_file: str, env_config: EnvironmentConfig
    ) -> str:
        """Upload script file to Docker container.

        Args:
            script_file: Path to script file on local filesystem
            env_config: Environment configuration with container_id

        Returns:
            Path to script in container

        Raises:
            Exception: If upload fails
        """
        # Read script content
        with open(script_file, "r") as f:
            content = f.read()

        # Create script in container using stdin
        return self._create_temp_script_docker(content, env_config)

    def _create_temp_script_local(self, content: str) -> str:
        """Create temporary script file locally.

        Args:
            content: Script content

        Returns:
            Path to created script file
        """
        fd, path = tempfile.mkstemp(suffix=".sh", text=True)
        try:
            with os.fdopen(fd, "w") as f:
                f.write(content)
            os.chmod(path, 0o755)
            logger.debug(f"Created local temp script: {path}")
            return path
        except Exception as e:
            # Close file descriptor if still open
            try:
                os.close(fd)
            except Exception:
                pass
            raise Exception(f"Failed to create local temp script: {e}")

    def _create_temp_script_docker(
        self, content: str, env_config: EnvironmentConfig
    ) -> str:
        """Create temporary script in Docker container.

        Args:
            content: Script content
            env_config: Environment configuration with container_id

        Returns:
            Path to script in container

        Raises:
            Exception: If creation fails
        """
        from ee_bench_core.adapters.docker import DockerAdapter

        script_name = f"script_{uuid.uuid4().hex}.sh"
        dest_path = f"/tmp/{script_name}"

        # Get container ID from env_config
        container_id = env_config.container_id

        # Use DockerAdapter to copy file directly (more reliable than heredoc)
        docker_adapter = DockerAdapter()
        logger.debug(f"Creating script in container {container_id}: {dest_path}")

        try:
            docker_adapter.copy_to_container(
                container_id=container_id,
                content=content,
                dest_path=dest_path,
                permissions=0o755,  # Already executable
            )
            logger.debug(f"Created temp script in container: {dest_path}")
            return dest_path
        except Exception as e:
            raise Exception(f"Failed to create script in container: {e}")

    def run_command(
        self,
        command: Union[str, List[str]],
        sandbox: "Sandbox",
        timeout: Optional[int] = None,
        **kwargs,
    ) -> CommandExecutionResult:
        """Run a command or script in the configured environment.

        Args:
            command: Shell command to execute (string or list of args)
                    - Ignored if script_file/script_content provided
                    - Can be a string for shell commands: "echo hello"
                    - Can be a list for direct execution: ["echo", "hello"]
            sandbox: Sandbox instance with environment configuration
                    (env_config accessible via sandbox.env_config if needed)
            timeout: Command timeout in seconds (None for no timeout)
            **kwargs: Additional execution parameters including:
                     - script_file: Path to shell script file to execute
                     - script_content: Shell script content to execute directly
                     - shell: Execute in shell mode
                     - stdin_input: Input to send via stdin
                     - instance_id: Instance identifier for logging
                     - stream_output: Stream output in real-time (bool)
                     - output_callback: Callback function for streaming output lines (Callable[[str], None])

        Returns:
            CommandExecutionResult with execution details and result status

        Raises:
            Exception: If command execution fails critically

        Note:
            Priority: script_file > script_content > command
            When command is a list, it's passed directly to avoid shell parsing issues
        """
        # Get env_config from sandbox
        env_config = sandbox.env_config

        instance_id = kwargs.get("instance_id", "unknown")
        log_prefix = f"[{instance_id}] "

        # Determine actual command to execute based on priority
        script_file = kwargs.get("script_file")
        script_content = kwargs.get("script_content")
        actual_command = command
        temp_script_path = None
        use_shell = kwargs.get("shell", False)  # Track if we need shell mode

        try:
            # Priority: script_file > script_content > command
            if script_file is not None:
                logger.info(f"{log_prefix}Executing script file: {script_file}")

                # Upload script based on sandbox type
                sandbox_type = getattr(env_config, "sandbox_type", "local")
                if sandbox_type == "docker":
                    script_path = self._upload_script_docker(script_file, env_config)
                    temp_script_path = script_path  # Track for cleanup
                else:
                    script_path = self._upload_script_local(script_file)

                actual_command = f"bash {script_path}"
                use_shell = True  # Scripts need shell mode to execute bash command

            elif script_content is not None:
                logger.info(f"{log_prefix}Executing inline script content")

                # Create temporary script based on sandbox type
                sandbox_type = getattr(env_config, "sandbox_type", "local")
                if sandbox_type == "docker":
                    script_path = self._create_temp_script_docker(
                        script_content, env_config
                    )
                    temp_script_path = script_path  # Track for cleanup
                else:
                    script_path = self._create_temp_script_local(script_content)
                    temp_script_path = script_path  # Track for cleanup

                actual_command = f"bash {script_path}"
                use_shell = True  # Scripts need shell mode to execute bash command

        except Exception as exc:
            target = script_file or (
                "<inline>" if script_content is not None else actual_command
            )
            logger.exception("%sFailed to prepare script %s", log_prefix, target)
            # Return error result for script preparation failure
            return CommandExecutionResult(
                instance_id=instance_id,
                command=command,
                exit_code=-1,
                stdout="",
                stderr="",
                duration=0.0,
                error=f"Script preparation failed: {exc}",
                environment=env_config,
            )

        logger.debug(f"{log_prefix}Running command: {actual_command}")
        start_time = time.time()

        try:
            # Set working directory if available
            working_dir = None
            if hasattr(env_config, "workspace_dir"):
                working_dir = env_config.workspace_dir

            env_vars = {}
            if hasattr(env_config, "env_vars") and env_config.env_vars:
                env_vars.update(env_config.env_vars)
            if kwargs.get("env_vars"):
                env_vars.update(kwargs.get("env_vars"))

            # Filter out parameters that are passed explicitly to avoid duplicates
            # stream_output and output_callback are passed through for streaming support
            from ee_bench_core.core.utils import exclude_keys

            filtered_kwargs = exclude_keys(
                kwargs,
                "stdin_input",
                "shell",
                "env_vars",
                "instance_id",
                "script_file",
                "script_content",
            )

            # Execute command using sandbox (no need for ProcessManagerFactory)
            result = sandbox.run_command(
                cmd=actual_command,
                cwd=working_dir,
                timeout=timeout,
                stdin_input=kwargs.get("stdin_input"),
                shell=use_shell,  # Use determined shell mode (True for scripts)
                log_prefix=log_prefix,
                env=env_vars,
                **filtered_kwargs,
            )
            duration = time.time() - start_time

            logger.debug(
                f"{log_prefix}Command completed with exit code {result.returncode} "
                f"in {duration:.2f}s"
            )

            # Convert ProcessResult to CommandExecutionResult
            stdin_input = kwargs.get("stdin_input")
            cmd_result = CommandExecutionResult(
                instance_id=instance_id,
                command=actual_command,  # Store actual command executed (may be script invocation)
                exit_code=result.returncode,
                stdout=result.stdout,
                stderr=result.stderr,
                duration=result.duration,
                timed_out=result.timed_out,
                error=None,
                environment=env_config,
                stdin_input=stdin_input,
                interactive=bool(stdin_input),
            )

            return cmd_result

        except Exception as exc:
            duration = time.time() - start_time if "start_time" in locals() else 0.0
            logger.exception(
                "%sCommand execution failed (%s)", log_prefix, actual_command
            )

            # Return error result instead of raising
            stdin_input = kwargs.get("stdin_input")
            return CommandExecutionResult(
                instance_id=instance_id,
                command=actual_command,
                exit_code=-1,
                stdout="",
                stderr="",
                duration=duration,
                timed_out=False,
                error=str(exc),
                environment=env_config,
                stdin_input=stdin_input,
                interactive=bool(stdin_input),
            )

        finally:
            # Cleanup temporary scripts for local execution
            if (
                temp_script_path
                and getattr(env_config, "sandbox_type", "local") == "local"
            ):
                try:
                    if os.path.exists(temp_script_path):
                        os.remove(temp_script_path)
                        logger.debug(
                            f"{log_prefix}Cleaned up temp script: {temp_script_path}"
                        )
                except Exception as e:
                    logger.warning(
                        f"{log_prefix}Failed to cleanup temp script {temp_script_path}: {e}"
                    )
