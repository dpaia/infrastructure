"""Maven configurer for adding Maven to JVM base images.

This configurer adds Apache Maven build tool to JVM base images, creating
Maven-enabled images that can be used for Maven-based projects.
"""

import logging

from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig

from ee_bench_jvm_spec.jvm.base_docker_build_tool_configurer import (
    BaseDockerBuildToolConfigurer,
)
from ee_bench_jvm_spec.jvm.jvm_config import BuildSystem

logger = logging.getLogger(__name__)

# Maven version mappings based on JDK version
MAVEN_VERSION_MAP = {
    "8": "3.8.8",  # Last version supporting Java 8
    "11": "3.9.6",
    "17": "3.9.6",
    "21": "3.9.6",
    "24": "3.9.9",
    "25": "3.9.9",# Latest for newest JDK
}

DEFAULT_MAVEN_VERSION = "3.9.6"


class DockerMavenConfigurer(BaseDockerBuildToolConfigurer):
    """Configurer that adds Maven to JVM base image.

    This configurer enhances a JVM base image by installing Apache Maven
    build tool. It automatically selects an appropriate Maven version based
    on the JDK version.

    The resulting image can be used for Maven-based Java projects.

    Metadata:
        name: maven
        priority: 50 (build tool - runs after base)
        dependencies: ["jvm_base_image"]
        specs: ["jvm"]
    """

    # Metadata for plugin discovery
    __configurer_name__ = "maven"
    __configurer_description__ = "Adds Maven to JVM base image"
    __configurer_version__ = "1.0.0"
    __configurer_specs__ = ["jvm"]

    def __init__(self, namespace: str = "ee-bench", **kwargs):
        """Initialize Maven configurer.

        Args:
            namespace: Docker image namespace (default: "ee-bench")
            **kwargs: Additional parameters (ignored, for compatibility)
        """
        super().__init__(tool_name="maven", namespace=namespace, **kwargs)

    @property
    def build_system(self):
        """Return the BuildSystem enum for Maven."""
        return BuildSystem.MAVEN

    @property
    def tool_version_param_name(self) -> str:
        """Return the parameter name for Maven version override."""
        return "maven_version"

    def get_version_map(self) -> dict[str, str]:
        """Return version mapping dictionary for Maven.

        Returns:
            Dict mapping JDK version to Maven version
        """
        return MAVEN_VERSION_MAP

    def get_default_version(self) -> str:
        """Return default Maven version.

        Returns:
            Default Maven version string
        """
        return DEFAULT_MAVEN_VERSION

    def generate_dockerfile(
        self,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        **kwargs,
    ) -> str:
        """Generate Dockerfile to add Maven.

        Args:
            env_config: Environment configuration
            config: Dataset configuration
            **kwargs: Additional parameters (base_image, maven_version required)

        Returns:
            Dockerfile content as string
        """
        base_image = kwargs.get("base_image", "ubuntu:22.04")
        maven_version = kwargs.get("maven_version", DEFAULT_MAVEN_VERSION)
        maven_major = maven_version.split(".")[0]

        return f"""FROM {base_image}

# Install Maven {maven_version}
RUN wget https://archive.apache.org/dist/maven/maven-{maven_major}/{maven_version}/binaries/apache-maven-{maven_version}-bin.tar.gz \\
    && tar xzf apache-maven-{maven_version}-bin.tar.gz -C /opt \\
    && ln -s /opt/apache-maven-{maven_version} /opt/maven \\
    && rm apache-maven-{maven_version}-bin.tar.gz

ENV PATH="/opt/maven/bin:${{PATH}}"
ENV MAVEN_HOME="/opt/maven"
"""
