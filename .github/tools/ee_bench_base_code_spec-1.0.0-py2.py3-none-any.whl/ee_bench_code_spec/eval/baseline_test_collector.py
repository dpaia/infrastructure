"""Baseline test collector evaluator for regression detection.

This module provides an evaluator that collects baseline test results
before applying predictions, storing them in shared context for later
regression analysis.
"""

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Optional

from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig, EvalSpec
from ee_bench_core.core.eval.evaluator import (
    EvaluationContext,
    Evaluator,
    EvaluatorResult,
    EvaluatorStatus,
)

if TYPE_CHECKING:
    from ee_bench_core.adapters.sandbox_base import Sandbox

logger = logging.getLogger(__name__)


class BaselineTestCollector(Evaluator):
    """Collects baseline test results for regression detection.

    This evaluator runs ALL tests (*) before predictions are applied and
    stores the results in shared_context for later comparison. This enables
    detection of regressions (tests that passed before but fail after prediction).

    The baseline results are stored in shared_context.shared_data["baseline_tests"]
    as a TestResult object containing individual test statuses.

    REQUIRES dependency injection: test_runner MUST be injected via constructor.
    Use DI container to create evaluators with proper dependencies injected.
    """

    def __init__(
        self,
        name: str = "baseline_test_collection",
        description: Optional[str] = None,
        test_runner=None,
        timeout: Optional[int] = None,
        dependencies=None,
        is_terminal: bool = False,
    ):
        """Initialize baseline test collector.

        Args:
            name: Unique name for this evaluator
            description: Human-readable description
            test_runner: REQUIRED TestRunner instance (MUST be injected via DI)
            timeout: Optional custom timeout in seconds
            dependencies: Optional dependency specification
            is_terminal: Whether failure should stop the pipeline (default: False)
        """
        self._name = name
        self._description = (
            description or "Collect baseline test results for regression detection"
        )
        self._test_runner = test_runner
        self._timeout = timeout
        self._dependencies = dependencies
        self._is_terminal = is_terminal

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return self._description

    @property
    def dependencies(self):
        return self._dependencies

    @property
    def is_terminal(self) -> bool:
        return self._is_terminal

    @property
    def timeout(self) -> Optional[int]:
        return self._timeout

    @property
    def retry_count(self) -> int:
        return 1

    @property
    def max_score(self) -> float:
        """This evaluator does not award scores."""
        return 0.0

    def evaluate(
        self,
        spec: EvalSpec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        run_id: str,
        shared_context: EvaluationContext,
        sandbox: "Sandbox",
        **kwargs,
    ) -> EvaluatorResult:
        """Collect baseline test results.

        Args:
            spec: Evaluation spec
            env_config: Environment configuration
            config: Dataset configuration
            run_id: Evaluation run ID
            shared_context: Shared context for storing baseline results
            sandbox: Sandbox instance
            **kwargs: Additional parameters

        Returns:
            EvaluatorResult with baseline collection status
        """
        # test_runner MUST be injected via constructor (DI pattern)
        if not self._test_runner:
            return EvaluatorResult(
                evaluator_name=self.name,
                status=EvaluatorStatus.ERROR,
                message="test_runner must be injected via constructor",
                error=(
                    "BaselineTestCollector requires test_runner to be provided at initialization. "
                    "Use DI container to create evaluators with injected dependencies."
                ),
            )

        test_runner = self._test_runner

        try:
            # Get project path from env_config
            project_path = "/workspace/task_project"
            if hasattr(env_config, "project_path"):
                project_path = str(env_config.project_path)
            elif hasattr(env_config, "workspace_dir") and env_config.workspace_dir:
                project_path = str(Path(env_config.workspace_dir) / "task_project")

            # Run ALL tests (*)
            logger.info(f"Collecting baseline test results in {project_path}")
            test_args = config.get("test_args") if hasattr(config, "get") else None
            test_result = test_runner.run_tests(
                sandbox=sandbox,
                test_classes=["*"],  # Run all tests
                project_dir=project_path,
                test_args=test_args,
                env_config=env_config,
            )

            # Store baseline results in shared context
            shared_context.shared_data["baseline_tests"] = test_result

            logger.info(
                f"Baseline collection complete: "
                f"{test_result.passed_tests} passed, "
                f"{test_result.failed_tests} failed, "
                f"{test_result.total_tests} total"
            )

            return EvaluatorResult(
                evaluator_name=self.name,
                status=EvaluatorStatus.SUCCESS,
                message=f"Baseline collected: {test_result.passed_tests} passed, {test_result.failed_tests} failed",
                data={
                    "baseline_total": test_result.total_tests,
                    "baseline_passed": test_result.passed_tests,
                    "baseline_failed": test_result.failed_tests,
                    "baseline_skipped": test_result.skipped_tests,
                    "baseline_tests": {
                        name: result.to_dict()
                        for name, result in test_result.tests.items()
                    },
                },
            )

        except Exception as e:
            logger.error(f"Error collecting baseline tests: {e}", exc_info=True)
            return EvaluatorResult(
                evaluator_name=self.name,
                status=EvaluatorStatus.ERROR,
                message="Exception while collecting baseline tests",
                error=str(e),
            )
