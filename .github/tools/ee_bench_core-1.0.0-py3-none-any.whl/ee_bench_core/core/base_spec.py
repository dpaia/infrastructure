"""Base implementation of EvalSpec with common orchestration methods.

This module provides BaseEvalSpec which implements high-level orchestration
methods (prepare_environment, run_evaluation) that work across all specification
types by delegating to the abstract getter methods.

Includes support for dependency injection containers for managing component
lifecycles and dependencies.
"""

import logging
import multiprocessing
import os
from abc import abstractmethod
from pathlib import Path
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from .abc_types import (
    DatasetManager,
    EnvironmentManager,
    EnvironmentTools,
    EvalSpec,
    EvaluationRunner,
    ReportManager,
)
from .eval import Evaluator, BaseEvaluationRunner
from .eval.environment_configurer_registry import get_global_registry as get_configurer_registry
from .models import (
    DatasetConfig,
    EnvironmentConfig,
    EnvironmentPreparationResult,
)
from .utils.concurrency import run_threadpool, run_sequential
from .report_manager import ReportManager as DefaultReportManager

if TYPE_CHECKING:
    from dependency_injector.containers import DeclarativeContainer

logger = logging.getLogger(__name__)


class BaseEvalSpec(EvalSpec):
    """Base evaluation specification with common orchestration logic.

    This class provides default implementations for high-level orchestration
    methods (prepare_environment, run_evaluation) that work across all
    specification types. Subclasses must implement the abstract getter methods
    to provide spec-specific components.

    The orchestration methods handle:
    - Loading datasets
    - Iterating over instance IDs
    - Setting up environments (parallel or sequential)
    - Running evaluations (parallel or sequential)
    - Collecting results via ReportManager

    Dependency Injection Support:
    - Subclasses can optionally provide ApplicationContainer and SpecContainer
    - Provides common DI patterns (configure_for_evaluation, container access)
    - Backward compatible (DI is optional)
    """

    def __init__(self, report_manager: Optional[ReportManager] = None):
        """Initialize base specification.

        Args:
            report_manager: Optional report manager for tracking evaluation results

        Raises:
            NotImplementedError: If subclass doesn't implement initialize_containers()
                or doesn't create self.container
        """
        self.report_manager = report_manager

        # DI container attributes
        self.app_container: Optional["DeclarativeContainer"] = None
        self.container: Optional["DeclarativeContainer"] = None
        self._configured = False

        # Call subclass initialization (REQUIRED)
        self.initialize_containers()

        # Verify container was created
        if not self.has_container():
            raise NotImplementedError(
                f"{self.__class__.__name__} must implement initialize_containers() "
                f"and create self.container. See JvmSweEvalSpec for example:\n\n"
                f"def initialize_containers(self):\n"
                f"    self.app_container = ApplicationContainer.create_with_defaults()\n"
                f"    self.container = MySpecContainer()\n"
                f"    self.container.app.override(self.app_container)"
            )

    # Required abstract properties from EvalSpec

    @property
    @abstractmethod
    def name(self) -> str:
        """Get the canonical name of this specification."""
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        """Get a human-readable description of this specification."""
        pass

    # Abstract getter methods for spec-specific components
    # Subclasses must implement these to provide concrete implementations

    @abstractmethod
    def get_dataset_manager(self, **kwargs) -> DatasetManager:
        """Create a dataset manager instance.

        Args:
            **kwargs: Spec-specific initialization parameters

        Returns:
            DatasetManager implementation
        """
        pass

    @abstractmethod
    def get_environment_manager(
        self, config: DatasetConfig, **kwargs
    ) -> EnvironmentManager:
        """Create an environment manager instance.

        Args:
            config: Dataset configuration for the task
            **kwargs: Spec-specific initialization parameters

        Returns:
            EnvironmentManager implementation
        """
        pass

    @abstractmethod
    def get_evaluators(
        self,
        config: DatasetConfig,
        env_config: EnvironmentConfig,
        enable_plugins: bool = True,
        **kwargs,
    ) -> List[Evaluator]:
        """Get list of evaluators for this specification.

        Args:
            config: Dataset configuration for the task
            env_config: Environment configuration
            enable_plugins: If True, auto-discover and load plugin evaluators (default: True)
            **kwargs: Spec-specific initialization parameters

        Returns:
            List of Evaluator instances to run in pipeline

        Note:
            Subclasses should call load_plugin_evaluators(enable_plugins) to automatically
            load applicable plugin evaluators for this spec.
        """
        pass

    def load_plugin_evaluators(self, enable_plugins: bool = True) -> List[Evaluator]:
        """Load plugin evaluators applicable to this spec.

        This is a helper method that subclasses can call from get_evaluators()
        to automatically discover and load plugin evaluators registered for this spec.

        Args:
            enable_plugins: If True, discover and load plugins; if False, return empty list

        Returns:
            List of plugin evaluator instances applicable to this spec

        Example:
            def get_evaluators(self, config, env_config, enable_plugins=True, **kwargs):
                # Get standard evaluators
                evaluators = self.container.evaluators()

                # Load plugins
                plugin_evaluators = self.load_plugin_evaluators(enable_plugins)
                evaluators.extend(plugin_evaluators)

                return evaluators
        """
        if not enable_plugins:
            return []

        from .eval import get_global_registry

        registry = get_global_registry()

        # Discover plugins if not already done
        registry.discover_plugins()

        # Get plugin evaluators for this spec
        plugin_evaluators = []
        for metadata in registry.list_for_spec(self.name):
            try:
                # Create evaluator instance (no-arg constructor)
                evaluator = metadata.factory()
                plugin_evaluators.append(evaluator)
                logger.info(
                    f"Loaded plugin evaluator '{metadata.name}' for spec '{self.name}'"
                )
            except Exception as e:
                logger.warning(
                    f"Failed to instantiate plugin evaluator '{metadata.name}' for spec '{self.name}': {e}",
                    exc_info=True,
                )

        if plugin_evaluators:
            logger.info(
                f"Loaded {len(plugin_evaluators)} plugin evaluator(s) for spec '{self.name}'"
            )

        return plugin_evaluators

    def get_evaluation_runner(
        self, config: DatasetConfig, **kwargs
    ) -> EvaluationRunner:
        """Create an evaluation runner instance.

        Default implementation returns BaseEvaluationRunner using evaluators
        from get_evaluators(). Subclasses can override for custom behavior.

        Args:
            config: Dataset configuration for the task
            **kwargs: Spec-specific initialization parameters including:
                     - env_config: Environment configuration (REQUIRED)
                     - report_manager: Report manager instance
                     - max_workers: Maximum parallel workers
                     - timeout: Default timeout

        Returns:
            EvaluationRunner implementation

        Raises:
            ValueError: If env_config not provided in kwargs
        """
        # Extract env_config
        env_config = kwargs.pop("env_config", None)
        if not env_config:
            raise ValueError(
                "env_config is required in kwargs for get_evaluation_runner(). "
                "Pass env_config=your_env_config in kwargs."
            )

        # Get evaluators from spec (env_config removed from kwargs to avoid duplicate)
        evaluators = self.get_evaluators(config, env_config, **kwargs)

        # Extract runner parameters
        max_workers = kwargs.get("max_workers", 1)
        default_timeout = kwargs.get("timeout", 1800)
        report_manager = kwargs.get("report_manager", self.report_manager)

        # Create and return BaseEvaluationRunner
        return BaseEvaluationRunner(
            spec=self,
            evaluators=evaluators,
            max_workers=max_workers,
            default_timeout=default_timeout,
            report_manager=report_manager,
        )

    # Optional DI container methods
    # Subclasses can override these to provide container-based dependency management

    @abstractmethod
    def initialize_containers(self) -> None:
        """Initialize DI containers (REQUIRED).

        Subclasses MUST override this to initialize app_container and container.
        This method is called automatically during __init__.

        Example:
            def initialize_containers(self):
                from di.application_container import ApplicationContainer
                from specs.my_spec.my_container import MySpecContainer

                self.app_container = ApplicationContainer.create_with_defaults()
                self.container = MySpecContainer()
                self.container.app.override(self.app_container)

        Raises:
            NotImplementedError: If subclass doesn't implement this method
        """
        pass

    @abstractmethod
    def configure_for_evaluation(
        self, config: DatasetConfig, env_config: EnvironmentConfig, **kwargs
    ) -> None:
        """Configure DI container for specific evaluation instance (REQUIRED).

        This method configures the spec-level DI container with runtime parameters
        based on the task configuration and environment. MUST set self._configured = True.

        Subclasses MUST override this to configure their container with
        runtime parameters (execution_mode, build_system, predictions_mode, etc.).

        Args:
            config: Dataset configuration for the task
            env_config: Environment configuration
            **kwargs: Additional runtime parameters

        Example:
            def configure_for_evaluation(self, config, env_config, **kwargs):
                execution_mode = "docker" if env_config.container_id else "local"
                build_system = "maven" if config.is_maven else "gradle"

                self.container.config.from_dict({
                    "execution_mode": execution_mode,
                    "build_system": build_system,
                    # ... other config
                })

                self._configured = True

        Raises:
            NotImplementedError: If subclass doesn't implement this method
        """
        pass

    def has_container(self) -> bool:
        """Check if spec uses DI containers.

        Returns:
            True if container is initialized, False otherwise
        """
        return self.container is not None

    @abstractmethod
    def get_environment_tools(
        self, config: DatasetConfig, **kwargs
    ) -> EnvironmentTools:
        """Create environment tools instance.

        Args:
            config: Dataset configuration for the task
            **kwargs: Spec-specific initialization parameters

        Returns:
            EnvironmentTools implementation
        """
        pass

    def get_report_manager(
        self,
        dataset_name: str,
        run_id: str,
        report_dir: Optional[Path] = None,
        rewrite_reports: bool = False,
        report_name: Optional[str] = None,
    ) -> ReportManager:
        """Create a report manager for tracking evaluation results.

        Args:
            dataset_name: Name of the dataset being evaluated
            run_id: Unique identifier for the evaluation run
            report_dir: Directory where reports are stored (default: ./reports)
            rewrite_reports: If True, delete existing report file before starting
            report_name: Optional custom name for the report file (default: run_id.json)

        Returns:
            ReportManager instance configured for this evaluation run
        """
        # Use default report directory if not specified
        if report_dir is None:
            report_dir = Path.cwd() / "reports"

        # Create report manager
        report_manager = DefaultReportManager(
            report_dir=report_dir, spec_name=self.name
        )

        # If rewrite_reports is True, delete existing report file
        if rewrite_reports:
            # Use custom report name if provided, otherwise use run_id
            filename = f"{report_name}.json" if report_name else f"{run_id}.json"
            report_path = report_dir / filename
            if report_path.exists():
                logger.info(f"Rewriting report: deleting existing file {report_path}")
                report_path.unlink()

        return report_manager

    def _configure_environment(
        self, config: DatasetConfig, env_config: EnvironmentConfig, **kwargs
    ) -> EnvironmentConfig:
        """Configure environment using registered configurers.

        This method:
        1. Gets spec name from the evaluation spec
        2. Discovers configurers applicable to this spec
        3. Merges configuration from environment variables and kwargs
        4. Executes each configurer's configure() method
        5. Returns potentially modified environment configuration

        Args:
            config: Dataset configuration
            env_config: Environment configuration
            **kwargs: Configuration parameters passed from CLI/config

        Returns:
            EnvironmentConfig: Potentially modified environment configuration.
            Configurers can create enhanced images or modify the configuration.
        """
        # Get spec name for filtering configurers
        spec_name = getattr(self, "name", None)
        if not spec_name:
            logger.debug("Spec has no name, skipping environment configuration")
            return env_config

        # Get configurer registry and discover plugins
        registry = get_configurer_registry()
        registry.discover_plugins()

        # Get configurers for this spec
        configurers_metadata = registry.list_for_spec(spec_name)
        if not configurers_metadata:
            logger.debug(f"No environment configurers found for spec '{spec_name}'")
            return env_config

        logger.info(
            f"Found {len(configurers_metadata)} environment configurer(s) for spec '{spec_name}'"
        )

        # Merge configuration from environment variables and kwargs
        # Environment variables take precedence over kwargs for security
        config_params = dict(kwargs)  # Start with kwargs

        # Extract configuration from environment variables
        # Format: EE_BENCH_<CONFIGURER>_<KEY> (e.g., EE_BENCH_SNYK_TOKEN)
        for key, value in os.environ.items():
            if key.startswith("EE_BENCH_"):
                # Remove EE_BENCH_ prefix and convert to lowercase
                config_key = key[9:].lower()
                config_params[config_key] = value
                logger.debug(f"Loaded config from environment: {config_key}")

        # Execute each configurer and allow them to modify env_config
        current_env_config = env_config
        for metadata in configurers_metadata:
            configurer_name = metadata.name
            logger.info(f"Running environment configurer: {configurer_name}")

            try:
                # Create configurer instance
                configurer = metadata.factory()

                # Check if configurer should run
                should_configure, reason = configurer.should_configure(
                    self, current_env_config, config, **config_params
                )

                if not should_configure:
                    logger.info(
                        f"Skipping configurer '{configurer_name}': {reason or 'no reason given'}"
                    )
                    continue

                # Configure environment and get potentially modified config
                new_env_config = configurer.configure(self, current_env_config, config, **config_params)

                # Update current config for next configurer
                if new_env_config != current_env_config:
                    logger.info(f"Configurer '{configurer_name}' modified environment configuration")
                    current_env_config = new_env_config

                logger.info(f"Environment configurer '{configurer_name}' completed successfully")

            except Exception as e:
                logger.error(
                    f"Environment configurer '{configurer_name}' failed: {e}",
                    exc_info=True,
                )
                # Continue with other configurers even if one fails
                # This allows partial configuration and doesn't block evaluation

        return current_env_config

    # High-level orchestration methods

    def prepare_environment(
        self, dataset_name: str, instance_ids: List[str], **kwargs
    ) -> EnvironmentPreparationResult:
        """Prepare environments for multiple task instances.

        This method orchestrates environment preparation across multiple tasks:
        1. Load dataset
        2. Get dataset instances
        3. Create environment manager
        4. Setup environment for each instance (parallel or sequential)

        Args:
            dataset_name: Name of the dataset
            instance_ids: List of instance IDs to prepare
            **kwargs: Additional parameters
                     - max_workers: Number of parallel workers (-1 for sequential)
                     - Other spec-specific parameters

        Returns:
            EnvironmentPreparationResult containing:
            - successful_ids: Set of successfully prepared instance IDs
            - failed_ids: Set of failed instance IDs
            - environments: Dict mapping instance_id to EnvironmentConfig
            - errors: Dict mapping failed instance_id to error message
        """
        max_workers = kwargs.get("max_workers", 1)
        logger.info(
            f"Preparing environments for {len(instance_ids)} instances from {dataset_name} "
            f"(max_workers={max_workers})"
        )

        # Get dataset manager (only pass working_dir, not orchestration params)
        working_dir = kwargs.get("working_dir", ".")
        dataset_manager = self.get_dataset_manager(working_dir=working_dir)

        # Storage for results
        environments: Dict[str, EnvironmentConfig] = {}
        errors: Dict[str, str] = {}

        # Create preparation function that returns EnvironmentConfig
        def prepare_single_environment(instance_id: str) -> EnvironmentConfig:
            """Prepare environment for a single instance.

            Returns:
                EnvironmentConfig for the prepared environment

            Raises:
                Exception: On any failure (captured by orchestration layer)
            """
            logger.info(f"Preparing environment for {instance_id}")

            # Get dataset config (include dataset_name for path resolution)
            config = dataset_manager.get_dataset_instance(
                instance_id=instance_id, dataset_name=dataset_name, **kwargs
            )

            # Get environment manager for this config
            env_manager = self.get_environment_manager(config, **kwargs)

            # Setup environment
            env_config = env_manager.setup_environment(config=config, **kwargs)

            logger.info(
                f"Environment prepared for {instance_id}: {env_config.image_name}"
            )
            return env_config

        # Prepare payloads (each instance_id as a tuple)
        payloads = [(instance_id,) for instance_id in instance_ids]

        # Run preparation (parallel or sequential)
        if max_workers == -1:
            succeeded, failed = run_sequential(prepare_single_environment, payloads)
        else:
            succeeded, failed = run_threadpool(
                prepare_single_environment, payloads, max_workers
            )

        # Process successful results
        for payload, result in succeeded:
            instance_id = payload[0]
            environments[instance_id] = result

        # Process failures
        for payload, error in failed:
            instance_id = payload[0]
            error_msg = str(error)
            errors[instance_id] = error_msg
            logger.error(
                f"Failed to prepare environment for {instance_id}: {error_msg}"
            )

        # Create result object
        result = EnvironmentPreparationResult(
            successful_ids=set(environments.keys()),
            failed_ids=set(errors.keys()),
            environments=environments,
            errors=errors,
            total_count=len(instance_ids),
        )

        # Log summary
        logger.info(
            f"Environment preparation complete: {result.success_count}/{result.total_count} succeeded, "
            f"{result.failure_count} failed (success rate: {result.success_rate:.1f}%)"
        )

        if result.failure_count > 0:
            logger.warning(f"Failed instance IDs: {list(result.failed_ids)}")

        return result

    def run_evaluation(
        self, dataset_name: str, instance_ids: List[str], run_id: str, **kwargs
    ) -> Dict[str, Any]:
        """Run evaluations for multiple task instances.

        This method orchestrates evaluation across multiple tasks:
        1. Create report manager (if not provided)
        2. Load dataset
        3. Get dataset instances
        4. Create evaluation runner
        5. Run evaluation for each instance (parallel or sequential)
        6. Report results to ReportManager

        Args:
            dataset_name: Name of the dataset
            instance_ids: List of instance IDs to evaluate
            run_id: Unique identifier for this evaluation run
            **kwargs: Additional parameters
                     - max_workers: Number of parallel workers (-1 for sequential)
                     - timeout: Evaluation timeout in seconds
                     - report_dir: Directory where reports are stored
                     - rewrite_reports: If True, delete existing report before starting
                     - report_name: Custom name for the report file
                     - Other spec-specific parameters

        Returns:
            Report dictionary from ReportManager containing:
            - results: Dict mapping instance_id to result details
            - completed: Boolean indicating if run is complete
            - total_tasks: Total number of tasks
            - Other report metadata

        Raises:
            Exception: If any evaluation fails
        """
        max_workers = kwargs.get("max_workers", 1)
        logger.info(
            f"Running evaluation for {len(instance_ids)} instances from {dataset_name} "
            f"(run_id={run_id}, max_workers={max_workers})"
        )

        # Get or create report manager
        # First check if report_manager was provided in kwargs or constructor
        report_manager = self.report_manager
        if report_manager is None:
            # Parse report parameters from kwargs
            report_dir = kwargs.get("report_dir")
            if report_dir is not None:
                report_dir = Path(report_dir)
            rewrite_reports = kwargs.get("rewrite_reports", False)
            report_name = kwargs.get("report_name")

            # Create report manager using get_report_manager
            report_manager = self.get_report_manager(
                dataset_name=dataset_name,
                run_id=run_id,
                report_dir=report_dir,
                rewrite_reports=rewrite_reports,
                report_name=report_name,
            )
            logger.debug(f"Created report manager for run {run_id}")

        # Get dataset manager (only pass working_dir, not orchestration params)
        working_dir = kwargs.get("working_dir", ".")
        dataset_manager = self.get_dataset_manager(working_dir=working_dir)

        # Create evaluation function
        def evaluate_single_instance(instance_id: str) -> None:
            """Evaluate a single instance."""
            logger.info(f"Running evaluation for {instance_id}")

            try:
                # Get dataset config (include dataset_name for path resolution)
                config = dataset_manager.get_dataset_instance(
                    instance_id=instance_id, dataset_name=dataset_name, **kwargs
                )

                # Get environment manager to get env config
                env_manager = self.get_environment_manager(config, **kwargs)

                # Setup environment (or get existing)
                env_config = env_manager.setup_environment(config=config, **kwargs)

                # Configure environment using environment configurers
                # This may return a modified env_config (e.g., with enhanced Docker image)
                env_config = self._configure_environment(config, env_config, **kwargs)

                # Get evaluation runner for this config
                # Pass report_manager and env_config
                eval_kwargs = dict(kwargs)
                if report_manager:
                    eval_kwargs["report_manager"] = report_manager
                eval_kwargs["env_config"] = env_config

                eval_runner = self.get_evaluation_runner(config, **eval_kwargs)

                # Run evaluation (container lifecycle managed by evaluation runner)
                result = eval_runner.run_evaluation(
                    config=config, env_config=env_config, run_id=run_id, **kwargs
                )

                # Report result to ReportManager if available
                if report_manager:
                    report_manager.set_result(instance_id, result, run_id)

                logger.info(f"Evaluation completed for {instance_id}: {result.result}")

            except Exception as e:
                # Handle environment setup or evaluation errors
                logger.error(f"Failed to evaluate {instance_id}: {e}", exc_info=True)

                # Create an error result
                from ee_bench_core.core.eval import PipelineEvaluationResult
                from ee_bench_core.core.eval.base_evaluation_runner import PipelineEvaluationResultAdapter
                from ee_bench_core.core.models import ResultStatus

                # Create minimal config if we don't have one yet
                if 'config' not in locals():
                    try:
                        config = dataset_manager.get_dataset_instance(
                            instance_id=instance_id, dataset_name=dataset_name, **kwargs
                        )
                    except Exception:
                        # If we can't even get config, create a minimal mock
                        from ee_bench_core.core.models import DatasetConfig
                        config = type('MinimalConfig', (), {'instance_id': instance_id})()

                # Create error result
                error_result = PipelineEvaluationResult(
                    instance_id=instance_id,
                    result=ResultStatus.FAILED,
                    successful=False,
                    duration=0.0,
                    message=f"Environment setup or evaluation failed: {str(e)}",
                    evaluations={},
                    error=str(e),
                )

                # Wrap as EvaluationResult
                result = PipelineEvaluationResultAdapter(error_result, config)

                # Report error result to ReportManager if available
                if report_manager:
                    report_manager.set_result(instance_id, result, run_id)

                logger.info(f"Evaluation failed for {instance_id}: {result.result}")

                # Re-raise to mark as failed in concurrent execution
                raise

        # Prepare payloads (each instance_id as a tuple)
        payloads = [(instance_id,) for instance_id in instance_ids]

        # Run evaluation (parallel or sequential)
        if max_workers == -1:
            succeeded, failed = run_sequential(evaluate_single_instance, payloads)
        else:
            succeeded, failed = run_threadpool(
                evaluate_single_instance, payloads, max_workers
            )

        # Mark evaluation run as completed (even if there were failures)
        if report_manager:
            report_manager.mark_completed(run_id)

        if failed:
            # failed is now list of (payload, exception) tuples
            failed_ids = [payload[0] for payload, _ in failed]
            logger.error(f"Failed to evaluate {len(failed)} instances: {failed_ids}")

        logger.info(f"Successfully completed {len(succeeded)} evaluations")

        # Return the report from report manager
        if report_manager:
            report = report_manager.get_report(run_id)
            logger.debug(f"Returning report for run_id={run_id}")
            return report
        else:
            # If no report manager, return minimal summary
            return {
                "run_id": run_id,
                "completed": True,
                "total_tasks": len(instance_ids),
                "message": "Evaluation completed without report manager",
            }

    def get_base_cli_parameters(self, command: str) -> List[Dict[str, Any]]:
        """Get base CLI parameters common to all specs.

        Args:
            command: Command name (e.g., "prepare_environment", "run_evaluation")

        Returns:
            List of parameter definitions for Click options
        """
        # Calculate default max_workers as 75% of CPU cores
        cpu_count = multiprocessing.cpu_count()
        default_max_workers = max(1, int(cpu_count * 0.75))

        # Base parameters common to all commands
        base_params = [
            {
                "names": ["--max-workers"],
                "type": int,
                "default": default_max_workers,
                "help": f"Maximum number of parallel workers (default: {default_max_workers}, 75% of {cpu_count} cores; use -1 for sequential)",
            }
        ]

        # Add report parameters for run_evaluation command
        if command == "run_evaluation":
            base_params.extend(
                [
                    {
                        "names": ["--report-dir"],
                        "type": str,
                        "default": None,
                        "help": "Directory where evaluation reports are stored (default: ./reports)",
                    },
                    {
                        "names": ["--rewrite-reports"],
                        "is_flag": True,
                        "default": False,
                        "help": "Delete existing report file before starting evaluation",
                    },
                    {
                        "names": ["--report-name"],
                        "type": str,
                        "default": None,
                        "help": "Custom name for the report file (default: {run_id}.json)",
                    },
                ]
            )

        return base_params
