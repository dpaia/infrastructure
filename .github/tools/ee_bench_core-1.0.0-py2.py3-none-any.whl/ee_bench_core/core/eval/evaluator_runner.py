"""Orchestrator for evaluator pipeline execution.

This module provides the EvaluationRunner which coordinates the execution
of multiple evaluators with dependency management, parallel execution,
and timeout handling.
"""

import logging
import time
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeoutError
from typing import TYPE_CHECKING, Dict, List, Optional

from dataclasses import dataclass

from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig
from .evaluator import EvaluationContext, Evaluator, EvaluatorResult, EvaluatorStatus
from ..utils.dependency_resolver import DependencyResolver
from ee_bench_core.core.models import ResultStatus

if TYPE_CHECKING:
    from ee_bench_core.adapters.sandbox_base import Sandbox
    from ee_bench_core.core.base_spec import BaseEvalSpec


@dataclass
class PipelineEvaluationResult:
    """Result of running an evaluator pipeline.

    This is a concrete implementation separate from the abstract EvaluationResult
    used by specs.
    """

    instance_id: str
    result: ResultStatus
    successful: bool
    duration: float
    message: str
    evaluations: dict
    error: str = None


logger = logging.getLogger(__name__)


class EvaluationRunner:
    """Orchestrates execution of evaluator pipelines.

    The runner:
    1. Validates evaluator dependencies using DependencyResolver
    2. Computes execution order (batches that can run in parallel)
    3. Executes evaluators respecting dependencies and timeouts
    4. Manages shared evaluation context
    5. Handles terminal evaluator failures
    """

    def __init__(
        self,
        evaluators: List[Evaluator],
        max_workers: int = 1,
        default_timeout: int = 1800,
    ):
        """Initialize evaluation runner.

        Args:
            evaluators: List of evaluators to execute
            max_workers: Maximum number of parallel workers for async evaluators
            default_timeout: Default timeout in seconds for evaluator execution
        """
        self.evaluators = evaluators
        self.max_workers = max_workers
        self.default_timeout = default_timeout

        # Validate dependencies and compute execution order
        resolver = DependencyResolver(evaluators, skip_unresolved=True)
        resolver.validate()
        self.execution_batches = resolver.get_execution_order()

        logger.debug(
            f"Initialized EvaluationRunner with {len(evaluators)} evaluators "
            f"in {len(self.execution_batches)} batches"
        )

    def run_evaluation(self, spec: "BaseEvalSpec", sandbox: "Sandbox", config: DatasetConfig, run_id: str,
                       timeout: Optional[int] = None, **kwargs) -> PipelineEvaluationResult:
        """Execute evaluation pipeline.

        Args:
            spec: Evaluation specification providing dependencies and configuration
            config: Dataset configuration for the task
            env_config: Environment configuration
            run_id: Unique identifier for this evaluation run
            sandbox: Sandbox instance for executing commands in the environment
            timeout: Optional timeout override (uses default_timeout if not provided)
            **kwargs: Additional parameters passed to evaluators

        Returns:
            PipelineEvaluationResult with overall evaluation outcome
        """
        # Create shared context for all evaluators
        shared_context = EvaluationContext()
        env_config = sandbox.env_config
        start_time = time.time()
        effective_timeout = timeout or self.default_timeout

        logger.debug(
            f"Starting evaluation pipeline for {config.instance_id} "
            f"(run_id={run_id}, timeout={effective_timeout}s)"
        )

        try:
            # Execute batches in order
            for batch_idx, batch in enumerate(self.execution_batches):
                logger.debug(
                    f"Executing batch {batch_idx + 1}/{len(self.execution_batches)} "
                    f"with {len(batch)} evaluators"
                )

                batch_results = self._execute_batch(
                    batch,
                    spec,
                    env_config,
                    config,
                    run_id,
                    shared_context,
                    sandbox,
                    timeout=effective_timeout,
                    **kwargs,
                )

                # Update shared context with results
                for result in batch_results.values():
                    shared_context.set_result(result)

                # Check for terminal failures
                terminal_failure = self._check_terminal_failures(batch, batch_results)
                if terminal_failure:
                    logger.warning(
                        f"Terminal evaluator '{terminal_failure.evaluator_name}' failed, Reason: {terminal_failure.message},"
                        "stopping pipeline"
                    )
                    return self._create_failure_result(
                        config,
                        shared_context,
                        start_time,
                        terminal_failure.message,
                    )

            # All evaluators completed
            duration = time.time() - start_time
            logger.debug(
                f"Evaluation pipeline completed successfully in {duration:.2f}s "
                f"({len(shared_context.results)} evaluators)"
            )

            return self._create_success_result(config, shared_context, start_time)

        except Exception as e:
            duration = time.time() - start_time
            logger.error(
                f"Evaluation pipeline failed after {duration:.2f}s: {e}", exc_info=logger.isEnabledFor(logging.DEBUG)
            )
            return self._create_error_result(config, shared_context, start_time, str(e))

    def _execute_batch(
        self,
        batch: List[Evaluator],
        spec: "BaseEvalSpec",
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        run_id: str,
        shared_context: EvaluationContext,
        sandbox: "Sandbox",
        timeout: int,
        **kwargs,
    ) -> Dict[str, EvaluatorResult]:
        """Execute a batch of evaluators (potentially in parallel).

        Args:
            batch: List of evaluators to execute in parallel
            spec: Evaluation specification
            env_config: Environment configuration
            config: Dataset configuration
            run_id: Evaluation run ID
            shared_context: Shared context
            sandbox: Sandbox instance for executing commands
            timeout: Timeout for each evaluator
            **kwargs: Additional parameters

        Returns:
            Dict mapping evaluator names to results
        """
        # Filter evaluators that can be skipped
        evaluators_to_run: List[Evaluator] = []
        results: Dict[str, EvaluatorResult] = {}

        for evaluator in batch:
            should_skip, reason = evaluator.can_skip(
                spec, env_config, config, run_id, shared_context
            )

            if should_skip:
                logger.debug(
                    f"Skipping evaluator '{evaluator.name}': {reason or 'no reason given'}"
                )
                results[evaluator.name] = EvaluatorResult(
                    evaluator_name=evaluator.name,
                    status=EvaluatorStatus.SKIPPED,
                    message=reason or "Evaluator was skipped",
                )
            else:
                evaluators_to_run.append(evaluator)

        if not evaluators_to_run:
            return results

        # Execute evaluators (parallel if max_workers > 1 and batch size > 1)
        if len(evaluators_to_run) == 1 or self.max_workers == 1:
            # Sequential execution
            for evaluator in evaluators_to_run:
                result = self._execute_evaluator(
                    evaluator,
                    spec,
                    env_config,
                    config,
                    run_id,
                    shared_context,
                    sandbox,
                    timeout,
                    **kwargs,
                )
                results[evaluator.name] = result
        else:
            # Parallel execution
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                futures = {
                    executor.submit(
                        self._execute_evaluator,
                        evaluator,
                        spec,
                        env_config,
                        config,
                        run_id,
                        shared_context,
                        sandbox,
                        timeout,
                        **kwargs,
                    ): evaluator
                    for evaluator in evaluators_to_run
                }

                for future in futures:
                    evaluator = futures[future]
                    try:
                        result = future.result(timeout=timeout)
                        results[evaluator.name] = result
                    except Exception as e:
                        logger.error(
                            f"Evaluator '{evaluator.name}' raised exception: {e}",
                            exc_info=logger.isEnabledFor(logging.DEBUG),
                        )
                        results[evaluator.name] = EvaluatorResult(
                            evaluator_name=evaluator.name,
                            status=EvaluatorStatus.ERROR,
                            message="Evaluator raised exception",
                            error=str(e),
                        )

        return results

    def _execute_evaluator(
        self,
        evaluator: Evaluator,
        spec: "BaseEvalSpec",
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        run_id: str,
        shared_context: EvaluationContext,
        sandbox: "Sandbox",
        timeout: int,
        **kwargs,
    ) -> EvaluatorResult:
        """Execute a single evaluator with timeout handling.

        Args:
            evaluator: Evaluator to execute
            spec: Evaluation specification
            env_config: Environment configuration
            config: Dataset configuration
            run_id: Evaluation run ID
            shared_context: Shared context
            sandbox: Sandbox instance for executing commands
            timeout: Default timeout in seconds (overridden by evaluator.timeout if set)
            **kwargs: Additional parameters

        Returns:
            EvaluatorResult
        """
        # Set command context for logging
        from ee_bench_core.core.utils.logging import set_command_context

        instance_id = getattr(config, "instance_id", "unknown")
        set_command_context(f"{evaluator.name} [{instance_id}]")

        # Use evaluator-specific timeout if available, otherwise use default
        effective_timeout = (
            evaluator.timeout if evaluator.timeout is not None else timeout
        )
        max_attempts = max(1, evaluator.retry_count)  # Ensure at least 1 attempt

        logger.debug(
            f"Executing evaluator: {evaluator.name} "
            f"(timeout={effective_timeout}s, max_attempts={max_attempts})"
        )
        start_time = time.time()

        last_error = None
        for attempt in range(1, max_attempts + 1):
            if attempt > 1:
                logger.debug(
                    f"Retrying evaluator '{evaluator.name}' "
                    f"(attempt {attempt}/{max_attempts})"
                )

            try:
                result_or_id = evaluator.evaluate(
                    spec, env_config, config, run_id, shared_context, sandbox, **kwargs
                )

                duration = time.time() - start_time

                if evaluator.is_async:
                    # Async evaluator returns evaluation ID
                    logger.debug(
                        f"Async evaluator '{evaluator.name}' started with "
                        f"ID: {result_or_id} (took {duration:.2f}s)"
                    )
                    return EvaluatorResult(
                        evaluator_name=evaluator.name,
                        status=EvaluatorStatus.SUCCESS,
                        message="Async evaluation started",
                        data={
                            "evaluation_id": result_or_id,
                            "duration": duration,
                            "attempts": attempt,
                        },
                    )
                else:
                    # Sync evaluator returns result
                    # If result is SUCCESS or explicitly FAILED (expected failure), don't retry
                    if result_or_id.status in (
                        EvaluatorStatus.SUCCESS,
                        EvaluatorStatus.FAILED,
                    ):
                        logger.debug(
                            f"Evaluator '{evaluator.name}' completed with status "
                            f"{result_or_id.status.value} (took {duration:.2f}s, attempt {attempt})"
                        )
                        return result_or_id

                    # If result is ERROR or SKIPPED and we have retries left, try again
                    if (
                        attempt < max_attempts
                        and result_or_id.status == EvaluatorStatus.ERROR
                    ):
                        logger.warning(
                            f"Evaluator '{evaluator.name}' returned ERROR status, "
                            f"will retry ({attempt}/{max_attempts})"
                        )
                        last_error = result_or_id.error
                        continue

                    # No more retries or not an error, return result
                    logger.debug(
                        f"Evaluator '{evaluator.name}' completed with status "
                        f"{result_or_id.status.value} (took {duration:.2f}s, attempt {attempt})"
                    )
                    return result_or_id

            except FuturesTimeoutError:
                duration = time.time() - start_time
                logger.error(
                    f"Evaluator '{evaluator.name}' timed out after {duration:.2f}s "
                    f"(attempt {attempt}/{max_attempts})"
                )
                last_error = "Timeout"

                # If we have retries left, try again
                if attempt < max_attempts:
                    continue

                # No more retries
                return EvaluatorResult(
                    evaluator_name=evaluator.name,
                    status=EvaluatorStatus.ERROR,
                    message=f"Evaluator timed out after {effective_timeout}s ({max_attempts} attempts)",
                    error="Timeout",
                )

            except Exception as e:
                duration = time.time() - start_time
                logger.error(
                    f"Evaluator '{evaluator.name}' raised exception after {duration:.2f}s: {e} "
                    f"(attempt {attempt}/{max_attempts})",
                    exc_info=(
                        attempt == max_attempts
                    ),  # Only log full traceback on last attempt
                )
                last_error = str(e)

                # If we have retries left, try again
                if attempt < max_attempts:
                    continue

                # No more retries
                return EvaluatorResult(
                    evaluator_name=evaluator.name,
                    status=EvaluatorStatus.ERROR,
                    message=f"Evaluator raised exception ({max_attempts} attempts)",
                    error=str(e),
                )

        # Should never reach here, but just in case
        return EvaluatorResult(
            evaluator_name=evaluator.name,
            status=EvaluatorStatus.ERROR,
            message=f"Evaluator failed after {max_attempts} attempts",
            error=last_error or "Unknown error",
        )

    def _check_terminal_failures(
        self, batch: List[Evaluator], batch_results: Dict[str, EvaluatorResult]
    ) -> Optional[EvaluatorResult]:
        """Check if any terminal evaluator in batch failed.

        Args:
            batch: List of evaluators that were executed
            batch_results: Results from batch execution

        Returns:
            Name of failed terminal evaluator, or None if none failed
        """
        for evaluator in batch:
            if evaluator.is_terminal:
                result = batch_results.get(evaluator.name)
                if result and result.status in (
                    EvaluatorStatus.FAILED,
                    EvaluatorStatus.ERROR,
                ):
                    return result

        return None

    def _create_success_result(
        self,
        config: DatasetConfig,
        shared_context: EvaluationContext,
        start_time: float,
    ) -> PipelineEvaluationResult:
        """Create success result from evaluation context.

        Args:
            config: Dataset configuration
            shared_context: Evaluation context with all results
            start_time: Evaluation start timestamp

        Returns:
            PipelineEvaluationResult indicating success
        """
        duration = time.time() - start_time

        return PipelineEvaluationResult(
            instance_id=config.instance_id,
            result=ResultStatus.SUCCESS,
            successful=True,
            duration=duration,
            message="Evaluation pipeline completed successfully",
            evaluations={
                name: result.to_dict()
                for name, result in shared_context.results.items()
            },
        )

    def _create_failure_result(
        self,
        config: DatasetConfig,
        shared_context: EvaluationContext,
        start_time: float,
        reason: str,
    ) -> PipelineEvaluationResult:
        """Create failure result.

        Args:
            config: Dataset configuration
            shared_context: Evaluation context
            start_time: Evaluation start timestamp
            reason: Failure reason

        Returns:
            PipelineEvaluationResult indicating failure
        """
        duration = time.time() - start_time

        return PipelineEvaluationResult(
            instance_id=config.instance_id,
            result=ResultStatus.FAILED,
            successful=False,
            duration=duration,
            message=reason,
            evaluations={
                name: result.to_dict()
                for name, result in shared_context.results.items()
            },
        )

    def _create_error_result(
        self,
        config: DatasetConfig,
        shared_context: EvaluationContext,
        start_time: float,
        error: str,
    ) -> PipelineEvaluationResult:
        """Create error result.

        Args:
            config: Dataset configuration
            shared_context: Evaluation context
            start_time: Evaluation start timestamp
            error: Error message

        Returns:
            PipelineEvaluationResult indicating error
        """
        duration = time.time() - start_time

        return PipelineEvaluationResult(
            instance_id=config.instance_id,
            result=ResultStatus.FAILED,  # Use FAILED since ERROR doesn't exist
            successful=False,
            duration=duration,
            message=f"Evaluation pipeline error: {error}",
            error=error,
            evaluations={
                name: result.to_dict()
                for name, result in shared_context.results.items()
            },
        )
