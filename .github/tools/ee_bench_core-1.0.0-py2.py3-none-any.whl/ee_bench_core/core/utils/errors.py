"""Error handling utilities for the evaluation framework."""

import traceback


def trace_error(e: Exception) -> str:
    """Generate traceback string from exception.

    Args:
        e: Exception to generate traceback for

    Returns:
        Formatted traceback string
    """
    tb_str = "".join(traceback.format_exception(type(e), e, e.__traceback__))
    return tb_str
