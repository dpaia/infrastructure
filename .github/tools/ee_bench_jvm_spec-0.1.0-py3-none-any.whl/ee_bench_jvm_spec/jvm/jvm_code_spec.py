"""JVM-specific EE-bench evaluation specification.

This module provides the JVM (Java/Maven/Gradle) implementation of the
EE-bench specification with automatic build system detection and
appropriate test runner selection.
"""

import logging
from typing import Any

from ee_bench_code_spec.base_code_spec import CodeEvalSpec
from ee_bench_core.core.abc_types import (
    DatasetManager,
    EnvironmentManager,
    ReportManager,
)
from ee_bench_core.core.models import DatasetConfig, EnvironmentConfig
from ee_bench_core.core.spec_registry import register_spec
from ee_bench_core.di.application_container import ApplicationContainer

from .jvm_config import BuildSystem, JvmCodeBenchmarkConfig
from .jvm_dataset import JvmCodeDatasetManager
from .jvm_di_container import JvmCodeContainer

logger = logging.getLogger(__name__)


@register_spec
class JvmCodeEvalSpec(CodeEvalSpec):
    """JVM-specific EE-bench evaluation specification.

    Provides JVM-specific implementation for EE-bench format evaluations
    including Maven/Gradle build system detection, appropriate test runner
    selection, and JVM-specific environment management.
    """

    def __init__(self, report_manager: ReportManager | None = None):
        """Initialize JVM EE-bench specification.

        Args:
            report_manager: Optional report manager for tracking evaluation results
        """
        super().__init__(report_manager)

        # Initialize DI containers (using BaseEvalSpec infrastructure)
        self.initialize_containers()

    @property
    def name(self) -> str:
        """Get the canonical name of this specification.

        Returns:
            "jvm"
        """
        return "jvm"

    @property
    def description(self) -> str:
        """Get a human-readable description.

        Returns:
            Description of JVM EE-bench specification
        """
        return "Software Engineering Benchmark for JVM (Java/Maven/Gradle)"

    # DI Container Methods (override BaseEvalSpec)

    def initialize_containers(self) -> None:
        """Initialize DI containers for JVM EE-bench specification.

        Creates ApplicationContainer and JvmCodeContainer, linking them together.
        """
        self.app_container = ApplicationContainer.create_with_defaults()
        self.container = JvmCodeContainer()
        self.container.app.override(self.app_container)

    def get_dataset_manager(self, **kwargs) -> DatasetManager:
        """Create a JVM-specific dataset manager instance.

        Returns JvmCodeDatasetManager which returns JvmCodeBenchmarkConfig
        instances with JVM-specific fields.

        Args:
            **kwargs: Spec-specific initialization parameters

        Returns:
            JvmCodeDatasetManager instance
        """
        return JvmCodeDatasetManager(**kwargs)

    def configure_for_evaluation(
        self, config: DatasetConfig, env_config: EnvironmentConfig, **kwargs
    ) -> None:
        """Configure DI container for specific evaluation instance.

        This method should be called before get_evaluation_runner() to set
        runtime configuration based on the task config and environment.

        Args:
            config: Dataset configuration for the task
            env_config: Environment configuration
            **kwargs: Additional parameters including:
                - sandbox: Execution sandbox ("docker" or "local", default: "docker")
                - predictions_path: Path to predictions file or "gold"
                - working_dir: Working directory for dataset manager
                - max_workers: Maximum parallel workers
        """
        # Determine execution mode from sandbox_type property
        # This is set by the environment initializers
        execution_mode = getattr(env_config, "sandbox_type", "docker")

        # Determine build system
        build_system = JvmCodeEvalSpec.get_build_system(config, **kwargs)
        build_system_str = build_system.value  # Convert enum to string

        # Determine predictions mode
        predictions_path = kwargs.get("predictions_path")
        predictions_mode = (
            "gold"
            if not predictions_path
            or (isinstance(predictions_path, str) and predictions_path.lower() == "gold")
            else "json"
        )

        evaluators_pipeline = kwargs.get("evaluators_pipeline")
        predictions = kwargs.get("predictions")

        if not evaluators_pipeline:
            if predictions == "gold":
                evaluators_pipeline = "standard"
            if predictions == "file":
                evaluators_pipeline = "minimal_with_test_patch"

        if not evaluators_pipeline:
            evaluators_pipeline = "minimal_with_test_patch"

        protocol = "http" if execution_mode == "docker" else "unix"

        # Configure container
        self.container.config.from_dict(
            {
                "execution_mode": execution_mode,
                "build_system": build_system_str,
                "predictions_mode": predictions_mode,
                "predictions_path": predictions_path,
                "evaluators_pipeline": evaluators_pipeline,
                "working_dir": kwargs.get("working_dir", "."),
                "max_workers": kwargs.get("max_workers", 1),
            }
        )

        self._configured = True
        logger.debug(
            f"Configured JvmCodeContainer: execution_mode={execution_mode}, "
            f"build_system={build_system_str}, predictions_mode={predictions_mode}"
        )

    @classmethod
    def get_build_system(cls, config: DatasetConfig, **kwargs) -> BuildSystem:
        """Detect build system from configuration.

        Args:
            config: Dataset configuration (should be JvmCodeBenchmarkConfig)

        Returns:
            BuildSystem enum (MAVEN or GRADLE)

        Raises:
            ValueError: If config is not a JvmCodeBenchmarkConfig or build system cannot be determined
        """

        build_system_str = kwargs.get("build_system")
        if build_system_str:
            return BuildSystem.from_string(build_system_str.lower())

        if not isinstance(config, JvmCodeBenchmarkConfig):
            raise ValueError(
                f"config must be a JvmCodeBenchmarkConfig, got {type(config).__name__}"
            )

        # Use build_system field if available
        if config.build_system:
            return BuildSystem.from_string(config.build_system.lower())

        # Fall back to is_maven field
        if config.is_maven:
            return BuildSystem.MAVEN
        return BuildSystem.GRADLE

    def get_configurers(self, config: DatasetConfig | None = None, **kwargs) -> list:
        """Get environment configurers for JVM EE-bench specification.

        Returns configurers including environment initializers and build system
        specific configurers based on Maven or Gradle.

        The configurers are returned in this order:
        1. Environment initializers (Docker or Local) - create EnvironmentConfig
        2. Spec-specific configurers - enhance the environment

        Each configurer checks env_config type in should_configure() to determine
        if it should run.

        Args:
            config: Optional dataset configuration (used to determine build system)
            **kwargs: Additional parameters including:
                - sandbox: Execution sandbox ("docker" or "local", default: "docker")
                - build_system: Override build system detection ("maven" or "gradle")
                - jvm_version: JVM version to use (default: "24")
                - namespace: Docker image namespace (default: "ee-bench")

        Returns:
            List of EnvironmentConfigurer instances
        """
        from ee_bench_code_spec.configurers import (
            TaskImageConfigurer,
        )
        from ee_bench_core.adapters.docker import DockerEnvironmentInitializer

        from . import (
            DockerGradleConfigurer,
            DockerMavenConfigurer,
            GradleDependenciesConfigurer,
            JvmBaseImageConfigurer,
            JvmLocalEnvironmentInitializer,
            LocalGradleConfigurer,
            LocalJvmConfigurer,
            LocalMavenConfigurer,
            LocalTaskSetupConfigurer,
            MavenDependenciesConfigurer,
        )

        # Determine build system
        # If config is None (deserialization mode), return empty list
        if config is None:
            return []

        build_system = JvmCodeEvalSpec.get_build_system(config, **kwargs)

        if not build_system:
            build_system = BuildSystem.MAVEN

        # Common parameters
        jvm_version = kwargs.get("jvm_version", "24")
        namespace = kwargs.get("namespace", "ee-bench")

        # ALWAYS include both initializers first
        # They check sandbox parameter in should_configure() to determine which runs
        # JvmLocalEnvironmentInitializer has priority=-1100 (runs before DockerEnvironmentInitializer at -1000)
        configurers = [
            JvmLocalEnvironmentInitializer(**kwargs),  # For JVM local mode
            DockerEnvironmentInitializer(**kwargs),  # For Docker mode
        ]

        # Add local configurers (will only run for LocalEnvironmentConfig)
        configurers.extend(
            [
                LocalJvmConfigurer(**kwargs),
            ]
        )

        # Add Docker-specific configurer chain
        # These will check env_config type in should_configure()
        configurers.extend(
            [
                JvmBaseImageConfigurer(
                    default_jdk_version=jvm_version,
                    namespace=namespace,
                ),
            ]
        )

        # Add build tool configurers based on build system
        # Both Docker and Local configurers are added - they check env_config type
        if build_system == BuildSystem.MAVEN:
            configurers.append(LocalMavenConfigurer(**kwargs))  # For local
            configurers.append(DockerMavenConfigurer(namespace=namespace))  # For Docker
        elif build_system == BuildSystem.GRADLE:
            configurers.append(LocalGradleConfigurer(**kwargs))  # For local
            configurers.append(DockerGradleConfigurer(namespace=namespace))  # For Docker
        else:
            logger.warning(f"Unknown build system: {build_system.name}, defaulting to Maven")
            configurers.append(LocalMavenConfigurer(**kwargs))
            configurers.append(DockerMavenConfigurer(namespace=namespace))

        # Add local task setup (repository cloning)
        # Runs after build tool configurers, before Docker task image
        configurers.append(LocalTaskSetupConfigurer(**kwargs))

        # Add final task image configurer (Docker only)
        configurers.append(TaskImageConfigurer(namespace=namespace))

        # Add dependencies configurer based on build system
        if build_system == BuildSystem.MAVEN:
            configurers.append(MavenDependenciesConfigurer(namespace=namespace))
        elif build_system == BuildSystem.GRADLE:
            configurers.append(GradleDependenciesConfigurer(namespace=namespace))
        else:
            logger.warning(
                f"Unknown build system: {build_system.name}, defaulting to Maven dependencies"
            )
            configurers.append(MavenDependenciesConfigurer(namespace=namespace))

        return configurers

    def get_environment_manager(
        self, config: DatasetConfig | None = None, **kwargs
    ) -> EnvironmentManager:
        """Create environment manager using composable configurers.

        This method uses BaseEnvironmentManager with JVM-specific configurers
        to build Docker environments in a composable manner.

        Args:
            config: Optional dataset configuration for the task (should be JvmCodeBenchmarkConfig).
                   When None, returns a minimal environment manager for deserialization.
            **kwargs: Spec-specific initialization parameters including:
                - build_system: Override build system detection ("maven" or "gradle")
                - jvm_version: JVM version to use (default: "24")
                - namespace: Docker image namespace (default: "ee-bench")
                - enable_plugins: Whether to discover plugin configurers (default: True)

        Returns:
            BaseEnvironmentManager instance with JVM configurers

        Raises:
            ValueError: If config is not a JvmCodeBenchmarkConfig (when config is provided)
        """
        from ee_bench_core.core.environment_manager import BaseEnvironmentManager

        # Get configurers for this spec
        # Pass None for config if not provided (used for deserialization)
        configurers = self.get_configurers(config, **kwargs) if config else []

        namespace = kwargs.get("namespace", "ee-bench")
        logger.debug(f"Using namespace {namespace} for environment images")

        # Create and return BaseEnvironmentManager
        return BaseEnvironmentManager(
            spec=self,
            configurers=configurers,
            enable_plugins=kwargs.get("enable_plugins", True) if config else False,
            **kwargs,
        )

    def prepare_environment(self, dataset_name: str, instance_ids: list[str], **kwargs):
        """Prepare environments for multiple task instances.

        Overrides base implementation to support filtering when instance_ids is empty.

        Args:
            dataset_name: Name of the dataset
            instance_ids: List of instance IDs to prepare (if empty, uses filters)
            **kwargs: Additional parameters including:
                - filters: Optional dict of filters to apply when instance_ids is empty
                           (e.g., {"language": "java", "repo": "spring-petclinic", "tags": ["bug"]})
                - max_workers: Number of parallel workers
                - Other spec-specific parameters

        Returns:
            EnvironmentPreparationResult
        """
        # If no instance_ids provided, use filters to get list from dataset
        if not instance_ids:
            filters_param = kwargs.get("filters")

            # Parse filters if provided as JSON string
            if filters_param and isinstance(filters_param, str):
                import json

                try:
                    filters = json.loads(filters_param)
                except json.JSONDecodeError as e:
                    raise ValueError(f"Invalid filters JSON: {e}")
            elif isinstance(filters_param, dict):
                filters = filters_param
            else:
                filters = None

            # Get dataset manager and list instances with filters
            working_dir = kwargs.get("working_dir", ".")
            dataset_manager = self.get_dataset_manager(working_dir=working_dir)

            # List all instances matching filters
            configs = dataset_manager.list_dataset_instances(
                dataset_name=dataset_name, filters=filters
            )

            # Extract instance IDs
            instance_ids = [config.instance_id for config in configs]

            if filters:
                logger.info(
                    f"Applied filters {filters}, found {len(instance_ids)} matching instances"
                )
            else:
                logger.info(
                    f"No filters provided, found {len(instance_ids)} total instances in dataset"
                )

        # Call parent implementation with resolved instance_ids
        return super().prepare_environment(
            dataset_name=dataset_name, instance_ids=instance_ids, **kwargs
        )

    def get_cli_parameters(self, command: str) -> list[dict[str, Any]]:
        """Get spec-specific CLI parameters for a command.

        Args:
            command: Command name

        Returns:
            List of parameter definitions for Click options
        """
        # Get base parameters (includes max_workers)
        base_params = self.get_base_cli_parameters(command)

        # Common EE-bench parameters
        common_params = [
            {
                "names": ["--split"],
                "type": str,
                "default": None,
                "help": "Dataset split to use (e.g., 'lite', 'verified')",
            },
            {
                "names": ["--sandbox"],
                "type": str,
                "default": "docker",
                "help": "Execution sandbox: 'docker' (default) or 'local'",
            },
        ]

        # JVM-specific parameters
        jvm_params = [
            {
                "names": ["--jvm-version"],
                "type": str,
                "default": "24",
                "help": "JVM version to use (default: 24)",
            }
        ]

        # Command-specific parameters
        if command == "prepare-environment":
            return (
                base_params
                + common_params
                + jvm_params
                + [
                    {
                        "names": ["--base-only"],
                        "is_flag": True,
                        "default": False,
                        "help": "Build only base images, not task-specific images",
                    },
                    {
                        "names": ["--force-rebuild"],
                        "is_flag": True,
                        "default": False,
                        "help": "Force rebuild of instance images even if they exist",
                    },
                    {
                        "names": ["--namespace"],
                        "type": str,
                        "default": None,
                        "help": "Docker images namespace (default: ee-bench)",
                    },
                    {
                        "names": ["--cleanup-expired"],
                        "is_flag": True,
                        "default": False,
                        "help": "Cleanup expired/dangling images after build",
                    },
                    {
                        "names": ["--build-system"],
                        "type": str,
                        "default": None,
                        "help": "Force specific build system (maven or gradle)",
                    },
                    {
                        "names": ["--filters"],
                        "type": str,
                        "default": None,
                        "help": 'Filters to apply when instance-ids not provided (JSON format: {"language": "java", "repo": "spring-petclinic", "tags":["bug"]})',
                    },
                ]
            )
        if command == "run-evaluation":
            return (
                base_params
                + common_params
                + jvm_params
                + [
                    {
                        "names": ["--docker-opts"],
                        "type": str,
                        "default": None,
                        "help": "Additional Docker run options (JSON or CLI format: '{\"memory\": \"2g\"}' or '--memory 2g --cpus 2')",
                    },
                    {
                        "names": ["--clean"],
                        "is_flag": True,
                        "default": False,
                        "help": "Cleanup images created during evaluation after completion",
                    },
                    {
                        "names": ["--predictions-path"],
                        "type": str,
                        "default": None,
                        "help": "Path to predictions file - if 'gold', uses gold predictions",
                    },
                    {
                        "names": ["--build-system"],
                        "type": str,
                        "default": None,
                        "help": "Force specific build system (maven or gradle)",
                    },
                    {
                        "names": ["--force-rebuild"],
                        "is_flag": True,
                        "default": False,
                        "help": "Force rebuild of environments even if they exist",
                    },
                ]
            )
        return base_params + common_params + jvm_params
