"""Evaluation framework for EE-Benchmark.

This package provides the evaluator pipeline architecture for building
flexible, composable evaluation workflows.
"""

from .base_evaluation_runner import BaseEvaluationRunner
from .environment_configurer import EnvironmentConfigurer
from .environment_configurer_registry import (
    EnvironmentConfigurerMetadata,
    EnvironmentConfigurerRegistry,
    get_global_registry as get_configurer_registry,
    register_configurer,
)
from .evaluation_tracker import EvaluationTracker, get_evaluation_tracker
from .evaluator import (
    DependencyPosition,
    EvaluationContext,
    Evaluator,
    EvaluatorResult,
    EvaluatorStatus,
    PositionConstraint,
)
from .evaluator_registry import (
    EvaluatorMetadata,
    EvaluatorRegistry,
    get_global_registry,
    register_evaluator,
)
from .evaluator_runner import (
    EvaluationRunner as PipelineRunner,
    PipelineEvaluationResult,
)
from .score_evaluator import (
    BaseScoreEvaluator,
    FinalScore,
    ScoreBreakdown,
    ScoreEvaluator,
)

# Backward compatibility aliases
EvaluatorDependency = DependencyPosition

__all__ = [
    # Core Evaluator Framework
    "Evaluator",
    "EvaluationContext",
    "EvaluatorResult",
    "EvaluatorStatus",
    "EvaluatorDependency",
    "DependencyPosition",
    "PositionConstraint",
    # Score Calculation
    "ScoreEvaluator",
    "BaseScoreEvaluator",
    "FinalScore",
    "ScoreBreakdown",
    # Validation and Execution
    "PipelineRunner",
    "PipelineEvaluationResult",
    "BaseEvaluationRunner",
    # Registry and Plugins
    "EvaluatorRegistry",
    "EvaluatorMetadata",
    "get_global_registry",
    "register_evaluator",
    # Environment Configuration
    "EnvironmentConfigurer",
    "EnvironmentConfigurerRegistry",
    "EnvironmentConfigurerMetadata",
    "get_configurer_registry",
    "register_configurer",
    # Async Evaluation Tracking
    "EvaluationTracker",
    "get_evaluation_tracker",
]
