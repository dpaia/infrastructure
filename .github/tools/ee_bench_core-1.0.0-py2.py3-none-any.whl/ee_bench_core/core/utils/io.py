"""File I/O utilities for the EE Benchmark framework.

This module provides utilities for file operations including downloading
files from URLs and copying files to specific locations. All write operations
are atomic to prevent corruption from concurrent access.
"""

import logging
import shutil
import tempfile
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

import requests

from ee_bench_core.core.errors import DatasetError

logger = logging.getLogger(__name__)


def download_file(
    url: str,
    dest_dir: Path,
    filename: Optional[str] = None,
    timeout: int = 30,
    skip_if_exists: bool = True,
) -> Path:
    """Download a file from a URL to a destination directory.

    Args:
        url: URL to download from
        dest_dir: Destination directory (will be created if doesn't exist)
        filename: Optional filename override (otherwise extracted from URL)
        timeout: Request timeout in seconds (default: 30)
        skip_if_exists: If True, skip download if file already exists (default: True)

    Returns:
        Path to the downloaded file

    Raises:
        DatasetError: If download fails or URL is invalid
    """
    # Extract filename from URL if not provided
    if not filename:
        parsed_url = urlparse(url)
        filename = Path(parsed_url.path).name
        if not filename:
            raise DatasetError(f"Cannot extract filename from URL: {url}")

    # Ensure destination directory exists
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)

    dest_file = dest_dir / filename

    # Skip if file exists and skip_if_exists is True
    if skip_if_exists and dest_file.exists():
        logger.info(f"File already exists, skipping download: {dest_file}")
        return dest_file

    logger.info(f"Downloading file from {url} to {dest_file}")

    tmp_path = None
    try:
        response = requests.get(url, timeout=timeout)
        response.raise_for_status()

        # Write content to file atomically using temporary file
        try:
            with tempfile.NamedTemporaryFile(
                mode="wb", dir=dest_dir, delete=False, suffix=".tmp"
            ) as tmp_file:
                tmp_path = Path(tmp_file.name)
                tmp_file.write(response.content)

            # Atomic rename
            tmp_path.replace(dest_file)
            logger.info(f"Successfully downloaded file: {dest_file}")
            return dest_file

        except Exception as e:
            # Clean up temporary file on error
            if tmp_path is not None and tmp_path.exists():
                tmp_path.unlink()
            raise DatasetError(f"Failed to write file {dest_file}: {e}")

    except requests.exceptions.Timeout:
        raise DatasetError(f"Download timeout after {timeout}s: {url}")
    except requests.exceptions.HTTPError as e:
        raise DatasetError(f"HTTP error downloading {url}: {e}")
    except requests.exceptions.RequestException as e:
        raise DatasetError(f"Failed to download from {url}: {e}")


def copy_file(
    source_path: Path,
    dest_dir: Path,
    filename: Optional[str] = None,
    overwrite: bool = False,
) -> Path:
    """Copy a file to a destination directory.

    Args:
        source_path: Path to source file
        dest_dir: Destination directory (will be created if doesn't exist)
        filename: Optional destination filename (otherwise uses source filename)
        overwrite: If True, overwrite existing file (default: False)

    Returns:
        Path to the copied file

    Raises:
        DatasetError: If source doesn't exist or copy fails
    """
    source_path = Path(source_path)

    # Validate source
    if not source_path.exists():
        raise DatasetError(f"Source file does not exist: {source_path}")

    if not source_path.is_file():
        raise DatasetError(f"Source is not a file: {source_path}")

    # Prepare destination
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)

    dest_filename = filename or source_path.name
    dest_file = dest_dir / dest_filename

    # Check if destination exists
    if dest_file.exists() and not overwrite:
        logger.info(f"File already exists, skipping copy: {dest_file}")
        return dest_file

    logger.info(f"Copying file from {source_path} to {dest_file}")

    tmp_path = None
    try:
        # Copy to temporary file first for atomic operation
        with tempfile.NamedTemporaryFile(
            mode="wb", dir=dest_dir, delete=False, suffix=".tmp"
        ) as tmp_file:
            tmp_path = Path(tmp_file.name)

        # Copy with metadata preservation
        shutil.copy2(source_path, tmp_path)

        # Atomic rename
        tmp_path.replace(dest_file)
        logger.info(f"Successfully copied file: {dest_file}")
        return dest_file

    except Exception as e:
        # Clean up temporary file on error
        if tmp_path is not None and tmp_path.exists():
            tmp_path.unlink()
        raise DatasetError(
            f"Failed to copy file from {source_path} to {dest_file}: {e}"
        )


def ensure_directory(path: Path) -> Path:
    """Ensure a directory exists, creating it if necessary.

    Args:
        path: Directory path

    Returns:
        Path to the directory

    Raises:
        DatasetError: If path exists but is not a directory
    """
    path = Path(path)

    if path.exists():
        if not path.is_dir():
            raise DatasetError(f"Path exists but is not a directory: {path}")
        return path

    try:
        path.mkdir(parents=True, exist_ok=True)
        logger.debug(f"Created directory: {path}")
        return path
    except OSError as e:
        raise DatasetError(f"Failed to create directory {path}: {e}")


def read_json_file(file_path: Path) -> dict:
    """Read and parse a JSON file.

    Args:
        file_path: Path to JSON file

    Returns:
        Parsed JSON data

    Raises:
        DatasetError: If file doesn't exist or JSON is invalid
    """
    import json

    file_path = Path(file_path)

    if not file_path.exists():
        raise DatasetError(f"File does not exist: {file_path}")

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        raise DatasetError(f"Invalid JSON in {file_path}: {e}")
    except IOError as e:
        raise DatasetError(f"Failed to read file {file_path}: {e}")


def write_json_file(file_path: Path, data: dict, indent: int = 2) -> None:
    """Write data to a JSON file atomically.

    Uses a temporary file and atomic rename to prevent corruption
    from concurrent access or interrupted writes.

    Args:
        file_path: Path to JSON file
        data: Data to write
        indent: JSON indentation level (default: 2)

    Raises:
        DatasetError: If write fails
    """
    import json

    file_path = Path(file_path)

    # Ensure parent directory exists
    file_path.parent.mkdir(parents=True, exist_ok=True)

    tmp_path = None
    try:
        # Write to temporary file first
        with tempfile.NamedTemporaryFile(
            mode="w",
            dir=file_path.parent,
            delete=False,
            suffix=".tmp",
            encoding="utf-8",
        ) as tmp_file:
            tmp_path = Path(tmp_file.name)
            json.dump(data, tmp_file, indent=indent, ensure_ascii=False)

        # Atomic rename
        tmp_path.replace(file_path)
        logger.debug(f"Wrote JSON file: {file_path}")

    except (IOError, TypeError) as e:
        # Clean up temporary file on error
        if tmp_path is not None and tmp_path.exists():
            tmp_path.unlink()
        raise DatasetError(f"Failed to write JSON to {file_path}: {e}")
