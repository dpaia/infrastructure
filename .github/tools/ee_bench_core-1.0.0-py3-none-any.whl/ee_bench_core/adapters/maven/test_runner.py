"""Maven test runner adapter.

This module provides a test runner for Maven-based Java projects.
"""

import logging
import shlex
from pathlib import Path
from typing import Optional

from ee_bench_core.core.models import ResultStatus, EnvironmentConfig
from ee_bench_core.core.utils import set_command_context

from ..junit_parser import parse_junit_report
from ..process_manager import LocalProcessManager
from ..process_manager_base import ProcessManager
from ..testrunner_base import TestResult, TestRunner
from .module_detector import MavenModuleDetector
from .output_parser import MavenOutputParser

logger = logging.getLogger(__name__)


class MavenTestRunner(TestRunner):
    """Test runner implementation for Maven-based projects."""

    def __init__(self, process_manager: Optional[ProcessManager] = None):
        """Initialize Maven test runner.

        Args:
            process_manager: ProcessManager instance (LocalProcessManager if None)
        """
        self.module_detector = MavenModuleDetector()
        self.output_parser = MavenOutputParser()
        self.process_manager = process_manager or LocalProcessManager(debug_output=True)

    def _run_test(
        self,
        test_name: str,
        working_dir: Path,
        timeout: int,
        test_args: Optional[str] = None,
        env_config: Optional[EnvironmentConfig] = None,
    ) -> TestResult:
        """Run Maven test for a specific class and return parsed TestResult.

        Args:
            test_name: Test name to execute
            working_dir: Working directory where tests should run
            timeout: Timeout in seconds for test execution
            test_args: Optional additional arguments to pass to Maven

        Returns:
            TestResult for the test execution
        """
        set_command_context(f"run_test:maven:{test_name}")

        # Normalize and detect module
        module_hint, clean_name, class_for_search = self._normalize_test_name(test_name)
        module = module_hint or self.module_detector.detect_module(
            class_for_search, working_dir
        )

        if module:
            logger.debug(f"Detected module for {test_name}: {module}")
        else:
            logger.debug(f"No module detected for {test_name}, running from repo root")

        # Choose Maven wrapper if present
        mvnw_path = working_dir / "mvnw"
        if mvnw_path.exists() and mvnw_path.is_file():
            maven_cmd = ["./mvnw"]
        else:
            maven_cmd = ["mvn"]

        cmd = list(maven_cmd)
        cmd.append("test")
        if module and module != ".":
            cmd.extend(["-pl", module])
        cmd.append(f"-Dtest={clean_name}")
        cmd.append("-Dsurefire.failIfNoSpecifiedTests=true")
        cmd.append("-Dsurefire.useFile=true")
        cmd.extend(["-B", "--no-transfer-progress"])

        if test_args:
            cmd.extend(shlex.split(test_args))

            # Try to apply formatters (ignore errors)
            try:
                self.process_manager.run_command(
                    maven_cmd + ["spring-javaformat:apply"],
                    cwd=working_dir,
                    env_config=env_config,
                )
            except Exception:
                logger.debug("spring-javaformat:apply not available or failed")

            try:
                self.process_manager.run_command(
                    maven_cmd + ["spotless:apply"],
                    cwd=working_dir,
                    env_config=env_config,
                )
            except Exception:
                logger.debug("spotless:apply not available or failed")

        logger.info(f"Running Maven command: {' '.join(cmd)}")

        # Execute command using ProcessManager
        result = self.process_manager.run_command(
            cmd=cmd,
            cwd=working_dir,
            timeout=timeout,
            log_prefix="     ",
            env_config=env_config,
        )

        # Handle timeout
        if result.timed_out:
            logger.error(f"Maven test timed out after {timeout} seconds")
            timeout_result = TestResult(
                execution_time=result.duration, raw_output=result.stdout + result.stderr
            )
            timeout_result.add_test(
                test_name=clean_name,
                status=ResultStatus.FAILED,
                reason=f"Maven test timed out after {timeout} seconds",
                details=[f"Maven test timed out after {timeout} seconds"],
            )
            return timeout_result

        combined = result.stdout + result.stderr
        duration = result.duration
        ret = result.returncode

        # Parse Maven output (prefer JUnit XML only)
        parsed = self._parse_output(
            working_dir, combined, duration, module, class_for_search
        )

        # Determine success solely by return code
        success = ret == 0
        logger.debug(f"Maven test success: {success}")

        # Update parsed result's success based on return code
        parsed.success = success
        parsed.execution_time = duration
        parsed.raw_output = combined

        return parsed

    def _parse_output(
        self,
        working_dir: Path,
        stdout: str,
        execution_time: float,
        module: Optional[str],
        class_fqn: str,
    ) -> TestResult:
        """Parse Maven output preferring JUnit XML in target/surefire-reports or failsafe-reports.

        Args:
            working_dir: Project root directory
            stdout: Maven stdout output
            execution_time: Execution time in seconds
            module: Module path or None
            class_fqn: Fully qualified class name

        Returns:
            TestResult from parsing
        """
        base = working_dir
        if module and module != ".":
            base = base / module

        # Try Surefire then Failsafe
        for reports_dir in [
            base / "target" / "surefire-reports",
            base / "target" / "failsafe-reports",
        ]:
            try:
                xml_result = parse_junit_report(reports_dir, class_fqn)
            except Exception as e:
                from core.utils import trace_error

                logger.debug(trace_error(e))
                xml_result = None

            if xml_result is not None:
                if not xml_result.execution_time:
                    xml_result.execution_time = execution_time
                return xml_result
            else:
                return self.output_parser.parse(stdout, class_fqn, execution_time)

        fallback_result = TestResult(execution_time=execution_time, raw_output=stdout)
        fallback_result.add_test(
            test_name=class_fqn,
            status=ResultStatus.FAILED,
            reason="No test results found",
            details=[],
        )
        return fallback_result
