"""Gradle formatter evaluator for applying Gradle code formatters.

This module provides evaluators for applying Gradle-specific formatters
after patches are applied. It automatically detects Gradle wrapper (gradlew)
if present in the project.
"""

import logging
from abc import ABC
from pathlib import Path
from typing import TYPE_CHECKING, Any

from ..build_tool_detector import detect_gradle_command
from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig, EvalSpec
from ee_bench_core.core.eval import (
    EvaluationContext,
    Evaluator,
    EvaluatorDependency,
    EvaluatorResult,
    EvaluatorStatus,
)

from ee_bench_jvm_spec.jvm.jvm_config import BuildSystem

if TYPE_CHECKING:
    from ee_bench_core.adapters.sandbox_base import Sandbox

logger = logging.getLogger(__name__)


class BaseGradleFormatterEvaluator(Evaluator, ABC):
    """Base evaluator for applying Gradle code formatters.

    This evaluator applies Gradle formatters (spotless) after patches are applied.
    It automatically detects Gradle wrapper (gradlew) if present.
    Errors are ignored as formatters are optional and non-blocking.
    """

    def __init__(
        self,
        name: str,
        dependencies: Any | None = None,
        is_terminal: bool = False,
        timeout: int | None = 300,
        retry_count: int = 1,
    ):
        """Initialize Gradle formatter evaluator.

        Args:
            name: Unique name for this evaluator
            dependencies: Dependency specification
            is_terminal: Whether failure should stop the pipeline (default: False)
            timeout: Optional custom timeout in seconds (default: 300)
            retry_count: Number of retry attempts (default: 1)
        """
        self._name = name
        self._dependencies = dependencies
        self._is_terminal = is_terminal
        self._timeout = timeout
        self._retry_count = retry_count

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return "Apply Gradle code formatters (spotless)"

    @property
    def dependencies(self) -> Any | None:
        return self._dependencies

    @property
    def is_terminal(self) -> bool:
        return self._is_terminal

    @property
    def timeout(self) -> int | None:
        return self._timeout

    @property
    def retry_count(self) -> int:
        return self._retry_count

    def can_skip(
        self,
        spec: EvalSpec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        run_id: str,
        shared_context,
    ) -> tuple[bool, str | None]:
        """Check if Gradle formatter should be skipped.

        Skips execution for non-Gradle projects.

        Args:
            spec: Evaluation spec
            env_config: Environment configuration
            config: Dataset configuration
            run_id: Run ID
            shared_context: Shared evaluation context

        Returns:
            Tuple of (should_skip, reason)
        """
        # Import here to avoid circular dependency
        from ee_bench_jvm_spec.jvm import JvmCodeEvalSpec

        # Get build system from spec
        build_system = JvmCodeEvalSpec.get_build_system(config)

        if build_system != BuildSystem.GRADLE:
            return True, f"Build system is {build_system.name}, not GRADLE"

        return False, None

    def evaluate(
        self,
        spec: EvalSpec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        run_id: str,
        shared_context: EvaluationContext,
        sandbox: "Sandbox",
        **kwargs,
    ) -> EvaluatorResult:
        """Apply Gradle formatters.

        Args:
            spec: Evaluation spec
            env_config: Environment configuration
            config: Dataset configuration
            run_id: Evaluation run ID
            shared_context: Shared context
            sandbox: Sandbox instance for executing commands
            **kwargs: Additional parameters

        Returns:
            EvaluatorResult with formatting outcome
        """
        try:
            # Get project path from env_config
            project_path = "/workspace/task_project"
            if hasattr(env_config, "project_path"):
                project_path = str(env_config.project_path)
            elif hasattr(env_config, "workspace_dir") and env_config.workspace_dir:
                project_path = str(Path(env_config.workspace_dir) / "task_project")

            working_dir = Path(project_path)

            # Detect Gradle wrapper using common detector
            gradle_cmd = detect_gradle_command(sandbox, working_dir)
            logger.debug(f"Using Gradle command: {' '.join(gradle_cmd)}")

            # Get formatter commands
            commands = self._get_gradle_formatter_commands(gradle_cmd)

            applied_formatters = []
            failed_formatters = []

            for cmd in commands:
                formatter_name = " ".join(cmd)
                try:
                    logger.debug(f"Trying to apply formatter: {formatter_name}")
                    result = sandbox.run_command(
                        cmd=cmd,
                        cwd=working_dir,
                        timeout=self._timeout,
                    )

                    if result.returncode == 0:
                        applied_formatters.append(formatter_name)
                        logger.info(f"Successfully applied formatter: {formatter_name}")
                    else:
                        failed_formatters.append(formatter_name)
                        logger.debug(
                            f"Formatter {formatter_name} failed with exit code {result.returncode}"
                        )
                except Exception as e:
                    failed_formatters.append(formatter_name)
                    logger.debug(f"Formatter {formatter_name} not available or failed: {e}")

            # Always return success since formatters are optional
            message_parts = []
            if applied_formatters:
                message_parts.append(f"Applied: {', '.join(applied_formatters)}")
            if failed_formatters:
                message_parts.append(f"Skipped: {', '.join(failed_formatters)}")

            message = "; ".join(message_parts) if message_parts else "No formatters applied"

            return EvaluatorResult(
                evaluator_name=self.name,
                status=EvaluatorStatus.SUCCESS,
                message=message,
                data={
                    "applied_formatters": applied_formatters,
                    "failed_formatters": failed_formatters,
                    "total_formatters": len(commands),
                    "build_system": "gradle",
                    "gradle_command": " ".join(gradle_cmd),
                },
            )

        except Exception as e:
            logger.error(f"Error applying Gradle formatters: {e}", exc_info=logger.isEnabledFor(logging.DEBUG))
            # Still return success since formatters are optional
            return EvaluatorResult(
                evaluator_name=self.name,
                status=EvaluatorStatus.SUCCESS,
                message="Gradle formatter evaluation failed but continuing",
                error=str(e),
            )

    def _get_gradle_formatter_commands(self, gradle_cmd: list[str]) -> list[list[str]]:
        """Get Gradle formatter commands.

        Args:
            gradle_cmd: Gradle command (either ['./gradlew'] or ['gradle'])

        Returns:
            List of Gradle formatter commands
        """
        return [
            gradle_cmd + ["spotlessApply"],
        ]


class GradleTestPatchFormatterEvaluator(BaseGradleFormatterEvaluator):
    """Gradle formatter evaluator that runs after test_patch_application.

    This plugin applies Gradle formatters after the test patch has been applied,
    before running fail_to_pass_validation.
    """

    # Plugin metadata
    __evaluator_name__ = "gradle_test_patch_formatter"
    __evaluator_description__ = "Apply Gradle formatters after test patch"
    __evaluator_version__ = "1.0.0"
    __evaluator_author__ = "EE-Benchmark Team"
    __evaluator_tags__ = ["formatting", "gradle", "test-patch"]
    __evaluator_specs__ = ["jvm"]

    def __init__(
        self,
        name: str = "gradle_test_patch_formatter",
        timeout: int | None = 300,
        retry_count: int = 1,
    ):
        """Initialize test patch formatter evaluator.

        Args:
            name: Evaluator name (default: "gradle_test_patch_formatter")
            timeout: Custom timeout in seconds (default: 300)
            retry_count: Number of retry attempts (default: 1)
        """
        super().__init__(
            name=name,
            dependencies=EvaluatorDependency(
                after=["test_patch_application"], before=["fail_to_pass_validation"]
            ),
            is_terminal=False,  # Non-terminal - don't stop pipeline on formatter errors
            timeout=timeout,
            retry_count=retry_count,
        )

    @property
    def description(self) -> str:
        return "Apply Gradle code formatters after test patch"

class GradleTestPatchReapplicationFormatterEvaluator(BaseGradleFormatterEvaluator):
    """Gradle formatter evaluator that runs after test_patch_application.

    This plugin applies Gradle formatters after the test patch has been applied,
    before running fail_to_pass_validation.
    """

    # Plugin metadata
    __evaluator_name__ = "gradle_test_patch_formatter_2"
    __evaluator_description__ = "Apply Gradle formatters after test patch"
    __evaluator_version__ = "1.0.0"
    __evaluator_author__ = "EE-Benchmark Team"
    __evaluator_tags__ = ["formatting", "gradle", "test-patch"]
    __evaluator_specs__ = ["jvm"]

    def __init__(
            self,
            name: str = "gradle_test_patch_formatter_2",
            timeout: int | None = 300,
            retry_count: int = 1,
    ):
        """Initialize test patch formatter evaluator.

        Args:
            name: Evaluator name (default: "gradle_test_patch_formatter")
            timeout: Custom timeout in seconds (default: 300)
            retry_count: Number of retry attempts (default: 1)
        """
        super().__init__(
            name=name,
            dependencies=EvaluatorDependency(
                after=["test_patch_reapplication"], before=["fail_to_pass_validation"]
            ),
            is_terminal=False,  # Non-terminal - don't stop pipeline on formatter errors
            timeout=timeout,
            retry_count=retry_count,
        )

    @property
    def description(self) -> str:
        return "Apply Gradle code formatters after test patch"


class GradlePredictionFormatterEvaluator(BaseGradleFormatterEvaluator):
    """Gradle formatter evaluator that runs after prediction_application.

    This plugin applies Gradle formatters after the prediction patch has been applied,
    before running all_tests_validation.
    """

    # Plugin metadata
    __evaluator_name__ = "gradle_prediction_formatter"
    __evaluator_description__ = "Apply Gradle formatters after prediction patch"
    __evaluator_version__ = "1.0.0"
    __evaluator_author__ = "EE-Benchmark Team"
    __evaluator_tags__ = ["formatting", "gradle", "prediction"]
    __evaluator_specs__ = ["jvm"]

    def __init__(
        self,
        name: str = "gradle_prediction_formatter",
        timeout: int | None = 300,
        retry_count: int = 1,
    ):
        """Initialize prediction formatter evaluator.

        Args:
            name: Evaluator name (default: "gradle_prediction_formatter")
            timeout: Custom timeout in seconds (default: 300)
            retry_count: Number of retry attempts (default: 1)
        """
        super().__init__(
            name=name,
            dependencies=EvaluatorDependency(
                after=["prediction_application"], before=["all_tests_validation"]
            ),
            is_terminal=False,  # Non-terminal - don't stop pipeline on formatter errors
            timeout=timeout,
            retry_count=retry_count,
        )

    @property
    def description(self) -> str:
        return "Apply Gradle code formatters after prediction patch"
