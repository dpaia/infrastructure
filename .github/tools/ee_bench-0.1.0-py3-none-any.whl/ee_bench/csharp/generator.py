"""CSharpEvalGenerator — transforms C# Dockerfiles + configs into EE-bench format."""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

from jinja2 import Environment, StrictUndefined

from ee_bench.generator.interfaces import Provider
from ee_bench.csharp.configs import get_config

logger = logging.getLogger(__name__)

_RESOURCES = Path(__file__).parent / "resources"

# Regex to match ENTRYPOINT and CMD directives
_ENTRYPOINT_CMD_PATTERN = re.compile(
    r'^(ENTRYPOINT|CMD)\s+.*$',
    re.MULTILINE,
)

RUN_SH_TEMPLATE = (_RESOURCES / "run.sh").read_text()
PARSER_PY = (_RESOURCES / "parser.py").read_text()
EMITTER_PY = (_RESOURCES / "emitter.py").read_text()


class CSharpEvalGenerator(Provider):
    """C# benchmark provider.

    Takes raw Dockerfile content and per-repo config, produces:
    - ``repo_shared``: Jinja2 templates for main branch (Dockerfile, run.sh, parser.py)
    - ``eval_files``: Pre-rendered install.sh for metadata.json
    """

    def provide(
        self,
        item=None,
        *,
        dockerfile_content: str = "",
        repo: str = "",
        base_commit: str = "",
        test_framework: str = "",
        env_setup_version: str = "1.0",
        run_tests_version: str = "1.0",
        target_org: str = "dpaia",
        **kwargs,
    ) -> dict[str, Any]:
        """Transform C# Dockerfile + config into EE-bench format.

        Args:
            item: Item dict (unused after explicit-param migration).
            dockerfile_content: Raw Dockerfile from CSHARP_HARNESS_PATH.
            repo: Upstream repo (e.g. "App-vNext/Polly").
            base_commit: Base commit hash.
            test_framework: Target framework (e.g. "net8.0", may be empty).
            env_setup_version: Install config version key.
            run_tests_version: Test config version key.
            target_org: GitHub org for forks.
            **kwargs: Ignored.

        Returns:
            Dict with 'repo_shared' and 'eval_files' keys.
        """
        # --- Resolve per-instance config ---
        config = get_config(repo, env_setup_version, run_tests_version)

        # Resolve test_framework_flag for Jinja2 templates
        test_framework_flag = f"--framework {test_framework}" if test_framework else ""

        # --- Pre-render install.sh (for metadata.json) ---
        install_sh = self._render_template(
            config["install"], test_framework_flag=test_framework_flag,
        )

        # --- Dockerfile as Jinja2 template ({{ instance.* }} variables) ---
        dockerfile_template = self._transform_dockerfile(dockerfile_content)

        # --- Assemble repo_shared dict (Jinja2 templates for main branch) ---
        repo_shared: dict[str, str] = {
            "environment/Dockerfile": dockerfile_template,
            "eval/run.sh": RUN_SH_TEMPLATE,
            "eval/scripts/parser.py": PARSER_PY,
            "eval/scripts/emitter.py": EMITTER_PY,
        }

        # --- Pre-rendered eval files (for metadata.json evaluation.files) ---
        eval_files: dict[str, str] = {
            "scripts/install.sh": install_sh,
        }

        return {
            "repo_shared": repo_shared,
            "eval_files": eval_files,
            "test_project": config["test_project"],
            "test_logger": config["test_logger"],
        }

    @staticmethod
    def _render_template(template_str: str, **variables: str) -> str:
        """Render a Jinja2 template string with variables."""
        env = Environment(undefined=StrictUndefined)
        tmpl = env.from_string(template_str)
        return tmpl.render(**variables)

    @staticmethod
    def _transform_dockerfile(raw: str) -> str:
        """Transform raw Dockerfile into a Jinja2 template for EE-bench.

        Appends git clone using ``{{ instance.owner }}/{{ instance.repo_name }}``,
        checks out ``{{ instance.base_commit }}``, sets WORKDIR,
        removes ENTRYPOINT/CMD, adds EE-bench labels.
        """
        if not raw:
            return ""

        dockerfile = _ENTRYPOINT_CMD_PATTERN.sub("", raw)

        while "\n\n\n" in dockerfile:
            dockerfile = dockerfile.replace("\n\n\n", "\n\n")

        dockerfile = dockerfile.rstrip() + "\n\n"
        dockerfile += 'RUN git clone https://github.com/{{ instance.owner }}/{{ instance.repo_name }}.git /app\n'
        dockerfile += 'WORKDIR /app\n'
        dockerfile += 'RUN git checkout {{ instance.base_commit }}\n\n'
        dockerfile += 'LABEL ee-bench.type="codegen"\n'
        dockerfile += 'LABEL ee-bench.version="1.0"\n'
        dockerfile += 'RUN rm -rf /app/.ee-bench/ 2>/dev/null || true\n'

        return dockerfile

