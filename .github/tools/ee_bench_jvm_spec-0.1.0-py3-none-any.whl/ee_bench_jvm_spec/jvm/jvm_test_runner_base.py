"""Base test runner for JVM-based build tools (Maven/Gradle).

This module provides a base class with common functionality for JVM test runners,
eliminating code duplication between Maven and Gradle implementations.
"""

import logging
from abc import abstractmethod
from pathlib import Path

from ee_bench_core.adapters import (
    Sandbox,
    TestResult,
    TestRunner,
    parse_junit_report,
)
from ee_bench_core.core.models import EnvironmentConfig, ResultStatus
from ee_bench_core.core.utils import set_command_context, trace_error

logger = logging.getLogger(__name__)


class BaseJvmTestRunner(TestRunner):
    """Base class for JVM test runners (Maven/Gradle) with common functionality.

    This class implements the template method pattern to provide common test execution
    orchestration while allowing subclasses to customize tool-specific details.

    Subclasses must implement:
    - _create_module_detector(): Return tool-specific module detector
    - _create_output_parser(): Return tool-specific output parser
    - _detect_build_command(): Detect build tool command (mvn/gradle wrapper)
    - _build_test_command(): Build tool-specific test command
    - _get_report_directories(): Get paths to XML report directories
    """

    # Tool name for logging (set by subclass)
    tool_name: str = "jvm"

    def __init__(self):
        """Initialize JVM test runner."""
        self.module_detector = self._create_module_detector()
        self.output_parser = self._create_output_parser()

    @abstractmethod
    def _create_module_detector(self):
        """Create tool-specific module detector.

        Returns:
            Module detector instance (MavenModuleDetector or GradleModuleDetector)
        """
        pass

    @abstractmethod
    def _create_output_parser(self):
        """Create tool-specific output parser.

        Returns:
            Output parser instance (MavenOutputParser or GradleOutputParser)
        """
        pass

    @abstractmethod
    def _detect_build_command(
        self, sandbox: Sandbox, working_dir: Path, env_config: EnvironmentConfig | None
    ) -> list[str]:
        """Detect build tool command (mvn/gradle wrapper).

        Args:
            working_dir: Project root directory
            env_config: Environment configuration

        Returns:
            List containing build command (e.g., ['mvn'] or ['./gradlew'])
        """
        pass

    @abstractmethod
    def _build_test_command(
        self,
        base_cmd: list[str],
        module: str | None,
        test_name: str,
        test_args: str | None,
    ) -> list[str]:
        """Build tool-specific test command.

        Args:
            base_cmd: Base build command (from _detect_build_command)
            module: Module path or None
            test_name: Clean test name
            test_args: Optional additional arguments

        Returns:
            Complete command list ready for execution
        """
        pass

    @abstractmethod
    def _get_report_directories(self, working_dir: Path, module: str | None) -> list[Path]:
        """Get paths to XML report directories.

        Args:
            working_dir: Project root directory
            module: Module path or None

        Returns:
            List of paths to check for JUnit XML reports
        """
        pass

    def _run_test(
        self,
        sandbox: Sandbox,
        test_name: str,
        working_dir: Path,
        timeout: int,
        test_args: str | None = None,
        env_config: EnvironmentConfig | None = None,
    ) -> TestResult:
        """Run test with common orchestration logic.

        This is the template method that orchestrates the test execution flow,
        delegating tool-specific operations to abstract methods.

        Args:
            test_name: Test name to execute
            working_dir: Working directory where tests should run
            timeout: Timeout in seconds for test execution
            test_args: Optional additional arguments to pass to build tool
            env_config: Optional environment configuration

        Returns:
            TestResult for the test execution
        """
        set_command_context(f"run_test:{self.tool_name}:{test_name}")

        # Normalize test name and detect module
        module_hint, clean_name, class_for_search = self._normalize_test_name(test_name)
        module = module_hint or self.module_detector.detect_module(
            class_for_search, working_dir, sandbox
        )

        if module:
            logger.debug(f"Detected module for {test_name}: {module}")
        else:
            logger.debug(f"No module detected for {test_name}, running from repo root")

        # Detect build command (mvn/gradle wrapper)
        build_cmd = self._detect_build_command(sandbox, working_dir, env_config)

        # Build tool-specific command
        cmd = self._build_test_command(build_cmd, module, clean_name, test_args)
        logger.debug(f"Running {self.tool_name} command: {' '.join(cmd)}")

        # Execute command
        result = sandbox.run_command(
            cmd=cmd,
            cwd=working_dir,
            timeout=timeout,
            log_prefix="     ",
            env_config=env_config,
        )

        # Handle timeout (common logic)
        if result.timed_out:
            return self._create_timeout_result(test_name, timeout, result)

        # Parse output (tool-specific directories, common fallback)
        combined = result.stdout + result.stderr
        parsed = self._parse_output(
            sandbox=sandbox,
            working_dir=working_dir,
            stdout=combined,
            execution_time=result.duration,
            module=module,
            class_fqn=class_for_search,
        )

        # Update parsed result with actual execution results
        parsed.success = result.returncode == 0
        parsed.execution_time = result.duration
        parsed.raw_output = combined

        return parsed

    def _create_timeout_result(self, test_name: str, timeout: int, result) -> TestResult:
        """Create TestResult for timeout scenario.

        Args:
            test_name: Test name that timed out
            timeout: Timeout value in seconds
            result: ProcessManager result with timeout info

        Returns:
            TestResult indicating timeout failure
        """
        logger.error(f"{self.tool_name} test timed out after {timeout} seconds")
        timeout_result = TestResult(
            execution_time=result.duration,
            raw_output=result.stdout + result.stderr,
        )
        timeout_result.add_test(
            test_name=test_name,
            status=ResultStatus.FAILED,
            reason=f"{self.tool_name} test timed out after {timeout} seconds",
            details=[f"{self.tool_name} test timed out after {timeout} seconds"],
        )
        return timeout_result

    def _parse_output(
        self,
        sandbox,
        working_dir: Path,
        stdout: str,
        execution_time: float,
        module: str | None,
        class_fqn: str,
    ) -> TestResult:
        """Parse output with JUnit XML fallback to stdout parser.

        This method tries to parse JUnit XML reports from tool-specific directories,
        falling back to stdout parsing if XML is not available.

        Supports both local filesystem and container-based XML reading.

        Args:
            sandbox: Sandbox instance for container access
            working_dir: Project root directory
            stdout: Test output (stdout + stderr combined)
            execution_time: Execution time in seconds
            module: Module path or None
            class_fqn: Fully qualified class name

        Returns:
            TestResult from parsing
        """
        report_dirs = self._get_report_directories(working_dir, module)

        # Try XML parsing first from each report directory
        for reports_dir in report_dirs:
            try:
                # Parse JUnit XML (from container if sandbox provided, otherwise from local filesystem)
                source = "container" if sandbox is not None else "local filesystem"
                logger.debug(f"Attempting to parse XML from {source}: {reports_dir}")

                xml_result = parse_junit_report(reports_dir, class_fqn, sandbox=sandbox)

                if xml_result is not None:
                    if not xml_result.execution_time:
                        xml_result.execution_time = execution_time
                    logger.debug(
                        f"Successfully parsed {xml_result.total_tests} tests from {source} XML"
                    )
                    return xml_result
                logger.debug(f"XML parsing returned None for {reports_dir}")
            except Exception as e:
                logger.debug(f"XML parse failed for {reports_dir}: {trace_error(e)}")

        # Fallback to stdout parser
        logger.debug(f"Falling back to stdout parser for class: {class_fqn}")
        return self.output_parser.parse(stdout, class_fqn, execution_time)
