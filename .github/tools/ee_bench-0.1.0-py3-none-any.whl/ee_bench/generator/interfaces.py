"""Abstract base class for Provider plugins."""

from __future__ import annotations

from abc import ABC, abstractmethod


class Provider(ABC):
    """Abstract base class for data providers.

    Providers fetch, transform, or enrich data. Each provider exposes
    a single ``provide()`` method that accepts an optional item dict
    and keyword arguments, and returns or yields result dicts.
    """

    @abstractmethod
    def provide(self, item=None, **kwargs):
        """Provide data.

        Args:
            item: Optional input item dict from upstream.
            **kwargs: Provider-specific parameters.

        Returns:
            A dict, a list of dicts, or yields dicts.
        """
        ...
