"""Base module detection for multi-module Java projects.

This module provides the base class for detecting which module a test class
belongs to in multi-module projects.
"""

import json
import logging
from pathlib import Path
from typing import TYPE_CHECKING, ClassVar

if TYPE_CHECKING:
    from ee_bench_core.adapters import Sandbox

logger = logging.getLogger(__name__)


class ModuleDetector:
    """Base class for module detection in multi-module projects.

    This class provides a flexible scoring system for build tool preference.
    Subclasses can specify which build files to prioritize by passing scoring
    weights to the constructor.
    """

    # Common test source roots to search
    TEST_ROOTS: ClassVar[list[str]] = [
        "src/test/java",
        "src/test/kotlin",
        "src/test/groovy",
        "src/integrationTest/java",
        "src/integrationTest/kotlin",
        "src/integrationTest/groovy",
        "src/it/java",
        "src/it/kotlin",
        "src/it/groovy",
    ]

    # File extensions to check
    FILE_EXTENSIONS: ClassVar[list[str]] = ["java", "kt", "groovy"]

    def __init__(
        self,
        primary_build_files: list[str] | None = None,
        secondary_build_files: list[str] | None = None,
    ):
        """Initialize module detector with build file preferences.

        Args:
            primary_build_files: Build files to strongly prefer (score -5 each)
            secondary_build_files: Build files to weakly prefer (score -1 each)
        """
        self.primary_build_files = primary_build_files or []
        self.secondary_build_files = secondary_build_files or []
        self._build_file_cache: dict[Path, set[str]] | None = None
        self._cache_working_dir: Path | None = None

    def detect_module(
        self, class_fqn: str, working_dir: Path, sandbox: "Sandbox | None" = None
    ) -> str | None:
        """Detect module directory for a given class FQN.

        Args:
            class_fqn: Fully qualified class name (e.g., com.example.MyTest)
            working_dir: Project root directory
            sandbox: Optional sandbox instance for container-aware file operations

        Returns:
            Relative module path (e.g., "." for root, "module-name" for submodule),
            or None if not found
        """
        if not class_fqn:
            return None

        # Try to find modules.json in workspace directory (parent of working_dir) first
        workspace_dir = working_dir.parent
        modules_json_path = workspace_dir / "modules.json"

        # Check if modules.json exists in workspace directory (container-aware if sandbox provided)
        modules_json_exists = False
        if sandbox:
            result = sandbox.run_command(
                cmd=["test", "-f", str(modules_json_path)],
                cwd=workspace_dir if workspace_dir.exists() else working_dir,
                timeout=5,
            )
            modules_json_exists = result.returncode == 0
        else:
            modules_json_exists = modules_json_path.exists()

        # If not in workspace, try working_dir for backward compatibility
        if not modules_json_exists:
            modules_json_path = working_dir / "modules.json"
            if sandbox:
                result = sandbox.run_command(
                    cmd=["test", "-f", str(modules_json_path)],
                    cwd=working_dir,
                    timeout=5,
                )
                modules_json_exists = result.returncode == 0
            else:
                modules_json_exists = modules_json_path.exists()

        if modules_json_exists:
            logger.debug(
                f"Found modules.json at {modules_json_path}, attempting to detect module using it"
            )
            module = self._detect_module_from_json(
                class_fqn, working_dir, modules_json_path, sandbox
            )
            if module is not None:
                logger.debug(f"Module detected from modules.json: {module}")
                return module
            logger.debug("Failed to detect module from modules.json, falling back to file scanning")

        # Fallback to file system scanning
        return self._detect_module_fallback(class_fqn, working_dir, sandbox)

    def _detect_module_from_json(
        self,
        class_fqn: str,
        working_dir: Path,
        modules_json_path: Path,
        sandbox: "Sandbox | None" = None,
    ) -> str | None:
        """Detect module using modules.json file.

        Optimized with batch file checking and early exit.

        Args:
            class_fqn: Fully qualified class name
            working_dir: Project root directory
            modules_json_path: Path to modules.json file
            sandbox: Optional sandbox instance for container-aware file operations

        Returns:
            Module path or None if not found
        """
        try:
            # Read modules.json (container-aware if sandbox provided)
            if sandbox:
                result = sandbox.run_command(
                    cmd=["cat", str(modules_json_path)],
                    cwd=working_dir,
                    timeout=5,
                )
                if result.returncode != 0:
                    logger.debug(f"Failed to read modules.json from container: {result.stderr}")
                    return None
                modules = json.loads(result.stdout)
            else:
                with open(modules_json_path) as f:
                    modules = json.load(f)

            class_name = class_fqn.split(".")[-1]
            package_name = ".".join(class_fqn.split(".")[:-1])
            pkg_path = package_name.replace(".", "/") if package_name else ""

            # Build list of all candidate file paths across all modules
            candidates_to_check = []
            path_to_module = {}

            for module_name, _module_info in modules.items():
                if module_name == "root":
                    module_path = working_dir
                    module_rel = "."
                else:
                    module_path = working_dir / module_name
                    module_rel = module_name

                # Build candidate paths for this module
                for test_root in self.TEST_ROOTS:
                    for ext in self.FILE_EXTENSIONS:
                        if pkg_path:
                            test_file_path = (
                                module_path / test_root / pkg_path / f"{class_name}.{ext}"
                            )
                        else:
                            test_file_path = module_path / test_root / f"{class_name}.{ext}"

                        candidates_to_check.append(test_file_path)
                        path_to_module[test_file_path] = module_rel

            # Batch check all candidate files
            existing_files = self._batch_file_exists(candidates_to_check, sandbox)

            # Return first match (test files should be unique per module)
            if existing_files:
                # Pick the first existing file
                for file_path in existing_files:
                    if file_path in path_to_module:
                        module_rel = path_to_module[file_path]
                        logger.debug(f"Found test file {file_path} in module {module_rel}")
                        return module_rel

            return None

        except (json.JSONDecodeError, FileNotFoundError, KeyError) as e:
            logger.debug(f"Error reading modules.json: {e}")
            return None

    def _detect_module_fallback(
        self, class_fqn: str, working_dir: Path, sandbox: "Sandbox | None" = None
    ) -> str | None:
        """Fallback module detection using file system scanning.

        Args:
            class_fqn: Fully qualified class name
            working_dir: Project root directory
            sandbox: Optional sandbox instance for container-aware file operations

        Returns:
            Module path or None if not found
        """
        class_name = class_fqn.split(".")[-1]
        package_name = ".".join(class_fqn.split(".")[:-1])
        pkg_path = package_name.replace(".", "/") if package_name else ""

        logger.debug(f"Detecting module for {class_fqn}")
        logger.debug(f"  class_name: {class_name}")
        logger.debug(f"  package_name: {package_name}")
        logger.debug(f"  pkg_path: {pkg_path}")
        logger.debug(f"  working_dir: {working_dir}")

        candidates: list[Path] = []

        # Use container-aware file finding if sandbox is provided
        if sandbox:
            candidates = self._find_files_in_container(sandbox, working_dir, class_name, pkg_path)
        else:
            # Optimized local glob for non-container environments
            # Use single ** pattern but limit with rglob for better performance
            seen = set()
            for root in self.TEST_ROOTS:
                for ext in self.FILE_EXTENSIONS:
                    # Build target filename
                    if pkg_path:
                        target_file = f"{root}/{pkg_path}/{class_name}.{ext}"
                    else:
                        target_file = f"{root}/{class_name}.{ext}"

                    # Use a single optimized glob pattern
                    # Pattern: [*,*/*,*/*/*]/{target_file} covers most module depths
                    pattern = f"**/{target_file}"

                    logger.debug(f"  Trying glob pattern: {pattern}")
                    try:
                        # Use Path.rglob which is more efficient than glob with **
                        # Split pattern to use rglob properly
                        matches = working_dir.rglob(target_file)

                        for p in matches:
                            # Skip common build/cache directories
                            path_parts = p.parts
                            skip = False
                            for exclude in [
                                ".git",
                                ".idea",
                                "target",
                                "build",
                                "node_modules",
                                ".gradle",
                            ]:
                                if exclude in path_parts:
                                    skip = True
                                    break

                            if not skip and p.is_file() and p not in seen:
                                logger.debug(f"      Candidate: {p}")
                                candidates.append(p)
                                seen.add(p)
                                # Early exit after finding first match for performance
                                # Comment out if you need to find all matches for scoring
                                # break

                    except Exception as e:
                        logger.debug(f"    Glob error: {e}")

        if not candidates:
            logger.debug(f"  No candidates found for {class_fqn}")
            return None

        # Cache build files for all candidates before scoring
        self._cache_build_files(working_dir, candidates, sandbox)

        # Score candidates and pick the best one
        best_mod = None
        best_score = 10**9
        logger.debug(f"  Scoring {len(candidates)} candidates")
        for p in candidates:
            parts = list(p.parts)
            try:
                idx = parts.index("src")
            except ValueError:
                logger.debug(f"    Skipping {p} - no 'src' in path")
                continue
            mod_path = Path(*parts[:idx])
            module_rel = "." if mod_path == working_dir else str(mod_path.relative_to(working_dir))

            score, has_build_file = self._score_module(mod_path, module_rel, sandbox)
            logger.debug(
                f"    Module: {module_rel}, Score: {score}, Path: {mod_path}, Has build file: {has_build_file}"
            )

            if score < best_score or best_mod is None:
                best_score = score
                best_mod = module_rel

        logger.debug(f"  Best module: {best_mod} with score {best_score}")
        return best_mod

    def _find_files_in_container(
        self, sandbox: "Sandbox", working_dir: Path, class_name: str, pkg_path: str
    ) -> list[Path]:
        """Find test files inside container using find command.

        Optimized to use single unified find command instead of multiple separate commands.

        Args:
            sandbox: Sandbox instance for command execution
            working_dir: Project root directory
            class_name: Simple class name (e.g., "ProductServiceApiTests")
            pkg_path: Package path with slashes (e.g., "shop/microservices/core/product")

        Returns:
            List of Path objects for found test files
        """
        # Build single optimized find command with all patterns combined using -o (OR)
        # This reduces subprocess overhead from O(R*E) to O(1)
        cmd = ["find", "."]

        # Exclude common build/cache directories to speed up traversal
        exclude_dirs = [".git", ".idea", "target", "build", "node_modules", ".gradle"]
        for d in exclude_dirs:
            cmd.extend(["-path", f"*/{d}", "-prune", "-o"])

        # Add type file constraint
        cmd.extend(["-type", "f"])

        # Build pattern conditions for all combinations of test roots and extensions
        cmd.append("(")
        first = True
        for root in self.TEST_ROOTS:
            for ext in self.FILE_EXTENSIONS:
                if not first:
                    cmd.append("-o")
                first = False

                if pkg_path:
                    pattern = f"*/{root}/{pkg_path}/{class_name}.{ext}"
                else:
                    pattern = f"*/{root}/{class_name}.{ext}"
                cmd.extend(["-path", pattern])
        cmd.append(")")

        # Print results
        cmd.append("-print")

        logger.debug(f"  Unified find command: {' '.join(cmd)}")

        candidates: list[Path] = []

        try:
            result = sandbox.run_command(
                cmd=cmd,
                cwd=working_dir,
                timeout=15,  # Slightly longer timeout for single comprehensive search
            )

            if result.returncode == 0 and result.stdout.strip():
                # Parse find output (one file per line)
                for line in result.stdout.strip().split("\n"):
                    if line.strip():
                        # Convert relative path to absolute
                        # find returns paths like "./microservices/product-service/src/test/java/..."
                        file_path = working_dir / line.lstrip("./")
                        if file_path not in candidates:
                            logger.debug(f"    Found candidate: {file_path}")
                            candidates.append(file_path)
            else:
                logger.debug("    No matches found in unified search")

        except Exception as e:
            logger.debug(f"    Unified find command error: {e}")

        logger.debug(f"  Total candidates found in container: {len(candidates)}")
        return candidates

    def _file_exists(self, file_path: Path, sandbox: "Sandbox | None" = None) -> bool:
        """Check if a single file exists.

        Args:
            file_path: Path to check
            sandbox: Optional sandbox instance for container-aware checks

        Returns:
            True if file exists, False otherwise
        """
        if sandbox:
            result = sandbox.run_command(
                cmd=["test", "-f", str(file_path)],
                cwd=file_path.parent if file_path.parent.exists() else file_path,
                timeout=5,
            )
            return result.returncode == 0
        return file_path.exists()

    def _batch_file_exists(
        self, file_paths: list[Path], sandbox: "Sandbox | None" = None
    ) -> set[Path]:
        """Check existence of multiple files efficiently.

        Args:
            file_paths: List of file paths to check
            sandbox: Optional sandbox instance for container-aware checks

        Returns:
            Set of paths that exist
        """
        if not file_paths:
            return set()

        existing = set()

        if sandbox:
            # Batch check in container using single command
            # Use: for f in path1 path2 ...; do test -f "$f" && echo "$f"; done
            paths_str = " ".join(f'"{p}"' for p in file_paths)
            cmd = ["bash", "-c", f'for f in {paths_str}; do test -f "$f" && echo "$f"; done']

            try:
                result = sandbox.run_command(cmd=cmd, cwd=file_paths[0].parent, timeout=10)
                if result.returncode == 0 and result.stdout.strip():
                    for line in result.stdout.strip().split("\n"):
                        if line.strip():
                            existing.add(Path(line.strip()))
            except Exception as e:
                logger.debug(f"Batch file check error: {e}")
        else:
            # Local file system check
            for p in file_paths:
                if p.exists():
                    existing.add(p)

        return existing

    def _cache_build_files(
        self, working_dir: Path, candidates: list[Path], sandbox: "Sandbox | None" = None
    ) -> None:
        """Cache build file locations for all candidate module directories.

        Args:
            working_dir: Project root directory
            candidates: List of candidate test file paths
            sandbox: Optional sandbox instance for container-aware operations
        """
        # Reset cache if working directory changed
        if self._cache_working_dir != working_dir:
            self._build_file_cache = {}
            self._cache_working_dir = working_dir

        # Extract unique module paths from candidates
        module_paths = set()
        for p in candidates:
            parts = list(p.parts)
            try:
                idx = parts.index("src")
                mod_path = Path(*parts[:idx])
                module_paths.add(mod_path)
            except ValueError:
                continue

        # Build list of all build files to check
        all_build_files = self.primary_build_files + self.secondary_build_files
        files_to_check = []
        path_to_module = {}

        for mod_path in module_paths:
            if mod_path not in self._build_file_cache:
                self._build_file_cache[mod_path] = set()
                for build_file in all_build_files:
                    build_file_path = mod_path / build_file
                    files_to_check.append(build_file_path)
                    path_to_module[build_file_path] = (mod_path, build_file)

        # Batch check all build files
        if files_to_check:
            existing_files = self._batch_file_exists(files_to_check, sandbox)
            for file_path in existing_files:
                if file_path in path_to_module:
                    mod_path, build_file = path_to_module[file_path]
                    self._build_file_cache[mod_path].add(build_file)

    def _check_build_files(
        self,
        mod_path: Path,
        build_files: list[str],
        score_weight: int,
        file_type: str,
        sandbox: "Sandbox | None" = None,
    ) -> tuple[int, bool]:
        """Check for build files and calculate score adjustment.

        Args:
            mod_path: Absolute path to module
            build_files: List of build file names to check
            score_weight: Score adjustment per found file (negative for preference)
            file_type: Description of file type (e.g., "primary", "secondary")
            sandbox: Optional sandbox instance for container-aware file checks

        Returns:
            Tuple of (score_adjustment, has_any_file) where score_adjustment is negative
            for found files and has_any_file indicates if at least one file was found
        """
        score_adjustment = 0
        has_any_file = False

        # Use cached build files if available
        if self._build_file_cache is not None and mod_path in self._build_file_cache:
            cached_files = self._build_file_cache[mod_path]
            for build_file in build_files:
                if build_file in cached_files:
                    logger.debug(f"      Found {file_type} build file: {build_file} in {mod_path}")
                    score_adjustment += score_weight
                    has_any_file = True
        else:
            # Fallback to individual file checks if cache not available
            for build_file in build_files:
                build_file_path = mod_path / build_file
                if self._file_exists(build_file_path, sandbox):
                    logger.debug(f"      Found {file_type} build file: {build_file} in {mod_path}")
                    score_adjustment += score_weight
                    has_any_file = True

        return score_adjustment, has_any_file

    def _score_module(
        self, mod_path: Path, module_rel: str, sandbox: "Sandbox | None" = None
    ) -> tuple[int, bool]:
        """Score a module candidate (lower is better).

        Uses configured build file preferences to score modules.
        Uses cached build file information if available to avoid redundant file checks.

        Args:
            mod_path: Absolute path to module
            module_rel: Relative module path
            sandbox: Optional sandbox instance for container-aware file checks

        Returns:
            Tuple of (score, has_build_file) where score is lower for better matches
            and has_build_file indicates if any build file was found
        """
        score = 0
        has_build_file = False

        # Check primary build files (strong preference)
        primary_score, primary_found = self._check_build_files(
            mod_path, self.primary_build_files, -5, "primary", sandbox
        )
        score += primary_score
        has_build_file = has_build_file or primary_found

        # Check secondary build files (weak preference)
        secondary_score, secondary_found = self._check_build_files(
            mod_path, self.secondary_build_files, -1, "secondary", sandbox
        )
        score += secondary_score
        has_build_file = has_build_file or secondary_found

        # Prefer shallower modules
        depth = module_rel.count("/") if module_rel != "." else 0
        score += depth

        return score, has_build_file
