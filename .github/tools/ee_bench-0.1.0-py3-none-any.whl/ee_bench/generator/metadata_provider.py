"""EEBenchMetadataProvider — builds metadata.json for EE-bench instances."""

from __future__ import annotations

import ast
import json
from typing import Any

from ee_bench.generator.interfaces import Provider


def parse_json_field(value: str | list, default=None):
    """Parse a JSON string field into a Python object, or return as-is if already parsed.

    Handles both JSON syntax and Python repr syntax (single-quoted strings).
    """
    if default is None:
        default = []
    if isinstance(value, list):
        return value
    if not value or not isinstance(value, str):
        return default
    value = value.strip()
    if value.startswith("[") or value.startswith("{"):
        try:
            return json.loads(value)
        except (json.JSONDecodeError, TypeError):
            pass
        # Fall back to Python literal (handles single-quoted strings from HF)
        try:
            return ast.literal_eval(value)
        except (ValueError, SyntaxError):
            pass
    return default


def parse_list_field(value, default=None):
    """Parse a value into a list.

    Handles JSON arrays, Python repr lists, and comma-separated strings.
    """
    if default is None:
        default = []
    result = parse_json_field(value, default=value)
    if isinstance(result, list):
        return result
    if isinstance(result, str) and result:
        return [f.strip() for f in result.split(",") if f.strip()]
    return default


class EEBenchMetadataProvider(Provider):
    """Builds metadata.json content for EE-bench instances.

    The caller defines the full output structure via ``**kwargs``.
    The ``fields`` parameter specifies which ``item`` keys to extract
    into the ``fields`` section of the output.

    Example::

        provider.provide(
            item=item,
            version="1.0",
            instance_id=item["instance_id"],
            evaluation={"timeout_seconds": 600},
            fields=["repo_language", "issue_categories"],
        )
    """

    def provide(self, item=None, *, fields=None, **kwargs) -> str:
        """Build metadata.json content.

        Args:
            item: Item dict (source for ``fields`` extraction).
            fields: List of field name strings to extract from ``item``
                into the ``fields`` section of the output.
            **kwargs: Structural metadata keys placed directly in the output.

        Returns:
            JSON string.
        """
        item = item or {}
        metadata: dict[str, Any] = dict(kwargs)

        # Populate fields section from item
        fields_dict: dict[str, Any] = {}
        if fields:
            for key in fields:
                val = item.get(key, "")
                if val:
                    fields_dict[key] = parse_json_field(val, default=val)
        metadata["fields"] = fields_dict

        return json.dumps(metadata, indent=2)
