"""JVM EE-bench local environment configuration.

This module provides the JvmCodeLocalEnvironmentConfig class for JVM-specific
local evaluation environments with tool paths and versions.
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ee_bench_code_spec.local_env_config import CodeLocalEnvironmentConfig


@dataclass
class JvmCodeLocalEnvironmentConfig(CodeLocalEnvironmentConfig):
    """Configuration for JVM EE-bench local evaluation environments.

    Extends CodeLocalEnvironmentConfig with JVM-specific fields including
    Java, Maven, and Gradle installation paths and versions.

    Attributes:
        Inherited from CodeLocalEnvironmentConfig:
            workspace_dir: Local workspace directory path
            env_vars: Environment variables for execution
            repo: Repository name (owner/repo format)
            base_commit: Base commit hash
            project_dir: Project directory name
            language: Programming language (should be "java")

        JVM-specific attributes:
            java_home: Path to JDK installation
            java_version: Java version string (e.g., "17", "21")
            maven_home: Path to Maven installation (if using Maven)
            maven_version: Maven version string (e.g., "3.9.6")
            gradle_home: Path to Gradle installation (if using Gradle)
            gradle_version: Gradle version string (e.g., "8.5")
            build_system: Build system being used ("maven" or "gradle")
    """

    java_home: Path | None = None
    """Path to JDK installation"""

    java_version: str | None = None
    """Java version string (e.g., '17', '21')"""

    maven_home: Path | None = None
    """Path to Maven installation"""

    maven_version: str | None = None
    """Maven version string (e.g., '3.9.6')"""

    gradle_home: Path | None = None
    """Path to Gradle installation"""

    gradle_version: str | None = None
    """Gradle version string (e.g., '8.5')"""

    build_system: str | None = None
    """Build system being used ('maven' or 'gradle')"""

    def to_dict(self) -> dict[str, Any]:
        """Convert environment config to dictionary format.

        Returns:
            Dictionary representation of the environment configuration
        """
        result = super().to_dict()
        result.update(
            {
                "java_home": str(self.java_home) if self.java_home else None,
                "java_version": self.java_version,
                "maven_home": str(self.maven_home) if self.maven_home else None,
                "maven_version": self.maven_version,
                "gradle_home": str(self.gradle_home) if self.gradle_home else None,
                "gradle_version": self.gradle_version,
                "build_system": self.build_system,
            }
        )
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "JvmCodeLocalEnvironmentConfig":
        """Create JvmCodeLocalEnvironmentConfig from dictionary.

        Args:
            data: Dictionary containing environment configuration

        Returns:
            JvmCodeLocalEnvironmentConfig instance
        """
        return cls(
            workspace_dir=Path(data["workspace_dir"]),
            env_vars=data.get("env_vars", {}),
            repo=data.get("repo"),
            base_commit=data.get("base_commit"),
            project_dir=data.get("project_dir", "task_project"),
            language=data.get("language", "java"),
            java_home=Path(data["java_home"]) if data.get("java_home") else None,
            java_version=data.get("java_version"),
            maven_home=Path(data["maven_home"]) if data.get("maven_home") else None,
            maven_version=data.get("maven_version"),
            gradle_home=Path(data["gradle_home"]) if data.get("gradle_home") else None,
            gradle_version=data.get("gradle_version"),
            build_system=data.get("build_system"),
        )
