"""Output serialization utilities."""

from __future__ import annotations

import fnmatch
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterator

import yaml


@dataclass
class OutputTarget:
    """Specifies where and how to write records.

    Attributes:
        datapoint: Path template for the record JSON/JSONL.
            - Contains ``{{ }}`` → per-instance pretty JSON file.
            - Literal path → aggregate file (format from extension).
            - ``None`` → no datapoint output (artifacts only).
        artifacts: Optional map of record field/pattern → path template.
            Values in dict-type fields are unpacked to the target directory.
        fields: Reserved for v2 (field filtering). Currently unused.
    """

    datapoint: str | None = None
    artifacts: dict[str, str] | None = None
    fields: list[str] | None = None


def write_output(
    records: Iterator[dict[str, Any]],
    targets: list[OutputTarget],
) -> int:
    """Write records to all output targets in a single streaming pass.

    Args:
        records: Iterator of record dicts.
        targets: List of :class:`OutputTarget` instances.

    Returns:
        Total number of records written.
    """
    # Separate aggregate vs per-instance datapoint targets
    aggregate_handles: dict[int, _AggregateHandle] = {}
    for target in targets:
        if target.datapoint and not _is_template(target.datapoint):
            aggregate_handles[id(target)] = _open_aggregate(target.datapoint)

    count = 0
    for record in records:
        count += 1
        for target in targets:
            _write_record_to_target(record, target, aggregate_handles)

    # Flush and close aggregate handles
    for handle in aggregate_handles.values():
        handle.close()

    return count


def _normalize_output_config(output_config: Any) -> list[OutputTarget]:
    """Convert any output config shape to a list of OutputTarget.

    Supports:
    - ``list``: each item is an OutputTarget dict (new multi-target format)
    - ``dict`` with ``datapoint``/``artifacts``: single OutputTarget
    - ``dict`` with ``path``/``format``: legacy format → OutputTarget(datapoint=path)
    - ``None``: default → [OutputTarget(datapoint="out.jsonl")]
    """
    if isinstance(output_config, list):
        result = []
        for item in output_config:
            if isinstance(item, dict):
                result.append(OutputTarget(
                    datapoint=item.get("datapoint"),
                    artifacts=item.get("artifacts"),
                    fields=item.get("fields"),
                ))
            elif isinstance(item, OutputTarget):
                result.append(item)
        return result or [OutputTarget(datapoint="out.jsonl")]

    if isinstance(output_config, dict):
        if "datapoint" in output_config or "artifacts" in output_config:
            return [OutputTarget(
                datapoint=output_config.get("datapoint"),
                artifacts=output_config.get("artifacts"),
                fields=output_config.get("fields"),
            )]
        # Legacy format: {path: "...", format: "jsonl"}
        path = output_config.get("path", "out.jsonl")
        return [OutputTarget(datapoint=path)]

    return [OutputTarget(datapoint="out.jsonl")]


# ---------------------------------------------------------------------------
# Backward-compatible write_records (thin wrapper)
# ---------------------------------------------------------------------------

def write_records(
    records: Iterator[dict[str, Any]],
    path: Path,
    output_format: str = "jsonl",
) -> int:
    """Write records to a file in the specified format.

    Args:
        records: Iterator of record dictionaries to write.
        path: Output file path.
        output_format: Output format - "json", "jsonl", or "yaml".

    Returns:
        Number of records written.
    """
    target = OutputTarget(datapoint=str(path))
    # Force extension to match requested format for aggregate handling
    p = str(path)
    if output_format == "json" and not p.endswith(".json"):
        # Use legacy path — aggregate handle detects format from extension
        # For explicit format override, write directly
        return _write_format(records, path, output_format)
    elif output_format == "yaml" and not (p.endswith(".yaml") or p.endswith(".yml")):
        return _write_format(records, path, output_format)

    return write_output(records, [target])


def _write_format(records: Iterator[dict[str, Any]], path: Path, fmt: str) -> int:
    """Write records in explicit format (legacy compat)."""
    records_list = list(records)
    path.parent.mkdir(parents=True, exist_ok=True)
    if fmt == "yaml":
        with open(path, "w") as f:
            yaml.safe_dump(records_list, f, default_flow_style=False, allow_unicode=True)
    elif fmt == "json":
        with open(path, "w") as f:
            json.dump(records_list, f, ensure_ascii=False, indent=2)
    else:
        with open(path, "w") as f:
            for record in records_list:
                f.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")))
                f.write("\n")
    return len(records_list)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _is_template(path: str) -> bool:
    return "{{" in path


def _render_path(template: str, record: dict[str, Any]) -> str:
    """Render a Jinja2 path template with record fields."""
    from jinja2 import ChainableUndefined, Environment

    env = Environment(undefined=ChainableUndefined)
    env.filters["replace"] = lambda s, old, new: s.replace(old, new)
    return env.from_string(template).render(**record)


@dataclass
class _AggregateHandle:
    """Open file handle for an aggregate (non-per-instance) output target."""

    path: str
    fmt: str
    _file: Any = field(default=None, repr=False)
    _records: list[dict[str, Any]] = field(default_factory=list, repr=False)

    def write(self, record: dict[str, Any]) -> None:
        if self.fmt == "jsonl":
            self._file.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")))
            self._file.write("\n")
        else:
            self._records.append(record)

    def close(self) -> None:
        if self.fmt == "json":
            json.dump(self._records, self._file, ensure_ascii=False, indent=2)
        elif self.fmt in ("yaml", "yml"):
            yaml.safe_dump(self._records, self._file, default_flow_style=False, allow_unicode=True)
        if self._file:
            self._file.close()


def _open_aggregate(path: str) -> _AggregateHandle:
    """Open an aggregate file handle, detect format from extension."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    ext = p.suffix.lower().lstrip(".")
    fmt = ext if ext in ("json", "jsonl", "yaml", "yml") else "jsonl"
    f = open(p, "w")
    handle = _AggregateHandle(path=path, fmt=fmt, _file=f)
    return handle


def _write_record_to_target(
    record: dict[str, Any],
    target: OutputTarget,
    aggregate_handles: dict[int, _AggregateHandle],
) -> None:
    """Write one record to one target (datapoint + artifacts)."""
    # --- Datapoint ---
    if target.datapoint:
        if _is_template(target.datapoint):
            # Per-instance: render path, write pretty JSON
            out_path = _render_path(target.datapoint, record)
            p = Path(out_path)
            p.parent.mkdir(parents=True, exist_ok=True)
            with open(p, "w") as f:
                json.dump(record, f, ensure_ascii=False, indent=2)
        else:
            # Aggregate: append to open handle
            handle = aggregate_handles.get(id(target))
            if handle:
                handle.write(record)

    # --- Artifacts ---
    if target.artifacts:
        _write_artifacts(record, target.artifacts)


def _write_artifacts(record: dict[str, Any], artifacts: dict[str, str]) -> None:
    """Unpack artifact fields to disk."""
    # Track which top-level fields/entries have been written (for wildcard dedup)
    written: set[str] = set()

    # Process explicit (non-wildcard) patterns first
    explicit = {k: v for k, v in artifacts.items() if "*" not in k}
    wildcard = {k: v for k, v in artifacts.items() if "*" in k}

    for pattern, path_template in explicit.items():
        _write_artifact_pattern(record, pattern, path_template, written)

    for pattern, path_template in wildcard.items():
        _write_artifact_pattern(record, pattern, path_template, written)


def _write_artifact_pattern(
    record: dict[str, Any],
    pattern: str,
    path_template: str,
    written: set[str],
) -> None:
    """Write artifact entries matching a single pattern."""
    if "*" not in pattern:
        # Exact field or field/subpath
        parts = pattern.split("/", 1)
        field_name = parts[0]
        sub_pattern = parts[1] if len(parts) > 1 else None

        value = record.get(field_name)
        if value is None:
            return

        out_path = _render_path(path_template, record)

        if isinstance(value, dict):
            if sub_pattern:
                # Filter dict entries by sub_pattern
                for key, content in value.items():
                    if fnmatch.fnmatch(key, sub_pattern):
                        entry_key = f"{field_name}/{key}"
                        if entry_key not in written:
                            _write_file(Path(out_path) / key if out_path.endswith("/") else Path(out_path).parent / key, content)
                            written.add(entry_key)
            else:
                # Unpack all dict entries
                base = Path(out_path)
                if not out_path.endswith("/"):
                    base = base.parent / base.name
                for key, content in value.items():
                    entry_key = f"{field_name}/{key}"
                    if entry_key not in written:
                        _write_file(base / key, content)
                        written.add(entry_key)
        elif isinstance(value, str):
            if field_name not in written:
                _write_file(Path(out_path), value)
                written.add(field_name)

    elif "/" in pattern:
        # Pattern like "field/glob" or "field/sub/glob"
        slash_idx = pattern.index("/")
        field_name = pattern[:slash_idx]
        glob_pattern = pattern[slash_idx + 1:]

        value = record.get(field_name)
        if not isinstance(value, dict):
            return

        out_path = _render_path(path_template, record)
        base = Path(out_path)

        for key, content in value.items():
            if fnmatch.fnmatch(key, glob_pattern):
                entry_key = f"{field_name}/{key}"
                if entry_key not in written:
                    target_path = base / Path(key).name if out_path.endswith("/") else base.parent / Path(key).name
                    _write_file(target_path, content)
                    written.add(entry_key)

    else:
        # Top-level wildcard "*" — matches all dict-type record fields
        out_path = _render_path(path_template, record)
        base = Path(out_path)

        for field_name, value in record.items():
            if not isinstance(value, dict):
                continue
            for key, content in value.items():
                entry_key = f"{field_name}/{key}"
                if entry_key not in written:
                    _write_file(base / field_name / key, content)
                    written.add(entry_key)


def _write_file(path: Path, content: str) -> None:
    """Write string content to a file, creating parent dirs."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        f.write(content)


def format_record(record: dict[str, Any], output_format: str = "json") -> str:
    """Format a single record as a string.

    Args:
        record: Record dictionary to format.
        output_format: Output format - "json" or "yaml".

    Returns:
        Formatted string representation.
    """
    if output_format == "yaml":
        return yaml.safe_dump(record, default_flow_style=False, allow_unicode=True)
    else:
        return json.dumps(record, ensure_ascii=False, indent=2)
