"""Docker environment configuration.

This module provides base configuration for Docker-based environments.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional

from ee_bench_core.core.abc_types import EnvironmentConfig


@dataclass
class DockerEnvironmentConfig(EnvironmentConfig):
    """Base configuration for Docker-based evaluation environments.

    This class provides common fields for Docker environments including
    container management, image tracking, and workspace configuration.
    """

    instance_id: str
    """Unique identifier for the task instance"""

    image_name: str
    """Docker image name/tag for the environment"""

    workspace_dir: Optional[Path] = None
    """Workspace directory path (typically the project directory inside container)"""

    container_id: Optional[str] = None
    """Running container ID (if started)"""

    created_at: Optional[str] = None
    """ISO timestamp when environment was created"""

    related_images: Dict[str, str] = field(default_factory=dict)
    """Map of related image types to their names (e.g., 'base': 'base-image-name')"""

    labels: Dict[str, str] = field(default_factory=dict)
    """Docker labels for the environment image"""

    def get_base_image(self) -> Optional[str]:
        """Get base image name if available.

        Returns:
            Base image name or None if not set
        """
        return self.related_images.get("base")

    def set_base_image(self, image_name: str) -> None:
        """Set base image name.

        Args:
            image_name: Base image name to store
        """
        self.related_images["base"] = image_name

    def to_dict(self) -> Dict[str, Any]:
        """Convert environment config to dictionary format.

        Returns:
            Dictionary representation of the environment configuration
        """
        return {
            "instance_id": self.instance_id,
            "image_name": self.image_name,
            "workspace_dir": str(self.workspace_dir) if self.workspace_dir else None,
            "container_id": self.container_id,
            "created_at": self.created_at,
            "related_images": self.related_images,
            "labels": self.labels,
        }
