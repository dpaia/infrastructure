"""Base protocol provider interface for file operations.

This module defines the abstract base class for protocol providers that handle
different URI schemes (file://, http://, https://, hf://, etc.).
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import BinaryIO, Optional


class FileProtocolProvider(ABC):
    """Abstract base class for file protocol providers.

    Protocol providers handle loading and saving files from different sources
    (local filesystem, HTTP, HuggingFace, etc.) based on URI schemes.

    Each provider must implement:
    - schemes(): List of URI schemes it handles (e.g., ["http", "https"])
    - load(): Load content from a URI
    - save(): Save content to a URI (optional, can raise NotImplementedError)
    - exists(): Check if a resource exists at URI
    """

    # Plugin metadata for registry
    __provider_name__: str = ""
    __provider_description__: str = ""
    __provider_version__: str = "1.0.0"
    __provider_author__: str = ""
    __provider_schemes__: list = []

    @classmethod
    @abstractmethod
    def schemes(cls) -> list[str]:
        """Return list of URI schemes this provider handles.

        Returns:
            List of scheme strings (e.g., ["http", "https"])
        """
        pass

    @abstractmethod
    def load(
        self,
        uri: str,
        cache_path: Optional[Path] = None,
        **kwargs
    ) -> bytes:
        """Load content from URI.

        Args:
            uri: Full URI (e.g., "https://example.com/file.json")
            cache_path: Optional path to cache the downloaded file
            **kwargs: Provider-specific options

        Returns:
            File content as bytes

        Raises:
            FileNotFoundError: If resource doesn't exist
            IOError: If loading fails
        """
        pass

    @abstractmethod
    def save(
        self,
        uri: str,
        content: bytes,
        **kwargs
    ) -> str:
        """Save content to URI.

        Args:
            uri: Full URI or path where to save
            content: Content to save
            **kwargs: Provider-specific options

        Returns:
            Final URI/path where content was saved

        Raises:
            NotImplementedError: If provider doesn't support writing
            IOError: If saving fails
        """
        pass

    @abstractmethod
    def exists(self, uri: str, **kwargs) -> bool:
        """Check if resource exists at URI.

        Args:
            uri: Full URI to check
            **kwargs: Provider-specific options

        Returns:
            True if resource exists, False otherwise
        """
        pass

    def stream_load(
        self,
        uri: str,
        cache_path: Optional[Path] = None,
        **kwargs
    ) -> BinaryIO:
        """Stream content from URI (optional).

        Default implementation loads entire content into memory.
        Providers can override for true streaming support.

        Args:
            uri: Full URI
            cache_path: Optional cache path
            **kwargs: Provider-specific options

        Returns:
            Binary stream
        """
        from io import BytesIO
        content = self.load(uri, cache_path=cache_path, **kwargs)
        return BytesIO(content)
