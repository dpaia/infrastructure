"""New unified CLI with global --spec parameter and dynamic spec parameters.

This module provides the new multi-specification CLI that replaces
the old ee_bench.cli module. The new CLI uses a global --spec parameter
to select the evaluation specification, and passes all additional
arguments to the spec for flexible parameter handling.
"""

import json
import logging
from pathlib import Path

import click

from ee_bench_core.core.spec_registry import (
    auto_discover_specs,
    get_eval_spec,
    get_spec_info,
    list_available_specs,
)
from ee_bench_core.core.errors import SpecNotFoundError, EEBenchError
from ee_bench_core.core.utils import set_command_context
from ee_bench_core.core.utils.logging import setup_logging
from ee_bench_core.core.utils.argparse_ext import parse_extra_args

logger = logging.getLogger(__name__)


class SpecAwareCommand(click.Command):
    """Custom Click Command that dynamically adds spec-specific options.

    This command class checks if --spec is provided in the parent context
    and adds the spec's CLI parameters as Click options before showing help
    or parsing arguments.
    """

    def __init__(self, *args, command_name=None, **kwargs):
        """Initialize the command with command name for spec lookup.

        Args:
            command_name: Name of the command for spec parameter lookup
        """
        super().__init__(*args, **kwargs)
        self.command_name = command_name

    def parse_args(self, ctx, args):
        """Parse arguments and add spec-specific options if spec is provided."""
        # Try to get spec from parent context or environment
        spec_name = None
        if ctx.parent and "spec" in ctx.parent.params:
            spec_name = ctx.parent.params["spec"]

        # If spec is provided, add dynamic options
        if spec_name and self.command_name:
            try:
                auto_discover_specs()
                spec = get_eval_spec(spec_name)

                # Get spec parameters for this command
                params = spec.get_cli_parameters(self.command_name)

                # Add each parameter as a Click option
                for param in params:
                    names = param.get("names", [])
                    if not names:
                        continue

                    # Skip if option already exists
                    param_name = names[0].lstrip("-").replace("-", "_")
                    if any(p.name == param_name for p in self.params):
                        continue

                    param_type = param.get("type", str)
                    default = param.get("default")
                    help_text = param.get("help", "")
                    required = param.get("required", False)
                    is_flag = param.get("is_flag", False)

                    # For boolean, use flag
                    if param_type is bool or param_type == "bool" or is_flag:
                        option = click.Option(
                            names,
                            is_flag=True,
                            default=default if default is not None else False,
                            help=help_text,
                            expose_value=True,
                        )
                        self.params.append(option)
                        continue

                    # Convert type to Python type if it's a string
                    python_type = param_type
                    if isinstance(param_type, str):
                        if param_type == "int":
                            python_type = int
                        elif param_type == "float":
                            python_type = float
                        elif param_type == "str":
                            python_type = str
                        else:
                            python_type = str
                    # If it's already a Python type, use it as-is

                    # Create Click option for other types
                    option = click.Option(
                        names,
                        type=python_type,
                        default=default,
                        help=help_text,
                        required=required,
                        expose_value=True,
                    )
                    self.params.append(option)

            except Exception as e:
                # If spec loading fails, continue without dynamic options
                logger.debug(f"Failed to load dynamic options for {spec_name}: {e}")

        return super().parse_args(ctx, args)


@click.group()
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose logging")
@click.option("--log-file", type=click.Path(), help="Path to log file")
@click.option(
    "--spec",
    type=str,
    envvar="EE_BENCH_SPEC",
    help="Evaluation specification (e.g., swe-jvm). Can be set via EE_BENCH_SPEC env var.",
)
@click.pass_context
def cli(ctx, verbose, log_file, spec):
    """EE Benchmark CLI - Multi-specification evaluation framework.

    A unified CLI for running evaluations across different benchmark specifications.
    Use --spec to select the specification (e.g., swe-jvm).

    Examples:
        ee-bench --spec swe-jvm prepare-environment --dataset-name my-dataset.json
        ee-bench --spec swe-jvm run-evaluation --run-id exp-001 --predictions-path preds/
    """
    # Setup logging
    setup_logging(
        "DEBUG" if verbose else "INFO", log_file=Path(log_file) if log_file else None
    )

    # Auto-discover specs (ensures all specs are registered)
    # Specs are now loaded via entry points in pyproject.toml
    auto_discover_specs()

    # Store spec in context for child commands
    ctx.ensure_object(dict)
    ctx.obj["spec"] = spec
    ctx.obj["verbose"] = verbose


@cli.command()
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    help="Show detailed information including source and package details",
)
@click.pass_context
def list_specs(ctx, verbose):
    """List all available evaluation specifications.

    Shows all registered specifications with their names, descriptions,
    and versions. Use --verbose for additional metadata like source and package info.
    """
    try:
        specs = list_available_specs()

        if not specs:
            click.echo("No specifications registered.")
            return

        click.echo("Available specifications:\n")

        for spec_name in specs:
            info = get_spec_info(spec_name)
            click.echo(f"  {click.style(spec_name, fg='green', bold=True)}")
            click.echo(f"    Description: {info['description']}")
            click.echo(f"    Version: {info['version']}")
            click.echo(f"    Class: {info['class_name']}")

            if verbose:
                click.echo(f"    Source: {info['source']}")
                click.echo(f"    Enabled: {info['enabled']}")

                if info.get("author"):
                    click.echo(f"    Author: {info['author']}")
                if info.get("homepage"):
                    click.echo(f"    Homepage: {info['homepage']}")
                if info.get("package_name"):
                    click.echo(f"    Package: {info['package_name']}")
                if info.get("entry_point_name"):
                    click.echo(f"    Entry Point: {info['entry_point_name']}")

            click.echo()

    except Exception as e:
        logger.error(f"Failed to list specs: {e}")
        raise click.ClickException(str(e))


@cli.command()
@click.argument("spec_name")
@click.option("--command", help="Show parameters for specific command")
@click.pass_context
def spec_help(ctx, spec_name, command):
    """Show detailed help for a specification.

    Displays information about a specification including available commands
    and their parameters.

    Arguments:
        SPEC_NAME: Name of the specification to show help for
    """
    try:
        spec = get_eval_spec(spec_name)
        info = get_spec_info(spec_name)

        click.echo(f"\n{click.style(info['name'], fg='green', bold=True)}")
        click.echo(f"{info['description']}\n")
        click.echo(f"Version: {info['version']}")
        click.echo(f"Framework version required: {info['framework_version_min']}")
        click.echo()

        if command:
            # Show parameters for specific command
            try:
                params = spec.get_cli_parameters(command)
                click.echo(f"Parameters for command '{command}':\n")

                if not params:
                    click.echo("  No spec-specific parameters for this command.")
                else:
                    for param in params:
                        names = param.get("names", [])
                        param_type = param.get("type", "string")
                        default = param.get("default")
                        help_text = param.get("help", "No description")
                        required = param.get("required", False)

                        names_str = ", ".join(str(n) for n in names)
                        click.echo(f"  {names_str}")
                        click.echo(
                            f"    Type: {param_type.__name__ if hasattr(param_type, '__name__') else param_type}"
                        )
                        if required:
                            click.echo("    Required: yes")
                        if default is not None:
                            click.echo(f"    Default: {default}")
                        click.echo(f"    Help: {help_text}")
                        click.echo()

            except Exception as e:
                click.echo(f"Error getting parameters for command '{command}': {e}")
        else:
            click.echo("Available commands:")
            click.echo("  - prepare-environment")
            click.echo("  - run-evaluation")
            click.echo()
            click.echo("Use --command to see parameters for a specific command.")
            click.echo(
                "Example: ee-bench spec-help swe-jvm --command prepare-environment"
            )

    except SpecNotFoundError as e:
        raise click.ClickException(str(e))
    except Exception as e:
        logger.error(f"Failed to show spec help: {e}")
        raise click.ClickException(str(e))


@cli.command(
    cls=SpecAwareCommand,
    command_name="prepare-environment",
    context_settings={"ignore_unknown_options": True},
)
@click.option(
    "--dataset-name", required=True, help="Name of dataset or path to JSON file"
)
@click.option(
    "--instance-ids",
    multiple=True,
    help="Instance IDs to prepare (can be specified multiple times or comma-separated)",
)
@click.argument("spec_args", nargs=-1, type=click.UNPROCESSED)
@click.pass_context
def prepare_environment(ctx, dataset_name, instance_ids, spec_args, **kwargs):
    """Prepare evaluation environments for task instances.

    Sets up Docker images or other environments required for evaluation.
    Requires --spec to be specified.

    For spec-specific options, use: ee-bench spec-help <spec> --command prepare-environment

    \b
    Examples:
        ee-bench --spec swe-jvm prepare-environment --dataset-name my-dataset.json
        ee-bench --spec swe-jvm prepare-environment --dataset-name data.json --instance-ids task-001,task-002 --max-workers 8
    """
    spec_name = ctx.obj.get("spec")

    if not spec_name:
        raise click.UsageError(
            "Specification not provided. Use --spec parameter or set EE_BENCH_SPEC environment variable.\n"
            "Example: ee-bench --spec swe-jvm prepare-environment --dataset-name my-dataset.json\n"
            "Available specs: " + ", ".join(list_available_specs())
        )

    try:
        # Get the specification
        spec = get_eval_spec(spec_name)
        logger.info(f"Using specification: {spec_name} ({spec.description})")
        set_command_context(spec.name)

        # Normalize instance IDs from multiple invocations or comma/space separated lists
        ids: list[str] = []
        for item in instance_ids:
            if isinstance(item, (list, tuple)):
                ids.extend([str(x) for x in item])
            elif isinstance(item, str):
                for part in item.replace(",", " ").split():
                    if part:
                        ids.append(part)

        # Parse spec-specific arguments from SPEC_ARGS
        spec_kwargs = _parse_spec_args(spec_args)

        # Convert kwargs types based on spec parameter definitions
        typed_kwargs = _convert_kwargs_types(kwargs, spec, "prepare-environment")

        # Merge with kwargs from dynamically added options (higher priority)
        # Skip None values to let spec use its own defaults
        spec_kwargs.update({k: v for k, v in typed_kwargs.items() if v is not None})

        click.echo(f"Dataset: {dataset_name}")
        if ids:
            click.echo(f"Instance IDs: {', '.join(ids)}")
        else:
            click.echo("Preparing all instances in dataset")

        # Call spec's prepare_environment method
        result = spec.prepare_environment(
            dataset_name=dataset_name, instance_ids=ids, **spec_kwargs
        )

        # Show results
        click.echo(
            f"\n{click.style('Environment Preparation Complete', fg='green', bold=True)}"
        )
        click.echo(f"Total: {result.total_count}")
        click.echo(f"Successful: {click.style(str(result.success_count), fg='green')}")
        click.echo(f"Failed: {click.style(str(result.failure_count), fg='red')}")

        if result.errors:
            click.echo("\nFailures:")
            for instance_id, error in result.errors.items():
                click.echo(f"  {instance_id}: {error}")

        # Print result as JSON
        click.echo("\nResult:")
        click.echo(json.dumps(result.to_dict(), indent=2))

        # Exit with non-zero code if all preparations failed
        if result.total_count > 0 and result.success_count == 0:
            raise click.ClickException("All environment preparations failed")

    except click.ClickException:
        # Re-raise ClickException without additional logging
        raise
    except SpecNotFoundError as e:
        raise click.ClickException(str(e))
    except EEBenchError as e:
        logger.error(f"Evaluation framework error: {e}")
        raise click.ClickException(str(e))
    except Exception as e:
        logger.error(f"Failed to prepare environment: {e}", exc_info=True)
        raise click.ClickException(f"Failed to prepare environment: {e}")


@cli.command(
    cls=SpecAwareCommand,
    command_name="run-evaluation",
    context_settings={"ignore_unknown_options": True},
)
@click.option(
    "--dataset-name", required=True, help="Name of dataset or path to JSON file"
)
@click.option(
    "--instance-ids",
    multiple=True,
    help="Instance IDs to evaluate (can be specified multiple times or comma-separated)",
)
@click.option(
    "--run-id", required=True, help="Unique identifier for this evaluation run"
)
@click.argument("spec_args", nargs=-1, type=click.UNPROCESSED)
@click.pass_context
def run_evaluation(ctx, dataset_name, instance_ids, run_id, spec_args, **kwargs):
    """Run evaluations for task instances.

    Evaluates predictions against task instances and generates reports.
    Requires --spec to be specified.

    For spec-specific options, use: ee-bench spec-help <spec> --command run-evaluation

    \b
    Examples:
        ee-bench --spec swe-jvm run-evaluation --dataset-name data.json --run-id exp-001 --predictions-path preds/
        ee-bench --spec swe-jvm run-evaluation --dataset-name data.json --run-id exp-002 --predictions-path preds/ --instance-ids task-001,task-002 --timeout 3600
    """
    spec_name = ctx.obj.get("spec")

    if not spec_name:
        raise click.UsageError(
            "Specification not provided. Use --spec parameter or set EE_BENCH_SPEC environment variable.\n"
            "Example: ee-bench --spec swe-jvm run-evaluation --run-id exp-001 --predictions-path preds/ --dataset-name data.json\n"
            "Available specs: " + ", ".join(list_available_specs())
        )

    try:
        # Get the specification
        spec = get_eval_spec(spec_name)
        logger.info(f"Using specification: {spec_name} ({spec.description})")
        set_command_context(spec.name)

        # Normalize instance IDs
        ids: list[str] = []
        for item in instance_ids:
            if isinstance(item, (list, tuple)):
                ids.extend([str(x) for x in item])
            elif isinstance(item, str):
                for part in item.replace(",", " ").split():
                    if part:
                        ids.append(part)

        # Parse spec-specific arguments from SPEC_ARGS
        spec_kwargs = _parse_spec_args(spec_args)

        # Convert kwargs types based on spec parameter definitions
        typed_kwargs = _convert_kwargs_types(kwargs, spec, "run-evaluation")

        # Merge with kwargs from dynamically added options (higher priority)
        # Skip None values to let spec use its own defaults
        spec_kwargs.update({k: v for k, v in typed_kwargs.items() if v is not None})

        # Validate required predictions-path
        if "predictions_path" not in spec_kwargs:
            raise click.UsageError(
                "Missing required parameter: --predictions-path\n"
                "Example: ee-bench --spec swe-jvm run-evaluation --run-id exp-001 --predictions-path preds/ --dataset-name data.json"
            )

        click.echo(f"Dataset: {dataset_name}")
        click.echo(f"Run ID: {run_id}")
        click.echo(f"Predictions path: {spec_kwargs.get('predictions_path')}")
        if ids:
            click.echo(f"Instance IDs: {', '.join(ids)}")
        else:
            click.echo("Evaluating all instances with predictions")

        # Call spec's run_evaluation method
        result = spec.run_evaluation(
            dataset_name=dataset_name, instance_ids=ids, run_id=run_id, **spec_kwargs
        )

        # Show results
        click.echo(f"\n{click.style('Evaluation Complete', fg='green', bold=True)}")

        if hasattr(result, "total_tasks"):
            # FinalReport format
            click.echo(f"Total tasks: {result.total_tasks}")
            click.echo(
                f"Successful: {click.style(str(result.successful_tasks), fg='green')}"
            )
            click.echo(f"Failed: {click.style(str(result.failed_tasks), fg='red')}")
            click.echo(f"Skipped: {result.skipped_tasks}")

            # Show report path (absolute path)
            report_dir = Path(spec_kwargs.get("report_dir", "./reports")).resolve()
            report_path = report_dir / f"{run_id}.json"
            click.echo(f"\nReport saved to: {report_path}")

            # Print report contents
            import json

            if report_path.exists():
                click.echo(f"\n{click.style('Report Contents:', fg='cyan', bold=True)}")
                with open(report_path, "r") as f:
                    report_data = json.load(f)
                    click.echo(json.dumps(report_data, indent=2))

            # Exit with non-zero code if any evaluation failed
            if result.failed_tasks > 0:
                raise click.ClickException(
                    f"{result.failed_tasks} evaluation(s) failed"
                )
        else:
            # Fallback for other result formats
            click.echo(f"Results: {result}")

    except click.ClickException:
        # Re-raise ClickException without additional logging
        raise
    except SpecNotFoundError as e:
        raise click.ClickException(str(e))
    except EEBenchError as e:
        logger.error(f"Evaluation framework error: {e}")
        raise click.ClickException(str(e))
    except Exception as e:
        logger.error(f"Failed to run evaluation: {e}", exc_info=True)
        raise click.ClickException(f"Failed to run evaluation: {e}")


@cli.command(context_settings={"ignore_unknown_options": True})
@click.option(
    "--dataset-name", required=True, help="Name of dataset or path to JSON file"
)
@click.option(
    "--instance-ids",
    multiple=True,
    help="Instance IDs to clean (can be specified multiple times or comma-separated)",
)
@click.argument("spec_args", nargs=-1, type=click.UNPROCESSED)
@click.pass_context
def clean_environment(ctx, dataset_name, instance_ids, spec_args):
    """Clean evaluation environments.

    Removes Docker containers, images, and other resources for task instances.
    Requires --spec to be specified.

    \b
    Common options:
        --max-workers INT  Max workers for parallel processing

    For spec-specific options, use: ee-bench spec-help <spec> --command clean-environment

    \b
    Examples:
        ee-bench --spec swe-jvm clean-environment --dataset-name my-dataset.json
        ee-bench --spec swe-jvm clean-environment --dataset-name data.json --instance-ids task-001,task-002
    """
    spec_name = ctx.obj.get("spec")

    if not spec_name:
        raise click.UsageError(
            "Specification not provided. Use --spec parameter or set EE_BENCH_SPEC environment variable.\n"
            "Example: ee-bench --spec swe-jvm clean-environment --dataset-name my-dataset.json\n"
            "Available specs: " + ", ".join(list_available_specs())
        )

    try:
        # Get the specification
        spec = get_eval_spec(spec_name)
        logger.info(f"Using specification: {spec_name} ({spec.description})")

        # Normalize instance IDs
        ids: list[str] = []
        for item in instance_ids:
            if isinstance(item, (list, tuple)):
                ids.extend([str(x) for x in item])
            elif isinstance(item, str):
                for part in item.replace(",", " ").split():
                    if part:
                        ids.append(part)

        # Parse spec-specific arguments
        spec_kwargs = _parse_spec_args(spec_args)

        click.echo(f"Dataset: {dataset_name}")
        if ids:
            click.echo(f"Instance IDs: {', '.join(ids)}")
        else:
            click.echo("Cleaning all environments")

        # Get dataset manager and environment manager from spec
        dataset_mgr = spec.get_dataset_manager()
        env_mgr = spec.get_environment_manager()

        # Resolve instances
        if ids:
            configs = [
                dataset_mgr.get_dataset_instance(instance_id, dataset_name=dataset_name)
                for instance_id in ids
            ]
        else:
            configs = dataset_mgr.list_dataset_instances(dataset_name=dataset_name)

        click.echo(f"\nCleaning {len(configs)} environments...")

        # Clean environments
        failed = 0
        for config in configs:
            try:
                env_mgr.clean_environment(config, **spec_kwargs)
                click.echo(f"  ✓ {config.instance_id}")
            except Exception as e:
                click.echo(f"  ✗ {config.instance_id}: {e}")
                failed += 1

        click.echo(f"\n{click.style('Cleanup Complete', fg='green', bold=True)}")
        click.echo(f"Successful: {click.style(str(len(configs) - failed), fg='green')}")
        if failed > 0:
            click.echo(f"Failed: {click.style(str(failed), fg='red')}")

    except SpecNotFoundError as e:
        raise click.ClickException(str(e))
    except EEBenchError as e:
        logger.error(f"Evaluation framework error: {e}")
        raise click.ClickException(str(e))
    except Exception as e:
        logger.error(f"Failed to clean environment: {e}", exc_info=True)
        raise click.ClickException(f"Failed to clean environment: {e}")


def _parse_spec_args(spec_args):
    """Parse spec-specific arguments from UNPROCESSED args.

    Uses core.utils.argparse_ext.parse_extra_args for parsing, then adds
    type conversion for common types (int, float, bool).

    Args:
        spec_args: Tuple of unprocessed arguments

    Returns:
        Dict of parsed arguments with converted types

    Examples:
        ("--max-workers", "8", "--force-rebuild") -> {"max_workers": 8, "force_rebuild": True}
        ("--timeout", "3600") -> {"timeout": 3600}
    """
    # Use existing argparse_ext parser
    parsed = parse_extra_args(list(spec_args))

    # Convert types for known patterns
    result = {}
    for key, value in parsed.items():
        if isinstance(value, bool):
            result[key] = value
        elif isinstance(value, list):
            # Convert list values
            result[key] = [_convert_value(v) for v in value]
        else:
            result[key] = _convert_value(value)

    return result


def _convert_value(value):
    """Convert string value to appropriate type.

    Args:
        value: String value to convert

    Returns:
        Converted value (bool, int, float, or original string)
    """
    if not isinstance(value, str):
        return value

    # Try boolean
    if value.lower() in ("true", "false"):
        return value.lower() == "true"

    # Try integer
    if value.isdigit() or (value.startswith("-") and value[1:].isdigit()):
        return int(value)

    # Try float
    try:
        return float(value)
    except ValueError:
        pass

    # Return as string
    return value


def _convert_kwargs_types(kwargs: dict, spec, command_name: str) -> dict:
    """Convert kwargs values to their correct types based on spec parameters.

    Args:
        kwargs: Dictionary of keyword arguments to convert
        spec: The evaluation spec instance
        command_name: Name of the command (e.g., 'prepare-environment')

    Returns:
        Dictionary with values converted to correct types
    """
    result = {}

    try:
        # Get spec parameters to know the expected types
        params = spec.get_cli_parameters(command_name)
        param_types = {}

        for param in params:
            names = param.get("names", [])
            if not names:
                continue

            # Get parameter name (remove -- and convert to snake_case)
            param_name = names[0].lstrip("-").replace("-", "_")
            param_type = param.get("type", "str")
            param_types[param_name] = param_type

        logger.debug(f"param_types map: {param_types}")

        # Convert each kwarg based on its expected type
        for key, value in kwargs.items():
            try:
                if key not in param_types:
                    # Unknown parameter, try auto-detect
                    result[key] = (
                        _convert_value(value) if isinstance(value, str) else value
                    )
                    continue

                expected_type = param_types[key]

                # Convert based on expected type (can be string or Python type)
                if expected_type == "int" or expected_type is int:
                    result[key] = int(value) if isinstance(value, str) else value
                elif expected_type == "float" or expected_type is float:
                    result[key] = float(value) if isinstance(value, str) else value
                elif expected_type == "bool" or expected_type is bool:
                    if isinstance(value, str):
                        result[key] = value.lower() in ("true", "1", "yes", "false")
                    else:
                        result[key] = bool(value)
                else:
                    result[key] = value
            except Exception as e:
                logger.debug(f"Failed to convert {key}={value} to {expected_type}: {e}")
                # Keep original value if conversion fails
                result[key] = value

    except Exception as e:
        logger.error(f"Failed to convert kwargs types: {e}", exc_info=True)
        # Fall back to original kwargs if conversion fails
        return kwargs

    return result


@cli.command()
@click.option("--instance-id", required=True, help="Task instance identifier")
@click.option(
    "--evaluator-name",
    required=True,
    help="Name of the evaluator that produced this result",
)
@click.option("--run-id", required=True, help="Evaluation run identifier")
@click.option(
    "--status",
    required=True,
    type=click.Choice(["success", "failed", "error", "timeout", "skipped"]),
    help="Evaluation status",
)
@click.option("--data", type=click.File("r"), help="JSON file with result data")
@click.option("--message", help="Result message")
@click.option("--error", help="Error message if failed or error")
@click.option(
    "--storage-dir", type=click.Path(), help="Storage directory for persistent results"
)
@click.pass_context
def submit_evaluator_result(
    ctx, instance_id, evaluator_name, run_id, status, data, message, error, storage_dir
):
    """Submit result from external/async evaluator.

    This endpoint allows external systems to submit evaluation results
    after async evaluators have completed their work.

    \b
    Examples:
        # Submit successful result
        ee-bench submit-evaluator-result \\
            --instance-id task-001 \\
            --evaluator-name security_scan \\
            --run-id eval-123 \\
            --status success \\
            --message "Security scan passed" \\
            --data result.json

        # Submit failed result
        ee-bench submit-evaluator-result \\
            --instance-id task-001 \\
            --evaluator-name quality_check \\
            --run-id eval-123 \\
            --status failed \\
            --message "Quality check failed" \\
            --error "Code complexity too high"
    """
    from ee_bench_core.core.eval import (
        EvaluatorResult,
        EvaluatorStatus,
        get_evaluation_tracker,
    )
    from pathlib import Path

    try:
        # Load result data
        result_data = {}
        if data:
            try:
                result_data = json.load(data)
            except json.JSONDecodeError as e:
                raise click.UsageError(f"Invalid JSON in data file: {e}")

        # Create evaluator result
        evaluator_result = EvaluatorResult(
            evaluator_name=evaluator_name,
            status=EvaluatorStatus[status.upper()],
            message=message or f"Evaluation {status}",
            data=result_data,
            error=error,
        )

        # Get evaluation tracker
        tracker_storage_dir = Path(storage_dir) if storage_dir else None
        tracker = get_evaluation_tracker(tracker_storage_dir)

        # Submit result
        tracker.submit_result(
            instance_id=instance_id,
            run_id=run_id,
            evaluator_name=evaluator_name,
            result=evaluator_result,
        )

        click.echo(
            f"✓ Result submitted for {instance_id}/{run_id}/{evaluator_name}: {status}"
        )

        # Show result summary
        if result_data:
            click.echo(f"  Data keys: {', '.join(result_data.keys())}")
        if error:
            click.echo(f"  Error: {error}")

    except Exception as e:
        logger.error(f"Failed to submit evaluator result: {e}", exc_info=True)
        raise click.ClickException(str(e))


if __name__ == "__main__":
    cli()
