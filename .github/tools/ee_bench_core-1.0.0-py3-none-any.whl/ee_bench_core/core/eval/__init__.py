"""Evaluation framework for EE-Benchmark.

This package provides the evaluator pipeline architecture for building
flexible, composable evaluation workflows.
"""

from .evaluator import (
    Evaluator,
    EvaluationContext,
    EvaluatorResult,
    EvaluatorStatus,
    EvaluatorDependency,
    DependencyPosition,
)
from .evaluator_validator import EvaluatorValidator
from .evaluator_runner import (
    EvaluationRunner as PipelineRunner,
    PipelineEvaluationResult,
)
from .base_evaluation_runner import BaseEvaluationRunner
from .evaluator_registry import (
    EvaluatorRegistry,
    EvaluatorMetadata,
    get_global_registry,
    register_evaluator,
)
from .environment_configurer import EnvironmentConfigurer
from .environment_configurer_registry import (
    EnvironmentConfigurerRegistry,
    EnvironmentConfigurerMetadata,
    get_global_registry as get_configurer_registry,
    register_configurer,
)
from .evaluation_tracker import EvaluationTracker, get_evaluation_tracker

__all__ = [
    # Core Evaluator Framework
    "Evaluator",
    "EvaluationContext",
    "EvaluatorResult",
    "EvaluatorStatus",
    "EvaluatorDependency",
    "DependencyPosition",
    # Validation and Execution
    "EvaluatorValidator",
    "PipelineRunner",
    "PipelineEvaluationResult",
    "BaseEvaluationRunner",
    # Registry and Plugins
    "EvaluatorRegistry",
    "EvaluatorMetadata",
    "get_global_registry",
    "register_evaluator",
    # Environment Configuration
    "EnvironmentConfigurer",
    "EnvironmentConfigurerRegistry",
    "EnvironmentConfigurerMetadata",
    "get_configurer_registry",
    "register_configurer",
    # Async Evaluation Tracking
    "EvaluationTracker",
    "get_evaluation_tracker",
]
