"""Adapters for shared integrations across specifications.

This package contains reusable adapters for common operations like Docker,
Git, patch management, and test running. These adapters can be used by
any specification implementation.
"""

from .docker import DockerAdapter
from .docker_env_config import DockerEnvironmentConfig
from .docker_evaluation_runner import DockerEvaluationRunner
from .docker_process_manager import DockerProcessManager

__all__ = [
    # Docker
    "DockerAdapter",
    "DockerEnvironmentConfig",
    "DockerEvaluationRunner",
    "DockerProcessManager",
]
