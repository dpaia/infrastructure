"""Dictionary and kwargs utility functions."""

from typing import Any, Dict, Iterable, Optional, Callable


def filter_kwargs(
    kwargs: Dict[str, Any],
    exclude: Optional[Iterable[str]] = None,
    include: Optional[Iterable[str]] = None,
    predicate: Optional[Callable[[str, Any], bool]] = None,
) -> Dict[str, Any]:
    """Filter kwargs dictionary by excluding/including keys or using a predicate.

    This utility helps avoid "duplicate argument" errors when passing kwargs
    to functions that already have some parameters defined.

    Args:
        kwargs: Original kwargs dictionary to filter
        exclude: Keys to exclude from result (mutually exclusive with include)
        include: Keys to include in result (mutually exclusive with exclude)
        predicate: Optional function(key, value) -> bool to filter entries
                  If provided, only entries where predicate returns True are included

    Returns:
        Filtered kwargs dictionary

    Raises:
        ValueError: If both exclude and include are specified

    Examples:
        # Exclude specific keys
        >>> kwargs = {"a": 1, "b": 2, "c": 3}
        >>> filter_kwargs(kwargs, exclude=["b", "c"])
        {"a": 1}

        # Include only specific keys
        >>> filter_kwargs(kwargs, include=["a", "b"])
        {"a": 1, "b": 2}

        # Filter None values
        >>> kwargs = {"a": 1, "b": None, "c": 3}
        >>> filter_kwargs(kwargs, predicate=lambda k, v: v is not None)
        {"a": 1, "c": 3}

        # Combine exclude with predicate
        >>> kwargs = {"a": 1, "b": None, "c": 3, "d": 4}
        >>> filter_kwargs(
        ...     kwargs,
        ...     exclude=["d"],
        ...     predicate=lambda k, v: v is not None
        ... )
        {"a": 1, "c": 3}
    """
    if exclude is not None and include is not None:
        raise ValueError("Cannot specify both 'exclude' and 'include' parameters")

    result = {}

    for key, value in kwargs.items():
        # Apply exclude/include filter
        if exclude is not None and key in exclude:
            continue
        if include is not None and key not in include:
            continue

        # Apply predicate filter
        if predicate is not None and not predicate(key, value):
            continue

        result[key] = value

    return result


def exclude_keys(kwargs: Dict[str, Any], *keys: str) -> Dict[str, Any]:
    """Shorthand for filtering kwargs by excluding specific keys.

    Args:
        kwargs: Original kwargs dictionary
        *keys: Keys to exclude

    Returns:
        Filtered kwargs dictionary

    Examples:
        >>> kwargs = {"a": 1, "b": 2, "c": 3}
        >>> exclude_keys(kwargs, "b", "c")
        {"a": 1}
    """
    return filter_kwargs(kwargs, exclude=keys)


def include_keys(kwargs: Dict[str, Any], *keys: str) -> Dict[str, Any]:
    """Shorthand for filtering kwargs by including only specific keys.

    Args:
        kwargs: Original kwargs dictionary
        *keys: Keys to include

    Returns:
        Filtered kwargs dictionary

    Examples:
        >>> kwargs = {"a": 1, "b": 2, "c": 3}
        >>> include_keys(kwargs, "a", "b")
        {"a": 1, "b": 2}
    """
    return filter_kwargs(kwargs, include=keys)


def filter_none_values(kwargs: Dict[str, Any]) -> Dict[str, Any]:
    """Filter out entries with None values.

    Args:
        kwargs: Original kwargs dictionary

    Returns:
        Filtered kwargs dictionary without None values

    Examples:
        >>> kwargs = {"a": 1, "b": None, "c": 3}
        >>> filter_none_values(kwargs)
        {"a": 1, "c": 3}
    """
    return filter_kwargs(kwargs, predicate=lambda k, v: v is not None)
