"""Regression detector evaluator for measuring test regressions.

This module provides an evaluator that compares current test results
with baseline results to detect regressions (tests that passed before
but now fail after prediction).
"""

import logging
from typing import Dict, List, Optional, Set

from ee_bench_core.adapters.testrunner_base import ResultStatus, TestResult
from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig, EvalSpec
from ee_bench_core.core.eval.evaluator import (
    EvaluationContext,
    Evaluator,
    EvaluatorResult,
    EvaluatorStatus,
)

logger = logging.getLogger(__name__)


class RegressionDetector(Evaluator):
    """Detects test regressions by comparing with baseline results.

    This evaluator compares current test results (after prediction) with baseline
    test results (before prediction) to identify regressions - tests that passed
    in the baseline but now fail.

    The evaluator calculates a regression score:
    - No regressions: max_score
    - Some regressions: proportional penalty based on regression count
    - All baseline tests regressed: 0 score

    Score formula: max_score * (1 - regressions / baseline_passed_tests)

    Requirements:
    - Baseline test results must be available in shared_context.shared_data["baseline_tests"]
    - Current test results must be available from the specified evaluator_name
    """

    def __init__(
        self,
        name: str = "regression_detection",
        description: Optional[str] = None,
        test_result_evaluator: str = "all_tests_validation",
        max_score: float = 0.0,
        dependencies=None,
        is_terminal: bool = False,
    ):
        """Initialize regression detector.

        Args:
            name: Unique name for this evaluator
            description: Human-readable description
            test_result_evaluator: Name of evaluator that ran tests after prediction
            max_score: Maximum penalty score for regressions (0 = no scoring)
            dependencies: Optional dependency specification
            is_terminal: Whether failure should stop the pipeline (default: False)
        """
        self._name = name
        self._description = (
            description or "Detect test regressions compared to baseline"
        )
        self._test_result_evaluator = test_result_evaluator
        self._max_score = max_score
        self._dependencies = dependencies
        self._is_terminal = is_terminal

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return self._description

    @property
    def dependencies(self):
        return self._dependencies

    @property
    def is_terminal(self) -> bool:
        return self._is_terminal

    @property
    def timeout(self) -> Optional[int]:
        return None

    @property
    def retry_count(self) -> int:
        return 1

    @property
    def max_score(self) -> float:
        """Maximum penalty score this evaluator can apply."""
        return self._max_score

    def evaluate(
        self,
        spec: EvalSpec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        run_id: str,
        shared_context: EvaluationContext,
        sandbox=None,
        **kwargs,
    ) -> EvaluatorResult:
        """Detect regressions by comparing with baseline.

        Args:
            spec: Evaluation spec
            env_config: Environment configuration
            config: Dataset configuration
            run_id: Evaluation run ID
            shared_context: Shared context containing baseline and current results
            sandbox: Sandbox instance (not used)
            **kwargs: Additional parameters

        Returns:
            EvaluatorResult with regression analysis and score
        """
        try:
            # Get baseline results from shared context
            baseline_result: TestResult = shared_context.shared_data.get(
                "baseline_tests"
            )
            if not baseline_result:
                return EvaluatorResult(
                    evaluator_name=self.name,
                    status=EvaluatorStatus.SKIPPED,
                    message="No baseline test results available",
                    error="baseline_tests not found in shared_context.shared_data",
                )

            # Get current test results from specified evaluator
            current_evaluator_result = shared_context.get_result(
                self._test_result_evaluator
            )
            if not current_evaluator_result:
                return EvaluatorResult(
                    evaluator_name=self.name,
                    status=EvaluatorStatus.SKIPPED,
                    message=f"No results from evaluator '{self._test_result_evaluator}'",
                    error=f"Evaluator '{self._test_result_evaluator}' not found in context",
                )

            # Extract current test result from evaluator data
            current_test_data = current_evaluator_result.data.get("test_result")
            if not current_test_data:
                return EvaluatorResult(
                    evaluator_name=self.name,
                    status=EvaluatorStatus.SKIPPED,
                    message="No test_result data in current evaluator",
                    error=f"test_result not found in {self._test_result_evaluator} data",
                )

            # Reconstruct TestResult from dict
            current_result = self._reconstruct_test_result(current_test_data)

            # Detect regressions
            regressions = self._find_regressions(baseline_result, current_result)

            # Calculate score
            baseline_passed = baseline_result.passed_tests
            regression_count = len(regressions)

            if self._max_score > 0 and baseline_passed > 0:
                # Apply penalty proportional to regression count
                # Score = max_score * (1 - regressions / baseline_passed)
                score = self._max_score * (1 - (regression_count / baseline_passed))
                score = max(0.0, score)  # Ensure non-negative
            else:
                score = 0.0

            # Create detailed message
            if regression_count == 0:
                message = "No regressions detected"
                status = EvaluatorStatus.SUCCESS
            else:
                message = (
                    f"Detected {regression_count} regressions: "
                    f"{regression_count}/{baseline_passed} baseline tests now fail"
                )
                status = EvaluatorStatus.SUCCESS  # Still success, just with penalty

            # Create score breakdown
            score_breakdown = None
            if self._max_score > 0:
                score_breakdown = (
                    f"Regression penalty: {self._max_score - score:.1f} points "
                    f"({regression_count} regressions out of {baseline_passed} baseline passed tests)"
                )

            logger.info(
                f"Regression analysis: {regression_count} regressions, "
                f"baseline: {baseline_passed} passed, "
                f"current: {current_result.passed_tests} passed"
            )

            return EvaluatorResult(
                evaluator_name=self.name,
                status=status,
                message=message,
                score=score,
                score_breakdown=score_breakdown,
                data={
                    "regression_count": regression_count,
                    "regressions": regressions,
                    "baseline_passed": baseline_passed,
                    "baseline_failed": baseline_result.failed_tests,
                    "baseline_total": baseline_result.total_tests,
                    "current_passed": current_result.passed_tests,
                    "current_failed": current_result.failed_tests,
                    "current_total": current_result.total_tests,
                },
            )

        except Exception as e:
            logger.error(f"Error detecting regressions: {e}", exc_info=True)
            return EvaluatorResult(
                evaluator_name=self.name,
                status=EvaluatorStatus.ERROR,
                message="Exception while detecting regressions",
                error=str(e),
            )

    def _reconstruct_test_result(self, test_data: Dict) -> TestResult:
        """Reconstruct TestResult from dictionary data.

        Args:
            test_data: Dictionary containing test result data

        Returns:
            TestResult object
        """
        from ee_bench_core.adapters.testrunner_base import TestEvaluationResult

        result = TestResult(
            success=test_data.get("success", True),
            total_tests=test_data.get("total_tests", 0),
            passed_tests=test_data.get("passed_tests", 0),
            failed_tests=test_data.get("failed_tests", 0),
            skipped_tests=test_data.get("skipped_tests", 0),
            execution_time=test_data.get("execution_time", 0.0),
            raw_output=test_data.get("raw_output", ""),
        )

        # Reconstruct individual test results
        tests_dict = test_data.get("tests", {})
        for test_name, test_info in tests_dict.items():
            status_str = test_info.get("status", "FAILED").upper()
            status = (
                ResultStatus[status_str]
                if status_str in ResultStatus.__members__
                else ResultStatus.FAILED
            )

            test_eval_result = TestEvaluationResult(
                test_name=test_name,
                status=status,
                reason=test_info.get("reason", ""),
                execution_time=test_info.get("execution_time", 0.0),
                details=test_info.get("details"),
            )
            result.tests[test_name] = test_eval_result

        return result

    def _find_regressions(self, baseline: TestResult, current: TestResult) -> List[str]:
        """Find tests that passed in baseline but fail in current.

        Args:
            baseline: Baseline test results (before prediction)
            current: Current test results (after prediction)

        Returns:
            List of test names that regressed
        """
        regressions = []

        # Get set of tests that passed in baseline
        baseline_passed: Set[str] = {
            name
            for name, result in baseline.tests.items()
            if result.result == ResultStatus.SUCCESS
        }

        # Check which of those now fail
        for test_name in baseline_passed:
            current_test = current.tests.get(test_name)
            if current_test and current_test.result != ResultStatus.SUCCESS:
                regressions.append(test_name)
                logger.debug(f"Regression detected: {test_name}")

        return regressions
