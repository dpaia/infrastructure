"""SWE-bench evaluation specification.

This module defines the abstract base specification for SWE-bench format evaluations.
Language-specific implementations should inherit from this class.
"""

import logging
from abc import abstractmethod
from pathlib import Path
from typing import Any, Dict, List, Optional

from ee_bench_core.adapters.docker import DockerProcessManager, DockerEvaluationRunner
from ee_bench_core.adapters.process_manager import LocalProcessManager
from ee_bench_core.core.abc_types import (
    DatasetManager,
    EnvironmentManager,
    EnvironmentTools,
    EvaluationRunner,
    ReportManager
)
from ee_bench_core.core.base_spec import BaseEvalSpec
from ee_bench_core.core.eval import Evaluator
from ee_bench_core.core.models import DatasetConfig, EnvironmentConfig

logger = logging.getLogger(__name__)


class SweEvalSpec(BaseEvalSpec):
    """Abstract SWE-bench evaluation specification.

    This is the base class for all SWE-bench format evaluations.
    Language-specific implementations (e.g., JVM, Python) should inherit
    from this class and provide concrete implementations for language-specific
    components like environment managers and test runners.
    """

    def __init__(self, report_manager: Optional[ReportManager] = None):
        """Initialize SWE-bench specification.

        Args:
            report_manager: Optional report manager for tracking evaluation results
        """
        super().__init__(report_manager)

        # Initialize containers if subclass implements DI
        self.initialize_containers()

    @property
    @abstractmethod
    def name(self) -> str:
        """Get the canonical name of this specification.

        Language-specific implementations should return a unique name
        like "swe-jvm", "swe-python", etc.

        Returns:
            Unique specification name
        """
        pass

    @property
    def description(self) -> str:
        """Get a human-readable description.

        Returns:
            Description of SWE-bench specification
        """
        return "Software Engineering Benchmark (SWE-bench format)"

    @property
    def version(self) -> str:
        """Get the specification version.

        Returns:
            Version string
        """
        return "1.0.0"

    def get_dataset_manager(self, **kwargs) -> DatasetManager:
        """Create a dataset manager instance.

        Args:
            **kwargs: Spec-specific initialization parameters

        Returns:
            SweDatasetManager instance
        """
        from .swe_dataset import SweDatasetManager
        return SweDatasetManager(**kwargs)

    @abstractmethod
    def get_environment_manager(
        self,
        config: DatasetConfig,
        **kwargs
    ) -> EnvironmentManager:
        """Create an environment manager instance.

        Language-specific implementations should provide the appropriate
        environment manager for building Docker images with the correct
        language runtime and build tools.

        Args:
            config: Dataset configuration for the task
            **kwargs: Spec-specific initialization parameters

        Returns:
            Language-specific environment manager instance
        """
        pass

    def get_evaluators(
        self,
        config: DatasetConfig,
        env_config: EnvironmentConfig,
        enable_plugins: bool = True,
        **kwargs
    ) -> List[Evaluator]:
        """Get list of evaluators for SWE-bench evaluation.

        Returns the standard SWE-Bench evaluation pipeline:
        1. Baseline evaluation (all tests should pass)
        2. Test patch validation (fail_to_pass should fail)
        3. Prediction application (apply AI/agent patch)
        4. Fail-to-pass checking (fail_to_pass should now pass)
        5. Pass-to-pass checking (pass_to_pass should still pass)

        Additionally, if enable_plugins=True, this method will automatically
        discover and load plugin evaluators that are registered for this spec.

        This method uses the DI container to create evaluators with proper
        dependency injection. Container must be configured before calling.

        Subclasses can override this to customize the pipeline.

        Args:
            config: Dataset configuration for the task
            env_config: Environment configuration (REQUIRED)
            enable_plugins: If True, auto-discover and load plugin evaluators (default: True)
            **kwargs: Spec-specific initialization parameters

        Returns:
            List of evaluators for standard SWE-bench pipeline plus any spec-specific plugins

        Raises:
            NotImplementedError: If container doesn't have 'evaluators' provider
        """
        # Configure container if needed
        if not self._configured:
            self.configure_for_evaluation(config, env_config, **kwargs)

        # Get standard evaluators from container (with injected dependencies)
        if not hasattr(self.container, 'evaluators'):
            raise NotImplementedError(
                f"{self.__class__.__name__}.container must have 'evaluators' provider. "
                "See JvmSweContainer for example."
            )

        evaluators = self.container.evaluators()

        # Load plugin evaluators using helper from BaseEvalSpec
        plugin_evaluators = self.load_plugin_evaluators(enable_plugins)
        evaluators.extend(plugin_evaluators)

        return evaluators

    def get_evaluation_runner(
        self,
        config: DatasetConfig,
        **kwargs
    ) -> EvaluationRunner:
        """Create evaluation runner for SWE-bench tasks.

        Returns DockerEvaluationRunner which handles Docker container lifecycle
        including starting containers, running evaluation, and cleanup.

        Args:
            config: Dataset configuration for the task
            **kwargs: Additional parameters including:
                - env_config: Environment configuration (REQUIRED)
                - docker_adapter: DockerAdapter instance
                - max_workers: Number of parallel workers
                - report_manager: Report manager instance
                - clean: Whether to cleanup images after evaluation

        Returns:
            DockerEvaluationRunner instance

        Raises:
            ValueError: If env_config not provided in kwargs
        """
        # Extract env_config
        env_config = kwargs.pop('env_config', None)
        if not env_config:
            raise ValueError(
                "env_config is required in kwargs for get_evaluation_runner(). "
                "Pass env_config=your_env_config in kwargs."
            )

        # Get evaluators (env_config removed from kwargs to avoid duplicate)
        evaluators = self.get_evaluators(config, env_config, **kwargs)

        # Get parameters
        max_workers = kwargs.get('max_workers', 1)
        clean_images = kwargs.get('clean', False)

        return DockerEvaluationRunner(
            spec=self,
            evaluators=evaluators,
            max_workers=max_workers,
            report_manager=self.report_manager,
            clean_images=clean_images
        )




    def get_environment_tools(self, config: DatasetConfig, **kwargs) -> EnvironmentTools:
        """Get environment tools for SWE-bench.

        Args:
            config: Dataset configuration
            **kwargs: Additional parameters

        Returns:
            EnvironmentTools instance
        """
        from .swe_environment_tools import SweEnvironmentTools
        return SweEnvironmentTools()

    def get_cli_parameters(self, command: str) -> List[Dict[str, Any]]:
        """Get spec-specific CLI parameters for a command.

        Args:
            command: Command name

        Returns:
            List of parameter definitions for Click options
        """
        # Get base parameters (includes max_workers)
        base_params = self.get_base_cli_parameters(command)

        # Common SWE-bench parameters
        common_params = [
            {
                "names": ["--split"],
                "type": str,
                "default": None,
                "help": "Dataset split to use (e.g., 'lite', 'verified')"
            }
        ]

        # Command-specific parameters
        if command == "prepare-environment":
            return base_params + common_params + [
                {
                    "names": ["--base-only"],
                    "is_flag": True,
                    "default": False,
                    "help": "Build only base images, not task-specific images"
                },
                {
                    "names": ["--force-rebuild"],
                    "is_flag": True,
                    "default": False,
                    "help": "Force rebuild of instance images even if they exist"
                },
                {
                    "names": ["--namespace"],
                    "type": str,
                    "default": None,
                    "help": "Docker images namespace (default: ee-bench)"
                },
                {
                    "names": ["--cleanup-expired"],
                    "is_flag": True,
                    "default": False,
                    "help": "Cleanup expired/dangling images after build"
                },
                {
                    "names": ["--workspace-dir"],
                    "type": str,
                    "default": None,
                    "help": "Workspace directory inside container (default: /workspace)"
                },
                {
                    "names": ["--project-dir"],
                    "type": str,
                    "default": None,
                    "help": "Project directory name relative to workspace (default: task_project)"
                }
            ]
        elif command == "run-evaluation":
            return base_params + common_params + [
                {
                    "names": ["--docker-opts"],
                    "type": str,
                    "default": None,
                    "help": "Additional Docker run options (JSON or CLI format: '{\"memory\": \"2g\"}' or '--memory 2g --cpus 2')"
                },
                {
                    "names": ["--clean"],
                    "is_flag": True,
                    "default": False,
                    "help": "Cleanup images created during evaluation after completion"
                },
                {
                    "names": ["--predictions-path"],
                    "type": str,
                    "default": None,
                    "help": "Path to predictions file - if 'gold', uses gold predictions"
                },
                {
                    "names": ["--workspace-dir"],
                    "type": str,
                    "default": None,
                    "help": "Workspace directory inside container (default: /workspace)"
                },
                {
                    "names": ["--project-dir"],
                    "type": str,
                    "default": None,
                    "help": "Project directory name relative to workspace (default: task_project)"
                }
            ]
        else:
            return base_params + common_params
