"""MetadataProvider - extracts metadata from <!--METADATA--> blocks in text."""

from __future__ import annotations

import re
from typing import Any

from ee_bench.generator import Provider
from ee_bench.generator.errors import ProviderError

_METADATA_PATTERN = re.compile(
    r"<!--METADATA\n(.*?)\nMETADATA-->",
    re.DOTALL,
)


def parse_metadata_block(text: str) -> dict[str, str]:
    """Parse the ``<!--METADATA ... METADATA-->`` block from *text*."""
    match = _METADATA_PATTERN.search(text)
    if not match:
        return {}

    content = match.group(1)
    result: dict[str, str] = {}

    for line in content.split("\n"):
        line = line.strip()
        if not line:
            continue
        colon_idx = line.find(":")
        if colon_idx < 0:
            continue
        key = line[:colon_idx].strip()
        value = line[colon_idx + 1 :]
        value = value.replace("\\n", "\n")
        result[key] = value

    return result


class MetadataProvider(Provider):
    """Enrichment provider that extracts fields from a ``<!--METADATA-->`` block."""

    def __init__(self, **kwargs: Any) -> None:
        self._fields: list[str] = []
        self._auto_discover: bool = False
        self._cache_key: str | None = None
        self._cache_result: dict[str, str] = {}
        if kwargs:
            self.prepare(**kwargs)

    def prepare(self, **options: Any) -> None:
        fields = options.get("fields")
        if not fields:
            raise ProviderError(
                "MetadataProvider requires 'fields' option — "
                "an explicit list of metadata field names to provide, "
                'or "auto" for auto-discovery mode'
            )
        if fields in ("auto", "*"):
            self._auto_discover = True
            self._fields = []
        else:
            self._auto_discover = False
            self._fields = list(fields)

    def provide(self, item=None, *, text="", **kwargs) -> dict[str, str]:
        """Extract metadata fields from text.

        Args:
            item: Item dict (text can be extracted from item if not provided directly).
            text: Text containing <!--METADATA--> block.
            **kwargs: Ignored.

        Returns:
            Dict of extracted metadata fields.
        """
        if not text and item:
            text = item.get("text", "") or item.get("description", "")

        if text != self._cache_key:
            self._cache_key = text
            self._cache_result = parse_metadata_block(text)

        return dict(self._cache_result)

    def get_discovered_field_names(self) -> set[str]:
        """Return all keys found in the last parsed METADATA block."""
        return set(self._cache_result.keys())
