"""Core predictions collector for extracting predictions from environments."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Optional, TYPE_CHECKING

from .models import EnvironmentConfig, PredictionResult

if TYPE_CHECKING:
    from ee_bench_core.adapters import Sandbox
    from .models import DatasetConfig

logger = logging.getLogger(__name__)


class PredictionsCollector(ABC):
    """Abstract base class for predictions collectors.

    All collectors must implement the collect() method to gather predictions
    for a single instance. Collectors should have NO constructor parameters
    and resolve all configuration from the collect() method arguments.

    This enables:
    - Simpler lifecycle management
    - Easier testing (no mocking constructor dependencies)
    - Consistent interface across all collectors
    - Configuration resolved lazily when needed

    Attributes:
        priority: Priority for auto-selection (higher = checked first). Default is 0.
                 Collectors with higher priority are checked first when no explicit
                 --predictions flag is provided.
    """

    # Priority for auto-selection (can be overridden in subclasses)
    priority: int = 0

    @abstractmethod
    def collect(
        self,
        instance_id: str,
        sandbox: "Sandbox",
        config: "DatasetConfig",
        timeout: Optional[int] = None,
        **kwargs,
    ) -> PredictionResult:
        """Collect prediction for a single instance.

        Args:
            instance_id: Unique identifier for the task instance
            sandbox: Sandbox instance with environment configuration
                    (env_config accessible via sandbox.env_config if needed)
            config: Dataset configuration for the task instance.
                   Contains task-specific information like base_commit, test commands, etc.
            timeout: Optional timeout in seconds
            **kwargs: Additional collector-specific parameters including:
                - predictions: Collector name (e.g., "git_diff", "agent", "gold", "json")
                - file: Path to predictions file (for file-based collectors)
                - agent: Agent name (for agent-based collectors)
                - agent_config_path: Path to agent config (for agent-based collectors)
                - agent_opts: Agent runtime options (for agent-based collectors)

        Returns:
            PredictionResult with instance_id, content, and source

        Raises:
            ValueError: If required parameters are missing
            RuntimeError: If collection fails
        """
        pass

    @classmethod
    def is_applicable(cls, spec, env_config: EnvironmentConfig, **kwargs) -> bool:
        """Check if this collector is applicable for the given parameters.

        This method is used for auto-selection when no explicit --predictions flag
        is provided. Collectors should check for required parameters in kwargs.

        Args:
            spec: The evaluation spec instance
            env_config: Environment configuration
            **kwargs: CLI parameters and configuration including:
                - file: Path to predictions file
                - agent: Agent name
                - agent_config_path: Path to agent config
                - Other collector-specific parameters

        Returns:
            True if this collector can handle the given parameters, False otherwise

        Examples:
            # JsonPredictionsCollector checks for file parameter
            def is_applicable(cls, spec, env_config, **kwargs):
                file = kwargs.get("file")
                return file is not None and Path(file).suffix == ".json"

            # AgentPredictionsCollector checks for agent parameters
            def is_applicable(cls, spec, env_config, **kwargs):
                return "agent" in kwargs or "agent_config_path" in kwargs
        """
        return False
