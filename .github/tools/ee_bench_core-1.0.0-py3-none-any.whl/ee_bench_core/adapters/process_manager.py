"""Process execution manager for running external commands locally.

This module provides a unified interface for executing commands with
subprocess, including support for input, streaming output, and timeouts.
"""

import logging
import subprocess
import time
from pathlib import Path
from typing import TYPE_CHECKING, Callable, List, Optional, Union

from .process_manager_base import ProcessManager, ProcessResult

if TYPE_CHECKING:
    from ee_bench_core.core.abc_types import EnvironmentConfig

logger = logging.getLogger(__name__)


class LocalProcessManager(ProcessManager):
    """Manager for executing external commands with subprocess."""

    def __init__(self, debug_output: bool = True):
        """Initialize process manager.

        Args:
            debug_output: Whether to write process output to debug log in real-time
        """
        self.debug_output = debug_output

    def run_command(
        self,
        cmd: Union[str, List[str]],
        cwd: Optional[Union[str, Path]] = None,
        timeout: Optional[int] = None,
        stdin_input: Optional[str] = None,
        env: Optional[dict] = None,
        shell: bool = False,
        log_prefix: str = "",
        env_config: Optional["EnvironmentConfig"] = None,
        stream_output: bool = False,
        output_callback: Optional[Callable[[str], None]] = None,
        **kwargs,
    ) -> ProcessResult:
        """Run a command and return its result.

        Args:
            cmd: Command to execute (list of args or string if shell=True)
            cwd: Working directory for the command
            timeout: Timeout in seconds (None for no timeout)
            stdin_input: Optional input to send to process stdin
            env: Optional environment variables dict (None uses parent env)
            shell: Whether to execute through shell
            log_prefix: Prefix for debug log messages
            env_config: Optional EnvironmentConfig (ignored for local execution)
            stream_output: Stream output in real-time
            output_callback: Callback function for each output line

        Returns:
            ProcessResult with execution details

        Raises:
            subprocess.SubprocessError: If command execution fails critically
        """
        start_time = time.time()
        timed_out = False

        debug_output = kwargs.get("debug_output", self.debug_output)

        # Extract env vars from EnvironmentConfig if provided
        env_vars = None
        if env is not None and isinstance(env, dict):
            env_vars = env
        # If env is EnvironmentConfig, ignore it for local execution

        # Convert Path to string for cwd
        if cwd is not None:
            cwd = str(cwd)

        # Log command execution
        cmd_str = cmd if isinstance(cmd, str) else " ".join(cmd)
        logger.debug(f"{log_prefix}Executing command: {cmd_str}")
        if cwd:
            logger.debug(f"{log_prefix}Working directory: {cwd}")
        if timeout:
            logger.debug(f"{log_prefix}Timeout: {timeout}s")

        try:
            # Start process
            proc = subprocess.Popen(
                cmd,
                cwd=cwd,
                stdin=subprocess.PIPE if stdin_input else None,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=env_vars,
                shell=shell,
                text=True,
                bufsize=1,  # Line buffered
            )

            # Collect output - use communicate() which handles everything properly
            try:
                if stream_output and output_callback:
                    # Stream output line by line in real-time
                    stdout_lines = []
                    stderr_lines = []

                    # Read stdout and stderr in real-time
                    import select
                    import sys

                    # Set up non-blocking reads
                    while True:
                        # Check if process is still running
                        if proc.poll() is not None:
                            # Process finished, read remaining output
                            remaining_stdout = proc.stdout.read()
                            remaining_stderr = proc.stderr.read()

                            if remaining_stdout:
                                for line in remaining_stdout.splitlines():
                                    stdout_lines.append(line)
                                    output_callback(line)

                            if remaining_stderr:
                                for line in remaining_stderr.splitlines():
                                    stderr_lines.append(line)

                            break

                        # Read available output
                        if sys.platform != "win32":
                            # Use select on Unix-like systems
                            readable, _, _ = select.select(
                                [proc.stdout, proc.stderr], [], [], 0.1
                            )

                            for stream in readable:
                                line = stream.readline()
                                if line:
                                    line = line.rstrip("\n")
                                    if stream == proc.stdout:
                                        stdout_lines.append(line)
                                        output_callback(line)
                                    else:
                                        stderr_lines.append(line)
                        else:
                            # Windows: simple polling
                            line = proc.stdout.readline()
                            if line:
                                line = line.rstrip("\n")
                                stdout_lines.append(line)
                                output_callback(line)

                        # Check timeout
                        if timeout and (time.time() - start_time) > timeout:
                            raise subprocess.TimeoutExpired(cmd, timeout)

                    stdout = "\n".join(stdout_lines)
                    stderr = "\n".join(stderr_lines)
                    returncode = proc.returncode
                else:
                    # Normal buffered execution
                    stdout, stderr = proc.communicate(
                        input=stdin_input, timeout=timeout
                    )
                    returncode = proc.returncode

                    # Log output if debug enabled
                    if debug_output:
                        for line in stdout.splitlines():
                            logger.debug(f"{log_prefix}[stdout] {line}")
                        for line in stderr.splitlines():
                            logger.debug(f"{log_prefix}[stderr] {line}")

            except subprocess.TimeoutExpired:
                logger.warning(f"{log_prefix}Process timed out after {timeout}s")
                proc.kill()
                stdout, stderr = proc.communicate()
                returncode = proc.returncode
                timed_out = True

        except Exception:
            duration = time.time() - start_time
            logger.exception("%sCommand execution failed", log_prefix)
            raise

        duration = time.time() - start_time

        # Log completion
        logger.debug(
            f"{log_prefix}Command completed in {duration:.2f}s "
            f"with exit code {returncode}"
        )

        return ProcessResult(
            returncode=returncode,
            stdout=stdout,
            stderr=stderr,
            duration=duration,
            timed_out=timed_out,
        )

    def open_interactive_shell(
        self,
        working_dir: Optional[Union[str, Path]] = None,
        env_config: Optional["EnvironmentConfig"] = None,
        **kwargs,
    ) -> ProcessResult:
        """Open an interactive shell in the local environment.

        Args:
            working_dir: Optional working directory for the shell
            env_config: Optional EnvironmentConfig (ignored for local execution)
            **kwargs: Additional parameters (ignored for local execution)

        Returns:
            ProcessResult with shell exit code and minimal output
        """
        import os
        import time

        start_time = time.time()

        # Convert Path to string if needed
        if working_dir is not None:
            working_dir = str(working_dir)

        logger.info(f"Opening interactive shell in: {working_dir or os.getcwd()}")

        # Determine shell to use
        shell = os.environ.get("SHELL", "/bin/bash")

        try:
            # Use os.system for interactive shell with TTY support
            if working_dir:
                # Change to directory and spawn shell
                cmd = f'cd "{working_dir}" && exec {shell}'
            else:
                cmd = f"exec {shell}"

            exit_code = os.system(cmd)

            # os.system returns exit code shifted left by 8 bits on Unix
            if os.name != "nt":
                exit_code >>= 8

            duration = time.time() - start_time
            logger.info(f"Interactive shell exited with code: {exit_code}")

            return ProcessResult(
                returncode=exit_code,
                stdout="",  # Interactive shell doesn't capture output
                stderr="",
                duration=duration,
                timed_out=False,
            )

        except Exception as e:
            duration = time.time() - start_time
            logger.exception(
                "Failed to open interactive shell in %s",
                working_dir or os.getcwd(),
            )
            return ProcessResult(
                returncode=1,
                stdout="",
                stderr=str(e),
                duration=duration,
                timed_out=False,
            )
