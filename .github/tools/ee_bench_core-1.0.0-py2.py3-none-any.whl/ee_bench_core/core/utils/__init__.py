"""Core utilities for the benchmark framework."""

from .argparse_ext import parse_extra_args
from .concurrency import LocksManager, run_sequential, run_threadpool
from .dependency_resolver import DependencyResolver, resolve_dependencies
from .dict_utils import (
    exclude_keys,
    filter_kwargs,
    filter_none_values,
    include_keys,
)
from .environment_helper import load_or_build_environments
from .errors import trace_error
from .interactive_shell_helper import open_interactive_shell
from .logging import get_command_context, set_command_context, setup_logging
from .report_manager_helper import get_or_create_report_manager
from .sandbox_helper import (
    cleanup_sandboxes,
    get_global_manager,
    with_sandbox,
    with_sandbox_safe,
)
from .sandbox_manager import SandboxManager, SandboxState

__all__ = [
    # Concurrency
    "run_threadpool",
    "run_sequential",
    "LocksManager",
    # Logging
    "setup_logging",
    "set_command_context",
    "get_command_context",
    # Argument parsing
    "parse_extra_args",
    # Error handling
    "trace_error",
    # Dependency resolution
    "DependencyResolver",
    "resolve_dependencies",
    # Environment helpers
    "load_or_build_environments",
    "open_interactive_shell",
    # Report manager helpers
    "get_or_create_report_manager",
    # Sandbox helpers
    "SandboxManager",
    "SandboxState",
    "with_sandbox",
    "with_sandbox_safe",
    "cleanup_sandboxes",
    "get_global_manager",
    # Dict utilities
    "filter_kwargs",
    "exclude_keys",
    "include_keys",
    "filter_none_values",
]
