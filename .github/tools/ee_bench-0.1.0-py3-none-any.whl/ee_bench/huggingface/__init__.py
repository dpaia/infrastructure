"""ee_bench.huggingface - HuggingFace dataset provider for ee_bench.generator.

This package provides a data provider that reads datasets from HuggingFace Hub
and exposes their columns as provider fields with dynamic discovery.
"""

from ee_bench.huggingface.provider import HuggingFaceDatasetProvider

__version__ = "0.1.0"

__all__ = [
    "HuggingFaceDatasetProvider",
]
