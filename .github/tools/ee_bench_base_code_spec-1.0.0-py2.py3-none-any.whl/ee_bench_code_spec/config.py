"""EE-bench dataset configuration.

This module provides the CodeBenchmarkConfig class for EE-bench tasks.
"""

import json
from typing import Any, Dict, List, Optional

from ee_bench_core.core.models import DatasetConfig


class CodeBenchmarkConfig(DatasetConfig):
    """Configuration for a EE-bench instance.

    This class extends DatasetConfig with EE-bench specific fields including
    repository information, commit details, problem statements, patches, and
    test specifications.
    """

    def __init__(
        self,
        instance_id: str,
        repo: str,
        base_commit: str,
        problem_statement: str,
        patch: Optional[str] = None,
        test_patch: Optional[str] = None,
        fail_to_pass: Optional[List[str]] = None,
        pass_to_pass: Optional[List[str]] = None,
        issue_numbers: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
        created_at: Optional[str] = None,
        version: Optional[str] = None,
        language: Optional[str] = None,
        _raw_instance: Optional[Dict[str, Any]] = None,
    ):
        """Initialize EE-bench configuration.

        Args:
            instance_id: Unique identifier for the task instance
            repo: GitHub repository (owner/repo format)
            base_commit: Base commit hash to start from
            problem_statement: Description of the problem to solve
            patch: Optional golden patch content
            test_patch: Optional test patch content
            fail_to_pass: Tests that should pass after fix
            pass_to_pass: Tests that should continue passing
            issue_numbers: Optional issue numbers
            tags: Optional tags for classification
            created_at: Optional creation timestamp
            version: Optional version string
            language: Programming language
            _raw_instance: Raw dataset entry for schema preservation
        """
        self._instance_id = instance_id
        self.repo = repo
        self.base_commit = base_commit
        self.problem_statement = problem_statement
        self.patch = patch
        self.test_patch = test_patch
        self.fail_to_pass = fail_to_pass or []
        self.pass_to_pass = pass_to_pass or []
        self.issue_numbers = issue_numbers
        self.tags = tags
        self.created_at = created_at
        self.version = version
        self.language = language
        self._raw_instance = _raw_instance or {}

    @property
    def instance_id(self) -> str:
        """Get the unique identifier for this task instance.

        Returns:
            Unique instance identifier
        """
        return self._instance_id

    def present(self) -> str:
        """Present the configuration in a human-readable format.

        Returns:
            Formatted string representation of the configuration
        """
        lines = [
            f"Instance ID: {self.instance_id}",
            f"Repository: {self.repo}",
            f"Base Commit: {self.base_commit}",
            f"Language: {self.language or 'Unknown'}",
        ]

        if self.problem_statement:
            lines.append("\nProblem Statement:")
            lines.append(
                self.problem_statement[:200] + "..."
                if len(self.problem_statement) > 200
                else self.problem_statement
            )

        if self.fail_to_pass:
            lines.append(f"\nTests to Fix ({len(self.fail_to_pass)}):")
            for test in self.fail_to_pass[:5]:  # Show first 5
                lines.append(f"  - {test}")
            if len(self.fail_to_pass) > 5:
                lines.append(f"  ... and {len(self.fail_to_pass) - 5} more")

        if self.pass_to_pass:
            lines.append(f"\nTests to Maintain ({len(self.pass_to_pass)}):")
            for test in self.pass_to_pass[:5]:  # Show first 5
                lines.append(f"  - {test}")
            if len(self.pass_to_pass) > 5:
                lines.append(f"  ... and {len(self.pass_to_pass) - 5} more")

        return "\n".join(lines)

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary.

        Returns:
            Dictionary representation of the configuration
        """
        return {
            "instance_id": self.instance_id,
            "repo": self.repo,
            "base_commit": self.base_commit,
            "problem_statement": self.problem_statement,
            "patch": self.patch,
            "test_patch": self.test_patch,
            "fail_to_pass": self.fail_to_pass,
            "pass_to_pass": self.pass_to_pass,
            "issue_numbers": self.issue_numbers,
            "tags": self.tags,
            "created_at": self.created_at,
            "version": self.version,
            "language": self.language,
        }

    def get(self, key: str, default: Any = None) -> Any:
        """Access a field from the original dataset entry.

        Args:
            key: Raw field name to fetch from the original JSON instance
            default: Default value if key is not found

        Returns:
            The raw value for the key, or default if missing
        """
        return self._raw_instance.get(key, default)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CodeBenchmarkConfig":
        """Create configuration from dictionary.

        Args:
            data: Dictionary containing configuration data

        Returns:
            CodeBenchmarkConfig instance
        """
        # Parse fail_to_pass and pass_to_pass from JSON strings if needed
        fail_to_pass = data.get("FAIL_TO_PASS") or data.get("fail_to_pass", [])
        if isinstance(fail_to_pass, str):
            fail_to_pass = json.loads(fail_to_pass)

        pass_to_pass = data.get("PASS_TO_PASS") or data.get("pass_to_pass", [])
        if isinstance(pass_to_pass, str):
            pass_to_pass = json.loads(pass_to_pass)

        # Parse issue_numbers from JSON string if needed
        issue_numbers = data.get("issue_numbers")
        if isinstance(issue_numbers, str):
            issue_numbers = json.loads(issue_numbers)

        # Parse tags from JSON string if needed
        tags = data.get("tags")
        if isinstance(tags, str):
            tags = json.loads(tags)

        return cls(
            instance_id=data["instance_id"],
            repo=data["repo"],
            base_commit=data["base_commit"],
            problem_statement=data.get("problem_statement", ""),
            patch=data.get("patch"),
            test_patch=data.get("test_patch"),
            fail_to_pass=fail_to_pass,
            pass_to_pass=pass_to_pass,
            issue_numbers=issue_numbers,
            tags=tags,
            created_at=data.get("created_at"),
            version=data.get("version"),
            language=data.get("language"),
            _raw_instance=data.copy(),
        )
