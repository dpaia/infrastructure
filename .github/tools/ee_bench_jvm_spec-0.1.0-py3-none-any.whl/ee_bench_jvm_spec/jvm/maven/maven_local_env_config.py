"""Maven-specific local environment configuration."""

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ee_bench_jvm_spec.jvm.jvm_local_env_config import JvmCodeLocalEnvironmentConfig


@dataclass
class MavenLocalEnvironmentConfig(JvmCodeLocalEnvironmentConfig):
    """Configuration for Maven local evaluation environments.

    Extends JvmCodeLocalEnvironmentConfig with Maven-specific fields.

    Attributes:
        Inherited from JvmCodeLocalEnvironmentConfig:
            workspace_dir: Local workspace directory path
            env_vars: Environment variables for execution
            repo: Repository name (owner/repo format)
            base_commit: Base commit hash
            project_dir: Project directory name
            language: Programming language (should be "java")
            java_home: Path to JDK installation
            java_version: Java version string
            maven_home: Path to Maven installation
            maven_version: Maven version string
            build_system: Build system being used (should be "maven")

        Maven-specific attributes:
            maven_wrapper_path: Path to Maven wrapper (./mvnw) if available
            maven_opts: Maven options (e.g., "-Xmx2g")
            use_wrapper: Whether to use Maven wrapper instead of system Maven
    """

    maven_wrapper_path: Path | None = None
    """Path to Maven wrapper (./mvnw) if available"""

    maven_opts: str | None = None
    """Maven options (e.g., '-Xmx2g')"""

    use_wrapper: bool = False
    """Whether to use Maven wrapper instead of system Maven"""

    def __post_init__(self):
        """Set build_system to maven."""
        super().__post_init__() if hasattr(super(), "__post_init__") else None
        self.build_system = "maven"
        self.language = "java"

    @property
    def maven_command(self) -> str:
        """Get the Maven command to use (wrapper or system).

        Returns:
            Maven command string (e.g., "./mvnw" or "mvn")
        """
        if self.use_wrapper and self.maven_wrapper_path:
            return str(self.maven_wrapper_path)
        return "mvn"

    def to_dict(self) -> dict[str, Any]:
        """Convert environment config to dictionary format.

        Returns:
            Dictionary representation of the environment configuration
        """
        result = super().to_dict()
        result.update(
            {
                "maven_wrapper_path": (
                    str(self.maven_wrapper_path) if self.maven_wrapper_path else None
                ),
                "maven_opts": self.maven_opts,
                "use_wrapper": self.use_wrapper,
            }
        )
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "MavenLocalEnvironmentConfig":
        """Create MavenLocalEnvironmentConfig from dictionary.

        Args:
            data: Dictionary containing environment configuration

        Returns:
            MavenLocalEnvironmentConfig instance
        """
        return cls(
            workspace_dir=Path(data["workspace_dir"]),
            env_vars=data.get("env_vars", {}),
            repo=data.get("repo"),
            base_commit=data.get("base_commit"),
            project_dir=data.get("project_dir", "task_project"),
            language=data.get("language", "java"),
            java_home=Path(data["java_home"]) if data.get("java_home") else None,
            java_version=data.get("java_version"),
            maven_home=Path(data["maven_home"]) if data.get("maven_home") else None,
            maven_version=data.get("maven_version"),
            gradle_home=Path(data["gradle_home"]) if data.get("gradle_home") else None,
            gradle_version=data.get("gradle_version"),
            build_system=data.get("build_system", "maven"),
            maven_wrapper_path=(
                Path(data["maven_wrapper_path"]) if data.get("maven_wrapper_path") else None
            ),
            maven_opts=data.get("maven_opts"),
            use_wrapper=data.get("use_wrapper", False),
        )
