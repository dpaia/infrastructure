"""GitHub API rate limit handling."""

import logging
import time

from github import Github, GithubException
from github.GithubRetry import GithubRetry

logger = logging.getLogger(__name__)

# Minimum remaining calls before proactively waiting
_LOW_WATERMARK = 50
# Buffer seconds added to reset wait
_RESET_BUFFER = 5


def create_github_client(token: str) -> Github:
    """Create a GitHub client with rate-limit-aware retry configuration.

    Disables PyGithub's built-in long backoff on 403 rate limits so that
    ``check_rate_limit`` and ``retry_on_rate_limit`` handle waiting instead.
    """
    retry = GithubRetry(
        total=3,
        backoff_factor=1,
        # Let GithubRetry handle 403 but with no secondary rate wait —
        # our code manages the actual sleep duration.
        secondary_rate_wait=0,
    )
    return Github(login_or_token=token, retry=retry)


def check_rate_limit(gh: Github, *, threshold: int = _LOW_WATERMARK) -> None:
    """Sleep until rate limit resets if remaining calls are below threshold."""
    try:
        rate = gh.get_rate_limit().rate
    except GithubException:
        return

    if rate.remaining >= threshold:
        return

    reset_time = rate.reset.timestamp()
    wait = max(reset_time - time.time(), 0) + _RESET_BUFFER
    logger.warning(
        "Rate limit low (%d/%d remaining). Waiting %.0fs until reset...",
        rate.remaining, rate.limit, wait,
    )
    time.sleep(wait)
    logger.info("Rate limit wait complete, resuming.")


def retry_on_rate_limit(func, *args, max_retries: int = 3, **kwargs):
    """Call func and retry on 403/429 rate limit errors.

    Handles both primary rate limits (403 with rate limit headers) and
    secondary/abuse rate limits (403 Forbidden, 429 Too Many Requests).
    """
    for attempt in range(max_retries + 1):
        try:
            return func(*args, **kwargs)
        except GithubException as e:
            if e.status not in (403, 429) or attempt == max_retries:
                raise

            # Check for Retry-After header
            retry_after = None
            if hasattr(e, "headers") and e.headers:
                retry_after = e.headers.get("Retry-After")

            if retry_after:
                wait = int(retry_after) + _RESET_BUFFER
            elif e.status == 429:
                wait = 60 * (2 ** attempt)
            else:
                # Primary rate limit — check reset time from headers
                reset_ts = None
                if hasattr(e, "headers") and e.headers:
                    reset_ts = e.headers.get("X-RateLimit-Reset")
                if reset_ts:
                    wait = max(float(reset_ts) - time.time(), 0) + _RESET_BUFFER
                else:
                    wait = 60 * (2 ** attempt)

            logger.warning(
                "Rate limited (HTTP %d, attempt %d/%d). Waiting %.0fs...",
                e.status, attempt + 1, max_retries + 1, wait,
            )
            time.sleep(wait)

    # Should not reach here
    raise RuntimeError("Exhausted rate limit retries")
