"""Patch adapters for applying and collecting git patches.

This module provides unified interfaces for patch operations including
applying patches to repositories and collecting patches from workspaces.
"""

import logging
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Dict, Optional

from .process_manager import LocalProcessManager
from .process_manager_base import ProcessManager

if TYPE_CHECKING:
    from core.abc_types import EnvironmentConfig

logger = logging.getLogger(__name__)

PATCH_APPLY_CMDS = [
    ["git", "apply", "--verbose"],
    ["git", "apply", "--verbose", "--3way"],
    ["patch", "--verbose", "-p1"],
    ["git", "apply", "--verbose", "--reject"],
]


class PatchAdapter:
    """Adapter for applying unified diff patches to working directories."""

    def __init__(self, process_manager: Optional[ProcessManager] = None):
        """Initialize patch adapter.

        Args:
            process_manager: ProcessManager instance (LocalProcessManager if None)
        """
        self.process_manager = process_manager or LocalProcessManager(debug_output=True)

    def apply_patch(
        self,
        patch_content: Optional[str],
        working_dir: str = "/workspace/task_project",
        dry_run: bool = True,
        env_config: Optional["EnvironmentConfig"] = None,
    ) -> bool:
        """Apply patch with optional dry-run validation.

        Args:
            patch_content: The unified diff patch text to apply
            working_dir: Working directory where patch will be applied
            dry_run: If True, validates with --dry-run first; if False, applies for real
            env_config: Optional EnvironmentConfig for execution context

        Returns:
            True on success, False on failure
        """
        if not patch_content:
            logger.error("Patch content is empty")
            return True

        working_path = Path(working_dir)
        logger.info(f"Applying patch (dry_run={dry_run}) to {working_path}")

        applied_patch = False
        for apply_cmd in PATCH_APPLY_CMDS:
            logger.debug(f"Trying patch application command: {apply_cmd}")
            cmd = apply_cmd + ["--dry-run"] if dry_run else apply_cmd
            result = self.process_manager.run_command(
                cmd,
                cwd=working_path,
                stdin_input=patch_content,
                log_prefix="     ",
                env_config=env_config,
            )

            if result.returncode == 0:
                if dry_run:
                    logger.info("Patch validation successful (dry-run)")
                else:
                    logger.info("Patch applied successfully")
                applied_patch = True
                return True
            else:
                logger.info(f"Failed to apply patch to container: {apply_cmd}")

        if not applied_patch:
            logger.error("Patch application failed")
            return False
        return False

    def apply_patch_from_file(
        self,
        patch_file: str,
        working_dir: str = "/workspace/task_project",
        dry_run: bool = True,
        env_config: Optional["EnvironmentConfig"] = None,
    ) -> bool:
        """Apply patch from a file path.

        Args:
            patch_file: Path to the patch file
            working_dir: Working directory where patch will be applied
            dry_run: Whether to validate or actually apply
            env_config: Optional EnvironmentConfig for execution context

        Returns:
            True on success; False if file missing or application fails
        """
        patch_path = Path(patch_file)
        if not patch_path.exists():
            logger.error(f"Patch file not found: {patch_file}")
            return False
        patch_content = patch_path.read_text()
        return self.apply_patch(patch_content, working_dir, dry_run, env_config)


class PatchCollectorAdapter:
    """Adapter for collecting git patches from container workspaces."""

    def __init__(
        self,
        working_dir: str = "/workspace/task_project",
        process_manager: Optional[ProcessManager] = None,
    ):
        """Initialize patch collector adapter.

        Args:
            working_dir: Directory where the project is located
            process_manager: ProcessManager instance (LocalProcessManager if None)
        """
        self.working_dir = Path(working_dir)
        self.process_manager = process_manager or LocalProcessManager(
            debug_output=False
        )

    def collect_patch(self, output_dir: str, patch_name: Optional[str] = None) -> str:
        """Generate git patch and save to mounted volume.

        Args:
            output_dir: Directory to save the patch file
            patch_name: Optional name for the patch file

        Returns:
            Path to the generated patch file

        Raises:
            RuntimeError: If not a git repository or git diff fails
        """
        if not patch_name:
            patch_name = f"solution-{datetime.now().strftime('%Y%m%d-%H%M%S')}.patch"

        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        patch_path = output_path / patch_name

        # Verify we're in a git repository
        if not (self.working_dir / ".git").exists():
            raise RuntimeError(f"Not a git repository: {self.working_dir}")

        logger.info(f"Collecting git patch from {self.working_dir}")
        logger.info(f"Saving patch to {patch_path}")

        # Generate patch using git diff from HEAD
        result = self.process_manager.run_command(
            ["git", "diff", "HEAD"], cwd=self.working_dir
        )

        if result.returncode != 0:
            raise RuntimeError(f"Git diff failed with return code {result.returncode}")

        # Write patch content to file
        patch_path.write_text(result.stdout)

        # Check if patch file has content
        if patch_path.stat().st_size == 0:
            logger.warning("Generated patch is empty - no changes detected")
        else:
            logger.info(f"Generated patch with {patch_path.stat().st_size} bytes")

        return str(patch_path)

    def collect_staged_patch(
        self, output_dir: str, patch_name: Optional[str] = None
    ) -> str:
        """Generate git patch from staged changes only.

        Args:
            output_dir: Directory to save the patch file
            patch_name: Optional name for the patch file

        Returns:
            Path to the generated patch file

        Raises:
            RuntimeError: If git diff --cached fails
        """
        if not patch_name:
            patch_name = f"staged-{datetime.now().strftime('%Y%m%d-%H%M%S')}.patch"

        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        patch_path = output_path / patch_name

        logger.info(f"Collecting staged git patch from {self.working_dir}")

        # Generate patch using git diff --cached
        result = self.process_manager.run_command(
            ["git", "diff", "--cached"], cwd=self.working_dir
        )

        if result.returncode != 0:
            raise RuntimeError(
                f"Git diff --cached failed with return code {result.returncode}"
            )

        # Write patch content to file
        patch_path.write_text(result.stdout)

        return str(patch_path)

    def get_git_status(self) -> Dict[str, any]:
        """Get current git status information.

        Returns:
            Dictionary with git status information including:
            - status_lines: List of status lines from git status --porcelain
            - branch: Current branch name
            - commit: Current commit hash
            - has_changes: Boolean indicating if there are uncommitted changes
            - error: Error message if git command fails
        """
        try:
            # Get status summary
            status_result = self.process_manager.run_command(
                ["git", "status", "--porcelain"], cwd=self.working_dir
            )

            # Get current branch
            branch_result = self.process_manager.run_command(
                ["git", "branch", "--show-current"], cwd=self.working_dir
            )

            # Get current commit hash
            commit_result = self.process_manager.run_command(
                ["git", "rev-parse", "HEAD"], cwd=self.working_dir
            )

            return {
                "status_lines": status_result.stdout.strip().split("\n")
                if status_result.stdout.strip()
                else [],
                "branch": branch_result.stdout.strip(),
                "commit": commit_result.stdout.strip(),
                "has_changes": bool(status_result.stdout.strip()),
            }
        except Exception as e:
            logger.error(f"Failed to get git status: {e}")
            return {"error": str(e)}
