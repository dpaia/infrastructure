"""Protocol providers for different URI schemes.

This package provides pluggable protocol providers for handling different
URI schemes (file://, http://, https://, hf://) with a unified interface.
"""

from .base import FileProtocolProvider
from .registry import ProtocolProviderRegistry
from .file_provider import FileProvider
from .http_provider import HttpProvider
from .hf_provider import HuggingFaceProvider

__all__ = [
    "FileProtocolProvider",
    "ProtocolProviderRegistry",
    "FileProvider",
    "HttpProvider",
    "HuggingFaceProvider",
]
