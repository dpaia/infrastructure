"""ee_bench.importer - GitHub PR importer state tracking for CLI.

This package provides sync state management for the import CLI command.
The GitHub PR importer logic has moved to ee_bench.github.
"""

__version__ = "0.1.0"

__all__ = [
    "GitHubPRImporterGenerator",
]


def __getattr__(name):
    if name == "GitHubPRImporterGenerator":
        from ee_bench.github.pr_importer import GitHubPRImporterGenerator
        return GitHubPRImporterGenerator
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
