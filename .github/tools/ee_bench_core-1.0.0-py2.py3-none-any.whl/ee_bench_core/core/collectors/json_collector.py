"""JSON file-based predictions collector.

Collects predictions from a JSON or JSONL predictions file with multi-protocol support.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Optional

from ee_bench_core.adapters import Sandbox
from ee_bench_core.core.predictions_collector import PredictionsCollector
from ee_bench_core.core.models import PredictionResult, ResultStatus
from ee_bench_core.core.io import FileManager

if TYPE_CHECKING:
    from ee_bench_core.core.models import DatasetConfig, EnvironmentConfig

logger = logging.getLogger(__name__)


class JsonPredictionsCollector(PredictionsCollector):
    """Collects predictions from a JSON or JSONL predictions file.

    This collector reads predictions from JSON/JSONL files where each entry contains
    instance_id and prediction fields. It's used to evaluate pre-generated
    predictions without running agents or extracting diffs.

    Supports:
    - JSON and JSONL formats
    - Local files (file://) and remote URIs (http://, https://, hf://)
    - Optional caching for remote files

    JSON Format:
        [
            {"instance_id": "task-1", "content": "patch content...", "status": "success"},
            {"instance_id": "task-2", "prediction": "patch content..."},
            ...
        ]

    JSONL Format (one JSON object per line):
        {"instance_id": "task-1", "content": "patch content...", "status": "success"}
        {"instance_id": "task-2", "prediction": "patch content..."}

    Note: Supports both "content" and "prediction" field names for the patch data.

    Usage:
        # Local file
        collector = JsonPredictionsCollector()
        entry = collector.collect(
            instance_id="task-1",
            config=dataset_config,
            file="/path/to/predictions.json",
        )

        # Remote file with caching
        entry = collector.collect(
            instance_id="task-1",
            config=dataset_config,
            file="https://example.com/predictions.json",
            use_cache=True,
        )
    """

    # Plugin metadata
    __collector_name__ = "file"
    __collector_description__ = "Collects predictions from JSON/JSONL file"
    __collector_version__ = "1.0.0"
    __collector_author__ = "EE-Bench"
    __collector_tags__ = ["json", "jsonl", "file"]
    __collector_specs__ = []  # Works with all specs
    __collector_trigger_modes__ = ["file"]

    # Higher priority than git_diff for file-based collection
    priority = 10

    def __init__(
        self,
        use_cache: bool = False,
        file_manager: Optional[FileManager] = None,
    ):
        """Initialize JSON predictions collector.

        Args:
            use_cache: Enable caching for remote files (default: False)
            file_manager: Optional FileManager instance (creates default if None)
        """
        self.use_cache = use_cache

        # Initialize FileManager
        if file_manager is None:
            self.file_manager = FileManager(use_cache=use_cache)
        else:
            self.file_manager = file_manager

    @classmethod
    def is_applicable(cls, spec, env_config, **kwargs) -> bool:
        """Check if JSON/JSONL file parameter is provided and valid.

        Args:
            spec: Evaluation spec instance
            env_config: Environment configuration
            **kwargs: Must contain 'file' parameter with .json or .jsonl extension

        Returns:
            True if file parameter exists and has .json or .jsonl extension
        """
        file_path = kwargs.get("file")
        if file_path is None:
            return False

        # Check if file has .json or .jsonl extension
        suffix = Path(file_path).suffix.lower()
        return suffix in (".json", ".jsonl")

    def collect(
        self,
        instance_id: str,
        sandbox: Sandbox,
        config: "DatasetConfig",
        timeout: Optional[int] = None,
        **kwargs,
    ) -> PredictionResult:
        """Collect prediction from JSON/JSONL predictions file.

        Args:
            instance_id: Unique identifier for the task instance
            sandbox: Sandbox environment (not used for JSON collection)
            config: Dataset configuration (not used for JSON collection)
            timeout: Optional timeout (not used for JSON collection)
            **kwargs: Additional parameters including:
                - file: Path/URI to JSON/JSONL predictions file (REQUIRED)
                - use_cache: Override instance cache setting

        Returns:
            PredictionResult with instance_id, content, and source from file

        Raises:
            ValueError: If file is not provided or invalid format
        """
        # Get file path from kwargs (support both 'file' and legacy 'predictions_path')
        predictions_path = kwargs.get("file") or kwargs.get("predictions_path")
        if not predictions_path:
            raise ValueError(
                "file parameter required for JsonPredictionsCollector. "
                "Provide --file=/path/to/predictions.json"
            )

        # Get cache setting (kwargs override instance setting)
        use_cache = kwargs.get("use_cache", self.use_cache)

        try:
            # Load predictions using FileManager (supports JSON, JSONL, and remote URIs)
            predictions_data = self.file_manager.load(
                predictions_path,
                use_cache=use_cache
            )

            # Handle both list and dict formats
            if isinstance(predictions_data, list):
                # List format: [{"instance_id": "...", "prediction": "..."}, ...]
                predictions_map = {
                    item["instance_id"]: item for item in predictions_data
                }
            elif isinstance(predictions_data, dict):
                # Dict format: {"task-1": {"prediction": "..."}, ...}
                # OR: {"task-1": "prediction string", ...}
                predictions_map = {}
                for key, value in predictions_data.items():
                    if isinstance(value, dict):
                        predictions_map[key] = value
                    else:
                        # Direct string value
                        predictions_map[key] = {"prediction": value}
            else:
                raise ValueError(
                    f"Invalid predictions format. Expected list or dict, got {type(predictions_data)}"
                )

            # Find prediction for this instance
            if instance_id not in predictions_map:
                logger.warning(
                    f"Instance {instance_id} not found in predictions file. "
                    f"Available instances: {list(predictions_map.keys())[:10]}..."
                )
                # Return empty prediction with SKIPPED status
                return PredictionResult(
                    instance_id=instance_id,
                    content="",
                    source=f"json:{predictions_path}",
                    status=ResultStatus.SKIPPED,
                    error=f"Instance not found in {predictions_path}",
                )

            # Extract prediction (support both "prediction" and "content" fields)
            item = predictions_map[instance_id]
            prediction = item.get("prediction") or item.get("content", "")

            # Extract optional status and error fields
            status_str = item.get("status")
            status = ResultStatus(status_str) if status_str else None
            error = item.get("error")

            logger.info(
                f"Collected JSON prediction for {instance_id} from {predictions_path} "
                f"({len(prediction)} chars)"
            )

            return PredictionResult(
                instance_id=instance_id,
                content=prediction,
                source=f"json:{predictions_path}",
                status=status,
                error=error,
            )

        except FileNotFoundError as e:
            logger.error(f"Predictions file not found: {predictions_path}")
            raise ValueError(f"Predictions file not found: {predictions_path}") from e
        except ValueError as e:
            logger.error(f"Invalid format in predictions file {predictions_path}: {e}")
            raise
        except KeyError as e:
            logger.error(f"Missing required field in predictions file: {e}")
            raise ValueError(f"Invalid predictions format: missing field {e}") from e
        except Exception as e:
            logger.error(f"Failed to collect prediction for {instance_id}: {e}")
            raise RuntimeError(f"Prediction collection failed: {e}") from e
