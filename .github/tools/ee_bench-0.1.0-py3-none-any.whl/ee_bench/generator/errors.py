"""Custom exceptions for ee_bench.generator."""

from __future__ import annotations


class EEBenchError(Exception):
    """Base exception for ee_bench.generator."""


class PluginNotFoundError(EEBenchError):
    """Raised when a requested plugin is not found."""

    def __init__(self, plugin_type: str, name: str) -> None:
        self.plugin_type = plugin_type
        self.name = name
        super().__init__(f"{plugin_type} '{name}' not found")


class ProviderError(EEBenchError):
    """Raised when a provider encounters an error."""
