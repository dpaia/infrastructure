"""Base class for Docker build tool configurers (Maven/Gradle).

This module provides an abstract base class that extracts common logic
for adding build tools (Maven, Gradle, etc.) to JVM base Docker images.
"""

import logging
from abc import ABC, abstractmethod

from ee_bench_core.adapters.docker import (
    DockerEnvironmentConfig,
    DockerEnvironmentConfigurer,
)
from ee_bench_core.core import DependencyPosition
from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig

logger = logging.getLogger(__name__)


class BaseDockerBuildToolConfigurer(DockerEnvironmentConfigurer, ABC):
    """Abstract base class for Docker build tool configurers.

    This class extracts common logic for adding build tools (Maven, Gradle, etc.)
    to JVM base images. Subclasses only need to implement tool-specific methods:
    - build_system property (returns BuildSystem enum)
    - get_version_map() (returns version mapping dict)
    - get_default_version() (returns default version string)
    - generate_dockerfile() (generates tool-specific Dockerfile)

    Common functionality handled by base class:
    - Image existence checking
    - Label management
    - Image building
    - Environment config updates
    - JDK version extraction
    """

    def __init__(self, tool_name: str, namespace: str = "ee-bench", **kwargs):
        """Initialize build tool configurer.

        Args:
            tool_name: Name of the build tool (e.g., "maven", "gradle")
            namespace: Docker image namespace (default: "ee-bench")
            **kwargs: Additional parameters (ignored, for compatibility)
        """
        super().__init__()
        self.tool_name = tool_name
        self.namespace = namespace

    @property
    @abstractmethod
    def build_system(self):
        """Return the BuildSystem enum for this tool.

        Returns:
            BuildSystem enum (e.g., BuildSystem.MAVEN or BuildSystem.GRADLE)
        """
        pass

    @property
    @abstractmethod
    def tool_version_param_name(self) -> str:
        """Return the parameter name for version override.

        Returns:
            String parameter name (e.g., "maven_version" or "gradle_version")
        """
        pass

    @abstractmethod
    def get_version_map(self) -> dict[str, str]:
        """Return version mapping dictionary for this tool.

        Maps JDK versions to appropriate build tool versions.

        Returns:
            Dict mapping JDK version to tool version
        """
        pass

    @abstractmethod
    def get_default_version(self) -> str:
        """Return default tool version.

        Returns:
            Default version string
        """
        pass

    @abstractmethod
    def generate_dockerfile(
        self,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        **kwargs,
    ) -> str:
        """Generate tool-specific Dockerfile.

        Args:
            env_config: Environment configuration
            config: Dataset configuration
            **kwargs: Additional parameters (base_image, {tool}_version required)

        Returns:
            Dockerfile content as string
        """
        pass

    @property
    def name(self) -> str:
        """Return configurer name."""
        return self.tool_name

    @property
    def description(self) -> str:
        """Return configurer description."""
        return f"Adds {self.tool_name.capitalize()} to JVM base image"

    @property
    def specs(self) -> list[str] | None:
        """Return supported spec names."""
        return ["jvm"]

    @property
    def dependencies(self) -> list[str] | DependencyPosition | None:
        """Return dependency configuration."""
        return DependencyPosition(after=["base_image"], before=["task_image"], priority=100)

    def should_configure(
        self,
        spec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        **kwargs,
    ) -> tuple[bool, str | None]:
        """Check if build tool should be added.

        Args:
            spec: Evaluation specification
            env_config: Environment configuration
            config: Dataset configuration
            **kwargs: Additional parameters

        Returns:
            Tuple of (should_configure, reason)
        """
        # Only configure for matching build system
        from ee_bench_jvm_spec.jvm import JvmCodeEvalSpec

        build_system = JvmCodeEvalSpec.get_build_system(config, **kwargs)
        if build_system != self.build_system:
            return False, f"Build tool is {build_system.name}"

        # Check if we have a base image to work with
        if not isinstance(env_config, DockerEnvironmentConfig):
            return False, "Not a Docker environment"

        if not env_config.image_name:
            return False, "No base image available"

        return True, None

    def configure(
        self,
        spec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        **kwargs,
    ) -> EnvironmentConfig:
        """Add build tool to base image.

        Args:
            spec: Evaluation specification
            env_config: Environment configuration
            config: Dataset configuration
            **kwargs: Additional parameters

        Returns:
            Updated EnvironmentConfig with build tool image

        Raises:
            EnvironmentError: If image build fails
        """
        if not isinstance(env_config, DockerEnvironmentConfig):
            return env_config

        base_image = env_config.image_name
        jdk_version = self._extract_jdk_version(env_config, **kwargs)
        tool_version = self._get_tool_version(jdk_version, **kwargs)

        # New image name
        tool_image = f"{self.namespace}-jdk{jdk_version}:{self.tool_name}{tool_version}"

        logger.info(f"Adding {self.tool_name.capitalize()} {tool_version} to {base_image}")

        # Check if image already exists
        force = kwargs.get("force", False)
        if not force and self.image_exists(tool_image):
            logger.info(
                f"{self.tool_name.capitalize()} image {tool_image} already exists, skipping build"
            )
            # Update env_config to use existing image
            env_config.image_name = tool_image
            env_config.related_images[f"{self.tool_name}"] = tool_image
            # Try to retrieve labels
            try:
                env_config.labels = self.get_image_labels(tool_image)
            except Exception as e:
                logger.warning(f"Could not retrieve labels from {tool_image}: {e}")
            return env_config

        # Generate Dockerfile
        dockerfile_content = self.generate_dockerfile(
            env_config,
            config,
            base_image=base_image,
            **{self.tool_version_param_name: tool_version},
        )

        # Build image
        labels = env_config.labels.copy() if env_config.labels else {}
        labels.update(
            {
                f"{self.namespace}.{self.tool_name}-version": tool_version,
                f"{self.namespace}.build-tool": self.tool_name,
                f"{self.namespace}.configurer": self.name,
            }
        )

        self.build_image(dockerfile_content, tool_image, labels)

        logger.info(f"Successfully built {self.tool_name.capitalize()} image: {tool_image}")

        # Update env_config
        env_config.image_name = tool_image
        env_config.labels = labels
        env_config.related_images[f"{self.tool_name}"] = tool_image

        return env_config

    def _get_tool_version(self, jdk_version: str, **kwargs) -> str:
        """Get build tool version for JDK version.

        Args:
            jdk_version: JDK version
            **kwargs: May contain {tool}_version override

        Returns:
            Build tool version string
        """
        # Check for version override in kwargs
        if self.tool_version_param_name in kwargs:
            return kwargs[self.tool_version_param_name]

        # Use version map
        version_map = self.get_version_map()
        default_version = self.get_default_version()
        return version_map.get(jdk_version, default_version)

    def _extract_jdk_version(self, env_config: DockerEnvironmentConfig, **kwargs) -> str:
        """Extract JDK version from image name.

        Args:
            image_name: Docker image name

        Returns:
            JDK version string (defaults to "24" if not found)
        """

        # Second priority: config.jvm_version (from dataset instance)
        if hasattr(env_config, "jvm_version") and env_config.jvm_version:
            return str(env_config.jvm_version)

        # Third priority: jvm_version parameter (global default)
        if kwargs.get("jvm_version"):
            return str(kwargs["jvm_version"])

        image_name = env_config.related_images.get("jvm", "")

        # Parse from image name like "ee-bench-base:jvm-jdk24"
        if "jdk" in image_name:
            parts = image_name.split("jdk")
            if len(parts) > 1:
                # Get the part after "jdk" and remove any trailing characters
                version = parts[-1].split(":")[0].split("-")[0]
                return version
        return "24"  # Default
