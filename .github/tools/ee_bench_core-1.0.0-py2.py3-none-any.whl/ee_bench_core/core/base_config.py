"""Base environment configuration"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from ee_bench_core.core.models import EnvironmentConfig


@dataclass
class BaseEnvironmentConfig(EnvironmentConfig):
    """Configuration for local (non-Docker) evaluation environments.

    This configuration stores minimal information about a local execution
    environment. Tool-specific details (JAVA_HOME, MAVEN_HOME, etc.) should
    be stored in env_vars by configurers.

    Attributes:
        workspace_dir: Local directory path for task workspace
        env_vars: Environment variables to set for execution (includes tool paths)
    """

    workspace_dir: Optional[Path] = "workspace"
    """Local workspace directory path"""

    project_dir: Optional[str] = "task_project"
    """Project directory name relative to workspace_dir (default: task_project)"""

    env_vars: Dict[str, str] = field(default_factory=dict)
    """Environment variables for execution (includes JAVA_HOME, MAVEN_HOME, etc.)"""

    configurers: List[str] = field(default_factory=list)
    """List of executed configurers"""

    @property
    def project_path(self) -> Path:
        """Get full path to project directory.

        Returns:
            Full path combining workspace_dir and project_dir
        """
        if self.workspace_dir:
            return self.workspace_dir / self.project_dir
        return Path(self.project_dir)

    def to_dict(self) -> Dict[str, Any]:
        """Convert environment config to dictionary format.

        Returns:
            Dictionary representation of the environment configuration
        """
        return {
            "workspace_dir": str(self.workspace_dir),
            "project_dir": self.project_dir,
            "env_vars": self.env_vars,
            "configurers": self.configurers,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BaseEnvironmentConfig":
        """Create LocalEnvironmentConfig from dictionary.

        Args:
            data: Dictionary containing environment configuration

        Returns:
            LocalEnvironmentConfig instance
        """
        return cls(
            workspace_dir=Path(data["workspace_dir"]),
            project_dir=data.get("project_dir", "task_project"),
            env_vars=data.get("env_vars", {}),
            configurers=data.get("configurers", {}),
        )
