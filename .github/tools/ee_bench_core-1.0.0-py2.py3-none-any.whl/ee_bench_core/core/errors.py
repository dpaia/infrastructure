"""Custom exception hierarchy for the EE Benchmark framework."""


class EEBenchError(Exception):
    """Base exception for all EE Benchmark errors.

    All custom exceptions in the framework should inherit from this class.
    """

    pass


class SpecNotFoundError(EEBenchError):
    """Raised when a requested specification cannot be found.

    This typically occurs when:
    - An invalid spec name is provided
    - A spec alias doesn't resolve to a registered spec
    - Auto-discovery failed to find the spec
    """

    pass


class DatasetError(EEBenchError):
    """Raised when dataset operations fail.

    This includes errors with:
    - Dataset file not found
    - Invalid dataset format
    - Dataset parsing errors
    - Instance ID not found in dataset
    """

    pass


class EnvironmentError(EEBenchError):
    """Raised when environment setup or management fails.

    This includes errors with:
    - Docker image building
    - Container creation
    - Environment configuration
    - Resource cleanup
    """

    pass


class EvaluationError(EEBenchError):
    """Raised when evaluation execution fails.

    This includes errors with:
    - Running evaluation in container
    - Test execution failures
    - Result collection
    - Timeout errors
    """

    pass


class ConfigurationError(EEBenchError):
    """Raised when configuration is invalid or missing.

    This includes errors with:
    - Invalid configuration values
    - Missing required configuration
    - Configuration validation failures
    """

    pass


class TimeoutError(EEBenchError):
    """Raised when an operation exceeds its time limit.

    This includes timeouts for:
    - Test execution
    - Container operations
    - Image building
    - Network operations
    """

    pass


class PatchApplicationError(EEBenchError):
    """Raised when patch application fails.

    This includes errors with:
    - Patch file parsing
    - Applying patch to code
    - Merge conflicts
    - Invalid patch format
    """

    pass


class TestExecutionError(EEBenchError):
    """Raised when test execution encounters errors.

    This includes errors with:
    - Test runner failures
    - Test framework issues
    - Test result parsing
    - Test environment problems
    """

    pass


class PluginError(EEBenchError):
    """Raised when plugin operations fail.

    This is a general error for plugin-related issues.
    """

    pass


class PluginLoadError(PluginError):
    """Raised when loading a plugin fails.

    This includes errors with:
    - Plugin module import
    - Plugin class instantiation
    - Plugin registration
    - Invalid plugin structure
    """

    pass


class SpecVersionError(EEBenchError):
    """Raised when spec version is incompatible.

    This includes errors with:
    - Framework version mismatch
    - Deprecated spec versions
    - Version requirement not met
    """

    pass
