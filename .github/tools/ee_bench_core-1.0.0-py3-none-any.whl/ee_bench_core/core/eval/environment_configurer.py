"""Environment configurer interface for evaluation framework.

This module provides the abstract EnvironmentConfigurer interface for
preparing evaluation environments before evaluation starts. Configurers
can be discovered as plugins to install tools, set up authentication, etc.
"""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from core.abc_types import DatasetConfig, EnvironmentConfig
    from core.base_spec import BaseEvalSpec


class EnvironmentConfigurer(ABC):
    """Abstract base class for environment configuration.

    Environment configurers prepare the evaluation environment before
    evaluations run. They can install tools, set up authentication,
    configure services, etc.

    Configurers are discovered via entry points and can be enabled/disabled
    per evaluation run.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique identifier for this configurer.

        Returns:
            Configurer name (must be unique within registry)
        """
        pass

    @property
    def description(self) -> str:
        """Human-readable description of what this configurer does.

        Returns:
            Description string
        """
        return f"Environment configurer: {self.name}"

    @property
    def specs(self) -> Optional[list[str]]:
        """List of spec names this configurer applies to.

        If None or empty, applies to all specs.

        Returns:
            List of spec names (e.g., ["swe-jvm", "swe-python"]) or None for all
        """
        return None

    @abstractmethod
    def configure(
        self,
        spec: "BaseEvalSpec",
        env_config: "EnvironmentConfig",
        config: "DatasetConfig",
        **kwargs,
    ) -> "EnvironmentConfig":
        """Configure the environment and optionally return modified configuration.

        This method is called once before the evaluation pipeline starts,
        allowing configurers to prepare the environment. It can:
        - Install tools, configure settings in existing environment
        - Create enhanced Docker images with additional tools
        - Return modified environment configuration

        Args:
            spec: Evaluation specification providing dependencies and configuration
            env_config: Environment configuration (e.g., DockerEnvironmentConfig)
            config: Dataset configuration for the task being evaluated
            **kwargs: Additional configurer-specific parameters
                - Configuration passed from CLI/config file
                - Tool-specific credentials and settings

        Returns:
            EnvironmentConfig: Either the same env_config or a modified version.
            For example, a new DockerEnvironmentConfig with a different image_name
            if the configurer created an enhanced Docker image with additional tools.

        Raises:
            Exception: If environment configuration fails

        Examples:
            # Example 1: Install tool in existing container (return same config)
            def configure(self, spec, env_config, config, **kwargs):
                from ee_bench_core.adapters import DockerProcessManager

                process_manager = DockerProcessManager(env_config.container_id)
                process_manager.run_command("npm install -g snyk")
                return env_config  # Return unchanged

            # Example 2: Create enhanced image (return new config)
            def configure(self, spec, env_config, config, **kwargs):
                # Build new image with Snyk pre-installed
                new_image = self._build_enhanced_image(env_config.image_name)

                # Return new config with updated image
                from copy import copy
                new_config = copy(env_config)
                new_config.image_name = new_image
                return new_config
        """
        pass

    def should_configure(
        self,
        spec: "BaseEvalSpec",
        env_config: "EnvironmentConfig",
        config: "DatasetConfig",
        **kwargs,
    ) -> tuple[bool, Optional[str]]:
        """Check if this configurer should run for this environment.

        This method is called before configure() to allow configurers to
        skip execution based on the environment state or configuration.

        Args:
            spec: Evaluation specification
            env_config: Environment configuration
            config: Dataset configuration
            **kwargs: Additional parameters

        Returns:
            Tuple of (should_configure, reason):
            - should_configure: True if configurer should run
            - reason: Optional explanation if False

        Examples:
            # Skip if tool already installed
            if self._is_tool_installed(env_config):
                return False, "Tool already installed"

            # Skip if credentials not provided
            if not kwargs.get("snyk_token"):
                return False, "No authentication token provided"

            # Run configurer
            return True, None
        """
        return True, None
