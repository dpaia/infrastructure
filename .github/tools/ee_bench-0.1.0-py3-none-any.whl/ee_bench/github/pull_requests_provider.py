"""GitHub Pull Requests provider implementation."""

from __future__ import annotations

from typing import Any, Iterator

from ee_bench.generator import Filter, Provider
from ee_bench.generator.errors import ProviderError

from ee_bench.github.api import GitHubAPIClient, GitHubAPIError
from ee_bench.github.pattern_matcher import expand_repo_pattern, is_pattern
from ee_bench.github.test_field_parser import parse_test_fields


class GitHubPullRequestsProvider(Provider):
    """Provider that fetches data from GitHub Pull Requests.

    Yields complete PR dicts with all fields eagerly resolved.
    """

    def __init__(self, **kwargs: Any) -> None:
        self._client: GitHubAPIClient | None = None
        self._options: dict[str, Any] = {}
        self._cache: dict[str, Any] = {}
        if kwargs:
            self.prepare(**kwargs)

    def prepare(self, **options: Any) -> None:
        """Prepare the provider for use.

        Args:
            **options: Provider options including:
                - token: GitHub API token (or uses GITHUB_TOKEN env var)
                - base_url: GitHub API base URL
                - timeout: Request timeout in seconds
        """
        self._options = options
        self._client = GitHubAPIClient(
            token=options.get("token"),
            base_url=options.get("base_url", "https://api.github.com"),
            timeout=options.get("timeout", 30),
        )
        self._cache = {}

    def provide(
        self, item=None, *, filters=None, limit=None, **kwargs
    ) -> Iterator[dict[str, Any]]:
        """Yield complete PR dicts with all fields eagerly resolved.

        Args:
            item: Ignored (this is a primary provider).
            filters: Dict of selection filters, list of Filter objects, or None.
            limit: Maximum number of items to yield.
            **kwargs: Ignored.

        Yields:
            Complete PR dicts with all fields populated.
        """
        if self._client is None:
            raise ProviderError("Provider not prepared. Call prepare() first.")

        raw_filters = self._normalize_filters(filters)

        for pr_ref in self._iter_prs(raw_filters, limit):
            owner = pr_ref["owner"]
            repo = pr_ref["repo"]
            pr_number = pr_ref["number"]

            result = {
                "owner": owner,
                "repo": repo,
                "number": pr_number,
                "repo_url": f"https://github.com/{owner}/{repo}.git",
            }

            # Eagerly resolve all PR fields
            try:
                pr = self._get_pr(owner, repo, pr_number)
                body = pr.get("body") or ""
                result["description"] = body
                result["title"] = pr.get("title") or ""
                result["labels"] = [label["name"] for label in pr.get("labels", [])]
                head_sha = pr["head"]["sha"]
                base_branch = pr["base"].get("ref", "")
                base_sha = pr["base"]["sha"]
                result["base_commit"] = base_sha
                result["head_commit"] = head_sha
                result["head_branch"] = pr["head"].get("ref", "")
                result["base_branch"] = base_branch

                test_fields = parse_test_fields(body)
                result["FAIL_TO_PASS"] = test_fields.fail_to_pass
                result["PASS_TO_PASS"] = test_fields.pass_to_pass
                result["metadata"] = self._parse_metadata_block(body)
            except Exception:
                pass

            try:
                result["commits"] = self._get_pr_commits(owner, repo, pr_number)
            except Exception:
                result["commits"] = []

            try:
                result["patch"] = self._get_pr_diff(owner, repo, pr_number)
            except Exception:
                result["patch"] = ""

            try:
                base_sha = result.get("base_commit", "HEAD")
                result["repo_tree"] = self._get_repo_tree(owner, repo, base_sha)
            except Exception:
                result["repo_tree"] = []

            yield result

    @staticmethod
    def _normalize_filters(filters) -> dict[str, Any]:
        """Convert Filter objects or dict to raw filters dict."""
        if filters is None:
            return {}
        if isinstance(filters, dict):
            return filters
        if isinstance(filters, list):
            raw: dict[str, Any] = {}
            for f in filters:
                if isinstance(f, Filter):
                    if f.eq is not None:
                        raw[f.field] = f.eq
                    elif f.in_ is not None:
                        raw[f.field] = {"in": f.in_}
                    elif f.contains is not None:
                        raw[f.field] = {"contains": f.contains}
                else:
                    raw.update(f)
            return raw
        return {}

    def _iter_prs(
        self, filters: dict[str, Any], limit: int | None
    ) -> Iterator[dict[str, Any]]:
        """Iterate over PR references (owner, repo, number)."""
        # Check for search query
        if "query" in filters:
            if "repo" in filters or "repos" in filters:
                raise ProviderError(
                    "Cannot use 'query' filter together with 'repo' or 'repos'. "
                    "Use repo: in the search query string instead."
                )
            yield from self._iter_from_search(filters["query"], limit)
            return

        repos = self._resolve_repos(filters)
        count = 0

        for repo_full in repos:
            owner, repo = repo_full.split("/", 1)
            for item_dict, new_count in self._iter_repo_items(
                owner, repo, filters, limit, count
            ):
                yield item_dict
                count = new_count
                if limit and count >= limit:
                    return

    # --- Internal helpers (kept unchanged) ---

    def _get_pr(self, owner: str, repo: str, pr_number: int) -> dict[str, Any]:
        """Get PR data, with caching."""
        cache_key = f"pr:{owner}/{repo}#{pr_number}"
        if cache_key not in self._cache:
            try:
                self._cache[cache_key] = self._client.get(
                    f"/repos/{owner}/{repo}/pulls/{pr_number}"
                )
            except GitHubAPIError as e:
                raise ProviderError(f"Failed to fetch PR: {e}")
        return self._cache[cache_key]

    def _get_pr_commits(self, owner: str, repo: str, pr_number: int) -> list[str]:
        """Get list of commit SHAs in the PR."""
        cache_key = f"pr_commits:{owner}/{repo}#{pr_number}"
        if cache_key not in self._cache:
            try:
                commits = list(
                    self._client.get_paginated(
                        f"/repos/{owner}/{repo}/pulls/{pr_number}/commits"
                    )
                )
                self._cache[cache_key] = [c["sha"] for c in commits]
            except GitHubAPIError as e:
                raise ProviderError(f"Failed to fetch PR commits: {e}")
        return self._cache[cache_key]

    def _get_branch_tip(self, owner: str, repo: str, branch: str) -> str:
        """Get the latest commit SHA of a branch (live, not cached from PR creation)."""
        cache_key = f"branch_tip:{owner}/{repo}:{branch}"
        if cache_key not in self._cache:
            try:
                data = self._client.get(f"/repos/{owner}/{repo}/branches/{branch}")
                self._cache[cache_key] = data["commit"]["sha"]
            except (GitHubAPIError, KeyError) as e:
                raise ProviderError(f"Failed to fetch branch tip for {branch}: {e}")
        return self._cache[cache_key]

    def _get_merge_base_commit(self, owner: str, repo: str, base_sha: str, head_sha: str) -> str:
        """Get the merge base commit SHA between base and head.

        Uses the GitHub compare API which returns the true merge base — the
        common ancestor used to compute the PR diff — rather than the tip of
        the base branch. This matters when the base branch has diverged from
        the head branch's ancestry.
        """
        cache_key = f"merge_base:{owner}/{repo}:{base_sha}...{head_sha}"
        if cache_key not in self._cache:
            try:
                data = self._client.get(
                    f"/repos/{owner}/{repo}/compare/{base_sha}...{head_sha}"
                )
                self._cache[cache_key] = data["merge_base_commit"]["sha"]
            except (GitHubAPIError, KeyError):
                # Fall back to base_sha if compare fails
                self._cache[cache_key] = base_sha
        return self._cache[cache_key]

    def _get_pr_diff(self, owner: str, repo: str, pr_number: int) -> str:
        """Get the combined diff for the PR."""
        cache_key = f"pr_diff:{owner}/{repo}#{pr_number}"
        if cache_key not in self._cache:
            try:
                self._cache[cache_key] = self._client.get_diff(
                    f"/repos/{owner}/{repo}/pulls/{pr_number}"
                )
            except GitHubAPIError as e:
                raise ProviderError(f"Failed to fetch PR diff: {e}")
        return self._cache[cache_key]

    def _get_repo_tree(self, owner: str, repo: str, ref: str) -> list[str]:
        """Get repository file tree."""
        cache_key = f"tree:{owner}/{repo}@{ref}"
        if cache_key not in self._cache:
            try:
                tree_data = self._client.get(
                    f"/repos/{owner}/{repo}/git/trees/{ref}",
                    recursive="true",
                )
                self._cache[cache_key] = [
                    item["path"]
                    for item in tree_data.get("tree", [])
                    if item["type"] == "blob"
                ]
            except GitHubAPIError as e:
                raise ProviderError(f"Failed to fetch repo tree: {e}")
        return self._cache[cache_key]

    @staticmethod
    def _parse_metadata_block(body: str) -> dict[str, str]:
        """Parse <!--METADATA ... METADATA--> block from PR body.

        Args:
            body: PR body text.

        Returns:
            Dictionary of key-value pairs from the metadata block.
            Empty dict if no metadata block found.
        """
        import re

        pattern = re.compile(r"<!--METADATA\n(.*?)\nMETADATA-->", re.DOTALL)
        match = pattern.search(body)
        if not match:
            return {}

        content = match.group(1)
        result = {}
        for line in content.split("\n"):
            line = line.strip()
            if not line:
                continue
            colon_idx = line.find(":")
            if colon_idx < 0:
                continue
            key = line[:colon_idx].strip()
            value = line[colon_idx + 1:]
            value = value.replace("\\n", "\n")
            result[key] = value

        return result

    def _expand_pattern(self, pattern: str) -> list[str]:
        """Expand a wildcard pattern to matching repositories.

        Args:
            pattern: Repository pattern (e.g., "apache/*", "apache/kafka-*").

        Returns:
            List of matching "owner/repo" strings.
        """
        try:
            return expand_repo_pattern(pattern, self._client.get_repos)
        except Exception as e:
            raise ProviderError(f"Failed to expand pattern '{pattern}': {e}")

    def _resolve_repos(self, filters: dict[str, Any]) -> list[str]:
        """Resolve repository list from filters.

        Supports:
        - 'repo': Single repository (e.g., "owner/repo")
        - 'repos': Multiple repositories (e.g., ["owner/repo1", "owner/repo2"])
        - Wildcard patterns (e.g., "apache/*", "apache/kafka-*")

        Args:
            filters: Selection filters dict.

        Returns:
            List of "owner/repo" strings.

        Raises:
            ProviderError: If neither 'repo' nor 'repos' is specified.
        """
        raw_repos: list[str] = []

        # Check for 'repos' (plural) first
        if "repos" in filters:
            repos_value = filters["repos"]
            if isinstance(repos_value, list):
                raw_repos.extend(repos_value)
            else:
                raw_repos.append(repos_value)

        # Check for 'repo' (singular)
        if "repo" in filters:
            raw_repos.append(filters["repo"])

        if not raw_repos:
            raise ProviderError(
                "Selection must include 'repo' or 'repos' filter (owner/repo)"
            )

        # Expand any wildcard patterns
        resolved_repos: list[str] = []
        for repo in raw_repos:
            if is_pattern(repo):
                resolved_repos.extend(self._expand_pattern(repo))
            else:
                resolved_repos.append(repo)

        if not resolved_repos:
            raise ProviderError(
                "No repositories matched the specified pattern(s)"
            )

        return resolved_repos

    def _iter_repo_items(
        self,
        owner: str,
        repo: str,
        filters: dict[str, Any],
        limit: int | None,
        count: int,
    ) -> Iterator[tuple[dict[str, Any], int]]:
        """Iterate over items from a single repository.

        Args:
            owner: Repository owner.
            repo: Repository name.
            filters: Selection filters.
            limit: Maximum total items to return.
            count: Current item count.

        Yields:
            Tuples of (item_dict, new_count).
        """
        # If specific PR numbers provided
        pr_numbers = filters.get("pr_numbers", [])
        if pr_numbers:
            for num in pr_numbers:
                if limit and count >= limit:
                    return
                yield {"owner": owner, "repo": repo, "number": int(num)}, count + 1
                count += 1
            return

        # Otherwise, list PRs with filters
        params = {}
        if "state" in filters:
            params["state"] = filters["state"]

        for pr in self._client.get_paginated(
            f"/repos/{owner}/{repo}/pulls", **params
        ):
            if limit and count >= limit:
                return

            # Filter by labels if specified
            if "labels" in filters:
                pr_labels = {label["name"] for label in pr.get("labels", [])}
                label_filter = filters["labels"]
                if isinstance(label_filter, dict) and "contains" in label_filter:
                    # Filter("labels", contains="x") → match if x is in pr labels
                    if label_filter["contains"] not in pr_labels:
                        continue
                elif isinstance(label_filter, dict) and "in" in label_filter:
                    # Filter("labels", in_=[...]) → match if any label is in list
                    if not pr_labels.intersection(label_filter["in"]):
                        continue
                else:
                    # Direct value or set — original behavior
                    if isinstance(label_filter, str):
                        label_filter = {label_filter}
                    if not pr_labels.intersection(label_filter):
                        continue

            yield {"owner": owner, "repo": repo, "number": pr["number"]}, count + 1
            count += 1

    def _iter_from_search(
        self, query: str, limit: int | None
    ) -> Iterator[dict[str, Any]]:
        """Iterate over items from GitHub Search API.

        Args:
            query: GitHub search query string.
            limit: Maximum items to return.

        Yields:
            Dictionaries with owner, repo, number keys.
        """
        count = 0

        for item in self._client.search_issues(query):
            if limit and count >= limit:
                return

            # Skip non-PRs (search_issues returns both issues and PRs)
            if "pull_request" not in item:
                continue

            # Extract owner/repo from repository_url
            # Format: "https://api.github.com/repos/owner/repo"
            repo_url = item.get("repository_url", "")
            parts = repo_url.split("/repos/")
            if len(parts) < 2:
                continue

            owner_repo = parts[1]
            owner, repo = owner_repo.split("/", 1)

            yield {"owner": owner, "repo": repo, "number": item["number"]}
            count += 1
