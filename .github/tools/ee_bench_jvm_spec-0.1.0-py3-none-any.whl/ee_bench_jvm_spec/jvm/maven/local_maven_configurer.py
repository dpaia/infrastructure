"""Local Maven configurer for verifying Maven installation on the host system."""

import logging
import re
import subprocess
from pathlib import Path

from ee_bench_core.adapters.local import LocalEnvironmentConfig
from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig
from ee_bench_core.core.errors import EnvironmentError

from ee_bench_jvm_spec.jvm.base_local_build_tool_configurer import (
    BaseLocalBuildToolConfigurer,
)
from ee_bench_jvm_spec.jvm.jvm_config import BuildSystem
from ee_bench_jvm_spec.jvm.jvm_local_env_config import JvmCodeLocalEnvironmentConfig

from .maven_local_env_config import MavenLocalEnvironmentConfig

logger = logging.getLogger(__name__)


class LocalMavenConfigurer(BaseLocalBuildToolConfigurer):
    """Configurer that verifies Maven installation on local system.

    This configurer checks that Maven is installed on the host system
    and sets MAVEN_HOME in env_vars if not already set.

    For local execution of Maven projects, the user must have Maven installed.
    This configurer verifies the installation and sets up environment variables.

    Metadata:
        name: local_maven
        priority: 150 (runs after local_jvm and local_task_setup)
        dependencies: after local_jvm, local_task_setup
        specs: ["jvm"]
    """

    __configurer_name__ = "local_maven"
    __configurer_description__ = "Verifies local Maven installation"
    __configurer_version__ = "1.0.0"
    __configurer_specs__ = ["jvm"]

    @property
    def build_system(self):
        """Return the BuildSystem enum for Maven."""
        return BuildSystem.MAVEN

    @property
    def tool_name(self) -> str:
        """Return tool name."""
        return "maven"

    @property
    def tool_command(self) -> str:
        """Return command name for Maven."""
        return "mvn"

    def get_download_url(self) -> str:
        """Return Maven download URL."""
        return "https://maven.apache.org/download.cgi"

    def parse_version_from_output(self, version_output: str) -> str | None:
        """Parse Maven version from output.

        Args:
            version_output: Output from mvn -version

        Returns:
            Version string or None
        """
        version_match = re.search(r"Apache Maven (\S+)", version_output)
        return version_match.group(1) if version_match else None

    def check_for_wrapper(
        self, env_config: LocalEnvironmentConfig, config: DatasetConfig
    ) -> tuple[str, str] | None:
        """Check for Maven wrapper (mvnw) in project.

        Args:
            env_config: Environment configuration
            config: Dataset configuration

        Returns:
            Tuple of (wrapper_path, version) if found, None otherwise
        """
        workspace_dir = Path(env_config.workspace_dir).resolve()
        project_dir = workspace_dir / "task_project"
        mvnw_path = project_dir / "mvnw"

        if not mvnw_path.exists():
            return None

        # Maven wrapper found
        logger.info(f"Found Maven wrapper at {mvnw_path}")

        # Make sure it's executable
        mvnw_path.chmod(0o755)

        # Get Maven version from wrapper
        try:
            result = subprocess.run(
                [str(mvnw_path), "-version"],
                cwd=project_dir,
                capture_output=True,
                text=True,
                check=True,
                timeout=30,
            )
            version_output = result.stdout
            logger.debug(f"Maven wrapper version output: {version_output}")

            # Parse version
            version = self.parse_version_from_output(version_output)
            if not version:
                version = "wrapper"

            logger.info(f"Using Maven wrapper version: {version}")
            return (str(mvnw_path), version)

        except subprocess.CalledProcessError as e:
            logger.warning(f"Maven wrapper found but failed to execute: {e.stderr}")
            logger.info("Falling back to checking for system Maven installation")
        except subprocess.TimeoutExpired:
            logger.warning("Maven wrapper execution timed out")
            logger.info("Falling back to checking for system Maven installation")

        return None

    def find_tool_home(self, tool_path: str, version_output: str) -> str | None:
        """Find MAVEN_HOME from executable path and version output.

        Maven -version output includes "Maven home:" which we can parse directly.

        Args:
            tool_path: Path to mvn executable
            version_output: Output from mvn -version

        Returns:
            MAVEN_HOME path or None if not found
        """
        # Try to parse from mvn -version output (usually shows Maven home)
        home_match = re.search(r"Maven home: (.+)", version_output)
        if home_match:
            return home_match.group(1).strip()

        # Fall back to base class implementation
        return super().find_tool_home(tool_path, version_output)

    def configure(
        self,
        spec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        **kwargs,
    ) -> EnvironmentConfig:
        """Verify Maven installation and upgrade to MavenLocalEnvironmentConfig.

        Args:
            spec: Evaluation specification
            env_config: Environment configuration (should be JvmCodeLocalEnvironmentConfig)
            config: Dataset configuration
            **kwargs: Additional parameters

        Returns:
            MavenLocalEnvironmentConfig with Maven-specific fields populated

        Raises:
            EnvironmentError: If Maven is not installed
        """
        if not isinstance(env_config, LocalEnvironmentConfig):
            return env_config

        logger.info("Verifying local Maven installation")

        # Upgrade to MavenLocalEnvironmentConfig if not already
        if not isinstance(env_config, MavenLocalEnvironmentConfig):
            if isinstance(env_config, JvmCodeLocalEnvironmentConfig):
                # Upgrade from JvmCodeLocalEnvironmentConfig
                env_config = MavenLocalEnvironmentConfig(
                    workspace_dir=env_config.workspace_dir,
                    env_vars=env_config.env_vars.copy(),
                    repo=env_config.repo,
                    base_commit=env_config.base_commit,
                    project_dir=env_config.project_dir,
                    language=env_config.language,
                    java_home=env_config.java_home,
                    java_version=env_config.java_version,
                    maven_home=env_config.maven_home,
                    maven_version=env_config.maven_version,
                    gradle_home=env_config.gradle_home,
                    gradle_version=env_config.gradle_version,
                    build_system=env_config.build_system,
                )
                logger.debug(
                    "Upgraded JvmCodeLocalEnvironmentConfig to MavenLocalEnvironmentConfig"
                )
            else:
                logger.warning(
                    f"Expected JvmCodeLocalEnvironmentConfig, got {type(env_config).__name__}"
                )
                return env_config

        # Check for wrapper first
        wrapper_result = self.check_for_wrapper(env_config, config)
        if wrapper_result:
            wrapper_path, version = wrapper_result
            logger.info(f"Using Maven wrapper: {wrapper_path}")

            # Set Maven-specific fields
            env_config.maven_wrapper_path = Path(wrapper_path)
            env_config.maven_version = version
            env_config.use_wrapper = True

            # Also set env_vars for backward compatibility
            env_config.env_vars["MAVEN_WRAPPER"] = wrapper_path
            env_config.env_vars["MAVEN_VERSION"] = version

            logger.info(f"Local Maven configuration complete: wrapper {version}")
            return env_config

        # No wrapper - check for system installation
        logger.info("No Maven wrapper found, checking for system Maven installation")

        import shutil

        tool_path = shutil.which("mvn")
        if not tool_path:
            raise EnvironmentError(
                "Maven not found in PATH and no wrapper in project.\n"
                "Please install Maven or ensure the project includes a Maven wrapper.\n"
                f"Download from: {self.get_download_url()}"
            )

        # Get version
        try:
            result = subprocess.run(
                ["mvn", "-version"],
                capture_output=True,
                text=True,
                check=True,
            )
            version_output = result.stdout
            logger.debug(f"Maven version output: {version_output}")
        except subprocess.CalledProcessError as e:
            raise EnvironmentError(f"Failed to get Maven version: {e}")

        # Parse version
        version = self.parse_version_from_output(version_output)
        if not version:
            logger.warning(f"Could not parse Maven version from: {version_output}")
            version = "unknown"

        logger.info(f"Found Maven version: {version} at {tool_path}")

        # Find MAVEN_HOME
        maven_home = env_config.env_vars.get("MAVEN_HOME")
        if not maven_home:
            maven_home = self.find_tool_home(tool_path, version_output)
            if maven_home:
                logger.info(f"Detected MAVEN_HOME: {maven_home}")
            else:
                logger.warning("Could not automatically detect MAVEN_HOME")

        # Set Maven-specific fields
        if maven_home:
            env_config.maven_home = Path(maven_home)
            env_config.env_vars["MAVEN_HOME"] = maven_home

        env_config.maven_version = version
        env_config.env_vars["MAVEN_VERSION"] = version
        env_config.use_wrapper = False

        logger.info(f"Local Maven configuration complete: Maven {version}")

        return env_config
