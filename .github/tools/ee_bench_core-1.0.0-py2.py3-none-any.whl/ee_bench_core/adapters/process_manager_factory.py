"""Factory for creating ProcessManager instances based on EnvironmentConfig sandbox type.

This module provides a factory pattern for creating the appropriate ProcessManager
implementation (Local or Docker) based on the environment configuration.
"""

import logging
from typing import TYPE_CHECKING

from .process_manager_base import ProcessManager
from .process_manager import LocalProcessManager
from .docker.docker_process_manager import DockerProcessManager
from .docker import DockerAdapter

if TYPE_CHECKING:
    from ee_bench_core.core.models import EnvironmentConfig

logger = logging.getLogger(__name__)


class ProcessManagerFactory:
    """Factory for creating ProcessManager instances.

    This factory examines the EnvironmentConfig sandbox_type and creates the appropriate
    ProcessManager implementation. This allows the codebase to support multiple
    execution environments (local, docker) in a consistent way.
    """

    @staticmethod
    def create_process_manager(
        env_config: "EnvironmentConfig", **kwargs
    ) -> ProcessManager:
        """Create appropriate ProcessManager based on EnvironmentConfig sandbox_type.

        Args:
            env_config: Environment configuration with sandbox_type property
            **kwargs: Additional parameters for ProcessManager initialization:
                - debug_output: Whether to write process output to debug log (default: True)
                - docker_adapter: DockerAdapter instance for Docker execution (optional)

        Returns:
            ProcessManager instance (LocalProcessManager or DockerProcessManager)

        Raises:
            ValueError: If sandbox_type is not 'local' or 'docker'
            AttributeError: If env_config doesn't have sandbox_type property

        Examples:
            >>> from ee_bench_core.adapters import ProcessManagerFactory
            >>> from ee_bench_core.adapters.docker import DockerEnvironmentConfig
            >>>
            >>> # For Docker environments
            >>> env_config = DockerEnvironmentConfig(
            ...     instance_id="test-1",
            ...     image_name="my-image:latest",
            ...     container_id="abc123"
            ... )
            >>> pm = ProcessManagerFactory.create_process_manager(env_config)
            >>> # Returns DockerProcessManager
            >>>
            >>> # For local environments
            >>> env_config = LocalEnvironmentConfig(
            ...     instance_id="test-1",
            ...     workspace_dir=Path("/tmp/test")
            ... )
            >>> pm = ProcessManagerFactory.create_process_manager(env_config)
            >>> # Returns LocalProcessManager
        """
        # Get sandbox_type from env_config
        if not hasattr(env_config, "sandbox_type"):
            raise AttributeError(
                f"EnvironmentConfig {env_config.__class__.__name__} "
                f"must have a 'sandbox_type' property"
            )

        sandbox_type = env_config.sandbox_type

        logger.debug(f"Creating ProcessManager for sandbox_type: {sandbox_type}")

        # Extract common parameters
        debug_output = kwargs.get("debug_output", True)

        # Create appropriate ProcessManager based on sandbox_type
        if sandbox_type == "local":
            logger.debug("Creating LocalProcessManager")
            return LocalProcessManager(debug_output=debug_output)

        elif sandbox_type == "docker":
            logger.debug("Creating DockerProcessManager")
            docker_adapter = kwargs.get("docker_adapter")
            if docker_adapter is None:
                docker_adapter = DockerAdapter()
            return DockerProcessManager(
                docker_adapter=docker_adapter, debug_output=debug_output
            )

        else:
            raise ValueError(
                f"Unsupported sandbox_type: '{sandbox_type}'. "
                f"Must be 'local' or 'docker'"
            )
