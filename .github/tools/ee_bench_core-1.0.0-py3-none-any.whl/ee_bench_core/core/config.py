"""Configuration management for EE-Benchmark.

This module handles loading and managing configuration from ~/.ee-bench/specs.yml
including disabling specs, evaluators, and environment configurers.
"""

import logging
from pathlib import Path
from typing import Dict, List, Optional, Set

import yaml

logger = logging.getLogger(__name__)


class EEBenchConfig:
    """Configuration for EE-Benchmark.

    Loads configuration from ~/.ee-bench/specs.yml with the following structure:

    ```yaml
    disabled:
      specs:
        - spec-name-1
        - spec-name-2
      evaluators:
        - evaluator-name-1
        - evaluator-name-2
      configurers:
        - configurer-name-1
        - configurer-name-2
    ```
    """

    DEFAULT_CONFIG_PATH = Path.home() / ".ee-bench" / "specs.yml"

    def __init__(self, config_path: Optional[Path] = None):
        """Initialize configuration.

        Args:
            config_path: Path to configuration file (default: ~/.ee-bench/specs.yml)
        """
        self.config_path = config_path or self.DEFAULT_CONFIG_PATH
        self._config: Dict = {}
        self._load_config()

    def _load_config(self) -> None:
        """Load configuration from file."""
        if not self.config_path.exists():
            logger.debug(f"Config file not found at {self.config_path}, using defaults")
            self._config = {}
            return

        try:
            with open(self.config_path, "r") as f:
                self._config = yaml.safe_load(f) or {}
            logger.info(f"Loaded configuration from {self.config_path}")
        except Exception as e:
            logger.warning(f"Failed to load config from {self.config_path}: {e}")
            self._config = {}

    def reload(self) -> None:
        """Reload configuration from file."""
        self._load_config()

    @property
    def disabled_specs(self) -> Set[str]:
        """Get set of disabled spec names."""
        disabled = self._config.get("disabled", {})
        specs = disabled.get("specs", [])
        return set(specs) if isinstance(specs, list) else set()

    @property
    def disabled_evaluators(self) -> Set[str]:
        """Get set of disabled evaluator names."""
        disabled = self._config.get("disabled", {})
        evaluators = disabled.get("evaluators", [])
        return set(evaluators) if isinstance(evaluators, list) else set()

    @property
    def disabled_configurers(self) -> Set[str]:
        """Get set of disabled environment configurer names."""
        disabled = self._config.get("disabled", {})
        configurers = disabled.get("configurers", [])
        return set(configurers) if isinstance(configurers, list) else set()

    def is_spec_enabled(self, spec_name: str) -> bool:
        """Check if a spec is enabled.

        Args:
            spec_name: Name of the spec

        Returns:
            True if spec is enabled, False if disabled
        """
        return spec_name not in self.disabled_specs

    def is_evaluator_enabled(self, evaluator_name: str) -> bool:
        """Check if an evaluator is enabled.

        Args:
            evaluator_name: Name of the evaluator

        Returns:
            True if evaluator is enabled, False if disabled
        """
        return evaluator_name not in self.disabled_evaluators

    def is_configurer_enabled(self, configurer_name: str) -> bool:
        """Check if an environment configurer is enabled.

        Args:
            configurer_name: Name of the configurer

        Returns:
            True if configurer is enabled, False if disabled
        """
        return configurer_name not in self.disabled_configurers

    def create_example_config(self) -> None:
        """Create an example configuration file.

        Creates ~/.ee-bench/specs.yml with example content if it doesn't exist.
        """
        if self.config_path.exists():
            logger.info(f"Config file already exists at {self.config_path}")
            return

        # Create directory if it doesn't exist
        self.config_path.parent.mkdir(parents=True, exist_ok=True)

        example_config = """# EE-Benchmark Configuration
# This file allows you to disable specific specs, evaluators, and environment configurers

disabled:
  # Disable specific evaluation specifications
  specs:
    # - swe-jvm  # Uncomment to disable JVM SWE spec
    # - swe-python  # Uncomment to disable Python SWE spec

  # Disable specific evaluators
  evaluators:
    # - snyk_baseline  # Uncomment to disable Snyk baseline collector
    # - snyk_validator  # Uncomment to disable Snyk validator

  # Disable specific environment configurers
  configurers:
    # - snyk  # Uncomment to disable Snyk environment configurer
"""

        with open(self.config_path, "w") as f:
            f.write(example_config)

        logger.info(f"Created example config at {self.config_path}")


# Global configuration instance
_global_config: Optional[EEBenchConfig] = None


def get_config() -> EEBenchConfig:
    """Get the global configuration instance.

    Returns:
        Global EEBenchConfig instance
    """
    global _global_config
    if _global_config is None:
        _global_config = EEBenchConfig()
    return _global_config


def reload_config() -> None:
    """Reload the global configuration from file."""
    global _global_config
    if _global_config is not None:
        _global_config.reload()
