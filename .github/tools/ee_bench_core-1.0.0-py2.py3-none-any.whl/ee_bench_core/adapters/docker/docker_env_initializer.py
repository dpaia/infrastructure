"""Docker environment initializer configurer."""

import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Optional, Union, List

from ee_bench_core.core.eval import EnvironmentConfigurer, DependencyPosition

if TYPE_CHECKING:
    from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig
    from ee_bench_core.core.base_spec import BaseEvalSpec

from .docker_env_config import DockerEnvironmentConfig

logger = logging.getLogger(__name__)


class DockerEnvironmentInitializer(EnvironmentConfigurer):
    """Creates initial DockerEnvironmentConfig for Docker sandbox mode.

    This configurer runs FIRST (priority=-1000) and creates the base
    DockerEnvironmentConfig instance that subsequent configurers will enhance.

    It only runs when --sandbox docker is specified (or by default).
    """

    __configurer_name__ = "docker_environment_initializer"
    __configurer_description__ = "Creates initial DockerEnvironmentConfig"
    __configurer_version__ = "1.0.0"
    __configurer_specs__ = []  # Applies to all specs

    def __init__(self, **kwargs):
        """Initialize Docker environment initializer.

        Args:
            **kwargs: Additional parameters (ignored, for compatibility)
        """
        pass

    @property
    def name(self) -> str:
        """Return configurer name."""
        return "docker_environment_initializer"

    @property
    def description(self) -> str:
        """Return configurer description."""
        return "Creates initial DockerEnvironmentConfig for Docker sandbox"

    @property
    def specs(self) -> Optional[list[str]]:
        """Return specs this configurer applies to."""
        return []  # Apply to all specs

    @property
    def dependencies(self) -> Optional[Union[List[str], DependencyPosition]]:
        """Return dependency specification.

        Returns:
            DependencyPosition with highest priority (lowest number) to run first
        """

        from ...core import PositionConstraint

        # Run FIRST - highest priority (lowest number)
        return DependencyPosition(position=PositionConstraint.FIRST, priority=-1000)

    def should_configure(
        self,
        spec: "BaseEvalSpec",
        env_config: "EnvironmentConfig",
        config: "DatasetConfig",
        **kwargs,
    ) -> tuple[bool, Optional[str]]:
        """Check if Docker environment should be initialized.

        Args:
            spec: Evaluation specification
            env_config: Environment configuration (will be None initially)
            config: Dataset configuration
            **kwargs: Additional parameters including 'sandbox'

        Returns:
            Tuple of (should_configure, reason)
        """
        # Check sandbox parameter
        sandbox = kwargs.get("sandbox", "docker")

        if sandbox != "docker":
            return False, f"Sandbox is '{sandbox}', not 'docker'"

        # Don't re-initialize if already created
        if isinstance(env_config, DockerEnvironmentConfig):
            return False, "DockerEnvironmentConfig already initialized"

        return True, None

    def configure(
        self,
        spec: "BaseEvalSpec",
        env_config: "EnvironmentConfig",
        config: "DatasetConfig",
        **kwargs,
    ) -> "EnvironmentConfig":
        """Create initial DockerEnvironmentConfig.

        Args:
            spec: Evaluation specification
            env_config: Existing environment config (may be None)
            config: Dataset configuration
            **kwargs: Additional parameters

        Returns:
            New DockerEnvironmentConfig instance
        """
        logger.debug(f"Initializing Docker environment for {config.instance_id}")

        # Create initial Docker environment config
        # Subsequent configurers will populate image_name, container_id, etc.
        docker_config = DockerEnvironmentConfig(
            instance_id=config.instance_id,
            image_name="",  # Will be set by image builder configurers
            workspace_dir=Path("/workspace"),  # Default Docker workspace
            created_at=datetime.now(timezone.utc).isoformat(),
            labels={
                "ee_bench.sandbox": "docker",
                "ee_bench.instance_id": config.instance_id,
            },
        )

        logger.debug(f"Created DockerEnvironmentConfig: {docker_config.to_dict()}")

        return docker_config
