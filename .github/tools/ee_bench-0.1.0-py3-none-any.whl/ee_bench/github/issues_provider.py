"""GitHub Issues provider implementation."""

from __future__ import annotations

import logging
from typing import Any, Iterator

from ee_bench.generator import Filter, Provider
from ee_bench.generator.errors import ProviderError

from ee_bench.github.api import GitHubAPIClient, GitHubAPIError
from ee_bench.github.build_system import detect_build_system
from ee_bench.github.commit_fetcher import (
    fetch_commits_for_issue,
    generate_combined_patch,
)
from ee_bench.github.pattern_matcher import expand_repo_pattern, is_pattern
from ee_bench.github.test_field_parser import fetch_test_fields_for_issue

logger = logging.getLogger(__name__)


class GitHubIssuesProvider(Provider):
    """Provider that fetches data from GitHub Issues.

    Yields complete issue dicts with all fields eagerly resolved.
    """

    def __init__(self, **kwargs: Any) -> None:
        self._client: GitHubAPIClient | None = None
        self._options: dict[str, Any] = {}
        self._cache: dict[str, Any] = {}
        if kwargs:
            self.prepare(**kwargs)

    def prepare(self, **options: Any) -> None:
        """Prepare the provider for use.

        Args:
            **options: Provider options including:
                - token: GitHub API token (or uses GITHUB_TOKEN env var)
                - base_url: GitHub API base URL
                - timeout: Request timeout in seconds
                - fetch_commits: Enable commit fetching (default: false)
                - parse_comments: Parse test fields from comments (default: false)
                - detect_build_system: Detect build system (default: false)
        """
        self._options = options
        self._client = GitHubAPIClient(
            token=options.get("token"),
            base_url=options.get("base_url", "https://api.github.com"),
            timeout=options.get("timeout", 30),
        )
        self._cache = {}

    def provide(
        self, item=None, *, filters=None, limit=None, **kwargs
    ) -> Iterator[dict[str, Any]]:
        """Yield complete issue dicts with all fields eagerly resolved.

        Args:
            item: Ignored (this is a primary provider).
            filters: Dict of selection filters, list of Filter objects, or None.
            limit: Maximum number of items to yield.
            **kwargs: Ignored.

        Yields:
            Complete issue dicts with all fields populated.
        """
        if self._client is None:
            raise ProviderError("Provider not prepared. Call prepare() first.")

        raw_filters = self._normalize_filters(filters)
        repos = self._resolve_repos(raw_filters)
        count = 0

        for repo_full in repos:
            owner, repo = repo_full.split("/", 1)
            for issue_ref, new_count in self._iter_repo_items(
                owner, repo, raw_filters, limit, count
            ):
                o = issue_ref["owner"]
                r = issue_ref["repo"]
                num = issue_ref["number"]

                result = {
                    "owner": o,
                    "repo": r,
                    "number": num,
                    "repo_url": f"https://github.com/{o}/{r}.git",
                }

                # Eagerly resolve issue fields
                try:
                    issue = self._get_issue(o, r, num)
                    result["description"] = issue.get("body") or ""
                    result["title"] = issue.get("title") or ""
                    result["labels"] = [label["name"] for label in issue.get("labels", [])]
                except Exception:
                    pass

                # Commit-related fields
                if self._should_fetch_commits():
                    try:
                        fetched = self._get_fetched_commits(o, r, num)
                        result["commits"] = fetched.commits
                        result["base_commit"] = fetched.base_commit
                        if fetched.commits:
                            result["patch"] = generate_combined_patch(
                                self._client, o, r, fetched.commits
                            )
                        else:
                            result["patch"] = ""
                    except Exception:
                        result["commits"] = []
                        result["base_commit"] = ""
                        result["patch"] = ""

                # Test fields
                if self._should_parse_comments():
                    try:
                        commit_shas = None
                        if self._should_fetch_commits():
                            try:
                                fetched = self._get_fetched_commits(o, r, num)
                                commit_shas = fetched.commits
                            except Exception:
                                pass
                        test_fields = fetch_test_fields_for_issue(
                            self._client, o, r, num, commit_shas
                        )
                        result["FAIL_TO_PASS"] = test_fields.fail_to_pass
                        result["PASS_TO_PASS"] = test_fields.pass_to_pass
                    except Exception:
                        result["FAIL_TO_PASS"] = "[]"
                        result["PASS_TO_PASS"] = "[]"
                else:
                    result["FAIL_TO_PASS"] = "[]"
                    result["PASS_TO_PASS"] = "[]"

                # Build system
                if self._should_detect_build_system():
                    try:
                        ref = result.get("base_commit") or None
                        result["build_system"] = detect_build_system(
                            self._client, o, r, ref
                        )
                    except Exception:
                        result["build_system"] = ""

                # Repo tree
                try:
                    ref = result.get("base_commit") or "HEAD"
                    result["repo_tree"] = self._get_repo_tree(o, r, ref)
                except Exception:
                    result["repo_tree"] = []

                yield result
                count = new_count

                if limit and count >= limit:
                    return

    @staticmethod
    def _normalize_filters(filters) -> dict[str, Any]:
        """Convert Filter objects or dict to raw filters dict."""
        if filters is None:
            return {}
        if isinstance(filters, dict):
            return filters
        if isinstance(filters, list):
            raw: dict[str, Any] = {}
            for f in filters:
                if isinstance(f, Filter):
                    if f.eq is not None:
                        raw[f.field] = f.eq
                    elif f.in_ is not None:
                        raw[f.field] = {"in": f.in_}
                    elif f.contains is not None:
                        raw[f.field] = {"contains": f.contains}
                else:
                    raw.update(f)
            return raw
        return {}

    def _should_fetch_commits(self) -> bool:
        """Check if commit fetching is enabled."""
        return self._options.get("fetch_commits", False) in (True, "true", "True", "1")

    def _should_parse_comments(self) -> bool:
        """Check if comment parsing is enabled."""
        return self._options.get("parse_comments", False) in (True, "true", "True", "1")

    def _should_detect_build_system(self) -> bool:
        """Check if build system detection is enabled."""
        return self._options.get("detect_build_system", False) in (True, "true", "True", "1")

    def _get_issue(self, owner: str, repo: str, issue_number: int) -> dict[str, Any]:
        """Get issue data, with caching."""
        cache_key = f"issue:{owner}/{repo}#{issue_number}"
        if cache_key not in self._cache:
            try:
                self._cache[cache_key] = self._client.get(
                    f"/repos/{owner}/{repo}/issues/{issue_number}"
                )
            except GitHubAPIError as e:
                raise ProviderError(f"Failed to fetch issue: {e}")
        return self._cache[cache_key]

    def _get_fetched_commits(self, owner: str, repo: str, issue_number: int) -> Any:
        """Get fetched commits data, with caching."""
        cache_key = f"fetched_commits:{owner}/{repo}#{issue_number}"
        if cache_key not in self._cache:
            try:
                self._cache[cache_key] = fetch_commits_for_issue(
                    self._client, owner, repo, issue_number
                )
            except Exception as e:
                logger.warning(f"Failed to fetch commits: {e}")
                raise ProviderError(f"Failed to fetch commits: {e}")
        return self._cache[cache_key]

    def _get_repo_tree(self, owner: str, repo: str, ref: str) -> list[str]:
        """Get repository file tree."""
        cache_key = f"tree:{owner}/{repo}@{ref}"
        if cache_key not in self._cache:
            try:
                tree_data = self._client.get(
                    f"/repos/{owner}/{repo}/git/trees/{ref}",
                    recursive="true",
                )
                self._cache[cache_key] = [
                    item["path"]
                    for item in tree_data.get("tree", [])
                    if item["type"] == "blob"
                ]
            except GitHubAPIError as e:
                raise ProviderError(f"Failed to fetch repo tree: {e}")
        return self._cache[cache_key]

    def _expand_pattern(self, pattern: str) -> list[str]:
        """Expand a wildcard pattern to matching repositories.

        Args:
            pattern: Repository pattern (e.g., "apache/*", "apache/kafka-*").

        Returns:
            List of matching "owner/repo" strings.
        """
        try:
            return expand_repo_pattern(pattern, self._client.get_repos)
        except Exception as e:
            raise ProviderError(f"Failed to expand pattern '{pattern}': {e}")

    def _resolve_repos(self, filters: dict[str, Any]) -> list[str]:
        """Resolve repository list from filters.

        Supports:
        - 'repo': Single repository (e.g., "owner/repo")
        - 'repos': Multiple repositories (e.g., ["owner/repo1", "owner/repo2"])
        - Wildcard patterns (e.g., "apache/*", "apache/kafka-*")

        Args:
            filters: Selection filters dict.

        Returns:
            List of "owner/repo" strings.

        Raises:
            ProviderError: If neither 'repo' nor 'repos' is specified.
        """
        raw_repos: list[str] = []

        # Check for 'repos' (plural) first
        if "repos" in filters:
            repos_value = filters["repos"]
            if isinstance(repos_value, list):
                raw_repos.extend(repos_value)
            else:
                raw_repos.append(repos_value)

        # Check for 'repo' (singular)
        if "repo" in filters:
            raw_repos.append(filters["repo"])

        if not raw_repos:
            raise ProviderError(
                "Selection must include 'repo' or 'repos' filter (owner/repo)"
            )

        # Expand any wildcard patterns
        resolved_repos: list[str] = []
        for repo in raw_repos:
            if is_pattern(repo):
                resolved_repos.extend(self._expand_pattern(repo))
            else:
                resolved_repos.append(repo)

        if not resolved_repos:
            raise ProviderError(
                "No repositories matched the specified pattern(s)"
            )

        return resolved_repos

    def _iter_repo_items(
        self,
        owner: str,
        repo: str,
        filters: dict[str, Any],
        limit: int | None,
        count: int,
    ) -> Iterator[tuple[dict[str, Any], int]]:
        """Iterate over items from a single repository.

        Args:
            owner: Repository owner.
            repo: Repository name.
            filters: Selection filters.
            limit: Maximum total items to return.
            count: Current item count.

        Yields:
            Tuples of (item_dict, new_count).
        """
        # If specific issue numbers provided
        issue_numbers = filters.get("issue_numbers", [])
        if issue_numbers:
            for num in issue_numbers:
                if limit and count >= limit:
                    return
                yield {"owner": owner, "repo": repo, "number": int(num)}, count + 1
                count += 1
            return

        # Otherwise, list issues with filters
        params = {}
        if "state" in filters:
            params["state"] = filters["state"]
        if "labels" in filters:
            params["labels"] = ",".join(filters["labels"])

        for issue in self._client.get_paginated(
            f"/repos/{owner}/{repo}/issues", **params
        ):
            if limit and count >= limit:
                return

            # Skip pull requests (they appear in issues API)
            if "pull_request" in issue:
                continue

            yield {"owner": owner, "repo": repo, "number": issue["number"]}, count + 1
            count += 1
