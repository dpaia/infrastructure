"""Centralized sandbox management with state tracking.

This module provides SandboxManager which manages sandbox instances,
tracks their states, and provides lifecycle management utilities.
"""

import logging
from contextlib import contextmanager
from enum import Enum
from typing import TYPE_CHECKING, Callable, Dict, Optional, TypeVar

if TYPE_CHECKING:
    from ee_bench_core.adapters import Sandbox

from ee_bench_core.core.models import EnvironmentConfig

logger = logging.getLogger(__name__)

T = TypeVar("T")


class SandboxState(Enum):
    """Sandbox lifecycle states."""

    CREATED = "created"  # Sandbox created but not started
    STARTED = "started"  # Sandbox is running
    STOPPED = "stopped"  # Sandbox stopped but not cleaned
    CLEANED = "cleaned"  # Sandbox cleaned up


class SandboxManager:
    """Manages sandbox instances and their lifecycle states.

    SandboxManager provides centralized management of sandboxes including:
    - Creating and tracking sandbox instances
    - Managing sandbox lifecycle (start, stop, cleanup)
    - Tracking sandbox states
    - Providing helper methods for common operations
    - Context manager support for automatic lifecycle management

    Example:
        >>> manager = SandboxManager()
        >>>
        >>> # Create and start sandbox
        >>> sandbox = manager.create_sandbox("task-1", env_config)
        >>> manager.start_sandbox("task-1")
        >>>
        >>> # Use sandbox
        >>> result = sandbox.run_command("ls")
        >>>
        >>> # Cleanup
        >>> manager.stop_sandbox("task-1")
        >>> manager.cleanup_sandbox("task-1")
        >>>
        >>> # Or use context manager
        >>> with manager.managed_sandbox("task-2", env_config, cleanup=True) as sandbox:
        ...     result = sandbox.run_command("ls")
    """

    def __init__(self):
        """Initialize empty sandbox manager."""
        self._sandboxes: Dict[str, "Sandbox"] = {}
        self._states: Dict[str, SandboxState] = {}
        self._env_configs: Dict[str, EnvironmentConfig] = {}

    def create_sandbox(
        self, instance_id: str, env_config: EnvironmentConfig, **kwargs
    ) -> "Sandbox":
        """Create a sandbox for the given instance.

        Args:
            instance_id: Unique identifier for this sandbox
            env_config: Environment configuration
            **kwargs: Additional parameters for sandbox creation

        Returns:
            Created Sandbox instance

        Raises:
            ValueError: If sandbox already exists for this instance_id
        """
        if instance_id in self._sandboxes:
            raise ValueError(
                f"Sandbox already exists for instance '{instance_id}'. "
                f"Current state: {self._states.get(instance_id)}"
            )

        logger.debug(
            f"Creating sandbox for instance '{instance_id}' "
            f"(sandbox_type={env_config.sandbox_type})"
        )

        # Import locally to avoid circular import
        from ee_bench_core.adapters import SandboxFactory

        sandbox = SandboxFactory.create_sandbox(env_config, **kwargs)
        self._sandboxes[instance_id] = sandbox
        self._states[instance_id] = SandboxState.CREATED
        self._env_configs[instance_id] = env_config

        logger.debug(f"Created sandbox for instance '{instance_id}'")
        return sandbox

    def start_sandbox(self, instance_id: str, **kwargs) -> None:
        """Start a sandbox.

        Args:
            instance_id: Instance ID of sandbox to start
            **kwargs: Additional parameters for sandbox.start()

        Raises:
            KeyError: If sandbox doesn't exist
            ValueError: If sandbox is already started
        """
        if instance_id not in self._sandboxes:
            raise KeyError(f"No sandbox found for instance '{instance_id}'")

        state = self._states[instance_id]
        if state == SandboxState.STARTED:
            logger.warning(f"Sandbox '{instance_id}' is already started")
            return

        if state == SandboxState.CLEANED:
            raise ValueError(
                f"Cannot start sandbox '{instance_id}' - it has been cleaned up"
            )

        logger.debug(f"Starting sandbox for instance '{instance_id}'")
        sandbox = self._sandboxes[instance_id]
        sandbox.start(**kwargs)
        self._states[instance_id] = SandboxState.STARTED
        logger.debug(f"Started sandbox for instance '{instance_id}'")

    def stop_sandbox(self, instance_id: str, **kwargs) -> None:
        """Stop a sandbox.

        Args:
            instance_id: Instance ID of sandbox to stop
            **kwargs: Additional parameters for sandbox.stop()

        Raises:
            KeyError: If sandbox doesn't exist
        """
        if instance_id not in self._sandboxes:
            raise KeyError(f"No sandbox found for instance '{instance_id}'")

        state = self._states[instance_id]
        if state == SandboxState.STOPPED:
            logger.warning(f"Sandbox '{instance_id}' is already stopped")
            return

        if state == SandboxState.CLEANED:
            logger.warning(f"Sandbox '{instance_id}' has been cleaned up")
            return

        logger.debug(f"Stopping sandbox for instance '{instance_id}'")
        try:
            sandbox = self._sandboxes[instance_id]
            sandbox.stop(**kwargs)
            self._states[instance_id] = SandboxState.STOPPED
            logger.debug(f"Stopped sandbox for instance '{instance_id}'")
        except Exception as e:
            logger.warning(f"Failed to stop sandbox '{instance_id}': {e}")

    def cleanup_sandbox(self, instance_id: str, **kwargs) -> None:
        """Clean up a sandbox completely.

        Args:
            instance_id: Instance ID of sandbox to cleanup
            **kwargs: Additional parameters for sandbox.cleanup()

        Raises:
            KeyError: If sandbox doesn't exist
        """
        if instance_id not in self._sandboxes:
            raise KeyError(f"No sandbox found for instance '{instance_id}'")

        state = self._states[instance_id]
        if state == SandboxState.CLEANED:
            logger.warning(f"Sandbox '{instance_id}' is already cleaned up")
            return

        logger.info(f"Cleaning up sandbox for instance '{instance_id}'")
        try:
            sandbox = self._sandboxes[instance_id]
            sandbox.cleanup(**kwargs)
            self._states[instance_id] = SandboxState.CLEANED
            logger.info(f"Cleaned up sandbox for instance '{instance_id}'")
        except Exception as e:
            logger.warning(f"Failed to cleanup sandbox '{instance_id}': {e}")
            # Mark as cleaned even on failure to avoid retry loops
            self._states[instance_id] = SandboxState.CLEANED

    def get_sandbox(self, instance_id: str) -> Optional["Sandbox"]:
        """Get sandbox instance by ID.

        Args:
            instance_id: Instance ID

        Returns:
            Sandbox instance or None if not found
        """
        return self._sandboxes.get(instance_id)

    def get_state(self, instance_id: str) -> Optional[SandboxState]:
        """Get current state of sandbox.

        Args:
            instance_id: Instance ID

        Returns:
            SandboxState or None if not found
        """
        return self._states.get(instance_id)

    def is_running(self, instance_id: str) -> bool:
        """Check if sandbox is currently running.

        Args:
            instance_id: Instance ID

        Returns:
            True if sandbox exists and is in STARTED state
        """
        return self._states.get(instance_id) == SandboxState.STARTED

    def remove_sandbox(self, instance_id: str) -> None:
        """Remove sandbox from manager (after cleanup).

        Args:
            instance_id: Instance ID to remove
        """
        if instance_id in self._sandboxes:
            del self._sandboxes[instance_id]
        if instance_id in self._states:
            del self._states[instance_id]
        if instance_id in self._env_configs:
            del self._env_configs[instance_id]

    def cleanup_all(self, **kwargs) -> tuple[int, int]:
        """Clean up all managed sandboxes.

        Args:
            **kwargs: Additional parameters for cleanup (e.g., keep_images)

        Returns:
            Tuple of (success_count, error_count)
        """
        if not self._sandboxes:
            logger.debug("No sandboxes to cleanup")
            return 0, 0

        logger.info(f"Cleaning up {len(self._sandboxes)} sandbox(es)")
        success_count = 0
        error_count = 0

        for instance_id in list(self._sandboxes.keys()):
            try:
                self.cleanup_sandbox(instance_id, **kwargs)
                success_count += 1
            except Exception as e:
                logger.error(f"Failed to cleanup sandbox '{instance_id}': {e}")
                error_count += 1

        logger.info(
            f"Cleanup completed: {success_count} cleaned up, {error_count} errors"
        )
        return success_count, error_count

    def with_sandbox(
        self,
        instance_id: str,
        env_config: EnvironmentConfig,
        func: Callable[["Sandbox"], T],
        cleanup: bool = False,
        **kwargs,
    ) -> T:
        """Execute function with managed sandbox lifecycle.

        This method manages the complete sandbox lifecycle:
        1. Create sandbox
        2. Start sandbox
        3. Execute provided function with sandbox
        4. Stop sandbox (in finally block)
        5. Cleanup sandbox if requested (in finally block)
        6. Remove from manager after cleanup

        Args:
            instance_id: Unique identifier for this sandbox
            env_config: Environment configuration
            func: Function to execute (receives sandbox as first argument)
            cleanup: Whether to cleanup sandbox after execution
            **kwargs: Additional arguments passed to func

        Returns:
            Result from func

        Raises:
            Exception: Any exception raised by func is propagated after cleanup

        Example:
            >>> manager = SandboxManager()
            >>> def run_tests(sandbox: Sandbox, config: DatasetConfig) -> TestResult:
            ...     result = sandbox.run_command("pytest")
            ...     return TestResult(passed=result.returncode == 0)
            >>>
            >>> result = manager.with_sandbox(
            ...     instance_id="task-1",
            ...     env_config=env_config,
            ...     func=run_tests,
            ...     cleanup=True,
            ...     config=dataset_config
            ... )
        """
        # Create and start sandbox
        sandbox = self.create_sandbox(instance_id, env_config, **kwargs)

        try:
            self.start_sandbox(instance_id, **kwargs)

            # Execute function with sandbox
            logger.debug(f"Executing function with sandbox '{instance_id}'")
            return func(sandbox, **kwargs)

        finally:
            # Always stop sandbox
            try:
                self.stop_sandbox(instance_id)
            except Exception as e:
                logger.warning(f"Failed to stop sandbox '{instance_id}': {e}")

            # Cleanup if requested
            if cleanup:
                try:
                    self.cleanup_sandbox(instance_id)
                    self.remove_sandbox(instance_id)
                except Exception as e:
                    logger.warning(f"Failed to cleanup sandbox '{instance_id}': {e}")

    @contextmanager
    def managed_sandbox(
        self,
        instance_id: str,
        env_config: EnvironmentConfig,
        cleanup: bool = True,
        **kwargs,
    ):
        """Context manager for sandbox lifecycle management.

        Args:
            instance_id: Unique identifier for this sandbox
            env_config: Environment configuration
            cleanup: Whether to cleanup sandbox on exit
            **kwargs: Additional parameters for sandbox creation

        Yields:
            Sandbox instance

        Example:
            >>> manager = SandboxManager()
            >>> with manager.managed_sandbox("task-1", env_config, cleanup=True) as sandbox:
            ...     result = sandbox.run_command("ls")
            ...     # Sandbox automatically stopped and cleaned up on exit
        """
        sandbox = self.create_sandbox(instance_id, env_config, **kwargs)

        try:
            self.start_sandbox(instance_id)
            yield sandbox

        finally:
            # Always stop
            try:
                self.stop_sandbox(instance_id)
            except Exception as e:
                logger.warning(f"Failed to stop sandbox '{instance_id}': {e}")

            # Cleanup if requested
            if cleanup:
                try:
                    self.cleanup_sandbox(instance_id)
                    self.remove_sandbox(instance_id)
                except Exception as e:
                    logger.warning(f"Failed to cleanup sandbox '{instance_id}': {e}")

    def get_all_states(self) -> Dict[str, SandboxState]:
        """Get states of all managed sandboxes.

        Returns:
            Dictionary mapping instance_id to SandboxState
        """
        return dict(self._states)

    def count_by_state(self) -> Dict[SandboxState, int]:
        """Count sandboxes by state.

        Returns:
            Dictionary mapping SandboxState to count
        """
        counts = {state: 0 for state in SandboxState}
        for state in self._states.values():
            counts[state] += 1
        return counts

    def __len__(self) -> int:
        """Return number of managed sandboxes."""
        return len(self._sandboxes)

    def __contains__(self, instance_id: str) -> bool:
        """Check if instance_id is managed."""
        return instance_id in self._sandboxes
