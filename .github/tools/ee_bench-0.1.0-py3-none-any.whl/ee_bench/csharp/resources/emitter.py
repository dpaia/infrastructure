#!/usr/bin/env python3
"""Emit EE-bench JSON v2.0 with 6 criteria from test results and environment.

Reads criteria status from environment variables (set by run.sh)
and parser JSON files from /tmp. Prints the result JSON to stdout.
"""
import json
import os
import sys


def read_file(path, limit=51200):
    try:
        with open(path) as f:
            return f.read(limit)
    except Exception:
        return ""


def load_json(path):
    try:
        with open(path) as f:
            return json.load(f)
    except Exception:
        return {}


def _prefix(name):
    """Strip parameterized suffix: 'Foo.Bar(x: 1)' -> 'Foo.Bar'."""
    idx = name.find("(")
    return name[:idx] if idx > 0 else name


def _test_in(name, name_set):
    """Match by exact name first, then by prefix (method name without parameters)."""
    if name in name_set:
        return True
    pfx = _prefix(name)
    return any(n == pfx or _prefix(n) == pfx for n in name_set)


def main():
    patch_status = os.environ.get("PATCH_STATUS", "pass")
    patch_duration = int(os.environ.get("PATCH_DURATION", "0"))
    compile_status = os.environ.get("COMPILE_STATUS", "pass")
    compile_duration = int(os.environ.get("COMPILE_DURATION", "0"))
    test_duration = int(os.environ.get("TEST_DURATION", "0"))
    baseline_duration = int(os.environ.get("BASELINE_DURATION", "0"))
    overall_duration = int(os.environ.get("OVERALL_DURATION", "0"))
    timestamp = os.environ.get("TIMESTAMP", "")
    has_test_patch = os.environ.get("HAS_TEST_PATCH", "false") == "true"
    rebuild_status = os.environ.get("REBUILD_STATUS", "skipped")

    patch_output = read_file("/tmp/_patch_output.txt")
    compile_output = read_file("/tmp/_compile_output.txt")

    # Load parser results for baseline and eval
    baseline_data = load_json("/tmp/baseline_parser.json")
    eval_data = load_json("/tmp/eval_parser.json")

    baseline_passed = {
        t["name"]
        for t in baseline_data.get("passed_tests", [])
        if isinstance(t, dict)
    }
    eval_passed = {
        t["name"] for t in eval_data.get("passed_tests", []) if isinstance(t, dict)
    }

    # Expected test lists (written to file by run.sh to avoid shell quoting issues)
    _expected = load_json("/tmp/_expected.json")
    expected_f2p = _expected.get("fail_to_pass", [])
    expected_p2p = _expected.get("pass_to_pass", [])

    # --- Criterion: baseline_tests ---
    if has_test_patch and compile_status == "pass":
        baseline_status = "pass"
    else:
        baseline_status = "skipped"

    # --- Criterion: tests (eval run) ---
    if compile_status != "pass" or patch_status not in ("pass", "skipped"):
        tests_status = "skipped"
    else:
        eval_summary = eval_data.get("summary", {})
        tests_status = "fail" if eval_summary.get("failed", 0) > 0 else "pass"

    # --- Criterion: fail_to_pass ---
    if not expected_f2p:
        f2p_status = "fail"
        f2p_detail = "no expected fail_to_pass tests defined"
    elif compile_status != "pass" or patch_status not in ("pass", "skipped"):
        f2p_status = "skipped"
        f2p_detail = "skipped due to compilation or patch failure"
    else:
        f2p_ok = all(_test_in(t, eval_passed) for t in expected_f2p)
        if has_test_patch:
            f2p_baseline_ok = all(
                not _test_in(t, baseline_passed) for t in expected_f2p
            )
        else:
            f2p_baseline_ok = True
        f2p_status = "pass" if (f2p_ok and f2p_baseline_ok) else "fail"
        detail_parts = []
        if not f2p_ok:
            missing = [t for t in expected_f2p if not _test_in(t, eval_passed)]
            detail_parts.append("eval missing: " + ", ".join(missing[:10]))
        if not f2p_baseline_ok:
            unexpected = [t for t in expected_f2p if _test_in(t, baseline_passed)]
            detail_parts.append(
                "baseline unexpected pass: " + ", ".join(unexpected[:10])
            )
        f2p_detail = (
            "; ".join(detail_parts)
            if detail_parts
            else "all fail_to_pass tests fixed"
        )

    # --- Criterion: pass_to_pass ---
    if not expected_p2p:
        p2p_status = "skipped"
        p2p_detail = "no expected pass_to_pass tests"
    elif compile_status != "pass" or patch_status not in ("pass", "skipped"):
        p2p_status = "skipped"
        p2p_detail = "skipped due to compilation or patch failure"
    else:
        p2p_eval_ok = all(_test_in(t, eval_passed) for t in expected_p2p)
        if has_test_patch:
            p2p_baseline_ok = all(_test_in(t, baseline_passed) for t in expected_p2p)
        else:
            p2p_baseline_ok = True
        p2p_status = "pass" if (p2p_eval_ok and p2p_baseline_ok) else "fail"
        detail_parts = []
        if not p2p_eval_ok:
            regressed = [t for t in expected_p2p if not _test_in(t, eval_passed)]
            detail_parts.append("eval regressions: " + ", ".join(regressed[:10]))
        if not p2p_baseline_ok:
            baseline_missing = [
                t for t in expected_p2p if not _test_in(t, baseline_passed)
            ]
            detail_parts.append(
                "baseline missing: " + ", ".join(baseline_missing[:10])
            )
        p2p_detail = (
            "; ".join(detail_parts)
            if detail_parts
            else "all pass_to_pass tests still passing"
        )

    # --- Overall status ---
    has_failure = any(
        s == "fail" for s in [compile_status, patch_status, f2p_status, p2p_status]
    )
    overall_status = "failure" if has_failure else "success"

    # --- Build eval test output/summary ---
    eval_summary = eval_data.get(
        "summary",
        {
            "total": 0,
            "passed": 0,
            "failed": 0,
            "errors": 0,
            "skipped": 0,
            "duration_seconds": 0.0,
        },
    )
    eval_test_output = read_file("/tmp/eval_stdout.log") + read_file(
        "/tmp/eval_stderr.log"
    )

    result = {
        "schema_version": "2.0",
        "status": overall_status,
        "timestamp": timestamp,
        "duration_seconds": overall_duration,
        "criteria": [
            {
                "criterion": "compilation",
                "status": compile_status,
                "duration_seconds": compile_duration,
                "output": compile_output[:51200],
            },
            {
                "criterion": "baseline_tests",
                "status": baseline_status,
                "duration_seconds": baseline_duration,
                "passed_tests": list(baseline_passed),
                "failed_tests": baseline_data.get("failed_tests", []),
            },
            {
                "criterion": "patch_applied",
                "status": patch_status,
                "duration_seconds": patch_duration,
                "output": patch_output[:51200],
            },
            {
                "criterion": "tests",
                "status": tests_status,
                "duration_seconds": test_duration,
                "output": eval_test_output[:51200],
                "summary": eval_summary,
                "passed_tests": eval_data.get("passed_tests", []),
                "failed_tests": eval_data.get("failed_tests", []),
                "skipped_tests": eval_data.get("skipped_tests", []),
                "methods": eval_data.get("methods", []),
            },
            {
                "criterion": "fail_to_pass",
                "status": f2p_status,
                "expected": expected_f2p,
                "detail": f2p_detail,
            },
            {
                "criterion": "pass_to_pass",
                "status": p2p_status,
                "expected": expected_p2p,
                "detail": p2p_detail,
            },
        ],
    }
    print(json.dumps(result))


if __name__ == "__main__":
    main()
