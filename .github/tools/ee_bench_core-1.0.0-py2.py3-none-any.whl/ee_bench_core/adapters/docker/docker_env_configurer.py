"""Base class for configurers that build Docker images.

This module provides DockerEnvironmentConfigurer with common Docker image
building functionality for environment configurers.
"""

import io
import logging
import tarfile
from abc import abstractmethod
from typing import TYPE_CHECKING, Dict, Optional

import docker

from ee_bench_core.adapters.docker import DockerAdapter
from ee_bench_core.core.errors import EnvironmentError
from ee_bench_core.core.eval import EnvironmentConfigurer

if TYPE_CHECKING:
    from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig

logger = logging.getLogger(__name__)


class DockerEnvironmentConfigurer(EnvironmentConfigurer):
    """Base class for configurers that build Docker images.

    Provides common functionality:
    - Docker image building from Dockerfile
    - Label management
    - Image caching and verification
    - Build context creation with multiple files

    Subclasses should implement:
    - generate_dockerfile(): Create Dockerfile content
    - configure(): Main configuration logic
    - Other EnvironmentConfigurer methods as needed

    Example:
        class MyDockerConfigurer(DockerEnvironmentConfigurer):
            @property
            def name(self) -> str:
                return "my_configurer"

            def generate_dockerfile(self, env_config, config, **kwargs):
                base_image = env_config.image_name or "ubuntu:22.04"
                return f'''FROM {base_image}
                RUN apt-get update && apt-get install -y my-tool
                '''

            def configure(self, spec, env_config, config, **kwargs):
                dockerfile = self.generate_dockerfile(env_config, config, **kwargs)
                new_image = f"{env_config.image_name}-mytool:latest"

                self.build_image(
                    dockerfile_content=dockerfile,
                    tag=new_image,
                    labels={"my.tool": "installed"}
                )

                env_config.image_name = new_image
                return env_config
    """

    def __init__(self, docker_adapter: Optional[DockerAdapter] = None):
        """Initialize Docker configurer.

        Args:
            docker_adapter: Optional DockerAdapter (creates new if None)
        """
        self.docker = docker_adapter or DockerAdapter()

    @abstractmethod
    def generate_dockerfile(
        self,
        env_config: "EnvironmentConfig",
        config: "DatasetConfig",
        **kwargs,
    ) -> str:
        """Generate Dockerfile content for this configurer.

        Subclasses must implement this to provide the Dockerfile that
        will be used to build the Docker image.

        Args:
            env_config: Current environment configuration
            config: Dataset configuration
            **kwargs: Additional parameters

        Returns:
            Dockerfile content as string

        Example:
            def generate_dockerfile(self, env_config, config, **kwargs):
                base = env_config.image_name or "ubuntu:22.04"
                return f'''FROM {base}
                RUN apt-get update && apt-get install -y curl
                RUN curl -o /usr/local/bin/tool https://example.com/tool
                RUN chmod +x /usr/local/bin/tool
                '''
        """
        pass

    def build_image(
        self,
        dockerfile_content: str,
        tag: str,
        labels: Dict[str, str],
        build_context_files: Optional[Dict[str, str]] = None,
        **kwargs,
    ) -> str:
        """Build Docker image from Dockerfile.

        Creates a tar archive with the Dockerfile and any additional files,
        then builds the Docker image using the Docker API.

        Args:
            dockerfile_content: Dockerfile content as string
            tag: Image tag (e.g., "my-image:latest")
            labels: Labels to apply to the image
            build_context_files: Optional files to include in build context
                Format: {"path/in/context": "file content"}
                Example: {"config.json": '{"key": "value"}'}
            **kwargs: Additional build options

        Returns:
            Image name/tag (same as input tag)

        Raises:
            EnvironmentError: If build fails

        Example:
            >>> self.build_image(
            ...     dockerfile_content="FROM ubuntu:22.04\\nRUN echo hello",
            ...     tag="my-image:latest",
            ...     labels={"app": "myapp", "version": "1.0"},
            ...     build_context_files={
            ...         "config.json": '{"setting": "value"}',
            ...         "scripts/setup.sh": "#!/bin/bash\\necho setup"
            ...     }
            ... )
        """
        try:
            # Create tar archive with Dockerfile and additional files
            tar_io = io.BytesIO()
            with tarfile.open(fileobj=tar_io, mode="w") as tar:
                # Add Dockerfile
                dockerfile_bytes = dockerfile_content.encode("utf-8")
                dockerfile_info = tarfile.TarInfo(name="Dockerfile")
                dockerfile_info.size = len(dockerfile_bytes)
                tar.addfile(dockerfile_info, io.BytesIO(dockerfile_bytes))

                # Add additional files
                if build_context_files:
                    for file_path, content in build_context_files.items():
                        if isinstance(content, str):
                            content_bytes = content.encode("utf-8")
                        else:
                            content_bytes = content

                        file_info = tarfile.TarInfo(name=file_path)
                        file_info.size = len(content_bytes)
                        tar.addfile(file_info, io.BytesIO(content_bytes))

            tar_io.seek(0)

            # Build image
            logger.info(f"Building Docker image: {tag}")
            logger.debug(
                f"Build context files: {list(build_context_files.keys()) if build_context_files else []}"
            )

            build_logs = self.docker.client.api.build(
                fileobj=tar_io,
                custom_context=True,
                tag=tag,
                labels=labels,
                rm=True,
                decode=True,
            )

            # Stream build output
            for log_entry in build_logs:
                if "stream" in log_entry:
                    log_lines = log_entry["stream"].rstrip("\n").split("\n")
                    for line in log_lines:
                        if line.strip():
                            logger.debug(f"Docker build: {line}")
                elif "error" in log_entry:
                    error_msg = log_entry["error"]
                    logger.error(f"Docker build error: {error_msg}")
                    raise docker.errors.BuildError(error_msg, build_logs)

            logger.info(f"Successfully built image: {tag}")
            return tag

        except docker.errors.BuildError as e:
            logger.exception("Docker build failed for tag=%s", tag)
            raise EnvironmentError(f"Docker build failed: {e}") from e
        except Exception as e:
            logger.exception("Failed to build image %s", tag)
            raise EnvironmentError(f"Failed to build image: {e}") from e

    def image_exists(self, image_name: str) -> bool:
        """Check if Docker image exists.

        Args:
            image_name: Image name/tag to check

        Returns:
            True if image exists, False otherwise

        Example:
            >>> if self.image_exists("my-image:latest"):
            ...     print("Image already built")
            ... else:
            ...     self.build_image(...)
        """
        return self.docker.image_exists(image_name)

    def get_image_labels(self, image_name: str) -> Dict[str, str]:
        """Get labels from Docker image.

        Args:
            image_name: Image name/tag

        Returns:
            Dictionary of labels (empty dict if image not found)

        Example:
            >>> labels = self.get_image_labels("my-image:latest")
            >>> print(labels.get("version"))
            1.0.0
        """
        try:
            image = self.docker.client.images.get(image_name)
            return image.labels or {}
        except Exception as e:
            logger.warning(f"Error getting image labels: {e}")
            return {}

    def remove_image(self, image_name: str, force: bool = False) -> bool:
        """Remove Docker image.

        Args:
            image_name: Image name/tag to remove
            force: Whether to force removal even if image is in use

        Returns:
            True if image was removed, False if it didn't exist

        Raises:
            EnvironmentError: If removal fails (and image exists)

        Example:
            >>> if self.remove_image("my-image:old"):
            ...     print("Old image removed")
        """
        try:
            self.docker.remove_image(image_name, force=force)
            return True
        except docker.errors.ImageNotFound:
            logger.debug(f"Image not found (already removed): {image_name}")
            return False
        except Exception as e:
            logger.exception("Failed to remove image %s", image_name)
            raise EnvironmentError(f"Failed to remove image: {e}") from e

    def verify_image_labels(
        self,
        image_name: str,
        expected_labels: Dict[str, str],
    ) -> bool:
        """Verify that an image has expected labels.

        Useful for checking if a cached image was built with the correct
        configuration.

        Args:
            image_name: Image name/tag to check
            expected_labels: Dictionary of expected label key-value pairs

        Returns:
            True if all expected labels match, False otherwise

        Example:
            >>> expected = {
            ...     "ee-bench.base-image": "ubuntu:22.04",
            ...     "ee-bench.tool-version": "1.2.3"
            ... }
            >>> if self.verify_image_labels("my-image:latest", expected):
            ...     print("Image built with correct configuration")
            ... else:
            ...     print("Need to rebuild image")
        """
        if not self.image_exists(image_name):
            return False

        actual_labels = self.get_image_labels(image_name)

        for key, expected_value in expected_labels.items():
            actual_value = actual_labels.get(key)
            if actual_value != expected_value:
                logger.debug(
                    f"Label mismatch for {image_name}: "
                    f"{key}={actual_value} (expected {expected_value})"
                )
                return False

        return True
