"""Patch applier evaluator implementation.

This module provides a parametrized evaluator for applying patches with
configurable patch sources.
"""

import logging
from typing import Callable, List, Optional, Union, TYPE_CHECKING

from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig
from ee_bench_core.core.eval.evaluator import (
    DependencyPosition,
    EvaluationContext,
    Evaluator,
    EvaluatorResult,
    EvaluatorStatus,
)

if TYPE_CHECKING:
    from ee_bench_core.adapters.sandbox_base import Sandbox

logger = logging.getLogger(__name__)


class PatchApplierEvaluator(Evaluator):
    """Parametrized evaluator for applying patches.

    This evaluator accepts a callback function that determines where to get
    the patch content from. This allows creating different patch appliers
    (test patch, prediction patch, golden patch, etc.) without code duplication.

    REQUIRES dependency injection: patch_adapter MUST be injected via constructor.
    Use DI container to create evaluators with proper dependencies injected.
    """

    def __init__(
        self,
        name: str,
        patch_getter: Callable[[DatasetConfig, EvaluationContext], str],
        dependencies: Optional[Union[List[str], DependencyPosition]] = None,
        is_terminal: bool = False,
        description: Optional[str] = None,
        patch_adapter=None,
        timeout: Optional[int] = None,
        retry_count: int = 1,
        can_skip_patch: bool = False,
    ):
        """Initialize patch applier evaluator.

        Args:
            name: Unique name for this evaluator
            patch_getter: Function that returns patch content
                Signature: (config: DatasetConfig, context: EvaluationContext) -> str
            dependencies: Optional dependency specification
            is_terminal: Whether failure should stop the pipeline
            description: Human-readable description
            patch_adapter: REQUIRED PatchAdapter instance (MUST be injected via DI)
            timeout: Optional custom timeout in seconds (None to use runner default)
            retry_count: Number of retry attempts (default: 1, no retries)
        """
        self._name = name
        self._patch_getter = patch_getter
        self._dependencies = dependencies
        self._is_terminal = is_terminal
        self._description = description or f"Apply patch from {patch_getter.__name__}"
        self._patch_adapter = patch_adapter  # Store injected dependency
        self._timeout = timeout
        self._retry_count = retry_count
        self._can_skip_patch = can_skip_patch

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return self._description

    @property
    def dependencies(self) -> Optional[Union[List[str], DependencyPosition]]:
        return self._dependencies

    @property
    def is_terminal(self) -> bool:
        return self._is_terminal

    @property
    def timeout(self) -> Optional[int]:
        return self._timeout

    @property
    def retry_count(self) -> int:
        return self._retry_count

    @property
    def patch_getter(self) -> Callable[[DatasetConfig, EvaluationContext], str]:
        """Get the patch getter function."""
        return self._patch_getter

    def evaluate(
        self,
        spec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        run_id: str,
        shared_context: EvaluationContext,
        sandbox: "Sandbox",
        **kwargs,
    ) -> EvaluatorResult:
        """Apply patch from patch_getter function.

        Args:
            spec: Evaluation spec (may provide patch_adapter if not injected)
            env_config: Environment configuration
            config: Dataset configuration
            run_id: Evaluation run ID
            shared_context: Shared context
            **kwargs: Additional parameters

        Returns:
            EvaluatorResult with patch application outcome
        """
        # patch_adapter MUST be injected via constructor (DI pattern)
        if not self._patch_adapter:
            return EvaluatorResult(
                evaluator_name=self.name,
                status=EvaluatorStatus.ERROR,
                message="patch_adapter must be injected via constructor",
                error=(
                    "PatchApplierEvaluator requires patch_adapter to be provided at initialization. "
                    "Use DI container to create evaluators with injected dependencies. "
                    "See JvmCodeContainer.evaluators() for example."
                ),
            )

        patch_adapter = self._patch_adapter

        try:
            # Get patch content using provided function
            patch_content = self._patch_getter(config, shared_context)

            if not patch_content:
                return EvaluatorResult(
                    evaluator_name=self.name,
                    status=EvaluatorStatus.SKIPPED
                    if self._can_skip_patch
                    else EvaluatorStatus.FAILED,
                    message="No patch content available",
                    error="patch_getter returned empty content",
                )

            # Get project path from env_config (workspace_dir / project_dir)
            # Default to /workspace/task_project if not available
            project_path = "/workspace/task_project"
            if hasattr(env_config, "project_path"):
                project_path = str(env_config.project_path)
            elif hasattr(env_config, "workspace_dir") and env_config.workspace_dir:
                # Fallback for configs without project_path property
                project_path = str(env_config.workspace_dir)

            # Apply patch (dry_run=False to actually apply)
            logger.debug(f"Applying patch (length: {len(patch_content)} chars)")
            success = patch_adapter.apply_patch(sandbox=sandbox,
                                                patch_content=patch_content,
                                                working_dir=project_path,
                                                dry_run=False,
                                                env_config=env_config)

            if success:
                return EvaluatorResult(
                    evaluator_name=self.name,
                    status=EvaluatorStatus.SUCCESS,
                    message="Patch applied successfully",
                    data={"patch_length": len(patch_content)},
                )
            else:
                return EvaluatorResult(
                    evaluator_name=self.name,
                    status=EvaluatorStatus.FAILED,
                    message="Failed to apply patch",
                    error="Patch application failed",
                    data={"patch_length": len(patch_content)},
                )

        except Exception as e:
            logger.error(f"Error applying patch: {e}", exc_info=logger.isEnabledFor(logging.DEBUG))
            return EvaluatorResult(
                evaluator_name=self.name,
                status=EvaluatorStatus.ERROR,
                message="Exception while applying patch",
                error=str(e),
            )
