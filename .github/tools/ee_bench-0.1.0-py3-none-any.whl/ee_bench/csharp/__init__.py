"""ee_bench.csharp - C# eval generator for EE-bench."""

from ee_bench.csharp.generator import CSharpEvalGenerator

__version__ = "0.1.0"

__all__ = ["CSharpEvalGenerator"]
