"""Extended argument parsing utilities for spec-specific parameters."""

import json
import shlex
from typing import Any, Dict, List


def parse_extra_args(args: List[str]) -> Dict[str, Any]:
    """Parse extra arguments into a dictionary.

    Parses command-line arguments in the format:
    - --key=value or --key value for string values
    - --flag for boolean flags
    - Multiple values: --key val1 --key val2 creates list

    Args:
        args: List of argument strings (e.g., sys.argv[1:])

    Returns:
        Dictionary mapping parameter names to values

    Examples:
        >>> parse_extra_args(['--verbose', '--max-workers', '4', '--tag', 'a', '--tag', 'b'])
        {'verbose': True, 'max_workers': '4', 'tag': ['a', 'b']}
    """
    result: Dict[str, Any] = {}
    i = 0

    while i < len(args):
        arg = args[i]

        # Skip non-flag arguments (including single-dash arguments)
        if not arg.startswith("--"):
            i += 1
            continue

        # Handle --key=value format
        if "=" in arg:
            key, value = arg[2:].split("=", 1)
            key = key.replace("-", "_")
            # Skip if key is empty (edge case: just "--")
            if key:
                _add_value(result, key, value)
            i += 1
            continue

        # Handle --key value or --flag format
        key = arg[2:].replace("-", "_")

        # Skip if key is empty (edge case: just "--")
        if not key:
            i += 1
            continue

        # Check if next arg is a value or another flag/option
        if i + 1 < len(args) and not args[i + 1].startswith("-"):
            value = args[i + 1]
            _add_value(result, key, value)
            i += 2
        else:
            # Standalone flag
            result[key] = True
            i += 1

    return result


def _add_value(result: Dict[str, Any], key: str, value: str) -> None:
    """Add value to result dictionary, handling duplicate keys.

    Args:
        result: Result dictionary to update
        key: Parameter key
        value: Parameter value
    """
    if key in result:
        # Key already exists - convert to list or append to existing list
        existing = result[key]
        if isinstance(existing, list):
            existing.append(value)
        else:
            result[key] = [existing, value]
    else:
        result[key] = value


def _parse_volume_mount(volume_str: str) -> tuple:
    """Parse volume mount string into host path, container path, and mode.

    Args:
        volume_str: Volume mount string in format "host:container[:mode]"

    Returns:
        Tuple of (host_path, container_path, mode)

    Examples:
        >>> _parse_volume_mount("/host:/container")
        ('/host', '/container', 'rw')
        >>> _parse_volume_mount("/host:/container:ro")
        ('/host', '/container', 'ro')
    """
    parts = volume_str.split(":")
    if len(parts) == 2:
        return parts[0], parts[1], "rw"
    elif len(parts) >= 3:
        return parts[0], parts[1], parts[2]
    else:
        raise ValueError(f"Invalid volume format: {volume_str}")


def _convert_cli_opts_to_sdk_params(cli_opts: Dict[str, Any]) -> Dict[str, Any]:
    """Convert CLI-style Docker options to Docker SDK parameters.

    Maps short flags and CLI options to the parameter names expected by
    docker.containers.run().

    Args:
        cli_opts: Dictionary of parsed CLI options

    Returns:
        Dictionary of Docker SDK parameters

    Examples:
        >>> _convert_cli_opts_to_sdk_params({'v': '/host:/container', 'e': ['VAR=value']})
        {'volumes': {'/host': {'bind': '/container', 'mode': 'rw'}}, 'environment': ['VAR=value']}
    """
    sdk_params: Dict[str, Any] = {}

    for key, value in cli_opts.items():
        # Volume mounts: -v, --volume
        if key in ("v", "volume"):
            if "volumes" not in sdk_params:
                sdk_params["volumes"] = {}

            volumes = [value] if isinstance(value, str) else value
            for vol in volumes:
                host_path, container_path, mode = _parse_volume_mount(vol)
                sdk_params["volumes"][host_path] = {"bind": container_path, "mode": mode}

        # Environment variables: -e, --env
        elif key in ("e", "env", "environment"):
            sdk_params["environment"] = value if isinstance(value, list) else [value]

        # Port mappings: -p, --publish
        elif key in ("p", "publish", "ports"):
            if "ports" not in sdk_params:
                sdk_params["ports"] = {}

            ports = [value] if isinstance(value, str) else value
            for port in ports:
                # Parse formats: "8080:80", "8080:80/tcp", "80"
                if ":" in port:
                    parts = port.split(":")
                    if len(parts) == 2:
                        host_port, container_port = parts
                        # Handle protocol suffix (e.g., "80/tcp")
                        if "/" in container_port:
                            sdk_params["ports"][container_port] = int(host_port)
                        else:
                            sdk_params["ports"][f"{container_port}/tcp"] = int(host_port)
                else:
                    # Just container port, assign random host port
                    sdk_params["ports"][f"{port}/tcp"] = None

        # Memory limit: --memory, -m
        elif key in ("m", "memory", "mem_limit"):
            sdk_params["mem_limit"] = value

        # Memory reservation: --memory-reservation
        elif key == "memory_reservation":
            sdk_params["mem_reservation"] = value

        # Memory swap limit: --memory-swap
        elif key == "memory_swap":
            sdk_params["memswap_limit"] = value

        # CPU shares: --cpu-shares
        elif key == "cpu_shares":
            sdk_params["cpu_shares"] = int(value)

        # CPU period: --cpu-period
        elif key == "cpu_period":
            sdk_params["cpu_period"] = int(value)

        # CPU quota: --cpu-quota
        elif key == "cpu_quota":
            sdk_params["cpu_quota"] = int(value)

        # CPUs: --cpus
        elif key == "cpus":
            # Convert to nano_cpus (1 CPU = 1e9 nano CPUs)
            sdk_params["nano_cpus"] = int(float(value) * 1e9)

        # Cpuset CPUs: --cpuset-cpus
        elif key == "cpuset_cpus":
            sdk_params["cpuset_cpus"] = value

        # Cpuset MEMs: --cpuset-mems
        elif key == "cpuset_mems":
            sdk_params["cpuset_mems"] = value

        # Network: --network, --net
        elif key in ("network", "net"):
            sdk_params["network"] = value

        # Network mode: --network-mode (deprecated, use --network)
        elif key == "network_mode":
            sdk_params["network_mode"] = value

        # Hostname: --hostname, -h
        elif key in ("h", "hostname"):
            sdk_params["hostname"] = value

        # User: --user, -u
        elif key in ("u", "user"):
            sdk_params["user"] = value

        # Working directory: --workdir, -w
        elif key in ("w", "workdir", "working_dir"):
            sdk_params["working_dir"] = value

        # Entrypoint: --entrypoint
        elif key == "entrypoint":
            sdk_params["entrypoint"] = value

        # Privileged: --privileged
        elif key == "privileged":
            sdk_params["privileged"] = bool(value)

        # Read-only: --read-only
        elif key == "read_only":
            sdk_params["read_only"] = bool(value)

        # Auto-remove: --rm
        elif key == "rm":
            sdk_params["auto_remove"] = bool(value)

        # Detach: --detach, -d
        elif key in ("d", "detach"):
            sdk_params["detach"] = bool(value)

        # TTY: --tty, -t
        elif key in ("t", "tty"):
            sdk_params["tty"] = bool(value)

        # Interactive: --interactive, -i
        elif key in ("i", "interactive", "stdin_open"):
            sdk_params["stdin_open"] = bool(value)

        # Name: --name
        elif key == "name":
            sdk_params["name"] = value

        # Labels: --label, -l
        elif key in ("l", "label", "labels"):
            if "labels" not in sdk_params:
                sdk_params["labels"] = {}

            labels = [value] if isinstance(value, str) else value
            for label in labels:
                if "=" in label:
                    label_key, label_value = label.split("=", 1)
                    sdk_params["labels"][label_key] = label_value
                else:
                    sdk_params["labels"][label] = ""

        # DNS: --dns
        elif key == "dns":
            sdk_params["dns"] = value if isinstance(value, list) else [value]

        # DNS search: --dns-search
        elif key == "dns_search":
            sdk_params["dns_search"] = value if isinstance(value, list) else [value]

        # DNS options: --dns-opt, --dns-option
        elif key in ("dns_opt", "dns_option"):
            sdk_params["dns_opt"] = value if isinstance(value, list) else [value]

        # Extra hosts: --add-host
        elif key == "add_host":
            if "extra_hosts" not in sdk_params:
                sdk_params["extra_hosts"] = {}

            hosts = [value] if isinstance(value, str) else value
            for host in hosts:
                if ":" in host:
                    hostname, ip = host.split(":", 1)
                    sdk_params["extra_hosts"][hostname] = ip

        # Cap add: --cap-add
        elif key == "cap_add":
            sdk_params["cap_add"] = value if isinstance(value, list) else [value]

        # Cap drop: --cap-drop
        elif key == "cap_drop":
            sdk_params["cap_drop"] = value if isinstance(value, list) else [value]

        # Devices: --device
        elif key == "device":
            sdk_params["devices"] = value if isinstance(value, list) else [value]

        # Security opt: --security-opt
        elif key == "security_opt":
            sdk_params["security_opt"] = value if isinstance(value, list) else [value]

        # Tmpfs: --tmpfs
        elif key == "tmpfs":
            if "tmpfs" not in sdk_params:
                sdk_params["tmpfs"] = {}

            tmpfs_mounts = [value] if isinstance(value, str) else value
            for tmpfs in tmpfs_mounts:
                if ":" in tmpfs:
                    path, opts = tmpfs.split(":", 1)
                    sdk_params["tmpfs"][path] = opts
                else:
                    sdk_params["tmpfs"][tmpfs] = ""

        # Shm size: --shm-size
        elif key == "shm_size":
            sdk_params["shm_size"] = value

        # Ulimit: --ulimit
        elif key == "ulimit":
            # This would need docker.types.Ulimit objects, keeping as-is for now
            sdk_params["ulimits"] = value if isinstance(value, list) else [value]

        # Restart policy: --restart
        elif key == "restart":
            # Parse restart policy (e.g., "on-failure:5", "always")
            if ":" in value:
                policy, max_retry = value.split(":", 1)
                sdk_params["restart_policy"] = {
                    "Name": policy,
                    "MaximumRetryCount": int(max_retry),
                }
            else:
                sdk_params["restart_policy"] = {"Name": value}

        # PID mode: --pid
        elif key == "pid":
            sdk_params["pid_mode"] = value

        # IPC mode: --ipc
        elif key == "ipc":
            sdk_params["ipc_mode"] = value

        # UTS mode: --uts
        elif key == "uts":
            sdk_params["uts_mode"] = value

        # Cgroup parent: --cgroup-parent
        elif key == "cgroup_parent":
            sdk_params["cgroup_parent"] = value

        # Platform: --platform
        elif key == "platform":
            sdk_params["platform"] = value

        # Publish all ports: --publish-all, -P
        elif key in ("P", "publish_all"):
            sdk_params["publish_all_ports"] = bool(value)

        # Already SDK-compatible parameters - pass through
        elif key in (
            "detach",
            "stdin_open",
            "tty",
            "auto_remove",
            "network_disabled",
            "oom_kill_disable",
            "oom_score_adj",
            "init",
            "sysctls",
            "runtime",
            "group_add",
            "cgroupns",
            "userns_mode",
            "pids_limit",
            "isolation",
            "volume_driver",
            "volumes_from",
            "blkio_weight",
            "blkio_weight_device",
            "device_read_bps",
            "device_write_bps",
            "device_read_iops",
            "device_write_iops",
            "device_cgroup_rules",
            "device_requests",
            "log_config",
            "healthcheck",
            "stop_signal",
            "storage_opt",
            "mounts",
        ):
            sdk_params[key] = value

        # Unknown parameter - pass through with warning
        else:
            sdk_params[key] = value

    return sdk_params


def parse_docker_opts(docker_opts_str: str) -> Dict[str, Any]:
    """Parse docker options from JSON or command-line format and convert to SDK parameters.

    Accepts two input formats:
    1. JSON: {"memory": "2g", "cpus": "2", "environment": ["VAR=value"]}
    2. CLI style: --memory 2g --cpus 2 -e VAR=value -v /path:/path

    CLI-style options are automatically converted to Docker SDK parameter names.
    For example, -v becomes 'volumes', -e becomes 'environment', etc.

    Args:
        docker_opts_str: Docker options as JSON string or CLI arguments

    Returns:
        Dictionary of Docker SDK-compatible parameters

    Raises:
        ValueError: If input cannot be parsed

    Examples:
        >>> parse_docker_opts('{"mem_limit": "2g", "nano_cpus": 2000000000}')
        {'mem_limit': '2g', 'nano_cpus': 2000000000}

        >>> parse_docker_opts('--memory 2g --cpus 2')
        {'mem_limit': '2g', 'nano_cpus': 2000000000}

        >>> parse_docker_opts('--env VAR1=val1 --env VAR2=val2')
        {'environment': ['VAR1=val1', 'VAR2=val2']}

        >>> parse_docker_opts('-e VAR=val -v /host:/container')
        {'environment': ['VAR=val'], 'volumes': {'/host': {'bind': '/container', 'mode': 'rw'}}}
    """
    if not docker_opts_str or not docker_opts_str.strip():
        return {}

    docker_opts_str = docker_opts_str.strip()

    # Try JSON first - assume it's already in SDK format
    if docker_opts_str.startswith("{"):
        try:
            return json.loads(docker_opts_str)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON format for docker-opts: {e}")

    # Parse as CLI arguments and convert to SDK parameters
    try:
        # Use shlex to properly handle quoted strings
        args = shlex.split(docker_opts_str)
        cli_opts = _parse_docker_cli_args(args)
        # Convert CLI options to SDK parameters
        return _convert_cli_opts_to_sdk_params(cli_opts)
    except ValueError as e:
        raise ValueError(f"Invalid CLI format for docker-opts: {e}")


def _parse_docker_cli_args(args: List[str]) -> Dict[str, Any]:
    """Parse Docker CLI-style arguments including single-dash options.

    Supports both single-dash (-e, -v, -p) and double-dash (--memory, --cpus) options.

    Args:
        args: List of argument strings

    Returns:
        Dictionary mapping parameter names to values
    """
    result: Dict[str, Any] = {}
    i = 0

    while i < len(args):
        arg = args[i]

        # Skip non-flag arguments
        if not arg.startswith("-"):
            i += 1
            continue

        # Handle --key=value format
        if arg.startswith("--") and "=" in arg:
            key, value = arg[2:].split("=", 1)
            key = key.replace("-", "_")
            if key:
                _add_value(result, key, value)
            i += 1
            continue

        # Handle --key or -k format
        if arg.startswith("--"):
            key = arg[2:].replace("-", "_")
        elif arg.startswith("-"):
            key = arg[1:]  # Keep single-char flags as-is (e.g., 'e', 'v', 'p')
        else:
            i += 1
            continue

        # Skip if key is empty
        if not key:
            i += 1
            continue

        # Check if next arg is a value or another flag/option
        if i + 1 < len(args) and not args[i + 1].startswith("-"):
            value = args[i + 1]
            _add_value(result, key, value)
            i += 2
        else:
            # Standalone flag
            result[key] = True
            i += 1

    return result
