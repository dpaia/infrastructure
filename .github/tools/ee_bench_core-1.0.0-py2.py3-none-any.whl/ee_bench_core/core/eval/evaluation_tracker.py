"""Evaluation tracker for managing async evaluator results.

This module provides a singleton tracker that stores and retrieves results
from async evaluators. Results can be stored in memory, filesystem, or database.
"""

import json
import logging
import threading
from dataclasses import asdict
from pathlib import Path
from typing import Dict, Optional

from .evaluator import EvaluatorResult

logger = logging.getLogger(__name__)


class EvaluationTracker:
    """Singleton tracker for async evaluator results.

    Stores results from async evaluators and allows retrieval by
    instance_id, run_id, and evaluator_name.

    Results can be stored in:
    - Memory (default)
    - Filesystem (if storage_dir is provided)
    - Database (future implementation)
    """

    _instance: Optional["EvaluationTracker"] = None
    _lock = threading.Lock()

    def __init__(self, storage_dir: Optional[Path] = None):
        """Initialize evaluation tracker.

        Args:
            storage_dir: Optional directory for persistent storage
        """
        self.storage_dir = storage_dir
        self._results: Dict[str, Dict[str, Dict[str, EvaluatorResult]]] = {}
        # Structure: {instance_id: {run_id: {evaluator_name: result}}}
        self._result_lock = threading.Lock()

        if storage_dir:
            storage_dir.mkdir(parents=True, exist_ok=True)
            logger.debug(f"Evaluation tracker using storage dir: {storage_dir}")

    @classmethod
    def get_instance(cls, storage_dir: Optional[Path] = None) -> "EvaluationTracker":
        """Get singleton instance of evaluation tracker.

        Args:
            storage_dir: Optional storage directory (only used on first call)

        Returns:
            Singleton EvaluationTracker instance
        """
        with cls._lock:
            if cls._instance is None:
                cls._instance = cls(storage_dir)
            return cls._instance

    @classmethod
    def reset_instance(cls):
        """Reset singleton instance (useful for testing)."""
        with cls._lock:
            cls._instance = None

    def submit_result(
        self,
        instance_id: str,
        run_id: str,
        evaluator_name: str,
        result: EvaluatorResult,
    ):
        """Submit result from async evaluator.

        Args:
            instance_id: Task instance identifier
            run_id: Evaluation run identifier
            evaluator_name: Name of the evaluator
            result: Evaluation result
        """
        with self._result_lock:
            # Store in memory
            if instance_id not in self._results:
                self._results[instance_id] = {}
            if run_id not in self._results[instance_id]:
                self._results[instance_id][run_id] = {}

            self._results[instance_id][run_id][evaluator_name] = result

            # Store to filesystem if configured
            if self.storage_dir:
                self._store_to_filesystem(instance_id, run_id, evaluator_name, result)

            logger.debug(
                f"Submitted result for {instance_id}/{run_id}/{evaluator_name}: "
                f"{result.status.value}"
            )

    def get_result(
        self, instance_id: str, run_id: str, evaluator_name: str
    ) -> Optional[EvaluatorResult]:
        """Get result for async evaluator.

        Args:
            instance_id: Task instance identifier
            run_id: Evaluation run identifier
            evaluator_name: Name of the evaluator

        Returns:
            EvaluatorResult if found, None otherwise
        """
        with self._result_lock:
            # Try memory first
            result = (
                self._results.get(instance_id, {}).get(run_id, {}).get(evaluator_name)
            )

            if result:
                return result

            # Try filesystem if configured
            if self.storage_dir:
                return self._load_from_filesystem(instance_id, run_id, evaluator_name)

            return None

    def has_result(self, instance_id: str, run_id: str, evaluator_name: str) -> bool:
        """Check if result exists for async evaluator.

        Args:
            instance_id: Task instance identifier
            run_id: Evaluation run identifier
            evaluator_name: Name of the evaluator

        Returns:
            True if result exists, False otherwise
        """
        return self.get_result(instance_id, run_id, evaluator_name) is not None

    def clear_results(
        self, instance_id: Optional[str] = None, run_id: Optional[str] = None
    ):
        """Clear results from tracker.

        Args:
            instance_id: If provided, only clear results for this instance
            run_id: If provided, only clear results for this run (requires instance_id)
        """
        with self._result_lock:
            if instance_id is None:
                # Clear all results
                self._results = {}
                logger.debug("Cleared all evaluation results")
            elif run_id is None:
                # Clear all results for instance
                if instance_id in self._results:
                    del self._results[instance_id]
                    logger.debug(f"Cleared results for instance {instance_id}")
            else:
                # Clear results for specific run
                if (
                    instance_id in self._results
                    and run_id in self._results[instance_id]
                ):
                    del self._results[instance_id][run_id]
                    logger.debug(f"Cleared results for {instance_id}/{run_id}")

    def _store_to_filesystem(
        self,
        instance_id: str,
        run_id: str,
        evaluator_name: str,
        result: EvaluatorResult,
    ):
        """Store result to filesystem.

        Args:
            instance_id: Task instance identifier
            run_id: Evaluation run identifier
            evaluator_name: Name of the evaluator
            result: Evaluation result
        """
        try:
            # Create directory structure: storage_dir/instance_id/run_id/
            result_dir = self.storage_dir / instance_id / run_id
            result_dir.mkdir(parents=True, exist_ok=True)

            # Convert result to dict and serialize enum properly
            result_dict = asdict(result)
            result_dict["status"] = result.status.value  # Convert enum to string value

            # Write result to JSON file
            result_file = result_dir / f"{evaluator_name}.json"
            with result_file.open("w") as f:
                json.dump(result_dict, f, indent=2)

            logger.debug(f"Stored result to {result_file}")
        except Exception as e:
            logger.error(f"Failed to store result to filesystem: {e}", exc_info=logger.isEnabledFor(logging.DEBUG))

    def _load_from_filesystem(
        self, instance_id: str, run_id: str, evaluator_name: str
    ) -> Optional[EvaluatorResult]:
        """Load result from filesystem.

        Args:
            instance_id: Task instance identifier
            run_id: Evaluation run identifier
            evaluator_name: Name of the evaluator

        Returns:
            EvaluatorResult if found, None otherwise
        """
        try:
            result_file = (
                self.storage_dir / instance_id / run_id / f"{evaluator_name}.json"
            )

            if not result_file.exists():
                return None

            with result_file.open("r") as f:
                result_dict = json.load(f)

            # Convert dict back to EvaluatorResult
            from .evaluator import EvaluatorStatus

            result_dict["status"] = EvaluatorStatus(result_dict["status"])

            result = EvaluatorResult(**result_dict)

            logger.debug(f"Loaded result from {result_file}")
            return result
        except Exception as e:
            logger.error(f"Failed to load result from filesystem: {e}", exc_info=logger.isEnabledFor(logging.DEBUG))
            return None


# Global convenience function
def get_evaluation_tracker(storage_dir: Optional[Path] = None) -> EvaluationTracker:
    """Get global evaluation tracker instance.

    Args:
        storage_dir: Optional storage directory (only used on first call)

    Returns:
        Singleton EvaluationTracker instance
    """
    return EvaluationTracker.get_instance(storage_dir)
