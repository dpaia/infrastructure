"""Provider for selecting appropriate predictions collectors.

This module provides the provider infrastructure for selecting the correct
predictions collector based on CLI parameters and configuration.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .predictions_collector import PredictionsCollector

logger = logging.getLogger(__name__)


class PredictionsCollectorProvider(ABC):
    """Abstract base class for predictions collector providers.

    Providers are responsible for selecting the appropriate collector
    based on evaluation parameters like --agent, --predictions-path, etc.
    """

    @abstractmethod
    def get_collector(self, **kwargs) -> "PredictionsCollector":
        """Get appropriate collector based on parameters.

        Args:
            **kwargs: Parameters including:
                - agent: Agent name (if using agent-based collection)
                - agent_config_path: Path to agent config
                - predictions_path: Path to predictions file or special value
                - Other collector-specific parameters

        Returns:
            PredictionsCollector instance

        Raises:
            ValueError: If parameters are invalid or no collector can be selected
        """
        pass


class BasePredictionsCollectorProvider(PredictionsCollectorProvider):
    """Default provider implementing standard collector selection logic.

    Selection Logic:
    1. If --predictions flag specified: Use named collector from registry
    2. Otherwise: Auto-select first applicable collector by priority

    The provider uses the global collector registry for plugin discovery.
    """

    def __init__(self):
        """Initialize provider and ensure registry is populated."""
        from .predictions_collector_registry import get_global_registry

        self.registry = get_global_registry()
        # Discover collectors from entry points if not already done
        self.registry.discover_plugins()

    def get_collector(
        self, spec=None, env_config=None, **kwargs
    ) -> "PredictionsCollector":
        """Get appropriate collector based on parameters.

        Args:
            spec: Evaluation spec instance (optional, for is_applicable checks)
            env_config: Environment configuration (optional, for is_applicable checks)
            **kwargs: Parameters including:
                - predictions: Collector name (e.g., "git_diff", "agent", "gold", "json")
                - file: Path to predictions file (for JSON collector)
                - agent: Agent name (for agent collector)
                - agent_config_path: Path to agent configuration (for agent collector)
                - Other collector-specific parameters

        Returns:
            PredictionsCollector instance

        Examples:
            # Explicit collector selection via --predictions
            collector = provider.get_collector(predictions="agent")

            # Auto-selection with agent parameters
            collector = provider.get_collector(agent="claude_code")

            # Auto-selection with file parameter
            collector = provider.get_collector(file="predictions.json")

            # Auto-selection fallback to git_diff
            collector = provider.get_collector()
        """
        predictions_name = kwargs.get("predictions")

        # Priority 1: Explicit collector selection via --predictions flag
        if predictions_name:
            logger.debug(f"Using explicitly requested collector: {predictions_name}")
            return self._get_collector_by_name(
                predictions_name, spec=spec, env_config=env_config, **kwargs
            )

        # Priority 2: Auto-select based on is_applicable checks
        logger.debug(
            "No explicit collector specified, auto-selecting based on parameters"
        )
        return self._auto_select_collector(spec, env_config, **kwargs)

    def _get_collector_by_name(
        self, name: str, spec=None, env_config=None, **kwargs
    ) -> "PredictionsCollector":
        """Get collector instance by registry name.

        Args:
            name: Collector name in registry
            spec: Optional spec for applicability check
            env_config: Optional env config for applicability check
            **kwargs: Additional parameters for applicability check

        Returns:
            PredictionsCollector instance

        Raises:
            KeyError: If collector not found in registry
            ValueError: If no applicable collector found
        """
        factory = self.registry.get(name, spec=spec, env_config=env_config, **kwargs)
        return factory()

    def _auto_select_collector(
        self, spec, env_config, **kwargs
    ) -> "PredictionsCollector":
        """Auto-select collector based on is_applicable checks and priority.

        Iterates through all registered collectors sorted by priority (highest first)
        and returns the first collector where is_applicable returns True.

        Args:
            spec: Evaluation spec instance
            env_config: Environment configuration
            **kwargs: CLI parameters

        Returns:
            PredictionsCollector instance

        Raises:
            RuntimeError: If no applicable collector found (should not happen
                         since git_diff is always applicable)
        """
        # Get all collectors sorted by priority (highest first)
        collectors = self._get_collectors_by_priority()

        for name, factory in collectors:
            try:
                # Check if collector is applicable
                if factory.is_applicable(spec, env_config, **kwargs):
                    logger.debug(
                        f"Auto-selected collector: {name} (priority={factory.priority})"
                    )
                    return factory()
            except Exception as e:
                logger.warning(
                    f"Error checking applicability of {name}: {e}. Skipping."
                )
                continue

        # Should never reach here since git_diff is always applicable
        raise RuntimeError(
            "No applicable collector found. This should not happen since "
            "git_diff is always applicable."
        )

    def _get_collectors_by_priority(self):
        """Get all collectors sorted by priority (highest first).

        Returns:
            List of (name, factory) tuples sorted by priority
        """
        collectors = []
        for name in self.registry.list():
            factory = self.registry.get(name)
            # Get priority from factory class (default to 0 if not set)
            priority = getattr(factory, "priority", 0)
            collectors.append((name, factory))

        # Sort by priority (highest first), then by name for stability
        collectors.sort(key=lambda x: (-getattr(x[1], "priority", 0), x[0]))

        logger.debug(
            f"Collectors by priority: {[(name, getattr(factory, 'priority', 0)) for name, factory in collectors]}"
        )

        return collectors
