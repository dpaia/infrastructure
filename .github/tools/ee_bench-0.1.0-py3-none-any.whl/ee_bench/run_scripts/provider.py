"""RunScriptsProvider — enrichment provider fetching run scripts from SWE-bench Pro OS repo."""

from __future__ import annotations

import logging
from typing import Any

from ee_bench.generator import Provider
from ee_bench.generator.errors import ProviderError

logger = logging.getLogger(__name__)


class RunScriptsProvider(Provider):
    """Enrichment provider that fetches run_script.sh and parser.py from a source repo."""

    def __init__(self, **kwargs: Any) -> None:
        self._repo = None
        self._scripts_dir = "run_scripts"
        self._instance_to_dir: dict[str, str] = {}
        self._content_cache: dict[str, dict[str, str]] = {}
        if kwargs:
            self.prepare(**kwargs)

    def prepare(self, **options: Any) -> None:
        """Prepare provider by building instance_id -> directory mapping.

        Options:
            repo: Source GitHub repo (default ``scaleapi/SWE-bench_Pro-os``).
            github_token: GitHub PAT for API access.
            scripts_dir: Directory in the repo containing run scripts (default ``run_scripts``).
        """
        from github import Github

        repo_name = options.get("repo", "scaleapi/SWE-bench_Pro-os")
        github_token = options.get("github_token", "")
        self._scripts_dir = options.get("scripts_dir", "run_scripts")

        gh = Github(github_token) if github_token else Github()
        self._repo = gh.get_repo(repo_name)

        self._instance_to_dir = {}
        try:
            contents = self._repo.get_contents(self._scripts_dir)
            if not isinstance(contents, list):
                contents = [contents]
            for item in contents:
                if item.type == "dir":
                    dir_name = item.name
                    instance_id = dir_name.rsplit("-v", 1)[0] if "-v" in dir_name else dir_name
                    self._instance_to_dir[instance_id] = dir_name
        except Exception as e:
            logger.warning("Failed to list %s in %s: %s", self._scripts_dir, repo_name, e)

        self._content_cache = {}

        logger.info(
            "RunScriptsProvider: mapped %d instance directories from %s/%s",
            len(self._instance_to_dir),
            repo_name,
            self._scripts_dir,
        )

    def provide(self, item=None, *, instance_id="", **kwargs) -> dict[str, str]:
        """Return run script files for the given item.

        Args:
            item: Item dict (unused after explicit-param migration).
            instance_id: Instance identifier for script lookup.
            **kwargs: Ignored.

        Returns:
            Dict with run_script, parser_script, run_script_name, parser_name.
        """

        if not instance_id:
            return {"run_script": "", "parser_script": "", "run_script_name": "", "parser_name": ""}

        dir_name = self._instance_to_dir.get(instance_id)
        if not dir_name:
            return {"run_script": "", "parser_script": "", "run_script_name": "", "parser_name": ""}

        files = self._fetch_directory(dir_name)

        return {
            "run_script": files.get("run_script.sh", ""),
            "parser_script": files.get("parser.py", ""),
            "run_script_name": "run_script.sh" if "run_script.sh" in files else "",
            "parser_name": "parser.py" if "parser.py" in files else "",
        }

    def _fetch_directory(self, dir_name: str) -> dict[str, str]:
        """Fetch and cache all files in a run_scripts subdirectory."""
        if dir_name in self._content_cache:
            return self._content_cache[dir_name]

        files: dict[str, str] = {}
        try:
            path = f"{self._scripts_dir}/{dir_name}"
            contents = self._repo.get_contents(path)
            if not isinstance(contents, list):
                contents = [contents]
            for item in contents:
                if item.type == "file" and item.name in ("run_script.sh", "parser.py", "instance_info.txt"):
                    files[item.name] = item.decoded_content.decode("utf-8")
        except Exception as e:
            logger.warning("Failed to fetch %s/%s: %s", self._scripts_dir, dir_name, e)

        self._content_cache[dir_name] = files
        return files
