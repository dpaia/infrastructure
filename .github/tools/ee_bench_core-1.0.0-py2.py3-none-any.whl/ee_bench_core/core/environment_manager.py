"""Base environment manager using composable configurers.

This module provides BaseEnvironmentManager that orchestrates environment
setup using a chain of configurers with dependency resolution.
"""

import logging
import time
from typing import TYPE_CHECKING, List, Optional

from .abc_types import DatasetConfig, EnvironmentConfig, EnvironmentManager
from .errors import EnvironmentError
from .eval import EnvironmentConfigurer
from .eval.environment_configurer_registry import get_global_registry
from .utils.dependency_resolver import resolve_dependencies
from .utils.dict_utils import exclude_keys

if TYPE_CHECKING:
    from .base_spec import BaseEvalSpec

logger = logging.getLogger(__name__)


class BaseEnvironmentManager(EnvironmentManager):
    """Base environment manager using composable configurers.

    This manager discovers applicable configurers, resolves dependencies,
    and executes them in order to build the evaluation environment.

    Features:
    - Plugin discovery from registry
    - Dependency resolution (topological sort)
    - Spec-specific filtering
    - Configurer chaining (each transforms EnvironmentConfig)
    - Skip logic (configurers can skip based on conditions)

    Example:
        >>> from ee_bench_core.core.environment_manager import BaseEnvironmentManager
        >>> from my_configurers import BaseImageConfigurer, TaskConfigurer
        >>>
        >>> # With explicit configurers
        >>> manager = BaseEnvironmentManager(
        ...     spec=my_spec,
        ...     configurers=[BaseImageConfigurer(), TaskConfigurer()]
        ... )
        >>>
        >>> # With plugin discovery
        >>> manager = BaseEnvironmentManager(
        ...     spec=my_spec,
        ...     enable_plugins=True
        ... )
        >>>
        >>> # Setup environment
        >>> env_config = manager.setup_environment(task_config)
    """

    def __init__(
        self,
        spec: "BaseEvalSpec",
        configurers: Optional[List[EnvironmentConfigurer]] = None,
        enable_plugins: bool = True,
        **kwargs,
    ):
        """Initialize base environment manager.

        Args:
            spec: Evaluation specification
            configurers: Optional list of configurers from spec (plugins will be added)
            enable_plugins: Whether to discover plugins from registry
            **kwargs: Additional configuration passed to configurers
        """
        self.spec = spec
        self.enable_plugins = enable_plugins
        self._configurers: List[EnvironmentConfigurer] = []
        self._kwargs = kwargs

        # Add spec-provided configurers first
        if configurers is not None:
            self._configurers.extend(configurers)
            logger.debug(
                f"Added {len(configurers)} configurers from spec: "
                f"{[c.name for c in configurers]}"
            )

        # Always discover plugins if enabled (will be merged with spec configurers)
        if self.enable_plugins:
            self._discover_plugins()

        logger.debug(
            f"Initialized BaseEnvironmentManager with {len(self._configurers)} configurers: "
            f"{[c.name for c in self._configurers]}"
        )

    def _discover_configurers(self) -> None:
        """Discover configurers from spec and registry."""
        # Get configurers from spec
        spec_configurers = self.spec.get_configurers(**self._kwargs)
        self._configurers.extend(spec_configurers)

        logger.debug(
            f"Discovered {len(spec_configurers)} configurers from spec: "
            f"{[c.name for c in spec_configurers]}"
        )

        # Get plugin configurers for this spec
        if self.enable_plugins:
            self._discover_plugins()

    def _discover_plugins(self) -> None:
        """Discover plugin configurers from registry."""
        registry = get_global_registry()

        # Ensure plugins are discovered from entry points
        registry.discover_plugins()

        plugin_metadata = registry.list_for_spec(self.spec.name)

        plugin_count = 0
        for metadata in plugin_metadata:
            factory = metadata.factory

            # Check if configurer is already added
            if any(c.name == metadata.name for c in self._configurers):
                logger.debug(
                    f"Skipping plugin configurer '{metadata.name}': already registered"
                )
                continue

            # Instantiate configurer (may need kwargs)
            try:
                configurer = factory(**self._kwargs)
                self._configurers.append(configurer)
                plugin_count += 1
                logger.debug(f"Discovered plugin configurer: {metadata.name}")
            except Exception as e:
                logger.warning(
                    f"Failed to instantiate plugin configurer '{metadata.name}': {e}"
                )

        if plugin_count > 0:
            logger.debug(
                f"Discovered {plugin_count} plugin configurers for spec '{self.spec.name}'"
            )

    def _resolve_dependencies(
        self,
        configurers: List[EnvironmentConfigurer],
    ) -> List[EnvironmentConfigurer]:
        """Resolve configurer dependencies using topological sort.

        Uses dependency resolver with priority-based ordering for configurers
        at the same dependency level.

        Args:
            configurers: List of configurers to sort

        Returns:
            Sorted list of configurers in execution order

        Raises:
            ValueError: If circular dependencies detected or dependency not found
        """
        logger.debug(
            f"Resolving dependencies for {len(configurers)} configurers: "
            f"{[c.name for c in configurers]}"
        )

        # Use dependency resolver with position constraints (FIRST/MIDDLE/LAST)
        batches = resolve_dependencies(configurers, validate=True, skip_unresolved=True)

        # Flatten batches into single list (configurers execute sequentially)
        sorted_configurers = [c for batch in batches for c in batch]

        logger.debug(
            f"Dependency resolution complete. Execution order: "
            f"{[c.name for c in sorted_configurers]}"
        )

        return sorted_configurers

    def setup_environment(
        self,
        config: DatasetConfig,
        force: bool = False,
        **kwargs,
    ) -> EnvironmentConfig:
        """Set up evaluation environment using configurers.

        Executes configurers in dependency order, each transforming the
        EnvironmentConfig until the final environment is ready.

        Supports incremental builds: if environment_config_path is provided,
        loads existing config and skips already-executed configurers.

        Args:
            config: Dataset configuration
            force: Whether to force rebuild (passed to configurers)
            **kwargs: Additional parameters passed to configurers
                     - environment_config_path: Path to existing config for incremental builds

        Returns:
            Final EnvironmentConfig after all configurers

        Raises:
            EnvironmentError: If environment setup fails
        """
        logger.info(f"Setting up environment for {config.instance_id}")
        setup_start = time.time()

        try:
            # Check if we should load existing environment config for incremental build
            environment_config_path = kwargs.get("environment_config_path")
            if environment_config_path and not force:
                # Filter out environment_config_path to avoid duplicate argument error
                filtered_kwargs = exclude_keys(kwargs, "environment_config_path")
                env_config = self._load_existing_config(
                    config, environment_config_path, **filtered_kwargs
                )
                if env_config:
                    logger.debug(
                        f"Loaded existing environment config from {environment_config_path} "
                        f"for incremental build"
                    )
                else:
                    logger.warning(
                        f"Failed to load config from {environment_config_path}, "
                        f"creating new environment"
                    )
                    env_config = self._create_initial_config(config, **kwargs)
            else:
                # Create initial environment config
                env_config = self._create_initial_config(config, **kwargs)

            # If no configurers, return initial config
            if not self._configurers:
                logger.warning("No configurers registered, returning initial config")
                return env_config

            # Resolve dependencies
            sorted_configurers = self._resolve_dependencies(self._configurers)

            logger.debug(
                f"Executing {len(sorted_configurers)} configurers in order: "
                f"{[c.name for c in sorted_configurers]}"
            )

            # Merge kwargs
            merged_kwargs = {**self._kwargs, **kwargs}
            # Handle force_rebuild as alias for force parameter
            force = force or merged_kwargs.get("force_rebuild", False)
            merged_kwargs["force"] = force

            applied_configurers = env_config.configurers

            # Execute configurers in order
            for configurer in sorted_configurers:
                # Check if configurer was already executed successfully (incremental build)
                already_executed = False
                if (
                    hasattr(env_config, "configurers")
                    and configurer.name in env_config.configurers
                ):
                    already_executed = True
                    logger.debug(
                        f"Skipping configurer '{configurer.name}': already executed successfully "
                        f"(use --force-rebuild to re-run)"
                    )
                    continue

                # Check if should configure
                should_run, reason = configurer.should_configure(
                    self.spec, env_config, config, **merged_kwargs
                )

                if not should_run:
                    logger.debug(f"Skipping configurer '{configurer.name}': {reason}")
                    continue

                # Execute configurer
                logger.debug(f"Executing configurer '{configurer.name}' ")
                configurer_start = time.time()

                try:
                    env_config = configurer.configure(
                        self.spec, env_config, config, **merged_kwargs
                    )

                    if env_config is None:
                        raise EnvironmentError(
                            f"Configurer '{configurer.name}' returned None. "
                            f"Configurers must return an EnvironmentConfig."
                        )

                    configurer_duration = time.time() - configurer_start
                    logger.debug(
                        f"Configurer '{configurer.name}' completed successfully "
                        f"in {configurer_duration:.2f}s"
                    )

                    applied_configurers.append(configurer.name)

                except Exception as e:
                    logger.error(
                        f"Configurer '{configurer.name}' failed: {e}",
                        exc_info=logger.isEnabledFor(logging.DEBUG),
                    )

                    raise EnvironmentError(
                        f"Environment setup failed in configurer '{configurer.name}': {e}"
                    ) from e

            setup_duration = time.time() - setup_start
            logger.debug(
                f"Environment setup completed successfully for {config.instance_id} "
                f"in {setup_duration:.2f}s"
            )

            if hasattr(env_config, "configurers"):
                env_config.configurers = applied_configurers

            return env_config

        except EnvironmentError:
            # Re-raise environment errors
            raise
        except Exception as e:
            logger.error(f"Failed to set up environment: {e}", exc_info=logger.isEnabledFor(logging.DEBUG))
            raise EnvironmentError(f"Environment setup failed: {e}") from e

    def _create_initial_config(
        self,
        config: DatasetConfig,
        **kwargs,
    ) -> EnvironmentConfig:
        """Create initial environment config.

        This is a minimal config that configurers will enhance.
        Subclasses can override this to provide spec-specific initial config.

        Args:
            config: Dataset configuration
            **kwargs: Additional parameters including:
                     - sandbox: Sandbox type ('docker' or 'local')
                     - workspace_dir: Workspace directory path

        Returns:
            Initial EnvironmentConfig (DockerEnvironmentConfig or LocalEnvironmentConfig)
        """
        from pathlib import Path

        # Determine sandbox type from kwargs
        sandbox_type = kwargs.get("sandbox", "docker")

        # Create appropriate environment config based on sandbox type
        if sandbox_type == "local":
            try:
                from ee_bench_core.adapters.local import LocalEnvironmentConfig

                return LocalEnvironmentConfig(
                    workspace_dir=Path(kwargs.get("workspace_dir", "/tmp/workspace")),
                    project_dir=kwargs.get("project_dir", "task_project"),
                    env_vars=kwargs.get("env_vars", {}),
                )
            except ImportError:
                logger.error(
                    "LocalEnvironmentConfig not available, cannot create local environment"
                )
                raise
        else:
            # Default to Docker
            try:
                from ee_bench_core.adapters.docker import DockerEnvironmentConfig

                return DockerEnvironmentConfig(
                    instance_id=config.instance_id,
                    workspace_dir=Path(kwargs.get("workspace_dir", "/workspace")),
                )
            except ImportError:
                logger.error(
                    "DockerEnvironmentConfig not available, cannot create docker environment"
                )
                raise

    def _load_existing_config(
        self,
        config: DatasetConfig,
        environment_config_path: str,
        **kwargs,
    ) -> Optional[EnvironmentConfig]:
        """Load existing environment config from file for incremental builds.

        Args:
            config: Dataset configuration
            environment_config_path: Path to existing environment config file
            **kwargs: Additional parameters

        Returns:
            Loaded EnvironmentConfig or None if loading fails
        """
        try:
            from pathlib import Path

            config_file = Path(environment_config_path)
            if not config_file.exists():
                logger.warning(
                    f"Environment config file not found: {environment_config_path}"
                )
                return None

            # Load environment config using EnvironmentSerializerManager
            serializer = self.spec.env_serializer
            environments = serializer.load_from_file(config_file)

            # Get the config for this instance
            if config.instance_id in environments:
                loaded_config = environments[config.instance_id]
                logger.debug(
                    f"Loaded environment config for {config.instance_id} "
                    f"from {environment_config_path}"
                )

                # Log which configurers have already been executed
                if hasattr(loaded_config, "configurers") and loaded_config.configurers:
                    logger.debug(
                        f"Already executed configurers: {', '.join(loaded_config.configurers)}"
                    )

                return loaded_config
            else:
                logger.warning(
                    f"Instance {config.instance_id} not found in environment config file"
                )
                return None

        except Exception as e:
            logger.error(f"Failed to load environment config: {e}", exc_info=logger.isEnabledFor(logging.DEBUG))
            return None

    def clean_environment(
        self,
        config: EnvironmentConfig,
        **kwargs,
    ) -> None:
        """Clean up environment.

        Base implementation: no-op.
        Configurers can register cleanup hooks if needed.

        Args:
            config: Dataset or environment configuration to clean
            **kwargs: Additional parameters
        """
        logger.debug("BaseEnvironmentManager.clean_environment() - no-op")
        pass

    def list_environments(self, **kwargs) -> List[EnvironmentConfig]:
        """List all environments.

        Base implementation: empty list.
        Subclasses can override to provide environment listing.

        Args:
            **kwargs: Additional parameters

        Returns:
            List of EnvironmentConfig instances
        """
        logger.debug(
            "BaseEnvironmentManager.list_environments() - returning empty list"
        )
        return []
