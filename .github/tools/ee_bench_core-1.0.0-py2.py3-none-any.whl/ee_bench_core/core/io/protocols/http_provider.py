"""HTTP/HTTPS protocol provider for remote file access.

Handles http:// and https:// URIs with download support.
"""

import logging
from pathlib import Path
from typing import BinaryIO, Optional
import requests

from .base import FileProtocolProvider

logger = logging.getLogger(__name__)


class HttpProvider(FileProtocolProvider):
    """Protocol provider for http:// and https:// schemes.

    Downloads files from HTTP(S) URLs and optionally caches them locally.
    """

    # Plugin metadata
    __provider_name__ = "http"
    __provider_description__ = "HTTP/HTTPS protocol for remote file downloads"
    __provider_version__ = "1.0.0"
    __provider_author__ = "EE-Bench"
    __provider_schemes__ = ["http", "https"]

    def __init__(self, timeout: int = 30):
        """Initialize HTTP provider.

        Args:
            timeout: Request timeout in seconds (default: 30)
        """
        self.timeout = timeout

    @classmethod
    def schemes(cls) -> list[str]:
        """Return supported URI schemes."""
        return ["http", "https"]

    def load(
        self,
        uri: str,
        cache_path: Optional[Path] = None,
        **kwargs
    ) -> bytes:
        """Load content from HTTP(S) URL.

        Args:
            uri: HTTP(S) URL
            cache_path: Optional path to save downloaded file
            **kwargs: Additional options:
                - timeout: Request timeout (default: self.timeout)
                - headers: Custom HTTP headers dict
                - skip_if_cached: Skip download if cache_path exists (default: True)

        Returns:
            File content as bytes

        Raises:
            FileNotFoundError: If URL returns 404
            IOError: If download fails
        """
        timeout = kwargs.get("timeout", self.timeout)
        headers = kwargs.get("headers", {})
        skip_if_cached = kwargs.get("skip_if_cached", True)

        # Check cache first
        if cache_path and skip_if_cached and cache_path.exists():
            logger.info(f"Using cached file: {cache_path}")
            with open(cache_path, "rb") as f:
                return f.read()

        logger.info(f"Downloading from: {uri}")

        try:
            response = requests.get(
                uri,
                timeout=timeout,
                headers=headers,
                stream=False,  # Load entire content
            )
            response.raise_for_status()

            content = response.content

            # Save to cache if provided
            if cache_path:
                logger.debug(f"Caching downloaded file to: {cache_path}")
                cache_path.parent.mkdir(parents=True, exist_ok=True)
                with open(cache_path, "wb") as f:
                    f.write(content)

            logger.info(f"Downloaded {len(content)} bytes from {uri}")
            return content

        except requests.exceptions.HTTPError as e:
            if e.response and e.response.status_code == 404:
                raise FileNotFoundError(f"URL not found (404): {uri}") from e
            raise IOError(f"HTTP error downloading {uri}: {e}") from e
        except requests.exceptions.Timeout as e:
            raise IOError(f"Timeout downloading {uri} (timeout={timeout}s)") from e
        except requests.exceptions.RequestException as e:
            raise IOError(f"Failed to download {uri}: {e}") from e
        except Exception as e:
            raise IOError(f"Unexpected error downloading {uri}: {e}") from e

    def save(
        self,
        uri: str,
        content: bytes,
        **kwargs
    ) -> str:
        """Save content to HTTP(S) URL.

        Args:
            uri: HTTP(S) URL (for PUT/POST)
            content: Content to upload
            **kwargs: Additional options:
                - method: HTTP method (default: "PUT")
                - headers: Custom HTTP headers dict
                - timeout: Request timeout

        Returns:
            URI of saved resource

        Raises:
            NotImplementedError: Upload not supported by default
            IOError: If upload fails
        """
        # HTTP upload support is optional
        # Most use cases don't need this, but it can be enabled
        if not kwargs.get("enable_upload", False):
            raise NotImplementedError(
                "HTTP upload not enabled. Use save with enable_upload=True if needed."
            )

        method = kwargs.get("method", "PUT")
        headers = kwargs.get("headers", {})
        timeout = kwargs.get("timeout", self.timeout)

        logger.info(f"Uploading {len(content)} bytes to: {uri}")

        try:
            if method.upper() == "PUT":
                response = requests.put(uri, data=content, headers=headers, timeout=timeout)
            elif method.upper() == "POST":
                response = requests.post(uri, data=content, headers=headers, timeout=timeout)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")

            response.raise_for_status()
            logger.info(f"Uploaded successfully to {uri}")
            return uri

        except requests.exceptions.RequestException as e:
            raise IOError(f"Failed to upload to {uri}: {e}") from e

    def exists(self, uri: str, **kwargs) -> bool:
        """Check if resource exists at HTTP(S) URL.

        Uses HEAD request to check existence without downloading.

        Args:
            uri: HTTP(S) URL
            **kwargs: Additional options:
                - timeout: Request timeout

        Returns:
            True if resource exists (200 status), False otherwise
        """
        timeout = kwargs.get("timeout", self.timeout)

        try:
            response = requests.head(uri, timeout=timeout, allow_redirects=True)
            return response.status_code == 200
        except requests.exceptions.RequestException:
            return False

    def stream_load(
        self,
        uri: str,
        cache_path: Optional[Path] = None,
        **kwargs
    ) -> BinaryIO:
        """Stream content from HTTP(S) URL.

        Args:
            uri: HTTP(S) URL
            cache_path: Optional path to cache streaming content
            **kwargs: Additional options:
                - timeout: Request timeout
                - headers: Custom HTTP headers
                - chunk_size: Streaming chunk size (default: 8192)

        Returns:
            Binary stream

        Raises:
            FileNotFoundError: If URL returns 404
            IOError: If download fails
        """
        from io import BytesIO

        timeout = kwargs.get("timeout", self.timeout)
        headers = kwargs.get("headers", {})
        chunk_size = kwargs.get("chunk_size", 8192)

        logger.info(f"Streaming from: {uri}")

        try:
            response = requests.get(
                uri,
                timeout=timeout,
                headers=headers,
                stream=True,
            )
            response.raise_for_status()

            # If caching, write to file and return file stream
            if cache_path:
                cache_path.parent.mkdir(parents=True, exist_ok=True)
                logger.debug(f"Caching streamed content to: {cache_path}")

                with open(cache_path, "wb") as cache_file:
                    for chunk in response.iter_content(chunk_size=chunk_size):
                        if chunk:
                            cache_file.write(chunk)

                # Return file stream from cache
                return open(cache_path, "rb")
            else:
                # Load into memory and return BytesIO
                content = BytesIO()
                for chunk in response.iter_content(chunk_size=chunk_size):
                    if chunk:
                        content.write(chunk)
                content.seek(0)
                return content

        except requests.exceptions.HTTPError as e:
            if e.response and e.response.status_code == 404:
                raise FileNotFoundError(f"URL not found (404): {uri}") from e
            raise IOError(f"HTTP error streaming {uri}: {e}") from e
        except requests.exceptions.RequestException as e:
            raise IOError(f"Failed to stream {uri}: {e}") from e
