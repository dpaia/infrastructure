"""Text sanitization utilities for GitHub content."""

import re


def sanitize_mentions(text: str) -> str:
    """Escape @mentions in text to prevent GitHub notifications.

    Inserts a zero-width space (U+200B) after '@' when followed by a word
    character, which prevents GitHub from parsing it as a user/team mention
    while keeping the text visually identical.
    """
    if not text:
        return text
    return re.sub(r"@(?=\w)", "@\u200b", text)
