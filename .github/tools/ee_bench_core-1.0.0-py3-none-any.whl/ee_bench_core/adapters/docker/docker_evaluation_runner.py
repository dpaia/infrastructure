"""Docker-aware evaluation runner.

This module provides an evaluation runner that manages Docker container lifecycle
for evaluations, including starting containers before evaluation and cleaning up
after completion.
"""

import logging
from typing import TYPE_CHECKING, Any, List, Optional

from ee_bench_core.core.abc_types import (
    DatasetConfig,
    EnvironmentConfig,
    EvaluationResult,
)
from ee_bench_core.core.eval.base_evaluation_runner import BaseEvaluationRunner
from ee_bench_core.core.eval.evaluator import Evaluator
from .docker import DockerAdapter
from .docker_env_config import DockerEnvironmentConfig
from ee_bench_core.core.utils.argparse_ext import parse_docker_opts

if TYPE_CHECKING:
    from ee_bench_core.core.base_spec import BaseEvalSpec

logger = logging.getLogger(__name__)


class DockerEvaluationRunner(BaseEvaluationRunner):
    """Evaluation runner with Docker container lifecycle management.

    This runner extends BaseEvaluationRunner to handle Docker-specific concerns:
    - Starting containers from task images before evaluation
    - Stopping and removing containers after evaluation
    - Optionally cleaning up task images when done

    The runner expects env_config to be a DockerEnvironmentConfig with an image_name.
    """

    def __init__(
        self,
        spec: "BaseEvalSpec",
        evaluators: List[Evaluator],
        docker_adapter: DockerAdapter = DockerAdapter(),
        max_workers: int = 1,
        default_timeout: int = 1800,
        report_manager: Optional[Any] = None,
        clean_images: bool = False,
    ):
        """Initialize Docker evaluation runner.

        Args:
            spec: Evaluation specification that created this runner
            evaluators: List of evaluators to execute in pipeline
            docker_adapter: Docker adapter for container operations
            max_workers: Maximum number of parallel workers for async evaluators
            default_timeout: Default timeout in seconds for evaluator execution
            report_manager: Optional report manager for tracking results
            clean_images: If True, remove task images after evaluation completes
        """
        super().__init__(spec, evaluators, max_workers, default_timeout, report_manager)
        self.docker_adapter = docker_adapter
        self.clean_images = clean_images

    def run_evaluation(
        self,
        config: DatasetConfig,
        env_config: EnvironmentConfig,
        timeout: int = 1800,
        run_id: str = "default",
        **kwargs,
    ) -> EvaluationResult:
        """Run evaluation with Docker container lifecycle management.

        This method:
        1. Starts a container from the task image (if not already running)
        2. Runs the evaluation pipeline
        3. Stops and removes the container
        4. Optionally removes the task image (if clean_images=True)

        Args:
            config: Dataset configuration
            env_config: Environment configuration (should be DockerEnvironmentConfig)
            timeout: Maximum execution time in seconds
            run_id: Unique identifier for the evaluation run
            **kwargs: Additional spec-specific parameters

        Returns:
            EvaluationResult with outcome

        Raises:
            EvaluationError: If evaluation fails
            TypeError: If env_config is not DockerEnvironmentConfig
        """
        if not isinstance(env_config, DockerEnvironmentConfig):
            raise TypeError(
                f"DockerEvaluationRunner requires DockerEnvironmentConfig, "
                f"got {type(env_config).__name__}"
            )

        logger.info(f"Running Docker evaluation for {config.instance_id}")

        # Start container if not already running
        container_started = False
        if not env_config.container_id:
            logger.info(f"Starting container for {config.instance_id}")
            container = self._start_container(env_config, **kwargs)
            env_config.container_id = container.id
            container_started = True
            logger.info(f"Started container {container.id}")

        try:
            # Run evaluation using parent implementation
            result = super().run_evaluation(
                config=config,
                env_config=env_config,
                timeout=timeout,
                run_id=run_id,
                **kwargs,
            )

            logger.info(
                f"Evaluation completed for {config.instance_id}: {result.result}"
            )
            return result

        finally:
            # Cleanup container if we started it
            if container_started and env_config.container_id:
                self._cleanup_container(env_config.container_id)

            # Cleanup task image if requested
            if self.clean_images:
                self._cleanup_image(env_config.image_name)

    def _start_container(self, env_config: DockerEnvironmentConfig, **kwargs):
        """Start container from task image.

        Args:
            env_config: Docker environment configuration

        Returns:
            Docker container object

        Raises:
            Exception: If container start fails
        """
        docker_opts = kwargs.get("docker_opts", "")
        if docker_opts:
            opts = parse_docker_opts(docker_opts)
            logger.debug(f"Starting container from {env_config.image_name} with opts: {opts}")
        else:
            opts = {}
        try:
            container = self.docker_adapter.client.containers.run(
                image=env_config.image_name,
                command="/bin/bash",
                detach=True,
                auto_remove=False,
                stdin_open=True,
                tty=True,
                **opts
            )
            logger.info(
                f"Container {container.id} started from {env_config.image_name}"
            )
            return container
        except Exception as e:
            logger.error(f"Failed to start container from {env_config.image_name}: {e}")
            raise

    def _cleanup_container(self, container_id: str) -> None:
        """Stop and remove container.

        Args:
            container_id: Container ID to cleanup
        """
        try:
            logger.info(f"Stopping container {container_id}")
            container = self.docker_adapter.client.containers.get(container_id)
            container.stop(timeout=10)
            container.remove()
            logger.info(f"Container {container_id} stopped and removed")
        except Exception as e:
            logger.warning(f"Failed to cleanup container {container_id}: {e}")

    def _cleanup_image(self, image_name: str) -> None:
        """Remove Docker image.

        Args:
            image_name: Image name to remove
        """
        try:
            logger.info(f"Removing image {image_name}")
            self.docker_adapter.remove_image(image_name, force=True)
            logger.info(f"Image {image_name} removed")
        except Exception as e:
            logger.warning(f"Failed to cleanup image {image_name}: {e}")

    def get_docker_adapter(self, **kwargs) -> DockerAdapter:
        return self.docker_adapter
