"""Generate command — placeholder for YAML-based pipeline execution.

The old DatasetEngine/CompositeProvider/MultiGeneratorRunner pipeline has been
removed. Script-based pipelines (``ee-dataset run-script``) are now the primary
interface.  This command is kept as a stub to provide a helpful error message.
"""

from __future__ import annotations

import click

from ee_bench.cli.cli import pass_context


@click.command()
@pass_context
def generate(ctx, **kwargs) -> None:
    """Generate a dataset (deprecated — use run-script instead).

    The YAML-based generate pipeline has been removed.
    Use 'ee-dataset run-script' with a Python script instead.

    Example:

        ee-dataset run-script scripts/import_swe_bench_pro.py -S LIMIT=10
    """
    raise click.ClickException(
        "The 'generate' command has been removed. "
        "Use 'ee-dataset run-script <script.py>' instead."
    )
