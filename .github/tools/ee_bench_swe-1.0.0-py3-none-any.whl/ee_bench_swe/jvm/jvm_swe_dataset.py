"""JVM-specific SWE-bench dataset manager implementation.

This module provides JVM-specific dataset management that returns
JvmSweBenchmarkConfig instances instead of the base SweBenchmarkConfig.
"""

import logging
from pathlib import Path
from typing import Dict, Optional

from ee_bench_swe.swe_dataset import SweDatasetManager
from .jvm_swe_config import JvmSweBenchmarkConfig

logger = logging.getLogger(__name__)


class JvmSweDatasetManager(SweDatasetManager):
    """JVM-specific dataset manager for SWE-bench specification.

    Extends SweDatasetManager to return JvmSweBenchmarkConfig instances
    which include JVM-specific fields like build_system, jvm_version, etc.
    """

    def _item_to_config(
        self,
        item: Dict,
        language: Optional[str] = None
    ) -> JvmSweBenchmarkConfig:
        """Convert a dataset item dictionary to JvmSweBenchmarkConfig.

        This overrides the parent method to return JVM-specific config.

        Args:
            item: Raw dataset item dictionary
            language: Language to assign if not in item

        Returns:
            JvmSweBenchmarkConfig instance
        """
        # Use JvmSweBenchmarkConfig's from_dict which handles all JVM-specific fields
        config = JvmSweBenchmarkConfig.from_dict(item)

        # Set language if not present
        if not hasattr(config, 'language') or not config.language:
            config.language = language or "jvm"

        return config
