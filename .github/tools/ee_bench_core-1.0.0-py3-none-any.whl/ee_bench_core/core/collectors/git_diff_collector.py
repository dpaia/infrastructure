"""Git diff-based predictions collector.

Collects predictions by running git diff in the evaluation environment.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Optional

from ee_bench_core.adapters import Sandbox
from ee_bench_core.core.predictions_collector import PredictionsCollector
from ee_bench_core.core.models import PredictionResult

if TYPE_CHECKING:
    from ee_bench_core.core.models import DatasetConfig, EnvironmentConfig

logger = logging.getLogger(__name__)


class GitDiffPredictionsCollector(PredictionsCollector):
    """Collects predictions using git diff from the environment.

    This collector extracts code changes from the evaluation environment by
    running git diff. It supports both Docker and local execution environments
    via GitAdapter.

    Usage:
        collector = GitDiffPredictionsCollector()
        result = collector.collect(
            instance_id="task-1",
            env_config=env_config,
            config=dataset_config,
            base_commit="HEAD",  # Optional: compare against specific commit
            include_untracked=True,  # Optional: include untracked files
        )
    """

    # Plugin metadata
    __collector_name__ = "git_diff"
    __collector_description__ = "Collects predictions from git diff in environment"
    __collector_version__ = "1.0.0"
    __collector_author__ = "EE-Bench"
    __collector_tags__ = ["git", "diff", "default"]
    __collector_specs__ = []  # Works with all specs
    __collector_trigger_modes__ = ["diff", "default"]

    # Default/fallback collector - lowest priority
    priority = 0

    @classmethod
    def is_applicable(cls, spec, env_config, **kwargs) -> bool:
        """Git diff collector is always applicable as fallback.

        This is the default collector used when no other collector
        can handle the request.

        Returns:
            Always True (default/fallback collector)
        """
        return True

    def collect(
        self,
        instance_id: str,
        sandbox: Sandbox,
        config: "DatasetConfig",
        timeout: Optional[int] = None,
        **kwargs,
    ) -> PredictionResult:
        """Collect prediction by running git diff in the environment.

        Args:
            instance_id: Unique identifier for the task instance
            env_config: Environment configuration containing container_id or workspace
            config: Dataset configuration for the task instance
            timeout: Optional timeout in seconds for git operations
            **kwargs: Additional parameters passed to GitAdapter including:
                - auto_start: Auto-start stopped containers (default: False)
                - include_untracked: Include untracked files in diff (default: True)
                - base_commit: Base commit to compare against (e.g., "HEAD", "abc123")
                              If not provided, checks config.base_commit, then compares
                              against staging area.

        Returns:
            PredictionResult with instance_id, content (git diff output), source, and status

        Examples:
            # Collect with dataset config (may contain base_commit)
            result = collector.collect("task-1", env_config, config=dataset_config)

            # Collect changes against specific commit
            result = collector.collect("task-1", env_config, config, base_commit="HEAD")

            # Collect only tracked file changes
            result = collector.collect("task-1", env_config, config, include_untracked=False)

        Raises:
            RuntimeError: If git diff execution fails
        """
        from ee_bench_core.adapters.git import GitAdapter

        try:
            # Create GitAdapter (resolved in collect, not constructor)
            git_adapter = GitAdapter()

            # Use GitAdapter to get diff (passes env_config to extract project path and container_id)
            prediction = git_adapter.get_diff(
                sandbox=sandbox,
                timeout=timeout,
                **kwargs,
            )

            # Return PredictionResult
            # Status will auto-set to SKIPPED if content is empty (via __post_init__)
            return PredictionResult(
                instance_id=instance_id,
                content=prediction,
                source="git_diff",
            )
        except Exception as e:
            logger.error(
                f"Failed to collect git diff prediction for {instance_id}: {e}"
            )
            raise RuntimeError(f"Git diff collection failed: {e}") from e
