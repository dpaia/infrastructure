"""Base serializer manager providing common JSON serialization functionality.

This module provides a generic base class for serializers that handle:
- Saving/loading collections to/from JSON files
- Converting between objects and dictionaries
- Merging data when files exist
- Standard error handling and logging
"""

import json
import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, Generic, List, Optional, TypeVar, Union

from .utils.io import read_json_file, write_json_file

logger = logging.getLogger(__name__)

# Generic type for the objects being serialized
T = TypeVar("T")


class BaseSerializerManager(ABC, Generic[T]):
    """Generic base class for JSON serialization managers.

    Provides common functionality for saving/loading collections of objects
    to/from JSON files. Subclasses specify the data structure (dict vs list)
    and provide conversion methods.

    Type Parameters:
        T: The type of objects being serialized

    Example:
        class MySerializer(BaseSerializerManager[MyObject]):
            def to_dict(self, obj: MyObject) -> Dict:
                return obj.to_dict()

            def from_dict(self, data: Dict) -> MyObject:
                return MyObject.from_dict(data)

            def get_collection_type(self) -> str:
                return "dict"  # or "list"

            def get_item_key(self, item: MyObject) -> str:
                return item.id  # For dict collections
    """

    @abstractmethod
    def to_dict(self, item: T) -> Dict[str, Any]:
        """Convert a single item to dictionary.

        Args:
            item: Object to serialize

        Returns:
            Dictionary representation

        Raises:
            TypeError: If item cannot be serialized
        """
        pass

    @abstractmethod
    def from_dict(self, data: Dict[str, Any]) -> T:
        """Convert a dictionary to an item.

        Args:
            data: Dictionary containing item data

        Returns:
            Deserialized item instance

        Raises:
            ValueError: If data format is invalid
            ImportError: If item class cannot be imported
        """
        pass

    @abstractmethod
    def get_collection_type(self) -> str:
        """Get the collection type for this serializer.

        Returns:
            Either "dict" for dictionary-based collections (keyed by ID)
            or "list" for list-based collections

        Example:
            # Dictionary-based (environments)
            {"instance-1": {...}, "instance-2": {...}}

            # List-based (predictions)
            [{"instance_id": "instance-1", ...}, {"instance_id": "instance-2", ...}]
        """
        pass

    def get_item_key(self, item: T) -> str:
        """Get the unique key for an item (used for dict collections and merging).

        Override this for dict-based collections or when implementing merge logic
        for list-based collections.

        Args:
            item: Item to extract key from

        Returns:
            Unique identifier for the item

        Raises:
            NotImplementedError: If not overridden and collection_type is "dict"
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement get_item_key() "
            f"for dict collections or list merging"
        )

    def save_to_file(
        self,
        items: Union[Dict[str, T], List[T]],
        file_path: Path,
        indent: int = 2,
        overwrite: bool = True,
    ) -> None:
        """Save items to a JSON file.

        Args:
            items: Dictionary or list of items to save
            file_path: Path where the JSON file should be written
            indent: JSON indentation level (default: 2)
            overwrite: If True, replace existing file; if False, merge with existing data

        Raises:
            IOError: If file cannot be written
            TypeError: If items cannot be serialized
        """
        collection_type = self.get_collection_type()

        # Convert items to the appropriate format
        if collection_type == "dict":
            if isinstance(items, dict):
                # Convert dict of objects to dict of dicts
                serialized = self._serialize_dict_collection(items)
            else:
                raise TypeError(
                    f"Expected dict for collection_type='dict', got {type(items)}"
                )
        elif collection_type == "list":
            if isinstance(items, list):
                # Convert list of objects to list of dicts
                serialized = self._serialize_list_collection(items)
            elif isinstance(items, dict):
                # Convert dict to list (for compatibility)
                serialized = self._serialize_list_collection(list(items.values()))
            else:
                raise TypeError(
                    f"Expected list or dict for collection_type='list', got {type(items)}"
                )
        else:
            raise ValueError(f"Invalid collection_type: {collection_type}")

        # Handle merge vs overwrite
        if file_path.exists() and not overwrite:
            logger.info(f"Merging data into existing file: {file_path}")
            serialized = self._merge_with_existing(file_path, serialized)
        elif overwrite and file_path.exists():
            logger.info(f"Overwriting existing file: {file_path}")
        else:
            logger.info(f"Creating new file: {file_path}")

        # Write to file
        try:
            write_json_file(file_path, serialized, indent=indent)
            item_count = len(serialized) if isinstance(serialized, (dict, list)) else 0
            logger.info(f"Successfully saved {item_count} item(s) to {file_path}")
        except Exception as e:
            logger.error(f"Failed to write to {file_path}: {e}")
            raise

    def load_from_file(self, file_path: Path) -> Union[Dict[str, T], List[T]]:
        """Load items from a JSON file.

        Args:
            file_path: Path to the JSON file to read

        Returns:
            Dictionary or list of deserialized items (based on collection_type)

        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If file format is invalid
        """
        logger.info(f"Loading data from {file_path}")

        try:
            data = read_json_file(file_path)
        except FileNotFoundError:
            logger.error(f"File not found: {file_path}")
            raise
        except Exception as e:
            logger.error(f"Failed to read {file_path}: {e}")
            raise

        collection_type = self.get_collection_type()

        # Deserialize based on collection type
        if collection_type == "dict":
            if not isinstance(data, dict):
                raise ValueError(f"Expected dict in {file_path}, got {type(data)}")
            result = self._deserialize_dict_collection(data)
        elif collection_type == "list":
            if not isinstance(data, list):
                raise ValueError(f"Expected list in {file_path}, got {type(data)}")
            result = self._deserialize_list_collection(data)
        else:
            raise ValueError(f"Invalid collection_type: {collection_type}")

        item_count = len(result) if isinstance(result, (dict, list)) else 0
        logger.info(f"Successfully loaded {item_count} item(s) from {file_path}")

        return result

    def _serialize_dict_collection(self, items: Dict[str, T]) -> Dict[str, Any]:
        """Convert a dictionary of items to a dictionary of dicts."""
        serialized = {}
        for key, item in items.items():
            try:
                serialized[key] = self.to_dict(item)
                logger.debug(f"Serialized item with key: {key}")
            except Exception as e:
                logger.error(f"Failed to serialize item {key}: {e}")
                raise
        return serialized

    def _serialize_list_collection(self, items: List[T]) -> List[Dict[str, Any]]:
        """Convert a list of items to a list of dicts."""
        serialized = []
        for item in items:
            try:
                serialized.append(self.to_dict(item))
            except Exception as e:
                logger.error(f"Failed to serialize item: {e}")
                raise
        return serialized

    def _deserialize_dict_collection(self, data: Dict[str, Any]) -> Dict[str, T]:
        """Convert a dictionary of dicts to a dictionary of items."""
        items = {}
        for key, item_dict in data.items():
            try:
                items[key] = self.from_dict(item_dict)
                logger.debug(f"Deserialized item with key: {key}")
            except Exception as e:
                logger.warning(f"Failed to deserialize item {key}: {e}. Skipping.")
                continue
        return items

    def _deserialize_list_collection(self, data: List[Dict[str, Any]]) -> List[T]:
        """Convert a list of dicts to a list of items."""
        items = []
        for item_dict in data:
            try:
                items.append(self.from_dict(item_dict))
            except Exception as e:
                logger.warning(f"Failed to deserialize item: {e}. Skipping.")
                continue
        return items

    def _merge_with_existing(
        self,
        file_path: Path,
        new_data: Union[Dict[str, Any], List[Dict[str, Any]]],
    ) -> Union[Dict[str, Any], List[Dict[str, Any]]]:
        """Merge new data with existing file data.

        Args:
            file_path: Path to existing file
            new_data: New serialized data to merge

        Returns:
            Merged data in the same format as new_data
        """
        try:
            with open(file_path) as f:
                existing_data = json.load(f)
        except (json.JSONDecodeError, IOError) as e:
            logger.warning(f"Failed to read existing file for merge, overwriting: {e}")
            return new_data

        collection_type = self.get_collection_type()

        if collection_type == "dict":
            # Dict merge: new data overwrites existing keys
            if not isinstance(existing_data, dict):
                logger.warning("Existing data is not dict, overwriting")
                return new_data
            if not isinstance(new_data, dict):
                logger.warning("New data is not dict, cannot merge")
                return new_data

            merged = dict(existing_data)
            merged.update(new_data)
            logger.info(f"Merged {len(new_data)} item(s), total: {len(merged)} item(s)")
            return merged

        elif collection_type == "list":
            # List merge: use get_item_key to create a map and update
            if not isinstance(existing_data, list):
                logger.warning("Existing data is not list, overwriting")
                return new_data
            if not isinstance(new_data, list):
                logger.warning("New data is not list, cannot merge")
                return new_data

            # Create map from existing data
            try:
                existing_map = {}
                for item_dict in existing_data:
                    if not isinstance(item_dict, dict):
                        continue
                    # Try to get key from the dict (works with raw dicts)
                    key = self._extract_key_from_dict(item_dict)
                    if key:
                        existing_map[key] = item_dict

                # Update with new data
                for item_dict in new_data:
                    if not isinstance(item_dict, dict):
                        continue
                    key = self._extract_key_from_dict(item_dict)
                    if key:
                        existing_map[key] = item_dict

                merged = list(existing_map.values())
                logger.info(
                    f"Merged {len(new_data)} item(s), total: {len(merged)} item(s)"
                )
                return merged

            except Exception as e:
                logger.warning(f"Failed to merge list data, overwriting: {e}")
                return new_data

        return new_data

    def _extract_key_from_dict(self, item_dict: Dict[str, Any]) -> Optional[str]:
        """Extract the key from a dictionary representation of an item.

        This is a helper for list merging. Subclasses can override to specify
        which field to use as the key.

        Args:
            item_dict: Dictionary representation of an item

        Returns:
            Key string or None if key cannot be extracted
        """
        # Default: try common key field names
        for field in ["instance_id", "id", "name"]:
            if field in item_dict:
                return item_dict[field]
        return None
