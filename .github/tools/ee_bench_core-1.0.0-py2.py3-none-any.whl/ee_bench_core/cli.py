"""New unified CLI with global --spec parameter and dynamic spec parameters.

This module provides the new multi-specification CLI that replaces
the old ee_bench.cli module. The new CLI uses a global --spec parameter
to select the evaluation specification, and passes all additional
arguments to the spec for flexible parameter handling.
"""

import json
import logging
from pathlib import Path

import click

from ee_bench_core.core import ResultStatus
from ee_bench_core.core.errors import SpecNotFoundError, EEBenchError
from ee_bench_core.core.spec_registry import (
    auto_discover_specs,
    get_eval_spec,
    get_spec_info,
    list_available_specs,
)
from ee_bench_core.core.utils.argparse_ext import (
    parse_spec_args,
)
from ee_bench_core.core.utils.logging import setup_logging

logger = logging.getLogger(__name__)


class SpecAwareCommand(click.Command):
    """Custom Click Command that dynamically adds spec-specific options.

    This command class checks if --spec is provided in the parent context
    and adds the spec's CLI parameters as Click options before showing help
    or parsing arguments.
    """

    def __init__(self, *args, command_name=None, **kwargs):
        """Initialize the command with command name for spec lookup.

        Args:
            command_name: Name of the command for spec parameter lookup
        """
        super().__init__(*args, **kwargs)
        self.command_name = command_name

    def parse_args(self, ctx, args):
        """Parse arguments and add spec-specific options if spec is provided."""
        # Try to get spec from parent context or environment
        spec_name = None
        if ctx.parent and "spec" in ctx.parent.params:
            spec_name = ctx.parent.params["spec"]

        # If spec is provided, add dynamic options
        if spec_name and self.command_name:
            try:
                auto_discover_specs()
                spec = get_eval_spec(spec_name)

                # Get spec parameters for this command
                params = spec.get_cli_parameters(self.command_name)

                # Add each parameter as a Click option
                for param in params:
                    names = param.get("names", [])
                    if not names:
                        continue

                    # Skip if option already exists
                    param_name = names[0].lstrip("-").replace("-", "_")
                    if any(p.name == param_name for p in self.params):
                        continue

                    param_type = param.get("type", str)
                    default = param.get("default")
                    help_text = param.get("help", "")
                    required = param.get("required", False)
                    is_flag = param.get("is_flag", False)

                    # For boolean, use flag
                    if param_type is bool or param_type == "bool" or is_flag:
                        option = click.Option(
                            names,
                            is_flag=True,
                            default=default if default is not None else False,
                            help=help_text,
                            expose_value=True,
                        )
                        self.params.append(option)
                        continue

                    # Convert type to Python type if it's a string
                    python_type = param_type
                    if isinstance(param_type, str):
                        if param_type == "int":
                            python_type = int
                        elif param_type == "float":
                            python_type = float
                        elif param_type == "str":
                            python_type = str
                        else:
                            python_type = str
                    # If it's already a Python type, use it as-is

                    # Check if this is a multiple-value option
                    multiple = param.get("multiple", False)

                    # Create Click option for other types
                    option = click.Option(
                        names,
                        type=python_type,
                        default=default,
                        help=help_text,
                        required=required,
                        multiple=multiple,
                        expose_value=True,
                    )
                    self.params.append(option)

            except Exception:
                # If spec loading fails, continue without dynamic options
                logger.debug(
                    "Failed to load dynamic options for %s", spec_name, exc_info=True
                )

        return super().parse_args(ctx, args)


@click.group()
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose logging")
@click.option("--log-file", type=click.Path(), help="Path to log file")
@click.option(
    "--cache",
    is_flag=True,
    default=False,
    help="Enable caching for remote files (datasets, predictions). "
         "Files are cached in ~/.ee-bench/cache/",
)
@click.option(
    "--spec",
    type=str,
    envvar="EE_BENCH_SPEC",
    help="Evaluation specification (e.g., jvm). Can be set via EE_BENCH_SPEC env var.",
)
@click.pass_context
def cli(ctx, verbose, log_file, cache, spec):
    """EE Benchmark CLI - Multi-specification evaluation framework.

    A unified CLI for running evaluations across different benchmark specifications.
    Use --spec to select the specification (e.g., jvm).

    Examples:
        ee-bench --spec jvm prepare-environment --dataset-name my-dataset.json
        ee-bench --spec jvm run-evaluation --run-id exp-001 --predictions-path preds/
        ee-bench --cache --spec jvm run-evaluation --dataset-name https://example.com/data.json
    """
    # Setup logging
    setup_logging(
        "DEBUG" if verbose else "INFO", log_file=Path(log_file) if log_file else None
    )

    # Auto-discover specs (ensures all specs are registered)
    # Specs are now loaded via entry points in pyproject.toml
    auto_discover_specs()

    # Store spec and global options in context for child commands
    ctx.ensure_object(dict)
    ctx.obj["spec"] = spec
    ctx.obj["verbose"] = verbose
    ctx.obj["cache"] = cache


@cli.command()
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    help="Show detailed information including source and package details",
)
@click.pass_context
def list_specs(ctx, verbose):
    """List all available evaluation specifications.

    Shows all registered specifications with their names, descriptions,
    and versions. Use --verbose for additional metadata like source and package info.
    """
    try:
        specs = list_available_specs()

        if not specs:
            click.echo("No specifications registered.")
            return

        click.echo("Available specifications:\n")

        for spec_name in specs:
            info = get_spec_info(spec_name)
            click.echo(f"  {click.style(spec_name, fg='green', bold=True)}")
            click.echo(f"    Description: {info['description']}")
            click.echo(f"    Version: {info['version']}")
            click.echo(f"    Class: {info['class_name']}")

            if verbose:
                click.echo(f"    Source: {info['source']}")
                click.echo(f"    Enabled: {info['enabled']}")

                if info.get("author"):
                    click.echo(f"    Author: {info['author']}")
                if info.get("homepage"):
                    click.echo(f"    Homepage: {info['homepage']}")
                if info.get("package_name"):
                    click.echo(f"    Package: {info['package_name']}")
                if info.get("entry_point_name"):
                    click.echo(f"    Entry Point: {info['entry_point_name']}")

            click.echo()

    except Exception as e:
        logger.exception("Failed to list available specs")
        raise click.ClickException(str(e))


@cli.command()
@click.argument("spec_name")
@click.option("--command", help="Show parameters for specific command")
@click.pass_context
def spec_help(ctx, spec_name, command):
    """Show detailed help for a specification.

    Displays information about a specification including available commands
    and their parameters.

    Arguments:
        spec_name: Name of the specification to show help for
        command: Name of the command to show help for (optional)
    """
    try:
        spec = get_eval_spec(spec_name)
        info = get_spec_info(spec_name)

        click.echo(f"\n{click.style(info['name'], fg='green', bold=True)}")
        click.echo(f"{info['description']}\n")
        click.echo(f"Version: {info['version']}")
        click.echo(f"Framework version required: {info['framework_version_min']}")
        click.echo()

        if command:
            # Show parameters for specific command
            try:
                params = spec.get_cli_parameters(command)
                click.echo(f"Parameters for command '{command}':\n")

                if not params:
                    click.echo("  No spec-specific parameters for this command.")
                else:
                    for param in params:
                        names = param.get("names", [])
                        param_type = param.get("type", "string")
                        default = param.get("default")
                        help_text = param.get("help", "No description")
                        required = param.get("required", False)

                        names_str = ", ".join(str(n) for n in names)
                        click.echo(f"  {names_str}")
                        click.echo(
                            f"    Type: {param_type.__name__ if hasattr(param_type, '__name__') else param_type}"
                        )
                        if required:
                            click.echo("    Required: yes")
                        if default is not None:
                            click.echo(f"    Default: {default}")
                        click.echo(f"    Help: {help_text}")
                        click.echo()

            except Exception as e:
                click.echo(f"Error getting parameters for command '{command}': {e}")
        else:
            click.echo("Available commands:")
            click.echo("  - prepare-environment")
            click.echo("  - run-evaluation")
            click.echo("  - run-command")
            click.echo("  - collect-predictions")
            click.echo()
            click.echo("Use --command to see parameters for a specific command.")
            click.echo("Example: ee-bench spec-help jvm --command prepare-environment")

    except SpecNotFoundError as e:
        raise click.ClickException(str(e))
    except Exception as e:
        logger.exception("Failed to show spec help for %s", spec_name)
        raise click.ClickException(str(e))


@cli.command(
    cls=SpecAwareCommand,
    command_name="prepare-environment",
    context_settings={"ignore_unknown_options": True},
)
@click.option(
    "--dataset-name", required=True, help="Name of dataset or path to JSON file"
)
@click.option(
    "--instance-ids",
    multiple=True,
    help="Instance IDs to prepare (can be specified multiple times or comma-separated)",
)
@click.option(
    "--print-report", default=False, help="Prints report to stdout", is_flag=True
)
@click.argument("spec_args", nargs=-1, type=click.UNPROCESSED)
@click.pass_context
def prepare_environment(
    ctx, dataset_name, instance_ids, print_report, spec_args, **kwargs
):
    """Prepare evaluation environments for task instances.

    Sets up Docker images or other environments required for evaluation.
    Requires --spec to be specified.

    For spec-specific options, use: ee-bench spec-help <spec> --command prepare-environment

    \b
    Examples:
        ee-bench --spec jvm prepare-environment --dataset-name my-dataset.json
        ee-bench --spec jvm prepare-environment --dataset-name data.json --instance-ids task-001,task-002 --max-workers 8
        ee-bench --spec jvm prepare-environment --dataset-name data.json --env-vars JAVA_HOME=/usr/lib/jvm/java-17 --env-vars MAVEN_OPTS="-Xmx2g"
    """
    from ee_bench_core.core.utils.cli_helpers import (
        get_and_validate_spec,
        normalize_instance_ids,
        parse_and_merge_spec_kwargs,
    )

    try:
        # Get and validate specification
        spec_name, spec = get_and_validate_spec(ctx, "prepare-environment")

        # Normalize instance IDs
        ids = normalize_instance_ids(instance_ids)

        # Parse and merge spec-specific kwargs
        spec_kwargs = parse_and_merge_spec_kwargs(
            spec, "prepare-environment", spec_args, kwargs
        )

        click.echo(f"Dataset: {dataset_name}")
        if ids:
            click.echo(f"Instance IDs: {', '.join(ids)}")
        else:
            click.echo("Preparing all instances in dataset")

        # Call spec's prepare_environment method
        result = spec.prepare_environment(
            dataset_name=dataset_name, instance_ids=ids, **spec_kwargs
        )

        # Show results
        click.echo(
            f"\n{click.style('Environment Preparation Complete', fg='green', bold=True)}"
        )
        click.echo(f"Total: {result.total_count}")
        click.echo(f"Successful: {click.style(str(result.success_count), fg='green')}")
        click.echo(f"Failed: {click.style(str(result.failure_count), fg='red')}")

        if result.errors:
            click.echo("\nFailures:")
            for instance_id, error in result.errors.items():
                click.echo(f"  {instance_id}: {error}")

        # Show report path
        report_dir = Path(spec_kwargs.get("report_dir", "./reports"))
        report_name = kwargs.get("report_name") or "environment"
        report_path = report_dir / f"{report_name}.json"
        click.echo(f"\nReport saved to: {report_path}")
        if hasattr(result, "environment_config_file"):
            click.echo(f"Environment config saved to: {result.environment_config_file}")

        # Print report contents
        import json

        if print_report and report_path.exists():
            click.echo(f"\n{click.style('Result:', fg='cyan', bold=True)}")
            with open(report_path, "r") as f:
                report_data = json.load(f)
                click.echo(json.dumps(report_data, indent=2))

        # Exit with non-zero code if all preparations failed
        if result.total_count > 0 and result.success_count == 0:
            raise click.ClickException("All environment preparations failed")

    except click.ClickException:
        # Re-raise ClickException without additional logging
        raise
    except SpecNotFoundError as e:
        raise click.ClickException(str(e))
    except EEBenchError as e:
        logger.exception("Evaluation framework error during prepare-environment")
        raise click.ClickException(str(e))
    except Exception as e:
        logger.exception("Failed to prepare environment command")
        raise click.ClickException(f"Failed to prepare environment: {e}")


@cli.command(
    cls=SpecAwareCommand,
    command_name="run-evaluation",
    context_settings={"ignore_unknown_options": True},
)
@click.option(
    "--dataset-name", required=True, help="Name of dataset or path to JSON file"
)
@click.option(
    "--instance-ids",
    multiple=True,
    help="Instance IDs to evaluate (can be specified multiple times or comma-separated)",
)
@click.option(
    "--run-id", required=True, help="Unique identifier for this evaluation run"
)
@click.option(
    "--print-report", default=False, help="Prints report to stdout", is_flag=True
)
@click.argument("spec_args", nargs=-1, type=click.UNPROCESSED)
@click.pass_context
def run_evaluation(
    ctx, dataset_name, instance_ids, run_id, print_report, spec_args, **kwargs
):
    """Run evaluations for task instances.

    Evaluates predictions against task instances and generates reports.
    Requires --spec to be specified.

    For spec-specific options, use: ee-bench spec-help <spec> --command run-evaluation

    \b
    Examples:
        ee-bench --spec jvm run-evaluation --dataset-name data.json --run-id exp-001 --predictions-path preds/
        ee-bench --spec jvm run-evaluation --dataset-name data.json --run-id exp-002 --predictions-path preds/ --instance-ids task-001,task-002 --timeout 3600
        ee-bench --spec jvm run-evaluation --dataset-name data.json --run-id exp-003 --predictions-path preds/ --env-vars TEST_MODE=integration --env-vars DEBUG=true
    """
    from ee_bench_core.core.utils.cli_helpers import (
        get_and_validate_spec,
        normalize_instance_ids,
        parse_and_merge_spec_kwargs,
    )

    try:
        # Get and validate specification
        spec_name, spec = get_and_validate_spec(ctx, "run-evaluation")

        # Normalize instance IDs
        ids = normalize_instance_ids(instance_ids)

        # Parse and merge spec-specific kwargs
        spec_kwargs = parse_and_merge_spec_kwargs(
            spec, "run-evaluation", spec_args, kwargs
        )

        # Validate required predictions-path
        if "predictions" not in spec_kwargs:
            raise click.UsageError(
                "Missing required parameter: --predictions\n"
                "Example: ee-bench --spec jvm run-evaluation --run-id exp-001 --predictions predictions.json --dataset-name data.json"
            )

        click.echo(f"Dataset: {dataset_name}")
        click.echo(f"Run ID: {run_id}")
        click.echo(f"Predictions path: {spec_kwargs.get('predictions_path')}")
        if ids:
            click.echo(f"Instance IDs: {', '.join(ids)}")
        else:
            click.echo("Evaluating all instances with predictions")

        # Call spec's run_evaluation method
        result = spec.run_evaluation(
            dataset_name=dataset_name, instance_ids=ids, run_id=run_id, **spec_kwargs
        )

        # Show results
        click.echo(f"\n{click.style('Evaluation Complete', fg='green', bold=True)}")

        failed_tasks = 0

        if hasattr(result, "total_items"):
            # FinalReport format
            click.echo(f"Total tasks: {result.total_items}")
            success_count = result.status_counts.get(ResultStatus.SUCCESS, 0)
            failed_tasks = result.status_counts.get(ResultStatus.FAILED, 0)
            skipped_count = result.status_counts.get(ResultStatus.SKIPPED, 0)
            click.echo(f"Successful: {click.style(str(success_count), fg='green')}")
            click.echo(f"Failed: {click.style(str(failed_tasks), fg='red')}")
            click.echo(f"Skipped: {skipped_count}")

        # Show report path
        report_dir = Path(spec_kwargs.get("report_dir", "./reports"))
        report_name = kwargs.get("report_name", run_id) or run_id
        report_path = report_dir / f"{report_name}.json"
        click.echo(f"\nReport saved to: {report_path}")

        # Print report contents
        import json

        if print_report and report_path.exists():
            click.echo(f"\n{click.style('Report Contents:', fg='cyan', bold=True)}")
            with open(report_path, "r") as f:
                report_data = json.load(f)
                click.echo(json.dumps(report_data, indent=2))

        # Exit with non-zero code if any evaluation failed
        if failed_tasks > 0 and spec_kwargs.get("predictions","") == "gold":
            raise click.ClickException(f"{failed_tasks} evaluation(s) failed")

    except click.ClickException:
        # Re-raise ClickException without additional logging
        raise
    except SpecNotFoundError as e:
        raise click.ClickException(str(e))
    except EEBenchError as e:
        logger.exception("Evaluation framework error during run-evaluation")
        raise click.ClickException(str(e))
    except Exception as e:
        logger.exception("Failed to execute run-evaluation command")
        raise click.ClickException(f"Failed to run evaluation: {e}")


@cli.command(
    cls=SpecAwareCommand,
    command_name="run-command",
    context_settings={"ignore_unknown_options": True},
)
@click.option(
    "--instance-ids",
    multiple=True,
    help="Instance IDs to run command for (only with --environment-config-path)",
)
@click.option(
    "--command",
    "command_list",  # Rename to avoid conflict with function parameter
    multiple=True,
    required=False,
    help="Shell command to execute (can be specified multiple times for sequential execution)",
)
@click.option(
    "--shell",
    "open_shell",
    default=False,
    is_flag=True,
    help="Open interactive shell instead of running a command",
)
@click.option(
    "--save-report", default=False, help="Print result to report", is_flag=True
)
@click.option(
    "--print-report", default=False, help="Prints report to stdout", is_flag=True
)
@click.option(
    "--stream", default=False, help="Stream command output in real-time", is_flag=True
)
@click.argument("spec_args", nargs=-1, type=click.UNPROCESSED)
@click.pass_context
def run_command(
    ctx,
    instance_ids,
    command_list,
    open_shell,
    save_report,
    print_report,
    stream,
    spec_args,
    **kwargs,
):
    """Run a command in configured environments or open an interactive shell.

    Supports three modes:
    1. Command execution: Use --command to run specific commands
    2. Interactive shell: Use --shell to open an interactive terminal
    3. Pre-configured mode: Use environments from prepare-environment

    Requires --spec to be specified.

    For spec-specific options, use: ee-bench spec-help <spec> --command run-command

    \b
    Pre-configured mode example:
        ee-bench --spec jvm run-command \\
            --dataset-name data.json \\
            --instance-ids task-001,task-002 \\
            --command "mvn test" \\
            --run-id cmd-001 \\
            --environment-config-path environment_config.json

    \b
    Ad-hoc Docker mode example:
        ee-bench --spec jvm run-command \\
            --command "ls -la" \\
            --run-id cmd-002 \\
            --sandbox docker \\
            --container-id abc123 \\
            --workspace-dir /workspace

    \b
    Ad-hoc local mode example:
        ee-bench --spec jvm run-command \\
            --command "pwd" \\
            --run-id cmd-003 \\
            --sandbox local \\
            --workspace-dir /tmp/workspace

    \b
    With environment variables:
        ee-bench --spec jvm run-command \\
            --command "mvn test" \\
            --sandbox local \\
            --workspace-dir /tmp/project \\
            --env-vars JAVA_HOME=/usr/lib/jvm/java-17 \\
            --env-vars MAVEN_OPTS="-Xmx2g" \\
            --save-report
    """
    from ee_bench_core.core.utils.cli_helpers import (
        get_and_validate_spec,
        normalize_instance_ids,
        parse_and_merge_spec_kwargs,
    )

    no_report = not save_report

    try:
        # Get and validate specification
        spec_name, spec = get_and_validate_spec(ctx, "run-command")

        # Normalize instance IDs
        ids = normalize_instance_ids(instance_ids)

        # Parse and merge spec-specific kwargs
        spec_kwargs = parse_and_merge_spec_kwargs(
            spec, "run-command", spec_args, kwargs
        )

        # Validate: either --command or --shell must be provided, but not both
        if not command_list and not open_shell:
            raise click.UsageError(
                "Either --command or --shell must be provided.\n"
                "Example with command: ee-bench --spec jvm run-command --command 'ls' --sandbox local --workspace-dir /tmp\n"
                "Example with shell: ee-bench --spec jvm run-command --shell --sandbox local --workspace-dir /tmp"
            )

        if command_list and open_shell:
            raise click.UsageError(
                "Cannot use both --command and --shell together. Use one or the other."
            )

        # Display mode information (validation happens in load_or_build_environments)
        from ee_bench_core.core.utils.cli_helpers import display_environment_mode

        display_environment_mode(spec_kwargs, ids)

        # Handle interactive shell mode
        if open_shell:
            click.echo(
                f"\n{click.style('Opening interactive shell...', fg='cyan', bold=True)}"
            )

            # Load or build environment configuration
            from ee_bench_core.core.utils import (
                load_or_build_environments,
                open_interactive_shell,
            )

            # Use load_or_build_environments to get environment config (handles validation)
            try:
                environments, adjusted_ids = load_or_build_environments(
                    instance_ids=ids, **spec_kwargs
                )
            except ValueError as e:
                # Convert ValueError from validation to Click-friendly error
                raise click.UsageError(str(e))

            if not environments:
                raise click.UsageError(
                    "No environment configuration found. "
                    "Provide either --environment-config-path OR (--sandbox + --workspace-dir).\n"
                    "Example: ee-bench --spec jvm run-command --shell --sandbox local --workspace-dir /tmp"
                )

            # Get the first environment (for adhoc mode, it's "adhoc"; for pre-configured, it's the first instance_id)
            env_id = adjusted_ids[0] if adjusted_ids else list(environments.keys())[0]
            env_config = environments[env_id]

            # Extract auto_start from spec_kwargs if Docker
            auto_start = spec_kwargs.get("start", False)

            # Open interactive shell using the helper
            # Pass as 'start' to match docker_process_manager's kwargs.get("start", False)
            exit_code = open_interactive_shell(env_config, start=auto_start)

            # Exit with shell's exit code
            raise SystemExit(exit_code)

        # Regular command execution mode
        if len(command_list) == 1:
            click.echo(f"Command: {command_list[0]}")
        else:
            click.echo(f"Commands ({len(command_list)} total):")
            for i, cmd in enumerate(command_list, 1):
                click.echo(f"  {i}. {cmd}")

        # Pass no_report and stream flags to spec_kwargs
        spec_kwargs["no_report"] = no_report
        spec_kwargs["stream"] = stream

        # Call spec's run_command method with list of commands
        result = spec.run_commands(
            instance_ids=ids, commands_list=command_list, **spec_kwargs
        )

        # Handle no-report mode: print result directly and exit
        if no_report:
            # Print command output directly
            if isinstance(result, dict) and "results" in result:
                for instance_id, cmd_result_dict in result["results"].items():
                    # Handle both dict and object results
                    if isinstance(cmd_result_dict, dict):
                        stdout = cmd_result_dict.get("stdout", "")
                        stderr = cmd_result_dict.get("stderr", "")
                        exit_code = cmd_result_dict.get("exit_code", 0)
                    else:
                        stdout = getattr(cmd_result_dict, "stdout", "")
                        stderr = getattr(cmd_result_dict, "stderr", "")
                        exit_code = getattr(cmd_result_dict, "exit_code", 0)

                    if stdout:
                        click.echo(stdout, nl=False)
                    if stderr:
                        click.echo(
                            stderr, file=click.get_text_stream("stderr"), nl=False
                        )
                    # Exit with command's exit code
                    if exit_code != 0:
                        raise SystemExit(exit_code)
            return

        # Show results
        click.echo(
            f"\n{click.style('Command Execution Complete', fg='green', bold=True)}"
        )

        failed_tasks = 0

        if hasattr(result, "total_items"):
            # FinalReport format
            click.echo(f"Total tasks: {result.total_items}")
            success_count = result.status_counts.get(ResultStatus.SUCCESS, 0)
            failed_tasks = result.status_counts.get(ResultStatus.FAILED, 0)
            click.echo(f"Successful: {click.style(str(success_count), fg='green')}")
            click.echo(f"Failed: {click.style(str(failed_tasks), fg='red')}")

        if not no_report:
            # Show report path
            report_dir = Path(spec_kwargs.get("report_dir", "./reports"))
            # Try to get actual report name from result
            if hasattr(result, "run_id") and result.run_id:
                actual_report_name = result.run_id
            else:
                # Check both kwargs (dynamically added) and spec_kwargs (converted)
                actual_report_name = (
                    spec_kwargs.get("report_name")
                    or kwargs.get("report_name")
                    or "command-result"
                )
            report_path = report_dir / f"{actual_report_name}.json"
            click.echo(f"\nReport saved to: {report_path}")

            # Print report contents
            import json

            if print_report and report_path.exists():
                click.echo(f"\n{click.style('Report Contents:', fg='cyan', bold=True)}")
                with open(report_path, "r") as f:
                    report_data = json.load(f)
                    click.echo(json.dumps(report_data, indent=2))

        # Exit with non-zero code if any execution failed
        if failed_tasks > 0:
            raise click.ClickException(f"{failed_tasks} command(s) failed")

    except click.ClickException:
        # Re-raise ClickException without additional logging
        raise
    except SpecNotFoundError as e:
        raise click.ClickException(str(e))
    except EEBenchError as e:
        logger.exception("Evaluation framework error during run-command")
        raise click.ClickException(str(e))
    except Exception as e:
        logger.exception("Failed to execute run-command")
        raise click.ClickException(f"Failed to run command: {e}")


@cli.command(
    cls=SpecAwareCommand,
    command_name="collect-predictions",
    context_settings={"ignore_unknown_options": True},
)
@click.option(
    "--dataset-name", required=True, help="Name of dataset or path to JSON file"
)
@click.option(
    "--instance-ids",
    multiple=True,
    help="Instance IDs to collect (can be specified multiple times or comma-separated)",
)
@click.argument("spec_args", nargs=-1, type=click.UNPROCESSED)
@click.pass_context
def collect_predictions(ctx, dataset_name, instance_ids, spec_args, **kwargs):
    """Collect predictions from configured environments and write a list-only JSON.

    Predictions are written to 'predictions.json' by default. Use --output-path to specify
    a different location.

    Supports two modes:
    - Pre-configured: use --environment-config-path with --instance-ids
    - Ad-hoc: use --sandbox and --workspace-dir; collects a single 'adhoc' instance

    \b
    Examples:
        # Default output (predictions.json)
        ee-bench --spec jvm collect-predictions \\
            --dataset-name data.json \\
            --environment-config-path env.json \\
            --instance-ids task-001

        # Custom output path
        ee-bench --spec jvm collect-predictions \\
            --dataset-name data.json \\
            --environment-config-path env.json \\
            --instance-ids task-001 \\
            --output-path my_predictions.json
    """
    from ee_bench_core.core.utils.cli_helpers import (
        get_and_validate_spec,
        normalize_instance_ids,
        parse_and_merge_spec_kwargs,
    )

    try:
        # Get and validate specification
        spec_name, spec = get_and_validate_spec(ctx, "collect-predictions")

        # Normalize instance IDs
        ids = normalize_instance_ids(instance_ids)

        # Parse and merge spec-specific kwargs
        spec_kwargs = parse_and_merge_spec_kwargs(
            spec, "collect-predictions", spec_args, kwargs
        )

        # Add dataset_name to spec_kwargs
        if dataset_name:
            spec_kwargs["dataset_name"] = dataset_name

        # Set default output path if not provided
        output_path = spec_kwargs.get("output_path") or spec_kwargs.get("output-path")
        if not output_path:
            output_path = "predictions.json"
            spec_kwargs["output_path"] = output_path

        # Display mode information (validation happens in spec or its helpers)
        from ee_bench_core.core.utils.cli_helpers import display_environment_mode

        display_environment_mode(spec_kwargs, ids)

        # Call spec's collect_predictions
        result_list = spec.collect_predictions(instance_ids=ids, **spec_kwargs)

        # Check for failed predictions
        from ee_bench_core.core.models import ResultStatus
        failed_results = [
            r for r in result_list
            if (hasattr(r, 'status') and r.status == ResultStatus.FAILED.value) or
               (isinstance(r, dict) and r.get('status') == ResultStatus.FAILED.value)
        ]

        # Echo summary - output_path is always set now
        click.echo(f"Total entries: {len(result_list)}")
        if failed_results:
            click.echo(f"Failed predictions: {len(failed_results)}")
            for failed in failed_results:
                # Handle both dict and object types
                if isinstance(failed, dict):
                    instance_id = failed.get('instance_id', 'unknown')
                    error = failed.get('error', 'unknown error')
                else:
                    instance_id = getattr(failed, 'instance_id', 'unknown')
                    error = getattr(failed, 'error', 'unknown error')
                click.echo(f"  - {instance_id}: {error}")
        click.echo(f"\nPredictions written to: {output_path}")

        # # Exit with error if any predictions failed
        # if failed_results:
        #     raise click.ClickException(
        #         f"Prediction collection failed for {len(failed_results)} instance(s). "
        #         f"See output above for details."
        #     )

    except click.ClickException:
        raise
    except SpecNotFoundError as e:
        raise click.ClickException(str(e))
    except EEBenchError as e:
        logger.exception("Evaluation framework error during collect-predictions")
        raise click.ClickException(str(e))
    except Exception as e:
        logger.exception("Failed to execute collect-predictions command")
        raise click.ClickException(f"Failed to collect predictions: {e}")


@cli.command(
    cls=SpecAwareCommand,
    command_name="start-environment",
    context_settings={"ignore_unknown_options": True},
)
@click.option(
    "--output-path",
    default="environment_config.json",
    help="Path to write environment config file (default: environment_config.json)",
)
@click.option(
    "--instance-ids",
    multiple=True,
    help="Instance IDs to start (only with --environment-config-path)",
)
@click.argument("spec_args", nargs=-1, type=click.UNPROCESSED)
@click.pass_context
def start_environment(ctx, output_path, instance_ids, spec_args, **kwargs):
    """Start environments from config file or ad-hoc configuration.

    For local environments: writes/updates config file without starting anything.
    For Docker environments: starts containers and writes/updates config with container IDs.

    Supports two modes:
    - Pre-configured: Load from --environment-config-path and start Docker containers
    - Ad-hoc: Build environment config from parameters (--sandbox, --workspace-dir, etc.)

    \b
    Pre-configured mode example:
        ee-bench --spec jvm start-environment \\
            --environment-config-path environment_config.json \\
            --instance-ids task-001,task-002 \\
            --output-path updated_environment_config.json

    \b
    Ad-hoc Docker mode example:
        ee-bench --spec jvm start-environment \\
            --sandbox docker \\
            --container-image ubuntu:22.04 \\
            --workspace-dir /workspace \\
            --output-path environment_config.json

    \b
    Ad-hoc local mode example:
        ee-bench --spec jvm start-environment \\
            --sandbox local \\
            --workspace-dir /tmp/workspace \\
            --output-path environment_config.json
    """
    from ee_bench_core.core.utils.cli_helpers import (
        get_and_validate_spec,
        normalize_instance_ids,
        parse_and_merge_spec_kwargs,
    )

    try:
        # Get and validate specification
        spec_name, spec = get_and_validate_spec(ctx, "start-environment")

        # Normalize instance IDs
        ids = normalize_instance_ids(instance_ids)

        # Parse and merge spec-specific kwargs
        spec_kwargs = parse_and_merge_spec_kwargs(
            spec, "start-environment", spec_args, kwargs
        )

        # Add output_path to spec_kwargs
        spec_kwargs["output_path"] = output_path

        # Display mode information (validation happens in spec or its helpers)
        from ee_bench_core.core.utils.cli_helpers import display_environment_mode

        display_environment_mode(spec_kwargs, ids)

        # Call spec's start_environments method
        result = spec.start_environments(instance_ids=ids, **spec_kwargs)

        # Show results
        click.echo(f"\n{click.style('Environments Started', fg='green', bold=True)}")
        click.echo(f"Total: {result.get('total', 0)}")
        click.echo(f"Started: {click.style(str(result.get('started', 0)), fg='green')}")
        click.echo(f"Skipped (local): {result.get('skipped', 0)}")
        if result.get("failed", 0) > 0:
            click.echo(f"Failed: {click.style(str(result.get('failed', 0)), fg='red')}")

        # Show config file path
        config_file = result.get("config_file", output_path)
        click.echo(f"\nEnvironment config saved to: {config_file}")

        # Show started container IDs if any
        if result.get("container_ids"):
            click.echo("\nStarted containers:")
            for instance_id, container_id in result["container_ids"].items():
                click.echo(f"  {instance_id}: {container_id}")

    except click.ClickException:
        raise
    except SpecNotFoundError as e:
        raise click.ClickException(str(e))
    except EEBenchError as e:
        logger.exception("Evaluation framework error during start-environment")
        raise click.ClickException(str(e))
    except Exception as e:
        logger.exception("Failed to execute start-environment command")
        raise click.ClickException(f"Failed to start environments: {e}")


@cli.command(context_settings={"ignore_unknown_options": True})
@click.option(
    "--dataset-name", required=True, help="Name of dataset or path to JSON file"
)
@click.option(
    "--instance-ids",
    multiple=True,
    help="Instance IDs to clean (can be specified multiple times or comma-separated)",
)
@click.argument("spec_args", nargs=-1, type=click.UNPROCESSED)
@click.pass_context
def clean_environment(ctx, dataset_name, instance_ids, spec_args):
    """Clean evaluation environments.

    Removes Docker containers, images, and other resources for task instances.
    Requires --spec to be specified.

    \b
    Common options:
        --max-workers INT  Max workers for parallel processing

    For spec-specific options, use: ee-bench spec-help <spec> --command clean-environment

    \b
    Examples:
        ee-bench --spec jvm clean-environment --dataset-name my-dataset.json
        ee-bench --spec jvm clean-environment --dataset-name data.json --instance-ids task-001,task-002
    """
    from ee_bench_core.core.utils.cli_helpers import (
        get_and_validate_spec,
        normalize_instance_ids,
    )

    try:
        # Get and validate specification (no need to set_command_context for cleanup)
        spec_name, spec = get_and_validate_spec(ctx, "clean-environment")

        # Normalize instance IDs
        ids = normalize_instance_ids(instance_ids)

        # Parse spec-specific arguments (simple parsing, no type conversion needed)
        spec_kwargs = parse_spec_args(spec_args)

        click.echo(f"Dataset: {dataset_name}")
        if ids:
            click.echo(f"Instance IDs: {', '.join(ids)}")
        else:
            click.echo("Cleaning all environments")

        # Get dataset manager and environment manager from spec
        use_cache = ctx.obj.get("cache", False)
        dataset_mgr = spec.get_dataset_manager(use_cache=use_cache)
        env_mgr = spec.get_environment_manager()

        # Resolve instances
        if ids:
            configs = [
                dataset_mgr.get_dataset_instance(instance_id, dataset_name=dataset_name)
                for instance_id in ids
            ]
        else:
            configs = dataset_mgr.list_dataset_instances(dataset_name=dataset_name)

        click.echo(f"\nCleaning {len(configs)} environments...")

        # Clean environments
        failed = 0
        for config in configs:
            try:
                env_mgr.clean_environment(config, **spec_kwargs)
                click.echo(f"  ✓ {config.instance_id}")
            except Exception as e:
                click.echo(f"  ✗ {config.instance_id}: {e}")
                failed += 1

        click.echo(f"\n{click.style('Cleanup Complete', fg='green', bold=True)}")
        click.echo(f"Successful: {click.style(str(len(configs) - failed), fg='green')}")
        if failed > 0:
            click.echo(f"Failed: {click.style(str(failed), fg='red')}")

    except SpecNotFoundError as e:
        raise click.ClickException(str(e))
    except EEBenchError as e:
        logger.exception("Evaluation framework error during clean-environment")
        raise click.ClickException(str(e))
    except Exception as e:
        logger.exception("Failed to execute clean-environment command")
        raise click.ClickException(f"Failed to clean environment: {e}")


@cli.command()
@click.option("--instance-id", required=True, help="Task instance identifier")
@click.option(
    "--evaluator-name",
    required=True,
    help="Name of the evaluator that produced this result",
)
@click.option("--run-id", required=True, help="Evaluation run identifier")
@click.option(
    "--status",
    required=True,
    type=click.Choice(["success", "failed", "error", "timeout", "skipped"]),
    help="Evaluation status",
)
@click.option("--data", type=click.File("r"), help="JSON file with result data")
@click.option("--message", help="Result message")
@click.option("--error", help="Error message if failed or error")
@click.option(
    "--storage-dir", type=click.Path(), help="Storage directory for persistent results"
)
@click.pass_context
def submit_evaluator_result(
    ctx, instance_id, evaluator_name, run_id, status, data, message, error, storage_dir
):
    """Submit result from external/async evaluator.

    This endpoint allows external systems to submit evaluation results
    after async evaluators have completed their work.

    \b
    Examples:
        # Submit successful result
        ee-bench submit-evaluator-result \\
            --instance-id task-001 \\
            --evaluator-name security_scan \\
            --run-id eval-123 \\
            --status success \\
            --message "Security scan passed" \\
            --data result.json

        # Submit failed result
        ee-bench submit-evaluator-result \\
            --instance-id task-001 \\
            --evaluator-name quality_check \\
            --run-id eval-123 \\
            --status failed \\
            --message "Quality check failed" \\
            --error "Code complexity too high"
    """
    from ee_bench_core.core.eval import (
        EvaluatorResult,
        EvaluatorStatus,
        get_evaluation_tracker,
    )
    from pathlib import Path

    try:
        # Load result data
        result_data = {}
        if data:
            try:
                result_data = json.load(data)
            except json.JSONDecodeError as e:
                raise click.UsageError(f"Invalid JSON in data file: {e}")

        # Create evaluator result
        evaluator_result = EvaluatorResult(
            evaluator_name=evaluator_name,
            status=EvaluatorStatus[status.upper()],
            message=message or f"Evaluation {status}",
            data=result_data,
            error=error,
        )

        # Get evaluation tracker
        tracker_storage_dir = Path(storage_dir) if storage_dir else None
        tracker = get_evaluation_tracker(tracker_storage_dir)

        # Submit result
        tracker.submit_result(
            instance_id=instance_id,
            run_id=run_id,
            evaluator_name=evaluator_name,
            result=evaluator_result,
        )

        click.echo(
            f"✓ Result submitted for {instance_id}/{run_id}/{evaluator_name}: {status}"
        )

        # Show result summary
        if result_data:
            click.echo(f"  Data keys: {', '.join(result_data.keys())}")
        if error:
            click.echo(f"  Error: {error}")

    except Exception as e:
        logger.exception(
            "Failed to submit evaluator result for %s/%s/%s",
            instance_id,
            run_id,
            evaluator_name,
        )
        raise click.ClickException(str(e))


# Attach Agents CLI group if agents-core plugin is installed
try:
    from ee_bench_agents.agent_cli import agents as agents_group  # noqa: E402

    cli.add_command(agents_group, name="agents")
except ImportError:
    # agents-core plugin (ee-bench-agents-core) not installed, skip agents CLI group
    pass

if __name__ == "__main__":
    cli()
