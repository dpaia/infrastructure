"""Report management for async evaluation tracking.

This module provides the report manager implementation and the
SummaryReport data structure for tracking evaluation progress.
"""

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

from .abc_types import ReportManager as AbstractReportManager
from .models import EvaluationResult, ResultStatus
from .utils.concurrency import LocksManager
from .utils.io import read_json_file, write_json_file

logger = logging.getLogger(__name__)


@dataclass
class SummaryReport:
    """Summary evaluation report structure.

    Tracks the overall progress and results of an evaluation run.
    """

    total_tasks: int = 0
    """Total number of tasks to evaluate"""

    successful_tasks: int = 0
    """Number of tasks that passed evaluation"""

    failed_tasks: int = 0
    """Number of tasks that failed evaluation"""

    skipped_tasks: int = 0
    """Number of tasks that were skipped"""

    completed: bool = False
    """Whether the evaluation run is completed"""

    results: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    """Mapping of instance_id to result dictionary"""

    spec_name: str = ""
    """Name of the specification being evaluated"""

    run_id: str = ""
    """Unique identifier for this evaluation run"""

    started_at: Optional[str] = None
    """ISO timestamp when evaluation started"""

    completed_at: Optional[str] = None
    """ISO timestamp when evaluation completed"""

    def to_dict(self) -> Dict[str, Any]:
        """Convert report to dictionary format.

        Returns:
            Dictionary representation of the report
        """
        return {
            "total_tasks": self.total_tasks,
            "successful_tasks": self.successful_tasks,
            "failed_tasks": self.failed_tasks,
            "skipped_tasks": self.skipped_tasks,
            "completed": self.completed,
            "results": self.results,
            "spec_name": self.spec_name,
            "run_id": self.run_id,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SummaryReport":
        """Create a SummaryReport from a dictionary.

        Args:
            data: Dictionary containing report data

        Returns:
            SummaryReport instance
        """
        return cls(
            total_tasks=data.get("total_tasks", 0),
            successful_tasks=data.get("successful_tasks", 0),
            failed_tasks=data.get("failed_tasks", 0),
            skipped_tasks=data.get("skipped_tasks", 0),
            completed=data.get("completed", False),
            results=data.get("results", {}),
            spec_name=data.get("spec_name", ""),
            run_id=data.get("run_id", ""),
            started_at=data.get("started_at"),
            completed_at=data.get("completed_at"),
        )


class ReportManager(AbstractReportManager):
    """Report manager with file persistence.

    Provides thread-safe management of evaluation reports with atomic file writes.
    Reports are stored in report_dir/{run_id}.json format.
    Supports managing multiple evaluation runs concurrently with per-run locks.
    """

    def __init__(self, report_dir: Path, spec_name: str):
        """Initialize report manager.

        Args:
            report_dir: Directory where report files are stored
            spec_name: Name of the specification being evaluated
        """
        self.report_dir = Path(report_dir)
        self.spec_name = spec_name

        # Locks manager for thread-safe operations per run_id
        self._locks_manager = LocksManager()

        # Cache of loaded reports per run_id
        self._reports: Dict[str, SummaryReport] = {}

        # Ensure report directory exists
        self.report_dir.mkdir(parents=True, exist_ok=True)

    def _get_report_path(self, run_id: str) -> Path:
        """Get the file path for a specific run_id's report.

        Args:
            run_id: Unique identifier for the evaluation run

        Returns:
            Path to the report file
        """
        return self.report_dir / f"{run_id}.json"

    def _load_or_create_report(self, run_id: str) -> SummaryReport:
        """Load existing report or create a new one.

        Args:
            run_id: Unique identifier for the evaluation run

        Returns:
            SummaryReport instance loaded from file or newly created
        """
        report_path = self._get_report_path(run_id)

        if report_path.exists():
            try:
                data = read_json_file(report_path)
                logger.debug(f"Loaded existing report from {report_path}")
                return SummaryReport.from_dict(data)
            except Exception as e:
                logger.warning(
                    f"Failed to load report from {report_path}: {e}. "
                    f"Creating new report."
                )

        # Create new report
        report = SummaryReport(
            spec_name=self.spec_name,
            run_id=run_id,
            started_at=datetime.now(timezone.utc).isoformat(),
        )
        logger.debug(f"Created new report for run {run_id}")
        return report

    def _write_report(self, run_id: str, report: SummaryReport) -> None:
        """Write report to file atomically.

        Args:
            run_id: Unique identifier for the evaluation run
            report: Report to write

        Uses write_json_file which performs atomic writes to prevent
        corruption from concurrent access.
        """
        report_path = self._get_report_path(run_id)

        try:
            write_json_file(report_path, report.to_dict(), indent=2)
            logger.debug(f"Wrote report to {report_path}")
        except Exception as e:
            logger.error(f"Failed to write report to {report_path}: {e}")
            raise

    def set_result(
        self, instance_id: str, result: EvaluationResult, run_id: str
    ) -> None:
        """Set evaluation result for a task instance.

        This method is thread-safe and can be called asynchronously
        from multiple evaluations running in parallel or from external
        evaluation services. It updates statistics based on ResultStatus.

        Args:
            instance_id: Task instance identifier
            result: Evaluation result to record
            run_id: Unique identifier for the evaluation run
        """
        lock = self._locks_manager.get_lock(run_id)

        with lock:
            # Load or get cached report
            if run_id not in self._reports:
                self._reports[run_id] = self._load_or_create_report(run_id)

            report = self._reports[run_id]

            # Check if result already exists to prevent duplicate writes
            if instance_id in report.results:
                logger.warning(
                    f"Result for instance {instance_id} already exists. "
                    f"Overwriting with new result."
                )
                # Decrement old statistics
                old_result = report.results[instance_id]
                old_status = old_result.get("result", old_result.get("status"))

                # Check for SWE-bench format (uses "resolved" field) or standard format
                if (
                    old_status == ResultStatus.SUCCESS.value
                    or old_result.get("successful")
                    or old_result.get("resolved")
                ):
                    report.successful_tasks -= 1
                elif old_status == ResultStatus.FAILED.value or (
                    old_result.get("resolved") is False
                ):
                    report.failed_tasks -= 1
                elif old_status == ResultStatus.SKIPPED.value:
                    report.skipped_tasks -= 1

            # Store result
            report.results[instance_id] = result.to_dict()

            # Update counts based on ResultStatus
            if result.result == ResultStatus.SUCCESS:
                report.successful_tasks += 1
            elif result.result == ResultStatus.FAILED:
                report.failed_tasks += 1
            elif result.result == ResultStatus.SKIPPED:
                report.skipped_tasks += 1

            # Always infer total_tasks from actual results count
            report.total_tasks = len(report.results)

            # Write report
            self._write_report(run_id, report)
            logger.debug(f"Set result for {instance_id} in run {run_id}")

    def get_report(self, run_id: str) -> SummaryReport:
        """Get current report snapshot for a specific run.

        Loads the report from report_dir/{run_id}.json file.

        Args:
            run_id: Unique identifier for the evaluation run

        Returns:
            Current report state (deep copy)
        """
        report_path = self._get_report_path(run_id)

        if not report_path.exists():
            # Return empty report if file doesn't exist
            return SummaryReport(
                spec_name=self.spec_name,
                run_id=run_id,
            )

        try:
            data = read_json_file(report_path)
            return SummaryReport.from_dict(data)
        except Exception as e:
            logger.warning(f"Failed to load report from {report_path}: {e}")
            return SummaryReport(
                spec_name=self.spec_name,
                run_id=run_id,
            )

    def mark_completed(self, run_id: str) -> None:
        """Mark the evaluation run as completed.

        Args:
            run_id: Unique identifier for the evaluation run
        """
        lock = self._locks_manager.get_lock(run_id)

        with lock:
            # Load or get cached report
            if run_id not in self._reports:
                self._reports[run_id] = self._load_or_create_report(run_id)

            report = self._reports[run_id]
            report.completed = True
            report.completed_at = datetime.now(timezone.utc).isoformat()
            self._write_report(run_id, report)
            logger.info(f"Marked evaluation run {run_id} as completed")

            # Release lock after marking as completed
            self._locks_manager.release_lock(run_id)
