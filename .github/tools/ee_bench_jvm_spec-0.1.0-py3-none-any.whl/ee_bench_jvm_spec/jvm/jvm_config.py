"""JVM-specific EE-bench configuration.

This module provides the JvmCodeBenchmarkConfig class for JVM-based EE-bench tasks,
including Java/Maven/Gradle specific fields.
"""

import json
from enum import Enum
from typing import Any

from ee_bench_code_spec.config import CodeBenchmarkConfig


class BuildSystem(Enum):
    """Enum for JVM build systems."""

    MAVEN = "maven"
    GRADLE = "gradle"

    @classmethod
    def from_string(cls, value: str) -> "BuildSystem":
        """Create BuildSystem from string value.

        Args:
            value: String representation ("maven" or "gradle")

        Returns:
            BuildSystem enum value

        Raises:
            ValueError: If value is not a valid build system
        """
        value_lower = value.lower()
        if value_lower == "maven":
            return cls.MAVEN
        if value_lower == "gradle":
            return cls.GRADLE
        if value_lower == "gradle-kotlin":
            return cls.GRADLE
        raise ValueError(f"Unknown build system: {value}")

    def __str__(self) -> str:
        """Return string representation."""
        return self.value


class JvmCodeBenchmarkConfig(CodeBenchmarkConfig):
    """Configuration for a JVM-based EE-bench instance.

    Extends CodeBenchmarkConfig with JVM-specific fields including build system
    detection, JVM version, and Maven/Gradle settings.
    """

    def __init__(
        self,
        instance_id: str,
        repo: str,
        base_commit: str,
        problem_statement: str,
        patch: str | None = None,
        test_patch: str | None = None,
        fail_to_pass: list[str] | None = None,
        pass_to_pass: list[str] | None = None,
        issue_numbers: list[str] | None = None,
        tags: list[str] | None = None,
        created_at: str | None = None,
        version: str | None = None,
        language: str | None = None,
        build_system: str | None = None,
        jvm_version: str | None = None,
        is_maven: bool | None = None,
        _raw_instance: dict[str, Any] | None = None,
    ):
        """Initialize JVM EE-bench configuration.

        Args:
            instance_id: Unique identifier for the task instance
            repo: GitHub repository (owner/repo format)
            base_commit: Base commit hash to start from
            problem_statement: Description of the problem to solve
            patch: Optional golden patch content
            test_patch: Optional test patch content
            fail_to_pass: Tests that should pass after fix
            pass_to_pass: Tests that should continue passing
            issue_numbers: Optional issue numbers
            tags: Optional tags for classification
            created_at: Optional creation timestamp
            version: Optional version string
            language: Programming language (e.g., "java")
            build_system: Build system ("maven" or "gradle")
            jvm_version: JVM version (e.g., "11", "17")
            is_maven: Whether this is a Maven project (derived from build_system)
            _raw_instance: Raw dataset entry for schema preservation
        """
        super().__init__(
            instance_id=instance_id,
            repo=repo,
            base_commit=base_commit,
            problem_statement=problem_statement,
            patch=patch,
            test_patch=test_patch,
            fail_to_pass=fail_to_pass,
            pass_to_pass=pass_to_pass,
            issue_numbers=issue_numbers,
            tags=tags,
            created_at=created_at,
            version=version,
            language=language or "jvm",
            _raw_instance=_raw_instance,
        )

        # JVM-specific fields
        self.build_system = build_system
        # Set default JVM version if not provided
        self.jvm_version = jvm_version if jvm_version is not None else "24"

        # Derive is_maven from build_system if not explicitly set
        if is_maven is not None:
            self.is_maven = is_maven
        elif build_system:
            self.is_maven = build_system.lower() == "maven"
        else:
            # Default to Maven if not specified
            self.is_maven = True
            self.build_system = "maven"

    def present(self) -> str:
        """Present the configuration in a human-readable format.

        Returns:
            Formatted string representation of the configuration
        """
        lines = [
            f"Instance ID: {self.instance_id}",
            f"Repository: {self.repo}",
            f"Base Commit: {self.base_commit}",
            f"Language: {self.language}",
            f"Build System: {self.build_system}",
            f"JVM Version: {self.jvm_version}",
        ]

        if self.problem_statement:
            lines.append("\nProblem Statement:")
            lines.append(
                self.problem_statement[:200] + "..."
                if len(self.problem_statement) > 200
                else self.problem_statement
            )

        if self.fail_to_pass:
            lines.append(f"\nTests to Fix ({len(self.fail_to_pass)}):")
            for test in self.fail_to_pass[:5]:  # Show first 5
                lines.append(f"  - {test}")
            if len(self.fail_to_pass) > 5:
                lines.append(f"  ... and {len(self.fail_to_pass) - 5} more")

        if self.pass_to_pass:
            lines.append(f"\nTests to Maintain ({len(self.pass_to_pass)}):")
            for test in self.pass_to_pass[:5]:  # Show first 5
                lines.append(f"  - {test}")
            if len(self.pass_to_pass) > 5:
                lines.append(f"  ... and {len(self.pass_to_pass) - 5} more")

        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        """Convert configuration to dictionary.

        Returns:
            Dictionary representation of the configuration including JVM fields
        """
        data = super().to_dict()
        data.update(
            {
                "build_system": self.build_system,
                "jvm_version": self.jvm_version,
                "is_maven": self.is_maven,
            }
        )
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "JvmCodeBenchmarkConfig":
        """Create configuration from dictionary.

        Args:
            data: Dictionary containing configuration data

        Returns:
            JvmCodeBenchmarkConfig instance
        """
        # Parse fail_to_pass and pass_to_pass from JSON strings if needed
        fail_to_pass = data.get("FAIL_TO_PASS") or data.get("fail_to_pass", [])
        if isinstance(fail_to_pass, str):
            fail_to_pass = json.loads(fail_to_pass)

        pass_to_pass = data.get("PASS_TO_PASS") or data.get("pass_to_pass", [])
        if isinstance(pass_to_pass, str):
            pass_to_pass = json.loads(pass_to_pass)

        # Parse issue_numbers from JSON string if needed
        issue_numbers = data.get("issue_numbers")
        if isinstance(issue_numbers, str):
            issue_numbers = json.loads(issue_numbers)

        # Parse tags from JSON string if needed
        tags = data.get("tags")
        if isinstance(tags, str):
            tags = json.loads(tags)

        # Parse is_maven - handle string "True"/"False" from JSON
        is_maven = data.get("is_maven")
        if isinstance(is_maven, str):
            is_maven = is_maven.lower() in ("true", "1", "yes")

        return cls(
            instance_id=data["instance_id"],
            repo=data["repo"],
            base_commit=data["base_commit"],
            problem_statement=data.get("problem_statement", ""),
            patch=data.get("patch"),
            test_patch=data.get("test_patch"),
            fail_to_pass=fail_to_pass,
            pass_to_pass=pass_to_pass,
            issue_numbers=issue_numbers,
            tags=tags,
            created_at=data.get("created_at"),
            version=data.get("version"),
            language=data.get("language", "jvm"),
            build_system=data.get("build_system"),
            jvm_version=data.get("jvm_version", data.get("java_version")),
            is_maven=is_maven,
            _raw_instance=data.copy(),
        )
