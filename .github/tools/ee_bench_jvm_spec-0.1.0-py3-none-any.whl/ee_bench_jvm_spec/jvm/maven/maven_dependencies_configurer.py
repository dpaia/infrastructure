"""Maven dependencies configurer for downloading and compiling Maven projects.

This configurer downloads Maven dependencies and compiles the project,
creating a dependencies image ready for evaluation.
"""

from ee_bench_core.core import EnvironmentConfig

from ee_bench_jvm_spec.jvm.base_dependencies_configurer import BaseDependenciesConfigurer
from ee_bench_jvm_spec.jvm.jvm_config import BuildSystem


class MavenDependenciesConfigurer(BaseDependenciesConfigurer):
    """Configurer that downloads Maven dependencies and compiles project.

    This configurer runs on a cloned repository image and:
    - Downloads all Maven dependencies
    - Compiles main and test source code
    - Produces a :dependencies image ready for evaluation

    Metadata:
        name: maven_dependencies
        priority: 80 (after clone, before task setup)
        dependencies: after task_clone, before task_image
        specs: ["jvm"]
    """

    # Metadata for plugin discovery
    __configurer_name__ = "maven_dependencies"
    __configurer_description__ = "Downloads Maven dependencies and compiles project"
    __configurer_version__ = "1.0.0"
    __configurer_specs__ = ["jvm"]

    @property
    def build_system(self):
        """Return the BuildSystem enum for Maven."""
        return BuildSystem.MAVEN

    @property
    def tool_name(self) -> str:
        """Return tool name."""
        return "maven"

    def get_dependency_download_commands(self, env_config: EnvironmentConfig) -> list[str]:
        """Get commands to download Maven dependencies.

        Returns:
            List of RUN commands for downloading dependencies with 'maven' placeholder
        """
        # Always return command with "maven" placeholder
        # Base class will replace it with the actual tool command (./mvnw or mvn)
        return [
            "maven dependency:go-offline compile test-compile -B -DskipTests || true"
        ]
