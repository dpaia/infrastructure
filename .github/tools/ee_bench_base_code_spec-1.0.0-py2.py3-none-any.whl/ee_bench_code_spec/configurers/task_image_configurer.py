"""Code task image configurer for building task-specific Docker images.

This configurer builds the final task-specific images with task metadata files.
Repository cloning and dependency installation are handled by separate configurers.
"""

import json
import logging
from typing import Optional

from ee_bench_core.adapters.docker import (
    DockerEnvironmentConfigurer,
    DockerEnvironmentConfig,
)
from ee_bench_core.core import DependencyPosition
from ee_bench_core.core.abc_types import DatasetConfig, EnvironmentConfig
from ee_bench_code_spec.config import CodeBenchmarkConfig
from ee_bench_code_spec.env_config import CodeEnvironmentConfig

logger = logging.getLogger(__name__)


class TaskImageConfigurer(DockerEnvironmentConfigurer):
    """Configurer that builds task-specific image with cloned repository.

    This configurer creates a task-specific Docker image that includes:
    - Base image with build tools (Maven or Gradle)
    - Cloned repository at the base commit
    - Task configuration files

    The resulting image is ready for evaluation.

    Metadata:
        name: task_image
        specs: ["jvm"]
    """

    # Metadata for plugin discovery
    __configurer_name__ = "task_image"
    __configurer_description__ = "Builds task image with cloned repository"
    __configurer_version__ = "1.0.0"
    __configurer_specs__ = ["jvm"]

    def __init__(self, namespace: str = "ee-bench"):
        """Initialize task image configurer.

        Args:
            namespace: Docker image namespace (default: "ee-bench")
        """
        super().__init__()
        self.namespace = namespace

    @property
    def name(self) -> str:
        return "task_image"

    @property
    def description(self) -> str:
        return "Builds task-specific image with cloned repository"

    @property
    def specs(self) -> Optional[list[str]]:
        return ["jvm"]

    @property
    def dependencies(self) -> Optional[list[str]] | DependencyPosition:
        # Task image runs after build tools (maven/gradle specify before=["task_image"])
        # Set priority to run after build tools
        return DependencyPosition(after=["base_image"], priority=100)

    def should_configure(
        self,
        spec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        **kwargs,
    ) -> tuple[bool, Optional[str]]:
        """Check if task image should be built.

        Args:
            spec: Evaluation specification
            env_config: Environment configuration
            config: Dataset configuration
            **kwargs: Additional parameters

        Returns:
            Tuple of (should_configure, reason)
        """
        if not isinstance(config, CodeBenchmarkConfig):
            return False, "Not a code benchmark task"

        if not isinstance(env_config, DockerEnvironmentConfig):
            return False, "Not a Docker environment"

        if not env_config.image_name:
            return False, "No base image available"

        return True, None

    def configure(
        self,
        spec,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        **kwargs,
    ) -> EnvironmentConfig:
        """Build task-specific image.

        Args:
            spec: Evaluation specification
            env_config: Environment configuration
            config: Dataset configuration
            **kwargs: Additional parameters

        Returns:
            Updated EnvironmentConfig with task image

        Raises:
            EnvironmentError: If image build fails
        """
        if not isinstance(config, CodeBenchmarkConfig):
            return env_config

        if not isinstance(env_config, DockerEnvironmentConfig):
            return env_config

        base_image = env_config.image_name
        task_image = self._get_task_image_name(config)
        # Determine project path from workspace_dir if available
        workspace_dir = (
            env_config.workspace_dir if env_config.workspace_dir else "/workspace"
        )

        project_dir = kwargs.get("project_dir", "task_project")

        kwargs["project_path"] = f"{workspace_dir}/{project_dir}"

        force = kwargs.get("force", False)
        task_image = self._get_task_image_name(config)
        # Build image
        labels = env_config.labels.copy() if env_config.labels else {}
        labels.update(
            {
                f"{self.namespace}.image-type": "task",
                f"{self.namespace}.instance-id": config.instance_id,
                f"{self.namespace}.base-image": base_image,
                f"{self.namespace}.repo": config.repo,
                f"{self.namespace}.base-commit": config.base_commit,
                f"{self.namespace}.configurer": self.name,
            }
        )

        if not force and self.image_exists(task_image):
            logger.info(f"Task image {task_image} already exists, skipping build")

        else:
            logger.info(f"Building task image: {task_image} from {base_image}")

            # Generate Dockerfile
            dockerfile_content = self.generate_dockerfile(env_config, config, **kwargs)

            # Prepare build context files
            build_context_files = self._prepare_build_context(config)

            self.build_image(
                dockerfile_content,
                task_image,
                labels,
                build_context_files=build_context_files,
            )

            logger.info(f"Successfully built task image: {task_image}")

        env_config = CodeEnvironmentConfig.from_dict(env_config.to_dict())
        # Update env_config
        env_config.image_name = task_image
        env_config.labels = labels
        env_config.related_images["task"] = task_image
        env_config.project_dir = project_dir

        return env_config

    def generate_dockerfile(
        self,
        env_config: EnvironmentConfig,
        config: DatasetConfig,
        **kwargs,
    ) -> str:
        """Generate Dockerfile for task image.

        Args:
            env_config: Environment configuration
            config: Dataset configuration
            **kwargs: Additional parameters

        Returns:
            Dockerfile content as string

        Raises:
            ValueError: If config is not CodeBenchmarkConfig
        """
        if not isinstance(config, CodeBenchmarkConfig):
            raise ValueError("Config must be CodeBenchmarkConfig")

        if not isinstance(env_config, DockerEnvironmentConfig):
            raise ValueError("env_config must be DockerEnvironmentConfig")

        base_image = env_config.image_name
        repo = config.repo if config.repo.endswith(".git") else f"{config.repo}.git"
        repo_url = f"https://github.com/{repo}"

        # Determine workspace directory
        workspace_dir = (
            env_config.workspace_dir if env_config.workspace_dir else "/workspace"
        )
        project_path = kwargs.get("project_path", workspace_dir)

        return f"""FROM {base_image}

# Set task metadata
ENV TASK_ID="{config.instance_id}"
ENV REPO="{config.repo}"
ENV BASE_COMMIT="{config.base_commit}"

# Copy task files
# COPY task-config.json {workspace_dir}/
# COPY task.txt {workspace_dir}/

# Clone and checkout
RUN git clone {repo_url} {project_path} \\
    && cd {project_path} \\
    && git checkout {config.base_commit}

WORKDIR {project_path}

CMD ["/bin/bash"]
"""

    def _prepare_build_context(self, config: CodeBenchmarkConfig) -> dict[str, str]:
        """Prepare build context files.

        Args:
            config: Code benchmark configuration

        Returns:
            Dictionary mapping file paths to content
        """
        # Get raw instance data if available, otherwise create from config
        task_config_data = (
            config._raw_instance
            if hasattr(config, "_raw_instance") and config._raw_instance
            else config.to_dict()
        )

        return {
            # "task-config.json": json.dumps([task_config_data], indent=2),
            # "task.txt": config.problem_statement,
        }

    def _get_task_image_name(self, config: CodeBenchmarkConfig) -> str:
        """Generate task image name.

        Args:
            config: Code benchmark configuration

        Returns:
            Docker image name with tag
        """
        # Sanitize instance ID for Docker image name
        sanitized_id = config.instance_id.replace("_", "-").replace("__", "-").lower()
        sanitized_id = "".join(c for c in sanitized_id if c.isalnum() or c in ".-")
        return f"{self.namespace}-{sanitized_id}:task"
