"""EE-bench dataset manager implementation.

This module provides dataset management for EE-bench specification,
including loading, filtering, and managing benchmark task instances.
"""

import json
import logging
from typing import Dict, List, Optional

from ee_bench_core.core.abc_types import DatasetManager
from ee_bench_core.core.errors import DatasetError
from ee_bench_core.core.io import FileManager

from .config import CodeBenchmarkConfig

logger = logging.getLogger(__name__)


class CodeDatasetManager(DatasetManager):
    """Dataset manager for EE-bench specification.

    Manages dataset files and instance retrieval for EE-bench tasks.
    Supports loading from local files, HTTP(S) URLs, and HuggingFace datasets.
    Supports JSON and JSONL formats with optional caching.
    """

    def __init__(
        self,
        use_cache: bool = False,
        file_manager: Optional[FileManager] = None,
        working_dir: str = ".",  # Kept for backward compatibility, ignored
        **kwargs,  # Accept and ignore any other legacy parameters
    ):
        """Initialize the dataset manager.

        Args:
            use_cache: Enable caching for remote files (default: False)
            file_manager: Optional FileManager instance (creates default if None)
            working_dir: Deprecated, kept for backward compatibility (ignored)
            **kwargs: Other legacy parameters (ignored)
        """
        self.use_cache = use_cache

        # Initialize FileManager
        if file_manager is None:
            self.file_manager = FileManager(use_cache=use_cache)
        else:
            self.file_manager = file_manager

        # Known dataset URLs for auto-download
        self.dataset_urls = {}

    def get_dataset_instance(self, instance_id: str, **kwargs) -> CodeBenchmarkConfig:
        """Retrieve a specific dataset instance by ID.

        Args:
            instance_id: Unique identifier for the task instance
            **kwargs: Additional parameters:
                - dataset_name: Path/URI to dataset file (REQUIRED)
                - language: Optional language filter

        Returns:
            CodeBenchmarkConfig for the requested instance

        Raises:
            DatasetError: If instance not found or dataset_name not provided
        """
        dataset_name = kwargs.get("dataset_name")
        if not dataset_name:
            raise DatasetError(
                "dataset_name parameter is required. "
                "Provide path or URI to dataset file (e.g., datasets/java/dataset.json, "
                "https://example.com/dataset.json, or hf://user/dataset/data.jsonl)"
            )

        language_filter = kwargs.get("language")

        logger.debug(f"Loading dataset from: {dataset_name}")

        try:
            # Load dataset using FileManager (handles all protocols and caching)
            data = self.file_manager.load(dataset_name, use_cache=self.use_cache)

            if not isinstance(data, list):
                raise DatasetError(
                    f"Dataset must contain a list/array of tasks, got {type(data)}"
                )

            # Search for instance
            for item in data:
                if not isinstance(item, dict):
                    continue
                if item.get("instance_id") == instance_id:
                    # Apply language filter if specified
                    item_language = item.get("language")
                    if language_filter and item_language != language_filter:
                        continue

                    logger.info(
                        f"Loaded task {instance_id} from dataset {dataset_name}"
                    )
                    return self._item_to_config(item, item_language)

            raise DatasetError(
                f"Task ID {instance_id} not found in dataset {dataset_name}"
            )

        except FileNotFoundError as e:
            raise DatasetError(f"Dataset file not found: {dataset_name}") from e
        except ValueError as e:
            raise DatasetError(f"Invalid dataset format in {dataset_name}: {e}") from e
        except Exception as e:
            raise DatasetError(
                f"Failed to load dataset {dataset_name}: {e}"
            ) from e

    def list_dataset_instances(
        self,
        dataset_name: Optional[str] = None,
        filters: Optional[Dict] = None,
        **kwargs,
    ) -> List[CodeBenchmarkConfig]:
        """List all available dataset instances.

        Args:
            dataset_name: Path/URI to dataset file (REQUIRED)
            filters: Optional filters to apply (e.g., {"language": "java", "repo": "spring-petclinic"})
            **kwargs: Additional parameters

        Returns:
            List of CodeBenchmarkConfig instances matching criteria

        Raises:
            DatasetError: If dataset_name not provided or dataset cannot be loaded
        """
        if not dataset_name:
            raise DatasetError(
                "dataset_name parameter is required. "
                "Provide path or URI to dataset file."
            )

        filters = filters or {}

        try:
            # Load dataset using FileManager
            data = self.file_manager.load(dataset_name, use_cache=self.use_cache)

            if not isinstance(data, list):
                raise DatasetError(
                    f"Dataset must contain a list/array, got {type(data)}"
                )

            # Convert all items to configs
            configs = []
            seen_ids = set()

            for item in data:
                if not isinstance(item, dict):
                    continue

                instance_id = item.get("instance_id")
                if not instance_id or instance_id in seen_ids:
                    continue

                seen_ids.add(instance_id)
                language = item.get("language")
                config = self._item_to_config(item, language)
                configs.append(config)

            # Apply filters
            if filters:
                configs = self._apply_filters(configs, filters)

            logger.info(
                f"Loaded {len(configs)} instances from {dataset_name}"
            )
            return configs

        except FileNotFoundError as e:
            raise DatasetError(f"Dataset file not found: {dataset_name}") from e
        except ValueError as e:
            raise DatasetError(f"Invalid dataset format: {e}") from e
        except Exception as e:
            raise DatasetError(f"Failed to load dataset: {e}") from e

    def install_dataset(
        self, dataset_url: str, dataset_name: Optional[str] = None, **kwargs
    ) -> str:
        """Verify and optionally cache a dataset.

        With the new FileManager architecture, datasets are accessed via URIs
        and optionally cached. This method verifies a dataset is accessible
        and valid, and with use_cache=True, ensures it's cached for offline use.

        Args:
            dataset_url: URI to dataset (file://, http://, https://, hf://)
            dataset_name: Ignored (kept for backward compatibility)
            **kwargs: Additional parameters

        Returns:
            The dataset URI (can be used with get_dataset_instance/list_dataset_instances)

        Raises:
            DatasetError: If dataset cannot be accessed or is invalid
        """
        logger.info(f"Verifying dataset accessibility: {dataset_url}")

        try:
            # Load dataset using FileManager (handles all protocols)
            # This will cache if use_cache=True
            data = self.file_manager.load(dataset_url, use_cache=True)

            # Verify it's a valid dataset
            if not isinstance(data, list):
                raise DatasetError(
                    f"Dataset must contain a list/array of tasks, got {type(data)}"
                )

            if len(data) == 0:
                logger.warning(f"Dataset {dataset_url} is empty")
            else:
                logger.info(
                    f"Successfully verified dataset {dataset_url} with {len(data)} instances"
                )

            # Return the URI for use with other methods
            return dataset_url

        except FileNotFoundError as e:
            raise DatasetError(f"Dataset not found: {dataset_url}") from e
        except ValueError as e:
            raise DatasetError(f"Invalid dataset format: {e}") from e
        except Exception as e:
            raise DatasetError(f"Failed to access dataset {dataset_url}: {e}") from e




    def _item_to_config(
        self, item: Dict, language: Optional[str] = None
    ) -> CodeBenchmarkConfig:
        """Convert a dataset item dictionary to CodeBenchmarkConfig.

        Args:
            item: Raw dataset item dictionary
            language: Language to assign if not in item

        Returns:
            CodeBenchmarkConfig instance
        """
        # Parse test lists (may be JSON strings)
        fail_to_pass = item.get("FAIL_TO_PASS", item.get("fail_to_pass", []))
        if isinstance(fail_to_pass, str):
            try:
                fail_to_pass = json.loads(fail_to_pass)
            except:
                fail_to_pass = []

        pass_to_pass = item.get("PASS_TO_PASS", item.get("pass_to_pass", []))
        if isinstance(pass_to_pass, str):
            try:
                pass_to_pass = json.loads(pass_to_pass)
            except:
                pass_to_pass = []

        # Parse optional fields
        issue_numbers = item.get("issue_numbers")
        if isinstance(issue_numbers, str):
            try:
                issue_numbers = json.loads(issue_numbers)
            except:
                issue_numbers = None

        tags = item.get("tags")
        if isinstance(tags, str):
            try:
                tags = json.loads(tags)
            except:
                tags = None

        # Ensure language is set
        lang = item.get("language") or language or "jvm"

        return CodeBenchmarkConfig(
            instance_id=item["instance_id"],
            repo=item.get("repo", ""),
            base_commit=item.get("base_commit", ""),
            problem_statement=item.get("problem_statement", ""),
            patch=item.get("patch"),
            test_patch=item.get("test_patch"),
            fail_to_pass=fail_to_pass,
            pass_to_pass=pass_to_pass,
            issue_numbers=issue_numbers,
            tags=tags,
            created_at=item.get("created_at"),
            version=item.get("version"),
            language=lang,
            _raw_instance=item,
        )

    def _apply_filters(
        self, configs: List[CodeBenchmarkConfig], filters: Dict
    ) -> List[CodeBenchmarkConfig]:
        """Apply filters to a list of configs.

        Args:
            configs: List of configurations
            filters: Dictionary of filters

        Returns:
            Filtered list of configurations
        """
        filtered = configs

        for key, value in filters.items():
            if key == "language":
                filtered = [c for c in filtered if c.language == value]
            elif key == "repo":
                filtered = [c for c in filtered if value in c.repo]
            elif key == "tags":
                # Filter by tag
                if isinstance(value, list):
                    filtered = [
                        c
                        for c in filtered
                        if c.tags and any(t in c.tags for t in value)
                    ]
                else:
                    filtered = [c for c in filtered if c.tags and value in c.tags]
            elif hasattr(filtered[0] if filtered else None, key):
                # Generic attribute filter
                filtered = [c for c in filtered if getattr(c, key, None) == value]

        return filtered





