"""AttachmentExportGenerator — downloads attachment files from PR branches to local folders."""

from __future__ import annotations

import logging
import os
from typing import Any

from ee_bench.generator.interfaces import Provider
from ee_bench.generator.scripting import is_dry_run

logger = logging.getLogger(__name__)


class AttachmentExportGenerator(Provider):
    """Provider that downloads attachment files from PR branches to local folders.

    For each item with attachments:
    1. Looks up the ``after`` branch for the instance
    2. Lists files in the attachment directory
    3. Downloads each file to ``{output_dir}/{instance_id}/``
    """

    def provide(
        self,
        item=None,
        *,
        instance_id="",
        repo_url="",
        github_token="",
        output_dir="",
        dataset_label="",
        attachment_dir="",
        dry_run=None,
        **kwargs,
    ) -> list[dict[str, Any]]:
        """Download attachment files for a single item.

        Args:
            item: Item dict (unused after explicit-param migration).
            instance_id: Instance identifier.
            repo_url: GitHub repository URL.
            github_token: GitHub PAT.
            output_dir: Local output directory.
            dataset_label: Dataset label for branch naming.
            attachment_dir: Remote attachment directory name.
            dry_run: Override dry run mode.
            **kwargs: Ignored.

        Returns:
            List containing single result dict.
        """
        if dry_run is None:
            dry_run = is_dry_run()
        output_dir = output_dir or "attachments"
        dataset_label = dataset_label or "swe-bench-pro"
        attachment_dir = attachment_dir or ".swe-bench-pro"

        if not instance_id:
            return []

        if dry_run:
            logger.info("[DRY RUN] Would export attachments for %s", instance_id)
            return [{
                "instance_id": instance_id,
                "status": "dry_run_downloaded",
                "output_dir": f"{output_dir}/{instance_id}",
                "files": [],
                "error": "",
            }]

        if not github_token:
            raise ValueError("github_token is required for non-dry-run attachment export")

        from github import Github
        gh = Github(github_token)

        try:
            result = self._export_attachments(
                gh=gh,
                instance_id=instance_id,
                repo_url=repo_url,
                dataset_label=dataset_label,
                attachment_dir=attachment_dir,
                output_dir=output_dir,
                repo_cache={},
            )
            return [result]
        except Exception as e:
            logger.error("Failed to export attachments for %s: %s", instance_id, e)
            return [{
                "instance_id": instance_id,
                "status": "error",
                "output_dir": "",
                "files": [],
                "error": str(e),
            }]

    def _export_attachments(
        self,
        gh: Any,
        instance_id: str,
        repo_url: str,
        dataset_label: str,
        attachment_dir: str,
        output_dir: str,
        repo_cache: dict[str, Any],
    ) -> dict[str, Any]:
        """Download attachment files from a PR branch."""
        repo_full_name = repo_url.rstrip("/").split("github.com/")[-1]
        if repo_full_name.endswith(".git"):
            repo_full_name = repo_full_name[:-4]

        if repo_full_name not in repo_cache:
            repo_cache[repo_full_name] = gh.get_repo(repo_full_name)
        repo = repo_cache[repo_full_name]

        branch_name = f"{dataset_label}/{instance_id}/after"

        try:
            contents = repo.get_contents(attachment_dir, ref=branch_name)
        except Exception:
            return {
                "instance_id": instance_id,
                "status": "no_attachments",
                "output_dir": "",
                "files": [],
                "error": "",
            }

        if not isinstance(contents, list):
            contents = [contents]

        if not contents:
            return {
                "instance_id": instance_id,
                "status": "no_attachments",
                "output_dir": "",
                "files": [],
                "error": "",
            }

        instance_output_dir = os.path.join(output_dir, instance_id)
        os.makedirs(instance_output_dir, exist_ok=True)

        downloaded_files = []
        for file_content in contents:
            if file_content.type != "file":
                continue
            file_path = os.path.join(instance_output_dir, file_content.name)
            content = file_content.decoded_content
            with open(file_path, "wb") as f:
                f.write(content)
            downloaded_files.append(file_content.name)
            logger.info("Downloaded %s/%s", instance_id, file_content.name)

        return {
            "instance_id": instance_id,
            "status": "downloaded",
            "output_dir": instance_output_dir,
            "files": downloaded_files,
            "error": "",
        }
