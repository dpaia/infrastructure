"""Base SWE-bench environment manager.

This module provides the abstract base SweEnvironmentManager class that defines
the interface for language-specific environment managers.
"""

import io
import logging
import tarfile
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

import docker

from ee_bench_core.core.abc_types import EnvironmentManager
from ee_bench_core.core.errors import EnvironmentError
from ee_bench_core.core.models import DatasetConfig
from ee_bench_core.core.utils.concurrency import LocksManager
from ee_bench_core.adapters import DockerAdapter

from .swe_config import SweBenchmarkConfig
from .swe_env_config import SweEnvironmentConfig

logger = logging.getLogger(__name__)


class SweEnvironmentManager(EnvironmentManager, ABC):
    """Abstract base class for SWE-bench environment managers.

    Provides common Docker environment management functionality while delegating
    language-specific and build-tool-specific operations to subclasses.

    Subclasses must implement:
    - get_language() - Return the language this manager handles
    - get_default_version() - Return default language version
    - generate_base_dockerfile() - Generate Dockerfile for base image
    - generate_task_dockerfile() - Generate Dockerfile for task image
    - setup_project() - Setup project inside container (install deps, etc.)
    """

    def __init__(self, docker_adapter: Optional[DockerAdapter] = None, namespace: str = "ee-bench"):
        """Initialize environment manager.

        Args:
            docker_adapter: Optional DockerAdapter instance (creates new if None)
            namespace: Docker images namespace (default: "ee-bench")

        Raises:
            EnvironmentError: If Docker is not available
        """
        self.docker = docker_adapter or DockerAdapter()
        self.namespace = namespace

        # Verify Docker is accessible
        try:
            self.docker.client.ping()
        except Exception as e:
            raise EnvironmentError(f"Docker is not available: {e}")

        # Lock manager for thread-safe base image builds
        self._locks_manager = LocksManager()

    @abstractmethod
    def get_language(self) -> str:
        """Get the programming language this manager handles.

        Returns:
            Language name (e.g., "java", "python")
        """
        pass

    @abstractmethod
    def get_default_version(self) -> str:
        """Get the default version for this language.

        Returns:
            Default version string (e.g., "17", "3.11")
        """
        pass

    def get_base_image_name(self, version: str, **kwargs) -> str:
        """Get the base image name for this language and version.

        Default implementation: "{namespace}-base:{language}-{version}"
        Subclasses can override for custom naming (e.g., including build tool versions).

        Args:
            version: Language version
            **kwargs: Additional parameters for naming

        Returns:
            Base image name
        """
        language = self.get_language()
        return f"{self.namespace}-base:{language}-{version}"

    @abstractmethod
    def generate_base_dockerfile(self, version: str, **kwargs) -> str:
        """Generate Dockerfile content for base image.

        Args:
            version: Language version
            **kwargs: Additional parameters (e.g., maven_version, gradle_version)

        Returns:
            Dockerfile content as string
        """
        pass

    @abstractmethod
    def generate_task_dockerfile(
        self,
        config: SweBenchmarkConfig,
        env_config: SweEnvironmentConfig
    ) -> str:
        """Generate Dockerfile content for task image.

        Args:
            config: Task configuration
            env_config: Environment configuration (e.g., base image)

        Returns:
            Dockerfile content as string
        """
        pass

    @abstractmethod
    def setup_project(
        self,
        container_id: str,
        config: SweBenchmarkConfig
    ) -> None:
        """Setup project inside container.

        This method is called after the container is started to install
        dependencies and prepare the project for evaluation.

        Args:
            container_id: Running container ID
            config: Task configuration

        Raises:
            EnvironmentError: If setup fails
        """
        pass

    def setup_environment(
        self,
        config: DatasetConfig,
        force: bool = False,
        **kwargs
    ) -> SweEnvironmentConfig:
        """Set up a Docker environment for a SWE-bench task.

        Creates a task-specific Docker image with the repository cloned at the
        base commit. If a base image for the language doesn't exist, builds it first.

        Args:
            config: SweBenchmarkConfig for the task
            force: Whether to force rebuild if environment exists
            **kwargs: Additional parameters
                - workspace_dir: Optional host directory for shared workspace
                - version: Language version override
                - namespace: Docker images namespace (default: "ee-bench")
                - force_rebuild: Alias for force parameter
                - cleanup_expired: Cleanup dangling images after build

        Returns:
            SweEnvironmentConfig describing the prepared environment

        Raises:
            EnvironmentError: If environment setup fails
            TypeError: If config is not a SweBenchmarkConfig
        """
        if not isinstance(config, SweBenchmarkConfig):
            raise TypeError(f"Expected SweBenchmarkConfig, got {type(config).__name__}")

        logger.info(f"Setting up environment for task: {config.instance_id}")

        try:
            # Handle namespace parameter (update if provided)
            if "namespace" in kwargs and kwargs["namespace"]:
                self.namespace = kwargs["namespace"]

            # Handle force_rebuild as alias for force
            force = force or kwargs.get("force_rebuild", False)

            # Determine language version
            # Priority: kwargs['version'] > default
            version = kwargs.get("version")
            if not version:
                version = self.get_default_version()

            # Extract base image kwargs (everything except workspace_dir, project_dir, version, namespace, force_rebuild, cleanup_expired)
            base_image_kwargs = {k: v for k, v in kwargs.items()
                               if k not in ("workspace_dir", "project_dir", "version", "namespace", "force_rebuild", "cleanup_expired")}

            # Build or get base image
            base_image = self._ensure_base_image(version, force, **base_image_kwargs)

            # Get workspace_dir and project_dir from kwargs, or use defaults
            workspace_dir = kwargs.get("workspace_dir", "/workspace")
            project_dir = kwargs.get("project_dir", "task_project")

            # Build task image
            task_image = self._build_task_image(config, base_image, force, workspace_dir, project_dir)

            # Cleanup expired/dangling images if requested
            if kwargs.get("cleanup_expired", False):
                try:
                    logger.info("Cleaning up dangling images...")
                    self.docker.prune_images(filters={"dangling": True})
                except Exception as e:
                    logger.warning(f"Failed to cleanup dangling images: {e}")

            # Create environment config
            # workspace_dir is the base workspace inside the container
            # project_dir is relative to workspace_dir (defaults to "task_project")
            # (workspace_dir and project_dir already extracted above)
            from pathlib import Path

            # Build labels with namespace prefix
            created_at = datetime.now(timezone.utc).isoformat()
            labels = {
                f"{self.namespace}.image-type": "task",
                f"{self.namespace}.instance-id": config.instance_id,
                f"{self.namespace}.base-image": base_image,
                f"{self.namespace}.repo": config.repo,
                f"{self.namespace}.base-commit": config.base_commit,
                f"{self.namespace}.language": self.get_language(),
                f"{self.namespace}.created": created_at,
            }

            env_config = SweEnvironmentConfig(
                instance_id=config.instance_id,
                image_name=task_image,
                workspace_dir=Path(workspace_dir),
                project_dir=project_dir,
                repo=config.repo,
                base_commit=config.base_commit,
                language=self.get_language(),
                created_at=created_at,
                related_images={"base": base_image},
                labels=labels,
            )

            logger.info(f"Successfully set up environment: {task_image}")
            return env_config

        except Exception as e:
            logger.error(f"Failed to set up environment for {config.instance_id}: {e}")
            raise EnvironmentError(f"Environment setup failed: {e}")

    def clean_environment(
        self,
        config: DatasetConfig | SweEnvironmentConfig,
        **kwargs
    ) -> None:
        """Clean up a Docker environment.

        Removes the task-specific Docker image. Does not remove base images
        as they are shared across tasks.

        Args:
            config: DatasetConfig or EnvironmentConfig to clean
            **kwargs: Additional parameters
                - remove_containers: Whether to remove containers (default: True)

        Raises:
            EnvironmentError: If cleanup fails
        """
        remove_containers = kwargs.get("remove_containers", True)

        try:
            if isinstance(config, SweEnvironmentConfig):
                instance_id = config.instance_id
                image_name = config.image_name
            elif isinstance(config, SweBenchmarkConfig):
                instance_id = config.instance_id
                image_name = self._get_task_image_name(config)
            else:
                raise TypeError(f"Expected SweBenchmarkConfig or SweEnvironmentConfig, got {type(config).__name__}")

            logger.info(f"Cleaning environment for task: {instance_id}")

            # Remove containers using this image
            if remove_containers:
                containers = self.docker.list_containers(filters={"ancestor": image_name})
                for container in containers:
                    container_id = container.get("Id", container.get("id", ""))
                    logger.debug(f"Removing container: {container_id[:12]}")
                    self.docker.remove_container(container_id, force=True)

            # Remove image
            try:
                self.docker.remove_image(image_name, force=True)
                logger.info(f"Removed environment image: {image_name}")
            except Exception as e:
                # Image might not exist, which is fine
                logger.debug(f"Could not remove image {image_name}: {e}")

        except Exception as e:
            logger.error(f"Failed to clean environment: {e}")
            raise EnvironmentError(f"Environment cleanup failed: {e}")

    def list_environments(self, **kwargs) -> List[SweEnvironmentConfig]:
        """List all existing SWE-bench environments.

        Returns:
            List of SweEnvironmentConfig instances for all task images

        Args:
            **kwargs: Additional parameters
                - instance_id_filter: Optional instance ID prefix to filter
        """
        instance_id_filter = kwargs.get("instance_id_filter")

        try:
            # List all images with namespace labels
            images = self.docker.list_images(filters={"label": f"{self.namespace}.image-type=task"})

            environments = []
            for image in images:
                labels = image.get("Labels", {})
                instance_id = labels.get(f"{self.namespace}.instance-id")

                # Apply filter if specified
                if instance_id_filter and not instance_id.startswith(instance_id_filter):
                    continue

                # Build related_images dict
                related_images = {}
                base_image = labels.get(f"{self.namespace}.base-image")
                if base_image:
                    related_images["base"] = base_image

                env_config = SweEnvironmentConfig(
                    instance_id=instance_id,
                    image_name=image.get("RepoTags", [""])[0] if image.get("RepoTags") else image["Id"][:12],
                    repo=labels.get(f"{self.namespace}.repo"),
                    base_commit=labels.get(f"{self.namespace}.base-commit"),
                    language=labels.get(f"{self.namespace}.language"),
                    created_at=labels.get(f"{self.namespace}.created"),
                    related_images=related_images,
                )
                environments.append(env_config)

            logger.debug(f"Found {len(environments)} environments")
            return environments

        except Exception as e:
            logger.error(f"Failed to list environments: {e}")
            raise EnvironmentError(f"Failed to list environments: {e}")

    def _ensure_base_image(self, version: str, force: bool, **kwargs) -> str:
        """Ensure base image exists, building it if necessary.

        Uses LocksManager to ensure thread-safe builds.

        Args:
            version: Language version
            force: Whether to force rebuild
            **kwargs: Additional parameters for base image (e.g., maven_version, gradle_version)

        Returns:
            Base image name

        Raises:
            EnvironmentError: If base image build fails
        """
        language = self.get_language()
        image_name = self.get_base_image_name(version, **kwargs)

        # Create lock key from image name for uniqueness
        lock_key = image_name.replace(":", "-").replace("/", "-")

        # Get lock for this specific base image
        lock = self._locks_manager.get_lock(lock_key)

        # Acquire image-specific lock
        with lock:
            logger.debug(f"Acquired lock for base image build: {image_name}")

            # Check for existing image (re-check inside lock)
            if not force:
                # First check if image exists by name
                if self.docker.image_exists(image_name):
                    logger.info(f"Using cached base image: {image_name}")
                    return image_name

            # Build new base image
            logger.info(f"Building base image: {image_name}")
            dockerfile_content = self.generate_base_dockerfile(version, **kwargs)

            labels = {
                "ee-bench.image-type": "base",
                "ee-bench.language": language,
                "ee-bench.version": version,
                "ee-bench.created": datetime.now(timezone.utc).isoformat(),
            }

            # Add additional labels from kwargs
            for key, value in kwargs.items():
                labels[f"ee-bench.{key.replace('_', '-')}"] = str(value)

            try:
                self._build_image_from_dockerfile(dockerfile_content, image_name, labels)
                logger.info(f"Successfully built base image: {image_name}")
                return image_name
            except Exception as e:
                raise EnvironmentError(f"Failed to build base image: {e}")

    def _build_task_image(
        self,
        config: SweBenchmarkConfig,
        base_image: str,
        force: bool,
        workspace_dir: str = "/workspace",
        project_dir: str = "task_project"
    ) -> str:
        """Build task-specific Docker image.

        Args:
            config: Task configuration
            base_image: Base image to build from
            force: Whether to force rebuild
            workspace_dir: Workspace directory inside container (default: /workspace)
            project_dir: Project directory name relative to workspace_dir (default: task_project)

        Returns:
            Task image name

        Raises:
            EnvironmentError: If build fails
        """
        image_name = self._get_task_image_name(config)

        # Check for existing image
        if not force:
            images = self.docker.list_images(filters={
                "label": f"{self.namespace}.instance-id={config.instance_id}"
            })
            if images:
                # Use the actual image name from the found image, not the constructed one
                existing_image = images[0]
                if hasattr(existing_image, 'tags') and existing_image.tags:
                    actual_image_name = existing_image.tags[0]
                    logger.info(f"Using cached task image: {actual_image_name}")
                    return actual_image_name
                else:
                    logger.warning(f"Found image without tags, will rebuild: {image_name}")

        logger.info(f"Building task image: {image_name}")

        # Generate Dockerfile for task
        dockerfile_content = self.generate_task_dockerfile(config, SweEnvironmentConfig(
            instance_id=config.instance_id,
            image_name=image_name,
            workspace_dir=Path(workspace_dir),
            project_dir=project_dir,
            related_images = {
                "base": base_image,
            }
        ))

        labels = {
            f"{self.namespace}.image-type": "task",
            f"{self.namespace}.instance-id": config.instance_id,
            f"{self.namespace}.base-image": base_image,
            f"{self.namespace}.repo": config.repo,
            f"{self.namespace}.base-commit": config.base_commit,
            f"{self.namespace}.language": self.get_language(),
            f"{self.namespace}.created": datetime.now(timezone.utc).isoformat(),
        }

        try:
            self._build_task_image_with_config(dockerfile_content, image_name, labels, config)
            logger.info(f"Successfully built task image: {image_name}")
            return image_name
        except Exception as e:
            raise EnvironmentError(f"Failed to build task image: {e}")

    def _get_task_image_name(self, config: SweBenchmarkConfig) -> str:
        """Generate Docker image name for a task.

        Args:
            config: Task configuration

        Returns:
            Docker image name
        """
        # Sanitize instance_id for Docker naming
        sanitized_id = config.instance_id.replace("_", "-").replace("__", "-").lower()
        sanitized_id = "".join(c for c in sanitized_id if c.isalnum() or c in ".-")
        return f"{self.namespace}-task:{sanitized_id}"

    def _build_image_from_dockerfile(
        self,
        dockerfile_content: str,
        image_name: str,
        labels: Dict[str, str]
    ) -> None:
        """Build Docker image from Dockerfile content.

        Args:
            dockerfile_content: Dockerfile content
            image_name: Name to tag the image
            labels: Labels to apply to the image

        Raises:
            EnvironmentError: If build fails
        """
        try:
            # Create tar archive with Dockerfile
            tar_io = io.BytesIO()
            with tarfile.open(fileobj=tar_io, mode="w") as tar:
                dockerfile_bytes = dockerfile_content.encode("utf-8")
                tarinfo = tarfile.TarInfo(name="Dockerfile")
                tarinfo.size = len(dockerfile_bytes)
                tar.addfile(tarinfo, io.BytesIO(dockerfile_bytes))

            tar_io.seek(0)

            # Build image using Docker adapter
            logger.info(f"Starting Docker build for: {image_name}")

            # Use low-level API for streaming build logs
            build_logs = self.docker.client.api.build(
                fileobj=tar_io,
                custom_context=True,
                tag=image_name,
                labels=labels,
                rm=True,
                decode=True,
            )

            # Stream build output
            for log_entry in build_logs:
                if "stream" in log_entry:
                    log_lines = log_entry["stream"].rstrip("\n").split("\n")
                    for line in log_lines:
                        if line.strip():
                            logger.debug(f"Docker build: {line}")
                elif "error" in log_entry:
                    error_msg = log_entry["error"]
                    logger.error(f"Docker build error: {error_msg}")
                    raise docker.errors.BuildError(error_msg, build_logs)

        except docker.errors.BuildError as e:
            raise EnvironmentError(f"Docker build failed: {e}")
        except Exception as e:
            raise EnvironmentError(f"Failed to build image: {e}")

    def _build_task_image_with_config(
        self,
        dockerfile_content: str,
        image_name: str,
        labels: Dict[str, str],
        config: SweBenchmarkConfig
    ) -> None:
        """Build task Docker image with task configuration files.

        Args:
            dockerfile_content: Dockerfile content
            image_name: Name to tag the image
            labels: Labels to apply to the image
            config: Task configuration

        Raises:
            EnvironmentError: If build fails
        """
        import json

        try:
            # Create tar archive with Dockerfile and task config files
            tar_io = io.BytesIO()
            with tarfile.open(fileobj=tar_io, mode="w") as tar:
                # Add Dockerfile
                dockerfile_bytes = dockerfile_content.encode("utf-8")
                dockerfile_info = tarfile.TarInfo(name="Dockerfile")
                dockerfile_info.size = len(dockerfile_bytes)
                tar.addfile(dockerfile_info, io.BytesIO(dockerfile_bytes))

                # Add task-config.json (wrap config in array to match ee_bench format)
                task_config_data = config._raw_instance if hasattr(config, '_raw_instance') and config._raw_instance else config.to_dict()
                task_config_json = json.dumps([task_config_data], indent=2).encode("utf-8")
                task_config_info = tarfile.TarInfo(name="task-config.json")
                task_config_info.size = len(task_config_json)
                tar.addfile(task_config_info, io.BytesIO(task_config_json))

                # Add task.txt (problem statement)
                task_txt_bytes = config.problem_statement.encode("utf-8")
                task_txt_info = tarfile.TarInfo(name="task.txt")
                task_txt_info.size = len(task_txt_bytes)
                tar.addfile(task_txt_info, io.BytesIO(task_txt_bytes))

            tar_io.seek(0)

            # Build image using Docker adapter
            logger.info(f"Starting Docker build for: {image_name}")

            # Use low-level API for streaming build logs
            build_logs = self.docker.client.api.build(
                fileobj=tar_io,
                custom_context=True,
                tag=image_name,
                labels=labels,
                rm=True,
                decode=True,
            )

            # Stream build output
            for log_entry in build_logs:
                if "stream" in log_entry:
                    log_lines = log_entry["stream"].rstrip("\n").split("\n")
                    for line in log_lines:
                        if line.strip():
                            logger.debug(f"Docker build: {line}")
                elif "error" in log_entry:
                    error_msg = log_entry["error"]
                    logger.error(f"Docker build error: {error_msg}")
                    raise docker.errors.BuildError(error_msg, build_logs)

        except docker.errors.BuildError as e:
            raise EnvironmentError(f"Docker build failed: {e}")
        except Exception as e:
            raise EnvironmentError(f"Failed to build image: {e}")
