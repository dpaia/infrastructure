"""Cache manager for file operations.

Provides hash-based caching for downloaded files with automatic cleanup.
"""

import hashlib
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


class CacheManager:
    """Manages file caching with hash-based directory structure.

    Cache structure:
        ~/.ee-bench/cache/{scheme}/{hash}/filename

    Example:
        ~/.ee-bench/cache/http/a1b2c3d4/dataset.json
        ~/.ee-bench/cache/hf/e5f6g7h8/dataset.json
    """

    def __init__(self, cache_dir: Optional[Path] = None):
        """Initialize cache manager.

        Args:
            cache_dir: Base cache directory (default: ~/.ee-bench/cache)
        """
        if cache_dir is None:
            cache_dir = Path.home() / ".ee-bench" / "cache"

        self.cache_dir = cache_dir
        logger.debug(f"Cache directory: {self.cache_dir}")

    def get_cache_path(
        self,
        uri: str,
        scheme: str,
        create_dirs: bool = True
    ) -> Path:
        """Get cache path for a URI.

        Args:
            uri: Full URI to cache
            scheme: Protocol scheme (e.g., "http", "hf")
            create_dirs: Create parent directories if needed

        Returns:
            Path to cache file
        """
        # Hash URI for directory name
        uri_hash = self._hash_uri(uri)

        # Extract filename from URI
        filename = self._extract_filename(uri)

        # Build cache path: cache_dir/scheme/hash/filename
        cache_path = self.cache_dir / scheme / uri_hash / filename

        # Create directories if needed
        if create_dirs:
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            logger.debug(f"Created cache directory: {cache_path.parent}")

        return cache_path

    def exists(self, uri: str, scheme: str) -> bool:
        """Check if URI is cached.

        Args:
            uri: URI to check
            scheme: Protocol scheme

        Returns:
            True if cached file exists
        """
        cache_path = self.get_cache_path(uri, scheme, create_dirs=False)
        return cache_path.exists()

    def get_cached_content(self, uri: str, scheme: str) -> Optional[bytes]:
        """Get cached content if available.

        Args:
            uri: URI to retrieve
            scheme: Protocol scheme

        Returns:
            Cached content as bytes, or None if not cached
        """
        if not self.exists(uri, scheme):
            return None

        cache_path = self.get_cache_path(uri, scheme, create_dirs=False)
        logger.debug(f"Reading from cache: {cache_path}")

        try:
            with open(cache_path, "rb") as f:
                return f.read()
        except Exception as e:
            logger.warning(f"Failed to read cached file {cache_path}: {e}")
            return None

    def save_to_cache(
        self,
        uri: str,
        scheme: str,
        content: bytes
    ) -> Path:
        """Save content to cache.

        Args:
            uri: URI being cached
            scheme: Protocol scheme
            content: Content to cache

        Returns:
            Path to cached file
        """
        cache_path = self.get_cache_path(uri, scheme, create_dirs=True)
        logger.debug(f"Saving to cache: {cache_path}")

        try:
            with open(cache_path, "wb") as f:
                f.write(content)
            logger.debug(f"Cached {len(content)} bytes at {cache_path}")
            return cache_path
        except Exception as e:
            logger.error(f"Failed to save to cache {cache_path}: {e}")
            raise IOError(f"Cache write failed: {e}") from e

    def delete(self, uri: str, scheme: str) -> bool:
        """Delete cached file.

        Args:
            uri: URI to delete from cache
            scheme: Protocol scheme

        Returns:
            True if file was deleted, False if not found
        """
        if not self.exists(uri, scheme):
            return False

        cache_path = self.get_cache_path(uri, scheme, create_dirs=False)
        logger.debug(f"Deleting from cache: {cache_path}")

        try:
            cache_path.unlink()

            # Try to clean up empty parent directories
            try:
                cache_path.parent.rmdir()  # Remove hash directory if empty
                cache_path.parent.parent.rmdir()  # Remove scheme directory if empty
            except OSError:
                pass  # Directories not empty, that's fine

            logger.debug(f"Deleted cached file: {cache_path}")
            return True
        except Exception as e:
            logger.warning(f"Failed to delete cached file {cache_path}: {e}")
            return False

    def clear_cache(self, scheme: Optional[str] = None) -> int:
        """Clear cached files.

        Args:
            scheme: Optional scheme to clear (clears all if None)

        Returns:
            Number of files deleted
        """
        if scheme:
            target_dir = self.cache_dir / scheme
        else:
            target_dir = self.cache_dir

        if not target_dir.exists():
            return 0

        deleted_count = 0
        logger.debug(f"Clearing cache: {target_dir}")

        try:
            # Remove all files recursively
            for file_path in target_dir.rglob("*"):
                if file_path.is_file():
                    file_path.unlink()
                    deleted_count += 1

            # Remove empty directories
            for dir_path in sorted(target_dir.rglob("*"), reverse=True):
                if dir_path.is_dir():
                    try:
                        dir_path.rmdir()
                    except OSError:
                        pass  # Not empty

            # Remove target directory if empty
            if scheme and target_dir.exists():
                try:
                    target_dir.rmdir()
                except OSError:
                    pass

            logger.debug(f"Cleared {deleted_count} cached files")
            return deleted_count
        except Exception as e:
            logger.error(f"Failed to clear cache: {e}")
            return deleted_count

    def get_cache_size(self, scheme: Optional[str] = None) -> int:
        """Get total size of cached files in bytes.

        Args:
            scheme: Optional scheme to check (all schemes if None)

        Returns:
            Total size in bytes
        """
        if scheme:
            target_dir = self.cache_dir / scheme
        else:
            target_dir = self.cache_dir

        if not target_dir.exists():
            return 0

        total_size = 0
        for file_path in target_dir.rglob("*"):
            if file_path.is_file():
                total_size += file_path.stat().st_size

        return total_size

    def _hash_uri(self, uri: str) -> str:
        """Generate hash for URI.

        Args:
            uri: URI to hash

        Returns:
            Hex digest (first 16 characters)
        """
        return hashlib.sha256(uri.encode()).hexdigest()[:16]

    def _extract_filename(self, uri: str) -> str:
        """Extract filename from URI.

        Args:
            uri: URI to parse

        Returns:
            Filename (or "file" if no filename found)
        """
        from urllib.parse import urlparse, unquote

        parsed = urlparse(uri)
        path = unquote(parsed.path)

        # Get last path component
        if path:
            filename = path.split("/")[-1]
            if filename:
                return filename

        # Fallback to generic name
        return "file"
