"""Base interface for process managers.

This module defines the abstract ProcessManager interface that can be implemented
for different execution environments (local, Docker, etc.).
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, List, Optional, Union

if TYPE_CHECKING:
    from ee_bench_core.core.abc_types import EnvironmentConfig


@dataclass
class ProcessResult:
    """Result of a process execution.

    Attributes:
        returncode: Process exit code
        stdout: Standard output as string
        stderr: Standard error as string
        duration: Execution time in seconds
        timed_out: Whether the process timed out
    """

    returncode: int
    stdout: str
    stderr: str
    duration: float
    timed_out: bool = False


class ProcessManager(ABC):
    """Abstract base class for process managers.

    Defines the interface for executing commands in different environments.
    """

    @abstractmethod
    def run_command(
        self,
        cmd: Union[str, List[str]],
        cwd: Optional[Union[str, Path]] = None,
        timeout: Optional[int] = None,
        stdin_input: Optional[str] = None,
        env: Optional[dict] = None,
        shell: bool = False,
        log_prefix: str = "",
        env_config: Optional["EnvironmentConfig"] = None,
        **kwargs,
    ) -> ProcessResult:
        """Run a command and return its result.

        Args:
            cmd: Command to execute (list of args or string if shell=True)
            cwd: Working directory for the command
            timeout: Timeout in seconds (None for no timeout)
            stdin_input: Optional input to send to process stdin
            env: Optional environment variables dict (None uses parent env)
            shell: Whether to execute through shell
            log_prefix: Prefix for debug log messages
            env_config: Optional EnvironmentConfig for extracting execution context (e.g., container_id)

        Returns:
            ProcessResult with execution details
        """
        pass

    @abstractmethod
    def open_interactive_shell(
        self,
        working_dir: Optional[Union[str, Path]] = None,
        env_config: Optional["EnvironmentConfig"] = None,
        **kwargs,
    ) -> ProcessResult:
        """Open an interactive shell in the environment.

        Args:
            working_dir: Optional working directory for the shell
            env_config: Optional EnvironmentConfig for extracting execution context (e.g., container_id)
            **kwargs: Additional implementation-specific parameters (e.g., auto_start for Docker)

        Returns:
            ProcessResult with shell exit code and minimal output
        """
        pass
