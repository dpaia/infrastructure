"""GitHub PR Importer — creates GitHub forks, branches, PRs from dataset items."""

from __future__ import annotations

import json
import logging
import random
import time
from typing import Any

from ee_bench.generator.interfaces import Provider
from ee_bench.generator.scripting import is_dry_run
from ee_bench.generator.templates import render_template
from ee_bench.generator.text import sanitize_mentions
from ee_bench.github.rate_limit import check_rate_limit, create_github_client, retry_on_rate_limit

from ee_bench.github.patch_applier import apply_patches_via_api
from ee_bench.github.project_manager import ProjectManager
from ee_bench.importer.sync_state import (
    ImportState,
    check_sync_status,
    load_state,
    save_state,
    update_item_state,
)

logger = logging.getLogger(__name__)


def _expand_value(value: Any) -> list[str]:
    """Expand a value into a list of strings."""
    if isinstance(value, list):
        return [str(v) for v in value if v]
    s = str(value).strip()
    if s.startswith("["):
        try:
            parsed = json.loads(s)
            if isinstance(parsed, list):
                return [str(v) for v in parsed if v]
        except (json.JSONDecodeError, TypeError):
            pass
    return [s] if s else []


def _random_color() -> str:
    """Generate a random 6-digit hex color string."""
    return f"{random.randint(0, 0xFFFFFF):06x}"


class GitHubPRImporterGenerator(Provider):
    """Provider that imports a single dataset item as a GitHub Pull Request.

    For each item:
    1. Check sync state — skip if unchanged
    2. Fork upstream repo into target org (idempotent)
    3. Set repo topics from config
    4. Apply golden + test patches via Git Data API
    5. Create branch and PR with structured metadata body
    6. Add labels and project assignments
    7. Update sync state and yield status record
    """

    def provide(
        self,
        item=None,
        *,
        instance_id="",
        checksum="",
        upstream_repo="",
        base_commit="",
        patch="",
        test_patch="",
        target_org="",
        github_token="",
        dataset_label="",
        state_file="",
        head_branch="",
        base_branch="",
        commit_message="",
        pr_title="",
        pr_body="",
        labels=None,
        repo_topics=None,
        projects=None,
        dry_run=None,
        repo_visibility=None,
        project_visibility=None,
        pr_state="open",
        **kwargs,
    ) -> list[dict[str, Any]]:
        """Import a single dataset item as a GitHub PR.

        Args:
            item: Dataset item dict (used as template bag for Jinja2 / from: patterns).
            instance_id: Unique identifier for this item.
            checksum: Content hash for sync-state change detection.
            upstream_repo: Full name of the upstream repo to fork (e.g. "owner/repo").
            base_commit: SHA of the base commit to apply patches on.
            patch: Unified diff for the golden patch.
            test_patch: Unified diff for the test patch.
            target_org: GitHub org to fork into.
            github_token: GitHub PAT.
            dataset_label: Label for the dataset.
            state_file: Path to sync state file.
            head_branch: Branch name for the patched commit.
            base_branch: Branch name for the unmodified base commit.
            commit_message: Commit message for the import commit.
            pr_title: PR title (required for create).
            pr_body: PR body (required for create).
            labels: Labels to add to PR.
            repo_topics: Topics to set on repo.
            projects: Project configs.
            dry_run: Override dry run mode (falls back to is_dry_run()).
            repo_visibility: "public" or "private".
            project_visibility: "PUBLIC", "PRIVATE", or "ORG".
            pr_state: PR state after creation ("open" or "closed").
            **kwargs: Ignored.

        Returns:
            List containing single result dict.
        """
        item = item or {}
        if dry_run is None:
            dry_run = is_dry_run()

        labels = labels or []
        repo_topics = repo_topics or []
        projects = self._normalize_projects(projects or [])
        state_file = state_file or ".state/import-state.json"
        dataset_label = dataset_label or "ee-bench"

        # Load sync state
        state = load_state(state_file)
        state.dataset = dataset_label

        # Check sync status
        sync_status = check_sync_status(state, instance_id, checksum)

        if sync_status == "skip":
            logger.info("Skipping %s (unchanged)", instance_id)
            return [{
                "instance_id": instance_id,
                "status": "skipped",
                "pr_url": state.items[instance_id].pr_url,
                "pr_number": state.items[instance_id].pr_number,
                "fork_repo": state.items[instance_id].fork_repo,
                "error": "",
            }]

        if dry_run:
            logger.info("[DRY RUN] Would %s: %s", sync_status, instance_id)
            return [{
                "instance_id": instance_id,
                "status": f"dry_run_{sync_status}",
                "pr_url": "",
                "pr_number": None,
                "fork_repo": "",
                "error": "",
            }]

        if not github_token:
            raise ValueError("github_token is required for non-dry-run imports")

        # Initialize GitHub client
        github_client = create_github_client(github_token)
        project_manager = ProjectManager(github_client)

        fork_cache: dict[str, Any] = {}
        label_cache: dict[str, set[str]] = {}

        try:
            result = self._import_item(
                item=item,
                instance_id=instance_id,
                upstream_repo=upstream_repo,
                base_commit=base_commit,
                patch=patch,
                test_patch=test_patch,
                github_client=github_client,
                project_manager=project_manager,
                target_org=target_org,
                head_branch=head_branch,
                base_branch=base_branch,
                commit_message=commit_message,
                pr_body=pr_body,
                pr_title=pr_title,
                labels_config=labels,
                topics_config=repo_topics,
                projects_config=projects,
                sync_status=sync_status,
                state=state,
                fork_cache=fork_cache,
                label_cache=label_cache,
                repo_visibility=repo_visibility,
                project_visibility=project_visibility,
                pr_state=pr_state,
            )

            update_item_state(
                state,
                instance_id,
                checksum=checksum,
                pr_number=result["pr_number"],
                pr_url=result["pr_url"],
                fork_repo=result["fork_repo"],
                status=result["status"],
            )
            save_state(state, state_file)

            return [result]

        except Exception as e:
            logger.error("Failed to import %s: %s", instance_id, e)
            update_item_state(
                state,
                instance_id,
                checksum=checksum,
                status="error",
            )
            save_state(state, state_file)

            return [{
                "instance_id": instance_id,
                "status": "error",
                "pr_url": "",
                "pr_number": None,
                "fork_repo": "",
                "error": str(e),
            }]

    def _import_item(
        self,
        item: dict[str, Any],
        instance_id: str,
        upstream_repo: str,
        base_commit: str,
        patch: str,
        test_patch: str,
        github_client: Any,
        project_manager: ProjectManager | None,
        target_org: str,
        head_branch: str,
        base_branch: str,
        commit_message: str,
        pr_body: str = "",
        pr_title: str = "",
        labels_config: list | None = None,
        topics_config: list | None = None,
        projects_config: list | None = None,
        sync_status: str = "create",
        state: ImportState | None = None,
        fork_cache: dict[str, Any] | None = None,
        label_cache: dict[str, set[str]] | None = None,
        repo_visibility: str | None = None,
        project_visibility: str | None = None,
        pr_state: str = "open",
    ) -> dict[str, Any]:
        """Import a single dataset item as a GitHub PR."""
        labels_config = labels_config or []
        topics_config = topics_config or []
        projects_config = projects_config or []
        fork_cache = fork_cache if fork_cache is not None else {}
        label_cache = label_cache if label_cache is not None else {}

        # Proactively wait if rate limit is low
        check_rate_limit(github_client)

        # 1. Fork the upstream repo into target org (idempotent)
        fork_repo = self._ensure_fork(
            github_client, upstream_repo, target_org, fork_cache
        )
        fork_full_name = fork_repo.full_name

        # 1b. Set repository visibility if configured
        if repo_visibility:
            self._set_repo_visibility(fork_repo, repo_visibility)

        # 2. Set repo topics
        if topics_config:
            resolved_topics = self._resolve_list_values(topics_config, item)
            self._set_repo_topics(fork_repo, resolved_topics)

        # Try to find an existing PR for this branch
        pr = self._find_existing_pr(state, fork_repo, instance_id, head_branch)

        # Sanitize @mentions to avoid notifying external users
        pr_title = sanitize_mentions(pr_title)
        pr_body = sanitize_mentions(pr_body)

        if pr:
            edit_kwargs: dict[str, Any] = {"body": pr_body}
            if pr_title:
                edit_kwargs["title"] = pr_title
            pr.edit(**edit_kwargs)
            result_status = "updated"
        else:
            if not pr_body:
                raise ValueError(
                    f"pr_body is required when creating a new PR for {instance_id}"
                )
            if not pr_title:
                raise ValueError(
                    f"pr_title is required when creating a new PR for {instance_id}"
                )

            apply_patches_via_api(
                repo=fork_repo,
                base_commit_sha=base_commit,
                patch_text=patch,
                test_patch_text=test_patch if test_patch else None,
                commit_message=commit_message,
                head_branch_name=head_branch,
                base_branch_name=base_branch,
            )

            pr = retry_on_rate_limit(
                fork_repo.create_pull,
                title=pr_title,
                body=pr_body,
                head=head_branch,
                base=base_branch,
            )
            result_status = "created"

        # 8. Add labels
        if labels_config:
            resolved_labels = self._resolve_list_values(labels_config, item)
            self._ensure_labels(fork_repo, resolved_labels, label_cache)
            pr.add_to_labels(*resolved_labels)

        # 9. Add to projects
        if project_manager and projects_config:
            self._add_to_projects(
                project_manager, target_org, projects_config, item, pr,
                visibility=project_visibility,
            )

        # 10. Close PR if configured
        if pr_state == "closed":
            pr.edit(state="closed")

        return {
            "instance_id": instance_id,
            "status": result_status,
            "pr_url": pr.html_url,
            "pr_number": pr.number,
            "fork_repo": fork_full_name,
            "error": "",
        }

    @staticmethod
    def _normalize_projects(projects: list) -> list[dict]:
        """Convert ProjectConfig objects or dicts to plain dicts."""
        from ee_bench.generator.dataclasses import ProjectConfig

        result = []
        for p in projects:
            if isinstance(p, ProjectConfig):
                d = {}
                if p.name:
                    d["name"] = p.name
                if p.id:
                    d["id"] = p.id
                result.append(d)
            else:
                result.append(p)
        return result

    @staticmethod
    def _find_existing_pr(
        state: ImportState, fork_repo: Any, instance_id: str, head_branch: str
    ) -> Any | None:
        existing = state.items.get(instance_id)
        if existing and existing.pr_number:
            try:
                return fork_repo.get_pull(existing.pr_number)
            except Exception:
                pass
        try:
            head_ref = f"{fork_repo.owner.login}:{head_branch}"
            pulls = fork_repo.get_pulls(state="all", head=head_ref)
            for pr in pulls:
                return pr
        except Exception:
            pass
        return None

    def _ensure_fork(self, github_client, upstream_repo, target_org, cache):
        if upstream_repo in cache:
            return cache[upstream_repo]
        repo = github_client.get_repo(upstream_repo)
        expected_name = f"{target_org}/{repo.name}"
        try:
            existing = github_client.get_repo(expected_name)
            if existing.fork:
                cache[upstream_repo] = existing
                logger.info("Fork already exists: %s", existing.full_name)
                return existing
        except Exception:
            pass
        fork = repo.create_fork(organization=target_org)
        cache[upstream_repo] = fork
        logger.info("Fork created: %s -> %s", upstream_repo, fork.full_name)
        return fork

    def _set_repo_visibility(self, repo, visibility):
        if visibility not in ("public", "private"):
            logger.warning("Invalid repo_visibility '%s'", visibility)
            return
        try:
            current_private = repo.private
            want_private = visibility == "private"
            if current_private != want_private:
                repo.edit(private=want_private)
                logger.info("Set %s visibility to %s", repo.full_name, visibility)
        except Exception as e:
            logger.warning("Failed to set visibility on %s: %s", repo.full_name, e)

    def _set_repo_topics(self, repo, topics):
        try:
            existing = set(repo.get_topics())
            new_topics = existing | {t.lower().replace(" ", "-") for t in topics}
            repo.replace_topics(sorted(new_topics))
        except Exception as e:
            logger.warning("Failed to set topics on %s: %s", repo.full_name, e)

    def _ensure_labels(self, repo, label_names, label_cache):
        repo_key = repo.full_name
        if repo_key not in label_cache:
            label_cache[repo_key] = {label.name for label in repo.get_labels()}
        for name in label_names:
            if name not in label_cache[repo_key]:
                try:
                    repo.create_label(name=name, color=_random_color())
                    label_cache[repo_key].add(name)
                except Exception:
                    label_cache[repo_key].add(name)

    def _add_to_projects(self, project_manager, target_org, projects_config, item, pr, visibility=None):
        for proj_config in projects_config:
            project_id = None
            project_label = ""
            raw_id = proj_config.get("id", "")
            if raw_id:
                if "{{" in raw_id:
                    raw_id = render_template(raw_id, item).strip()
                if raw_id:
                    project_id = raw_id
                    project_label = f"id={project_id}"
                else:
                    continue
            if project_id is None:
                project_name = proj_config.get("name", "")
                if "{{" in project_name:
                    project_name = render_template(project_name, item).strip()
                    if not project_name:
                        continue
                elif project_name.startswith("from:"):
                    field_name = project_name[5:]
                    project_name = str(item.get(field_name, ""))
                    if not project_name:
                        continue
                if not project_name:
                    continue
                project_label = project_name
                try:
                    project_id = project_manager.ensure_project(
                        target_org, project_name, visibility=visibility,
                    )
                except Exception as e:
                    logger.warning("Failed to ensure project '%s': %s", project_name, e)
                    continue
            try:
                pr_node_id = pr.raw_data.get("node_id", "")
                if pr_node_id:
                    project_manager.add_pr_to_project(project_id, pr_node_id)
            except Exception as e:
                logger.warning("Failed to add PR to project '%s': %s", project_label, e)

    @staticmethod
    def _resolve_list_values(config_list, item):
        result = []
        for value in config_list:
            if not isinstance(value, str):
                continue
            if "{{" in value:
                rendered = render_template(value, item).strip()
                if not rendered:
                    continue
                values = _expand_value(rendered)
                for v in values:
                    normalized = str(v).lower().replace(" ", "-").replace("+", "plus")
                    result.append(normalized)
                    if str(v) != normalized:
                        result.append(str(v))
            elif value.startswith("from:"):
                field_name = value[5:]
                resolved = item.get(field_name, "")
                if not resolved:
                    continue
                values = _expand_value(resolved)
                for v in values:
                    normalized = str(v).lower().replace(" ", "-").replace("+", "plus")
                    result.append(normalized)
                    if str(v) != normalized:
                        result.append(str(v))
            else:
                result.append(value)
        seen = set()
        deduped = []
        for v in result:
            if v not in seen:
                seen.add(v)
                deduped.append(v)
        return deduped
