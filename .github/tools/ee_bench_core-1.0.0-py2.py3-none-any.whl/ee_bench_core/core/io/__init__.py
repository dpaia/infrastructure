"""File I/O infrastructure with multi-protocol and format support.

This package provides a unified interface for file operations with:
- Protocol providers for different URI schemes (file://, http://, hf://)
- Format handlers for different file formats (JSON, JSONL)
- Optional caching for remote files
- Streaming support for large files
"""

from .cache_manager import CacheManager
from .file_manager import FileManager
from .formats import FormatHandler, JsonHandler, JsonlHandler
from .protocols import FileProtocolProvider, ProtocolProviderRegistry
from .protocols import FileProvider, HttpProvider, HuggingFaceProvider

__all__ = [
    # Main API
    "FileManager",
    "CacheManager",
    # Protocol providers
    "FileProtocolProvider",
    "ProtocolProviderRegistry",
    "FileProvider",
    "HttpProvider",
    "HuggingFaceProvider",
    # Format handlers
    "FormatHandler",
    "JsonHandler",
    "JsonlHandler",
]
