"""List command - shows available plugins."""

from __future__ import annotations

import click

from ee_bench.generator import list_providers

from ee_bench.cli.cli import Context, pass_context


@click.command("list")
@pass_context
def list_plugins(ctx: Context) -> None:
    """List available provider plugins."""
    _list_providers(ctx)


def _list_providers(ctx: Context) -> None:
    """List all available providers."""
    providers = list_providers()

    if not providers:
        click.echo("No providers installed.")
        return

    click.echo("Providers:")
    click.echo("-" * 40)

    for name in providers:
        click.echo(f"  {name}")
