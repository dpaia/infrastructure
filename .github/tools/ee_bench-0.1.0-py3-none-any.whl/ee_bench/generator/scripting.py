"""Scripting runtime state — provides script args and dry-run flag."""

from __future__ import annotations

import sys

_EE_BENCH_SCRIPT_ARGS: dict[str, str] = {}
_EE_BENCH_DRY_RUN: bool = False


def _parse_argv_args() -> dict[str, str]:
    """Parse ``--set KEY=VALUE`` flags from ``sys.argv``."""
    result: dict[str, str] = {}
    argv = sys.argv[1:]
    i = 0
    while i < len(argv):
        if argv[i] == "--set" and i + 1 < len(argv):
            pair = argv[i + 1]
            if "=" in pair:
                key, _, value = pair.partition("=")
                result[key] = value
            i += 2
        else:
            i += 1
    return result


def script_args() -> dict[str, str]:
    """Return the current script arguments set via CLI ``--set`` flags.

    When run via ``ee-dataset run-script``, arguments are injected by the
    runner.  When run directly with ``uv run python scripts/...``, falls back
    to parsing ``--set KEY=VALUE`` flags from ``sys.argv``.
    """
    if _EE_BENCH_SCRIPT_ARGS:
        return dict(_EE_BENCH_SCRIPT_ARGS)
    return _parse_argv_args()


def is_dry_run() -> bool:
    """Return True if the current script is running in dry-run mode."""
    return _EE_BENCH_DRY_RUN


def _set_script_args(args: dict[str, str]) -> None:
    """Set script arguments (called by the runner before executing a script)."""
    global _EE_BENCH_SCRIPT_ARGS
    _EE_BENCH_SCRIPT_ARGS = dict(args) if args else {}


def _set_dry_run(dry_run: bool) -> None:
    """Set the dry-run flag (called by the runner before executing a script)."""
    global _EE_BENCH_DRY_RUN
    _EE_BENCH_DRY_RUN = bool(dry_run)
