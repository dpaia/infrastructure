"""Check command — placeholder (compatibility validation removed)."""

from __future__ import annotations

import click

from ee_bench.cli.cli import pass_context


@click.command()
@pass_context
def check(ctx, **kwargs) -> None:
    """Check plugin compatibility (deprecated).

    The field-based compatibility validation system has been removed.
    Providers now use the unified provide() interface.
    """
    raise click.ClickException(
        "The 'check' command has been removed. "
        "Provider compatibility is no longer validated via metadata."
    )
