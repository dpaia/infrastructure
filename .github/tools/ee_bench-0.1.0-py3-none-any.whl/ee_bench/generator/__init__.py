"""ee_bench.generator - Core framework for pluggable dataset providers.

Example:
    >>> from ee_bench.generator import Provider, Filter, FileSpec
    >>> from ee_bench.generator import load_provider, list_providers
    >>> from ee_bench.generator import script_args, is_dry_run
"""

from ee_bench.generator.clock import now_iso8601_utc
from ee_bench.generator.dataclasses import AttachmentFile, FileSpec, Filter, ProjectConfig
from ee_bench.generator.errors import (
    EEBenchError,
    PluginNotFoundError,
    ProviderError,
)
from ee_bench.generator.interfaces import Provider
from ee_bench.generator.loader import (
    list_providers,
    load_provider,
)
from ee_bench.generator.metadata_provider import (
    EEBenchMetadataProvider,
    parse_json_field,
    parse_list_field,
)
from ee_bench.generator.scripting import is_dry_run, script_args

__version__ = "0.1.0"

__all__ = [
    # Interface
    "Provider",
    # Dataclasses
    "Filter",
    "FileSpec",
    "AttachmentFile",
    "ProjectConfig",
    # Providers
    "EEBenchMetadataProvider",
    # Utilities
    "parse_json_field",
    "parse_list_field",
    # Scripting
    "script_args",
    "is_dry_run",
    # Loader functions
    "load_provider",
    "list_providers",
    # Clock
    "now_iso8601_utc",
    # Errors
    "EEBenchError",
    "PluginNotFoundError",
    "ProviderError",
]
