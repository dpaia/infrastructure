"""Concurrency utilities for parallel task execution."""

import logging
import threading
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Callable, Dict, List, Tuple

logger = logging.getLogger(__name__)


def run_threadpool(
    func: Callable, payloads: List[Tuple], max_workers: int
) -> Tuple[List[Tuple[Tuple, Any]], List[Tuple[Tuple, Exception]]]:
    """Run a function with a list of payloads using ThreadPoolExecutor.

    Args:
        func: Function to run for each payload
        payloads: List of payloads to process (tuples of function arguments)
        max_workers: Maximum number of worker threads

    Returns:
        tuple: (succeeded, failed) where:
        - succeeded: List of (payload, result) tuples for successful executions
        - failed: List of (payload, exception) tuples for failed executions
    """
    if max_workers <= 0:
        return run_sequential(func, payloads)

    succeeded, failed = [], []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Create a future for running each instance
        futures = {executor.submit(func, *payload): payload for payload in payloads}
        # Wait for each future to complete
        for future in as_completed(futures):
            payload = futures[future]
            try:
                # Get result from function
                result = future.result()
                succeeded.append((payload, result))
            except Exception as e:
                print(f"{type(e).__name__}: {e}")
                traceback.print_exc()
                failed.append((payload, e))
    return succeeded, failed


def run_sequential(
    func: Callable, payloads: List[Tuple]
) -> Tuple[List[Tuple[Tuple, Any]], List[Tuple[Tuple, Exception]]]:
    """Run a function with a list of payloads sequentially.

    Args:
        func: Function to run for each payload
        payloads: List of payloads to process

    Returns:
        tuple: (succeeded, failed) where:
        - succeeded: List of (payload, result) tuples for successful executions
        - failed: List of (payload, exception) tuples for failed executions
    """
    succeeded, failed = [], []
    for payload in payloads:
        try:
            result = func(*payload)
            succeeded.append((payload, result))
        except Exception as e:
            traceback.print_exc()
            failed.append((payload, e))
    return succeeded, failed


class LocksManager:
    """Manager for per-ID locks with explicit release.

    Provides thread-safe lock management where each ID gets its own lock.
    Locks must be explicitly released when no longer needed.
    """

    def __init__(self):
        """Initialize the locks manager."""
        self._locks: Dict[str, threading.Lock] = {}
        self._locks_lock = threading.Lock()  # Lock for the locks dict itself

    def get_lock(self, lock_id: str) -> threading.Lock:
        """Get or create a lock for a specific ID.

        Args:
            lock_id: Unique identifier for the lock

        Returns:
            Lock for the specified ID
        """
        with self._locks_lock:
            if lock_id not in self._locks:
                self._locks[lock_id] = threading.Lock()
                logger.debug(f"Created lock for ID: {lock_id}")
            return self._locks[lock_id]

    def release_lock(self, lock_id: str) -> None:
        """Release and remove a lock for a specific ID.

        Args:
            lock_id: Unique identifier for the lock to release
        """
        with self._locks_lock:
            if lock_id in self._locks:
                del self._locks[lock_id]
                logger.debug(f"Released lock for ID: {lock_id}")

    def lock_count(self) -> int:
        """Get the current number of locks.

        Returns:
            Number of active locks
        """
        with self._locks_lock:
            return len(self._locks)

    def clear_all(self) -> None:
        """Remove all locks. Use with caution."""
        with self._locks_lock:
            self._locks.clear()
            logger.debug("Cleared all locks")
