"""Predictions provider abstraction for SWE-bench evaluations.

This module defines the interface for loading predictions (patches) from various sources
like JSON files or using gold patches from the dataset configuration.
"""

import json
import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional

from ee_bench_core.core.utils.io import download_file, copy_file, read_json_file
from .swe_config import SweBenchmarkConfig

logger = logging.getLogger(__name__)


class PredictionsProvider(ABC):
    """Abstract interface for loading predictions.

    Predictions providers are responsible for loading patch predictions
    from various sources (files, URLs, or configuration) and returning
    the appropriate patch content for a given task configuration.
    """

    def __init__(self, prediction_path: str):
        """Initialize predictions provider.

        Args:
            prediction_path: Path or identifier for the predictions source
        """
        self.prediction_path = prediction_path

    @abstractmethod
    def get_prediction(self, config: SweBenchmarkConfig) -> str:
        """Get prediction patch for a task.

        Args:
            config: Task configuration containing instance_id

        Returns:
            Patch content as string

        Raises:
            KeyError: If prediction not found for instance_id
            ValueError: If prediction format is invalid
        """
        pass


class GoldPredictionsProvider(PredictionsProvider):
    """Predictions provider that returns gold patches from task configuration.

    This provider is used when evaluating with gold (ground truth) patches
    to verify the evaluation infrastructure is working correctly.
    """

    def __init__(self, prediction_path: str = "gold"):
        """Initialize gold predictions provider.

        Args:
            prediction_path: Should be "gold" (ignored, for consistency)
        """
        super().__init__(prediction_path)

    def get_prediction(self, config: SweBenchmarkConfig) -> str:
        """Get gold patch from task configuration.

        Args:
            config: Task configuration containing gold patch

        Returns:
            Gold patch content from config.patch

        Raises:
            ValueError: If config.patch is None or empty
        """
        if not config.patch:
            raise ValueError(
                f"No gold patch available for instance {config.instance_id}. "
                "config.patch is empty or None."
            )

        logger.debug(f"Using gold patch for {config.instance_id}")
        return config.patch


class JsonPredictionsProvider(PredictionsProvider):
    """Predictions provider that loads patches from a JSON file.

    Expected JSON format:
    [
        {
            "instance_id": "task_id_1",
            "model_patch": "diff --git a/file.txt...",
            ...
        },
        ...
    ]

    Or as a dictionary:
    {
        "task_id_1": "diff --git a/file.txt...",
        "task_id_2": "diff --git a/file.txt...",
        ...
    }
    """

    def __init__(self, prediction_path: str):
        """Initialize JSON predictions provider.

        Loads predictions from a JSON file (local path or URL).
        The file is copied/downloaded to a local cache if needed.

        Args:
            prediction_path: Path to JSON file (local or URL)

        Raises:
            FileNotFoundError: If file not found
            ValueError: If JSON format is invalid
        """
        super().__init__(prediction_path)
        self._predictions = None
        self._load_predictions()

    def _load_predictions(self) -> None:
        """Load predictions from JSON file.

        Raises:
            FileNotFoundError: If file not found
            ValueError: If JSON format is invalid
        """
        path = Path(self.prediction_path)

        # Handle URL
        if self.prediction_path.startswith(('http://', 'https://')):
            logger.info(f"Downloading predictions from {self.prediction_path}")
            # Download to temporary location
            temp_path = Path.home() / ".cache" / "ee-bench" / "predictions" / path.name
            temp_path.parent.mkdir(parents=True, exist_ok=True)
            download_file(self.prediction_path, str(temp_path))
            path = temp_path
        elif not path.exists():
            raise FileNotFoundError(f"Predictions file not found: {self.prediction_path}")

        logger.info(f"Loading predictions from {path}")

        # Load JSON
        try:
            data = read_json_file(str(path))
        except Exception as e:
            raise ValueError(f"Failed to load predictions JSON: {e}")

        # Parse predictions format
        self._predictions = self._parse_predictions(data)

        logger.info(f"Loaded {len(self._predictions)} predictions")

    def _parse_predictions(self, data) -> dict:
        """Parse predictions from various JSON formats.

        Args:
            data: Loaded JSON data (list or dict)

        Returns:
            Dictionary mapping instance_id to patch content

        Raises:
            ValueError: If format is not recognized
        """
        predictions = {}

        # Format 1: List of dicts with instance_id and model_patch
        if isinstance(data, list):
            for item in data:
                if not isinstance(item, dict):
                    raise ValueError(f"Expected dict in predictions list, got {type(item)}")

                if "instance_id" not in item:
                    raise ValueError("Predictions list items must have 'instance_id' field")

                instance_id = item["instance_id"]

                # Try different field names for patch content
                patch = item.get("model_patch") or item.get("patch") or item.get("model_name_or_path")

                if not patch:
                    logger.warning(f"No patch found for {instance_id}, skipping")
                    continue

                predictions[instance_id] = patch

        # Format 2: Dict mapping instance_id to patch
        elif isinstance(data, dict):
            predictions = data

        else:
            raise ValueError(f"Unsupported predictions format: {type(data)}")

        if not predictions:
            raise ValueError("No predictions found in file")

        return predictions

    def get_prediction(self, config: SweBenchmarkConfig) -> str:
        """Get prediction patch for a task.

        Args:
            config: Task configuration containing instance_id

        Returns:
            Patch content as string

        Raises:
            KeyError: If no prediction found for instance_id
        """
        instance_id = config.instance_id

        if instance_id not in self._predictions:
            raise KeyError(
                f"No prediction found for instance {instance_id}. "
                f"Available predictions: {len(self._predictions)} tasks."
            )

        patch = self._predictions[instance_id]
        logger.debug(f"Retrieved prediction for {instance_id} ({len(patch)} chars)")

        return patch
